const mongoose = require('mongoose');
const TestSeriesSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, default: '' },
  examType: { type: String, default: 'NEET UG', enum: ['NEET', 'NEET UG', 'NEET PG', 'JEE', 'JEE Main', 'JEE Advanced', 'CUET', 'CUET UG', 'CUET PG', 'SSC CGL', 'SSC CHSL', 'UPSC CSE', 'NDA', 'CDS', 'CAT', 'CLAT', 'GATE', 'IIT JAM', 'CSIR NET', 'UGC NET', 'Railway (RRB)', 'Banking (IBPS / SBI)', 'State PSC', 'Nursing Entrance', 'Paramedical Entrance', 'Defence Exams', 'Class 11', 'Class 12', 'Foundation', 'Crash Course', 'Other', 'Other (Custom)'] },
  category: { type: String, default: 'Full Syllabus' },
  price: { type: Number, default: 0 },
  discountPrice: { type: Number, default: 0 },
  discountValidTill: { type: Date },
  isFree: { type: Boolean, default: false },
  thumbnail: { type: String, default: '' },
  totalTests: { type: Number, default: 0 },
  enrolledCount: { type: Number, default: 0 },
  language: { type: String, default: 'Hindi + English' },
  difficulty: { type: String, default: 'Medium', enum: ['Easy', 'Medium', 'Hard', 'Mixed'] },
  seriesType: { type: String, default: 'Recorded', enum: ['Live', 'Recorded', 'Both'] },
  isSpotlight: { type: Boolean, default: false },
  isBundle: { type: Boolean, default: false },
  bundleItems: [{ type: String }],
  validity: { type: Number, default: 365 },
  tags: [{ type: String }],
  status: { type: String, default: 'active', enum: ['active', 'inactive', 'draft'] },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  rating: { type: Number, default: 4.5 },
  ratingCount: { type: Number, default: 0 },
  syllabus: { type: String },
  subject: { type: String, default: 'All Subjects' },
  students: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  notes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'BatchNote' }],

  // ── FPR2 Ultra SaaS fields ──
  seriesCode: { type: String, unique: true, sparse: true },
  lifecycleStatus: { type: String, default: 'active', enum: ['draft', 'active', 'upcoming', 'paused', 'archived'] },
  visibility: { type: String, default: 'public', enum: ['public', 'private', 'invite_only'] },
  seatLimit: { type: Number, default: 0 },
  enrollmentRule: { type: String, default: 'open', enum: ['open', 'invite_only', 'manual_approval', 'auto_approval'] },
  accessPolicy: { type: String, default: 'open', enum: ['invite_only', 'open', 'manual_approval', 'code_based'] },
  joinCode: { type: String, default: '' },
  teacherAssigned: { type: String, default: '' },
  colorIcon: { type: String, default: '📚' },
  startDate: { type: Date },
  endDate: { type: Date },
  autoArchiveAfterEnd: { type: Boolean, default: false },
  priceLocked: { type: Boolean, default: false },
  settingsLocked: { type: Boolean, default: false },
  priceHistory: [{ oldPrice: Number, newPrice: Number, field: String, updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, updatedByName: String, updatedAt: { type: Date, default: Date.now } }],
  controlSnapshot: { appliedBy: String, appliedAt: Date, state: mongoose.Schema.Types.Mixed },
  healthScoreCache: { type: Number, default: 0 },
  isTemplate: { type: Boolean, default: false },
  clonedFrom: { type: mongoose.Schema.Types.ObjectId, ref: 'TestSeries' },
  lastActivityAt: { type: Date, default: Date.now },
  archivedAt: { type: Date },
  tests: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Exam' }],
  enrollments: [{ student: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, status: { type: String, default: 'active', enum: ['active', 'inactive'] }, joinedAt: { type: Date, default: Date.now } }],
  renameHistory: [{ oldName: String, newName: String, changedBy: String, changedAt: { type: Date, default: Date.now } }],

  // ── Publish Center (Go-Live Control Center) ──
  isPublished:{type:Boolean,default:false},
  publishState:{type:String,default:'draft',enum:['draft','ready','scheduled','published','unpublished','republish_pending','blocked']},
  publishVersion:{type:Number,default:0},
  lastPublishedAt:{type:Date,default:null},
  lastPublishedBy:{type:String,default:''},
  scheduledPublishAt:{type:Date,default:null},
  scheduledPublishTimezone:{type:String,default:'Asia/Kolkata'},
  scheduledAutoActivate:{type:Boolean,default:true},
  scheduledAutoUnpublishAt:{type:Date,default:null},
  draftChangesPending:{type:Boolean,default:false},
  publishIgnoredIssues:[{type:String}],
  publishSnapshots:[{
    version:Number,
    publishedAt:{type:Date,default:Date.now},
    publishedBy:String,
    status:String,
    action:String,
    notes:String,
    reason:String,
    visibilityMode:String,
    snapshotData:mongoose.Schema.Types.Mixed
  }],


}, { timestamps: true });
// ── Publish Center v2: Edit Lock + Draft-Changes-Pending (auto, via pre-save hook) ──
const PUBLISH_CRITICAL_FIELDS = ['examType', 'price', 'discountPrice', 'startDate', 'endDate', 'validity'];
const PUBLISH_WATCHED_FIELDS = ['name', 'description', 'examType', 'category', 'price', 'discountPrice', 'thumbnail', 'colorIcon',
  'startDate', 'endDate', 'validity', 'seatLimit', 'enrollmentRule', 'accessPolicy', 'visibility', 'teacherAssigned',
  'isSpotlight', 'isBundle', 'allowFreeTrial'];
TestSeriesSchema.pre('save', function () {
  const locked = (this.isPublished || this.publishState === 'scheduled') && !(this.$locals && this.$locals.allowCriticalEdit);
  if (locked) {
    const lockedField = PUBLISH_CRITICAL_FIELDS.find(f => this.isModified(f));
    if (lockedField) throw new Error('EDIT_LOCKED: Cannot change "' + lockedField + '" while Batch is Published/Scheduled. Unpublish it or use Publish Center to make critical changes.');
  }
  if (this.isPublished && !this.isNew && !this.isModified('draftChangesPending') && !this.isModified('publishState')) {
    if (PUBLISH_WATCHED_FIELDS.some(f => this.isModified(f))) {
      this.draftChangesPending = true;
      if (this.publishState === 'published') this.publishState = 'republish_pending';
    }
  }
});



module.exports = mongoose.models.TestSeries || mongoose.model('TestSeries', TestSeriesSchema);
