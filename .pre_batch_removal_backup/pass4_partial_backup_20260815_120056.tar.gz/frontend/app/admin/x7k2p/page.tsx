'use client'
import TestSeriesManagerUltra from './TestSeriesManagerUltra'
import CreateExamWizard from './CreateExamWizard'
import QBankStatsDashboard from './QBankStatsDashboard'
import PreviewAllQuestions from './PreviewAllQuestions'
import ExamTemplates from './ExamTemplates'
import AllExams from './AllExams'
import { DeleteBtn, DeleteConfirmModal, RecycleBinModal, ArchivedModal, UndoToast, useDeleteQuestion } from './DeleteQuestionSystem'
import ContentForge from './ContentForge';
import AIExplainTab from './AIExplainTab';
import SmartPaperGen from './SmartPaperGen';
import StoreAdminTab from './StoreAdminTab';
import AdminWelcomeBanner from './AdminWelcomeBanner';
import AdminPYQBankTab from './AdminPYQBankTab';
import AdminProfilePage from './AdminProfilePage';
import Student360Preview from './Student360Preview'; // F38B
import AdminAnnouncements from './AdminAnnouncements'; // F42A
import EntryProctoringControlCenter from './EntryProctoringControlCenter'; // F53-57-B
import { useState, useEffect, useRef, useCallback, memo } from 'react'
import katex from 'katex'

function formatQText(text) {
  if (!text) return text;
  var t = text;

  // ── Match Column: look for "Column I:" and "Column II:" headers ──
  if (/Column\s*I/i.test(t)) {
    try {
      // Normalize: add colon after Column I/II headers if missing
      // Skip intro sentence - only match Column I/II when followed by newline or colon
      var normalized = t
        .replace(/Column\s*II\s*(?=[\n\r])/gi, 'Column II:')
        .replace(/Column\s*I(?!I)\s*(?=[\n\r])/gi, 'Column I:');
      // Split on "Column I:" and "Column II:"
      var col1Split = normalized.split(/Column\s*I(?!I)\s*:/i);
      if (col1Split.length >= 2) {
        var intro = col1Split[0].trim();
        var afterCol1 = col1Split[1] || '';
        var col2Split = afterCol1.split(/Column\s*II\s*:/i);
        var col1raw = col2Split[0].trim();
        var afterCol2 = col2Split[1] || '';
        // outro = "Which of the following..."
        var outroMatch = afterCol2.match(/(Which of the following.*)/is);
        var col2raw = outroMatch ? afterCol2.slice(0, afterCol2.indexOf(outroMatch[1])).trim() : afterCol2.trim();
        var outro = outroMatch ? outroMatch[1].trim() : '';

        // Parse items: split on A. B. C. / P. Q. R. S.
        // Split on A. B. C. D. or A) B) C) D) — only at word boundary with space after
        var c1items = col1raw.split(/(?:^|\s)(?=[A-D][.)][\s])/g).map(function(x){return x.replace(/,\s*$/,'').trim();}).filter(function(x){return x.length>1;});
        var c2items = col2raw.split(/(?:^|\s)(?=[P-S][.)][\s])/g).map(function(x){return x.replace(/,\s*$/,'').trim();}).filter(function(x){return x.length>1;});
        // Fallback: original dot-only split
        if(c1items.length <= 1) c1items = col1raw.split(/(?=[A-D]\.\s)/g).map(function(x){return x.replace(/,\s*$/,'').trim();}).filter(Boolean);
        if(c2items.length <= 1) c2items = col2raw.split(/(?=[P-S]\.\s)/g).map(function(x){return x.replace(/,\s*$/,'').trim();}).filter(Boolean);

        var rows = '';
        var max = Math.max(c1items.length, c2items.length);
        for(var i=0;i<max;i++){
          rows += '<tr>'
            +'<td style="padding:4px 8px;border:1px solid rgba(255,255,255,0.15);color:#e2e8f0;font-size:13px">'+(c1items[i]||'')+'</td>'
            +'<td style="padding:4px 8px;border:1px solid rgba(255,255,255,0.15);color:#e2e8f0;font-size:13px">'+(c2items[i]||'')+'</td>'
            +'</tr>';
        }

        return (intro?'<div style="margin-bottom:8px;color:#e2e8f0">'+intro+'</div>':'')
          +'<table style="width:100%;border-collapse:collapse;margin:6px 0">'
          +'<thead><tr>'
          +'<th style="padding:5px 8px;background:rgba(251,191,36,0.2);border:1px solid rgba(255,255,255,0.2);color:#fbbf24;text-align:left;font-size:13px">Column I</th>'
          +'<th style="padding:5px 8px;background:rgba(251,191,36,0.2);border:1px solid rgba(255,255,255,0.2);color:#fbbf24;text-align:left;font-size:13px">Column II</th>'
          +'</tr></thead><tbody>'+rows+'</tbody></table>'
          +(outro?'<div style="margin-top:8px;color:#e2e8f0">'+outro+'</div>':'');
      }
    
    // ── Inline format fallback: "Column I (A) text, (B) text... Column II (P) text..." ──
    if(!/<table/.test(t)) {
      try {
        var inlineColMatch = t.match(/^(.*?)\bColumn\s*I(?!I)\b(.+?)\bColumn\s*II\b(.+?)(?=(Correct matching|Which of the following|$))/is);
        if(inlineColMatch) {
          var iIntro = inlineColMatch[1].trim();
          var iCol1raw = inlineColMatch[2].trim();
          var iCol2raw = inlineColMatch[3].trim();
          var iOutro = inlineColMatch[4]||'';
          // Parse "(A) text" or "A. text" or "A) text" format items
          function parseInlineCol(str) {
            var items=[];
            // Try (A) format
            var re1=/\(([A-S])\)\s*(.*?)(?=\s*\([A-S]\)|\s*[A-S][.)][\s]|$)/gs;
            var m;
            while((m=re1.exec(str))!==null){
              var txt=m[2].replace(/,\s*$/,'').trim();
              if(txt) items.push(m[1]+'. '+txt);
            }
            if(items.length>0) return items;
            // Try "A. text" or "A) text" format
            var re2=str.split(/(?<![a-z])(?=[A-S][.)][\s])/g);
            return re2.map(function(x){return x.replace(/,\s*$/,'').trim();}).filter(function(x){return x.length>2;});
          }
          var ic1=parseInlineCol(iCol1raw);
          var ic2=parseInlineCol(iCol2raw);
          if(ic1.length>0&&ic2.length>0){
            var iRows='';
            var iMax=Math.max(ic1.length,ic2.length);
            for(var ii=0;ii<iMax;ii++){
              iRows+='<tr>'
                +'<td style="padding:4px 8px;border:1px solid rgba(255,255,255,0.15);color:#e2e8f0;font-size:13px">'+(ic1[ii]||'')+'</td>'
                +'<td style="padding:4px 8px;border:1px solid rgba(255,255,255,0.15);color:#e2e8f0;font-size:13px">'+(ic2[ii]||'')+'</td>'
                +'</tr>';
            }
            t=(iIntro?'<div style="margin-bottom:8px;color:#e2e8f0">'+iIntro+'</div>':'')
              +'<table style="width:100%;border-collapse:collapse;margin:6px 0">'
              +'<thead><tr>'
              +'<th style="padding:5px 8px;background:rgba(251,191,36,0.2);border:1px solid rgba(255,255,255,0.2);color:#fbbf24;text-align:left;font-size:13px">Column I</th>'
              +'<th style="padding:5px 8px;background:rgba(251,191,36,0.2);border:1px solid rgba(255,255,255,0.2);color:#fbbf24;text-align:left;font-size:13px">Column II</th>'
              +'</tr></thead><tbody>'+iRows+'</tbody></table>'
              +(iOutro?'<div style="margin-top:8px;color:#e2e8f0">'+iOutro+'</div>':'');
          }
        }
      } catch(ie){ console.log('inline table err',ie); }
    }

  } catch(e) { console.log('table err',e); }
  }

  // ── Assertion / Reason ──
  var nl = String.fromCharCode(10);
  // Handle all newline variants including escaped \n from AI
  t = t.split('\\n').join('<br>');
  t = t.split('\n').join('<br>');
  t = t.split(nl).join('<br>');

  // Auto-convert math notation
  var supMap = {'0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹','-':'⁻','+':'⁺'};
  // Convert 10^-11 style → 10⁻¹¹
  t = t.replace(/\^(-?\d+)/g, function(m, exp) {
    return exp.split('').map(function(c){ return supMap[c]||c; }).join('');
  });
  // Convert m^2 kg^2 style (letter^number)
  t = t.replace(/([a-zA-Z])\^(\d+)/g, function(m, base, exp) {
    return base + exp.split('').map(function(c){ return supMap[c]||c; }).join('');
  });
  // * to × (multiplication) but not in CSS/HTML
  t = t.replace(/(\d)\s*\*\s*(\d)/g, '$1 × $2');
  t = t.replace(/Assertion\s*\(A\)\s*:/gi, '<br><b style="color:#7dd3fc">Assertion (A):</b>');
  t = t.replace(/Reason\s*\(R\)\s*:/gi,    '<br><b style="color:#86efac">Reason (R):</b>');
  t = t.replace(/Statement\s*(I{1,3}|\d)\s*:/gi, '<br><b style="color:#c4b5fd">Statement $1:</b>');
  t = t.replace(/(\d+)\.\s/g, '<br>$1. ');
  t = t.replace(/^(<br>\s*)+/i, '');
  return t;
}


function renderLatex(t){if(!t)return '';let h=t.replace(/\$\$([^$]+)\$\$/g,function(_,m){try{return katex.renderToString(m,{displayMode:true,throwOnError:false})}catch(e){return m}});h=h.replace(/\$([^$\n]+)\$/g,function(_,m){try{return katex.renderToString(m,{displayMode:false,throwOnError:false})}catch(e){return m}});return h;}
import { useRouter } from 'next/navigation'
import { getToken, getRole, clearAuth } from '@/lib/auth'

// ── API Base ──
const API = process.env.NEXT_PUBLIC_API_URL || 'https://proverank.onrender.com'

// ── TypeScript Interfaces ──
interface Student { _id:string;name:string;email:string;phone?:string;role:string;createdAt:string;banned?:boolean;banReason?:string;group?:string;integrityScore?:number;loginHistory?:any[];parentEmail?:string;deleted?:boolean;deletedAt?:string;deleteReason?:string;city?:string;school?:string;dob?:string;targetExam?:string;qualifications?:string;_snapshot?:any }
interface Exam { _id:string;title:string;scheduledAt:string;totalMarks:number;duration:number;status:string;attempts?:number;category?:string;password?:string;subject?:string }
interface Question { _id:string;text:string;subject:string;chapter?:string;topic?:string;difficulty:string;type:string;options?:string[];correctAnswer?:string;explanation?:string;approvalStatus?:string;image?:string;optionImages?:string[] }
interface Log { _id:string;action:string;by:string;at:string;detail:string }
interface Flag { _id:string;studentName:string;examTitle:string;type:string;count:number;severity:string;at:string;integrityScore?:number }
interface Ticket { _id:string;studentName:string;examTitle:string;type:string;status:string;createdAt:string;description:string }
interface Feature { key:string;label:string;description:string;enabled:boolean }
interface Notif { id:string;icon:string;msg:string;t:string;read:boolean }
interface Snapshot { _id:string;studentName:string;imageUrl?:string;flagged:boolean;capturedAt:string;examTitle?:string }
interface Batch { _id:string;name:string;studentCount:number;examCount:number;createdAt:string }
interface AdminUser { _id:string;name:string;email:string;role:string;createdAt:string;active:boolean;frozen?:boolean;archived?:boolean;archivedAt?:string;archivedBy?:string;permissions?:any }
interface Result { _id:string;studentName:string;examTitle:string;score:number;totalMarks:number;rank:number;percentile:number;submittedAt:string }

// ── Default Feature Flags ──
const DEF_FEATURES: Feature[] = [
  {key:'webcam',label:'Webcam Proctoring',description:'Camera compulsory during exams (Phase 5.2)',enabled:true},
  {key:'audio',label:'Audio Monitoring',description:'Microphone noise detection (S57)',enabled:false},
  {key:'eye_tracking',label:'Eye Tracking AI',description:'Detect looking away from screen (S-ET)',enabled:true},
  {key:'face_detect',label:'Face Detection TF.js',description:'Multi/no-face detection (Phase 5.4)',enabled:true},
  {key:'head_pose',label:'Head Pose Detection',description:'Head angle tracking (S73)',enabled:true},
  {key:'vbg_block',label:'Virtual Background Block',description:'Detect and block fake backgrounds (S74)',enabled:true},
  {key:'vpn_block',label:'VPN/Proxy Block',description:'Block VPN users from attempting (S20)',enabled:false},
  {key:'live_rank',label:'Live Rank Updates',description:'Socket.io real-time ranking (S107)',enabled:true},
  {key:'social_share',label:'Social Share Results',description:'WhatsApp/Instagram result card (S99)',enabled:true},
  {key:'pyq_bank',label:'PYQ Bank Access',description:'NEET 2015-2024 questions (S104)',enabled:true},
  {key:'maintenance',label:'Maintenance Mode',description:'Block students, keep admin accessible (S66)',enabled:false},
  {key:'sms_notify',label:'SMS Notifications',description:'Result SMS via Twilio/Fast2SMS (M19)',enabled:false},
  {key:'whatsapp',label:'WhatsApp Alerts',description:'Exam reminders via WhatsApp (S65)',enabled:false},
  {key:'ai_tagger',label:'AI Auto-Tagger',description:'Auto difficulty + subject tagging (AI-1/AI-2)',enabled:true},
  {key:'ai_explain',label:'AI Explanation Generator',description:'Auto explanation from question (AI-10)',enabled:true},
  {key:'two_fa',label:'2FA Admin Login',description:'OTP mandatory for admin accounts (S49)',enabled:true},
  {key:'ip_lock',label:'IP Lock During Exam',description:'Block IP change mid-exam (S20)',enabled:true},
  {key:'fullscreen',label:'Fullscreen Force Mode',description:'3 exits triggers auto-submit (S32)',enabled:true},
  {key:'watermark',label:'Screen Watermark',description:'Student name/ID watermark on screen (S76)',enabled:true},
  {key:'integrity',label:'AI Integrity Score',description:'0-100 score per exam attempt (AI-6)',enabled:true},
  {key:'n14_pattern',label:'Suspicious Pattern Detection',description:'Fast/identical answer flagging (N14)',enabled:true},
  {key:'onboarding',label:'Platform Onboarding Tour',description:'Guided tour for new students (S100)',enabled:true},
  {key:'n23_encrypt',label:'Paper Encryption',description:'Questions encrypted in browser (N23)',enabled:false},
  {key:'waiting_room',label:'Exam Waiting Room',description:'Students join 10 min before exam (M6)',enabled:true},
  {key:'cert_gen',label:'Certificate Generation',description:'Auto PDF certificate on completion (S21)',enabled:true},
]

// ══════════════════════════════════════════════════════════════
// MOBILE KEYBOARD FIX — memo components hold own state
// Parent re-renders do NOT cause these to re-render
// ══════════════════════════════════════════════════════════════
const SInput = memo(function SInput({init='',onSet,style,ph,type='text',disabled=false}:{init?:string;onSet:(v:string)=>void;style?:any;ph?:string;type?:string;disabled?:boolean}) {
  const [v,setV]=useState(init)
  useEffect(()=>{setV(init);onSet(init)},[init])
  return <input type={type} value={v} disabled={disabled} placeholder={ph} style={style} onChange={e=>{const x=e.target.value;setV(x);onSet(x)}} />
})
const STextarea = memo(function STextarea({init='',onSet,style,ph,rows=4}:{init?:string;onSet:(v:string)=>void;style?:any;ph?:string;rows?:number}) {
  const [v,setV]=useState(init)
  useEffect(()=>{setV(init);onSet(init)},[init])
  return <textarea value={v} rows={rows} placeholder={ph} style={style} onChange={e=>{const x=e.target.value;setV(x);onSet(x)}} />
})
const SSelect = memo(function SSelect({val,onChange,opts,style}:{val:string;onChange:(v:string)=>void;opts:{v:string;l:string}[];style?:any}) {
  return <select value={val} onChange={e=>onChange(e.target.value)} style={style}>{opts.map(o=><option key={o.v} value={o.v}>{o.l}</option>)}</select>
})

// ══════════════════════════════════════════════════════════════
// PR LOGO — Exact same as Login page (PR4 Hexagon)
// ══════════════════════════════════════════════════════════════
function PRLogo({size=36}:{size?:number}) {
  const blockSize = size * 0.94
  const pSize = Math.round(blockSize * 0.63)
  const rSize = Math.round(blockSize * 0.63)
  const fontSize = Math.round(pSize * 0.52)
  const radius = Math.round(pSize * 0.28)
  return (
    <div className="pr-logo-glowpulse" style={{position:'relative',width:blockSize,height:blockSize,flexShrink:0,display:'inline-flex'}}>
      <style>{`
        @keyframes prLogoGlowPulse{
          0%,100%{filter:drop-shadow(0 0 4px rgba(77,159,255,0.35)) drop-shadow(0 0 2px rgba(0,212,255,0.2))}
          50%{filter:drop-shadow(0 0 16px rgba(77,159,255,0.85)) drop-shadow(0 0 8px rgba(0,212,255,0.55))}
        }
        .pr-logo-glowpulse{animation:prLogoGlowPulse 2.6s ease-in-out infinite}
        @media (prefers-reduced-motion: reduce){.pr-logo-glowpulse{animation:none}}
      `}</style>
      <div style={{
        position:'absolute',top:0,left:0,
        width:pSize,height:pSize,
        borderRadius:radius,
        background:'linear-gradient(135deg,#4D9FFF,#00D4FF)',
        display:'flex',alignItems:'center',justifyContent:'center',
        fontSize:fontSize,fontWeight:900,fontFamily:'Inter,sans-serif',
        color:'#030810',
        boxShadow:'0 4px 16px rgba(77,159,255,0.4)'
      }}>P</div>
      <div style={{
        position:'absolute',bottom:0,right:0,
        width:rSize,height:rSize,
        borderRadius:radius,
        background:'rgba(0,212,255,0.1)',
        border:'1.5px solid rgba(0,212,255,0.45)',
        display:'flex',alignItems:'center',justifyContent:'center',
        fontSize:fontSize,fontWeight:900,fontFamily:'Inter,sans-serif',
        color:'#00D4FF',
        backdropFilter:'blur(8px)'
      }}>R</div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// PARTICLES BACKGROUND — Same as Login page
// ══════════════════════════════════════════════════════════════
function GalaxyBg() {
  const canvasRef=useRef(null)
  useEffect(()=>{
    const canvas=canvasRef.current;if(!canvas)return
    const ctx=canvas.getContext('2d');if(!ctx)return
    let W=window.innerWidth,H=window.innerHeight
    canvas.width=W;canvas.height=H
    // Stars
    const stars=[]
    for(let i=0;i<280;i++)stars.push({x:Math.random()*W,y:Math.random()*H,r:Math.random()*1.2+0.2,op:Math.random(),spd:0.003+Math.random()*0.007})
    // Particles
    const pts=[]
    for(let i=0;i<55;i++)pts.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.4,vy:(Math.random()-.5)*.4,r:Math.random()*1.4+0.4,op:Math.random()*.35+.12})
    // Nebula defs
    const nebs=[
      {fx:0.12,fy:0.22,fr:0.22,c:'rgba(77,159,255,0.18)'},
      {fx:0.82,fy:0.55,fr:0.26,c:'rgba(110,70,255,0.15)'},
      {fx:0.48,fy:0.88,fr:0.20,c:'rgba(0,212,255,0.14)'},
      {fx:0.28,fy:0.68,fr:0.17,c:'rgba(255,90,180,0.12)'},
      {fx:0.65,fy:0.15,fr:0.19,c:'rgba(0,230,160,0.11)'},
    ]
    let angle=0
    let animId
    const draw=()=>{
      ctx.clearRect(0,0,W,H)
      // Nebula blobs
      nebs.forEach(function(n){
        const nx=n.fx*W,ny=n.fy*H,nr=n.fr*W
        const g=ctx.createRadialGradient(nx,ny,0,nx,ny,nr)
        g.addColorStop(0,n.c)
        g.addColorStop(1,'rgba(0,0,0,0)')
        ctx.fillStyle=g;ctx.beginPath();ctx.arc(nx,ny,nr,0,Math.PI*2);ctx.fill()
      })
      // Galaxy spiral arms
      const cx=W*0.5,cy=H*0.42
      for(let arm=0;arm<3;arm++){
        for(let t=0;t<90;t++){
          const a=angle+(arm*Math.PI*2/3)+(t*0.11)
          const dist=t*2.8
          const sx=cx+Math.cos(a)*dist,sy=cy+Math.sin(a)*dist*0.42
          if(sx<0||sx>W||sy<0||sy>H)continue
          const op=Math.max(0,(1-t/90)*0.35)
          ctx.beginPath();ctx.arc(sx,sy,0.9,0,Math.PI*2)
          ctx.fillStyle='rgba(120,190,255,'+op+')'
          ctx.fill()
        }
      }
      // Galaxy core
      const cg=ctx.createRadialGradient(cx,cy,0,cx,cy,20)
      cg.addColorStop(0,'rgba(180,220,255,0.55)')
      cg.addColorStop(1,'rgba(0,0,0,0)')
      ctx.fillStyle=cg;ctx.beginPath();ctx.arc(cx,cy,20,0,Math.PI*2);ctx.fill()
      angle+=0.0007
      // Twinkling stars
      stars.forEach(function(s){
        s.op+=s.spd;if(s.op>=1||s.op<=0.02)s.spd*=-1
        ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2)
        ctx.fillStyle='rgba(215,235,255,'+Math.min(s.op*1.0,0.95)+')'
        ctx.fill()
      })
      // Particles
      pts.forEach(function(p){
        p.x+=p.vx;p.y+=p.vy
        if(p.x<0)p.x=W;if(p.x>W)p.x=0
        if(p.y<0)p.y=H;if(p.y>H)p.y=0
        ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2)
        ctx.fillStyle='rgba(77,159,255,'+p.op+')'
        ctx.fill()
      })
      // Connection lines
      for(let i=0;i<pts.length;i++)for(let j=i+1;j<pts.length;j++){
        const dx=pts[i].x-pts[j].x,dy=pts[i].y-pts[j].y,d=Math.sqrt(dx*dx+dy*dy)
        if(d<115){
          ctx.beginPath();ctx.moveTo(pts[i].x,pts[i].y);ctx.lineTo(pts[j].x,pts[j].y)
          ctx.strokeStyle='rgba(77,159,255,'+0.12*(1-d/115)+')'
          ctx.lineWidth=.5;ctx.stroke()
        }
      }
      animId=requestAnimationFrame(draw)
    }
    draw()
    const resize=function(){W=canvas.width=window.innerWidth;H=canvas.height=window.innerHeight}
    window.addEventListener('resize',resize)
    return function(){cancelAnimationFrame(animId);window.removeEventListener('resize',resize)}
  },[])
  return <canvas ref={canvasRef} style={{position:'fixed',inset:0,pointerEvents:'none',zIndex:0}}/>
}

// ══════════════════════════════════════════════════════════════
// GLOBAL SEARCH COMPONENT (M12) — Premium Rewrite

const NAV_TABS=[
  {label:'Dashboard',tab:'dashboard',icon:'📊'},{label:'Live Monitor',tab:'live_monitor',icon:'🔴'},
  {label:'All Exams',tab:'exams',icon:'📋'},{label:'Create Exam',tab:'create_exam',icon:'➕'},
  {label:'Question Bank',tab:'questions',icon:'📚'},{label:'Smart Generator',tab:'smart_gen',icon:'🤖'},
  {label:'PYQ Bank',tab:'pyq',icon:'📜'},{label:'Bulk Upload',tab:'bulk_upload',icon:'📤'},
  {label:'All Students',tab:'students',icon:'👥'},{label:'Test Series Management',tab:'test_series',icon:'📚'},
  {label:'Anti-Cheat',tab:'anticheat',icon:'🛡️'},
  {label:'Grievances',tab:'grievances',icon:'⚖️'},{label:'Announcements',tab:'announcements',icon:'📢'},
  {label:'Email Templates',tab:'email_tmpl',icon:'📧'},{label:'Feature Flags',tab:'feature_flags',icon:'🚩'},
  {label:'Branding',tab:'branding',icon:'🎨'},{label:'SEO Settings',tab:'seo',icon:'🔍'},
  {label:'Maintenance',tab:'maintenance',icon:'🔧'},{label:'Backup',tab:'backup',icon:'💾'},
  {label:'Audit Logs',tab:'audit',icon:'🔏'},{label:'Permissions',tab:'permissions',icon:'🔐'},
  {label:'Multi-Admin',tab:'admins',icon:'👤'},
  {label:'Transparency',tab:'transparency',icon:'👁️'},{label:'OMR View',tab:'omr_view',icon:'📄'},
  {label:'Global Search',tab:'global_search',icon:'🔎'}
]

const GlobalSearch=memo(function GlobalSearch({setTab,token}:{setTab:(t:string)=>void;token:string}){
  const [q,setQ]=useState('')
  const [results,setResults]=useState<any>(null)
  const [loading,setLoading]=useState(false)
  const [activeSection,setActiveSection]=useState('all')
  const debRef=useRef<any>(null)

  const sections=[
    {key:'all',label:'All',icon:'🔎'},
    {key:'navigation',label:'Tabs',icon:'🗂️'},
    {key:'students',label:'Students',icon:'👥'},
    {key:'admins',label:'Admins',icon:'👤'},
    {key:'exams',label:'Exams',icon:'📋'},
    {key:'questions',label:'Questions',icon:'📚'},
  ]

  useEffect(()=>{
    if(debRef.current) clearTimeout(debRef.current)
    if(!q||q.length<2){setResults(null);return}
    debRef.current=setTimeout(async()=>{
      setLoading(true)

  // Top students — standalone (has own state handler)
  const tk2=getToken();if(tk2){fetch(`${API}/api/admin/notifications/top-students?limit=10`,{headers:{Authorization:`Bearer ${tk2}`}}).then(r=>r.ok?r.json():null).then(d=>{if(d&&d.success&&d.topStudents)setTopStudents(d.topStudents);}).catch(()=>{});}

      try{
        const r=await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/admin/global-search?q=${encodeURIComponent(q)}`,{headers:{Authorization:`Bearer ${token}`}})
        const d=await r.json()
        if(d.success) setResults(d.results)
      }catch(e){}finally{setLoading(false)}
    },350)
  },[q])

  const navResults=NAV_TABS.filter(t=>t.label.toLowerCase().includes(q.toLowerCase()))
  const totalCount=(results?((results.students?.length||0)+(results.admins?.length||0)+(results.exams?.length||0)+(results.questions?.length||0)):0)+navResults.length

  const S:any={
    wrap:{position:'relative',width:'100%',maxWidth:720,margin:'0 auto'},
    input:{width:'100%',padding:'14px 20px 14px 48px',background:'rgba(0,28,52,0.85)',border:'1.5px solid rgba(77,159,255,0.35)',borderRadius:14,color:'#E8F4FF',fontSize:15,fontFamily:'Inter,sans-serif',outline:'none',boxSizing:'border-box',backdropFilter:'blur(12px)'},
    dropdown:{position:'relative',marginTop:8,background:'rgba(0,20,45,0.97)',border:'1px solid rgba(77,159,255,0.25)',borderRadius:16,boxShadow:'0 20px 60px rgba(0,0,0,0.6)',backdropFilter:'blur(20px)',zIndex:9999,maxHeight:520,overflowY:'auto'},
    tabs:{display:'flex',gap:6,padding:'12px 14px 8px',borderBottom:'1px solid rgba(77,159,255,0.1)',flexWrap:'wrap'},
    secTitle:{fontSize:10,fontWeight:700,color:'#4D9FFF',letterSpacing:1.5,textTransform:'uppercase',margin:'10px 14px 4px',display:'flex',alignItems:'center',gap:6},
    item:{display:'flex',alignItems:'center',gap:10,padding:'8px 14px',cursor:'pointer',transition:'background 0.15s'},
    label:{fontSize:13,color:'#E8F4FF',fontWeight:500,flex:1},
    sub:{fontSize:11,color:'#6B8BAF'},
    chip:(bg:string,col:string)=>({fontSize:10,padding:'2px 7px',borderRadius:10,fontWeight:600,background:bg,color:col}),
    divider:{height:1,background:'rgba(77,159,255,0.08)',margin:'4px 14px'},
  }

  const tabBtn=(active:boolean)=>({padding:'4px 12px',borderRadius:20,fontSize:11,fontWeight:600,cursor:'pointer',border:'1px solid '+(active?'#4D9FFF':'rgba(77,159,255,0.2)'),background:active?'rgba(77,159,255,0.2)':'transparent',color:active?'#4D9FFF':'#6B8BAF'})

  const show=(key:string)=>activeSection==='all'||activeSection===key

  return(
    <div style={S.wrap}>
      {/* Search Input */}
      <div style={{position:'relative',display:'flex',alignItems:'center',marginBottom:32}}>
        <span style={{position:'absolute',left:16,fontSize:20,color:'#4D9FFF',zIndex:1}}>🔎</span>
        <input style={S.input} value={q} onChange={e=>setQ(e.target.value)} placeholder="Search tabs, students, exams, questions, admins..."/>
        {q.length>=2&&<span style={{position:'absolute',right:16,background:'rgba(77,159,255,0.2)',border:'1px solid rgba(77,159,255,0.3)',borderRadius:20,padding:'2px 10px',fontSize:11,color:'#4D9FFF',fontWeight:700}}>{loading?'…':totalCount+' results'}</span>}
      </div>

      {/* Empty State — Rich Content */}
      {q.length<2&&(
        <div>
          {/* Stats Row */}
          <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(140px,1fr))',gap:12,marginBottom:28}}>
            {[{icon:'👥',label:'Students',color:'#00C864'},{icon:'📋',label:'Exams',color:'#4D9FFF'},{icon:'📚',label:'Questions',color:'#964DFF'},{icon:'👤',label:'Admins',color:'#FFA500'},{icon:'🗂️',label:'Tabs',color:'#E8F4FF'}].map((s,i)=>(
              <div key={i} style={{background:'rgba(0,28,52,0.7)',border:'1px solid rgba(77,159,255,0.15)',borderRadius:12,padding:'16px 12px',textAlign:'center',cursor:'pointer'}} onClick={()=>setActiveSection(s.label.toLowerCase())}>
                <div style={{fontSize:28,marginBottom:6}}>{s.icon}</div>
                <div style={{fontSize:12,color:s.color,fontWeight:600}}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* SVG Illustration + Info */}
          <div style={{background:'rgba(0,28,52,0.6)',border:'1px solid rgba(77,159,255,0.12)',borderRadius:16,padding:24,marginBottom:20,textAlign:'center'}}>
            <svg width="80" height="80" viewBox="0 0 80 80" style={{marginBottom:12,opacity:0.8}}>
              <circle cx="34" cy="34" r="22" fill="none" stroke="#4D9FFF" strokeWidth="3"/>
              <circle cx="34" cy="34" r="14" fill="none" stroke="rgba(77,159,255,0.3)" strokeWidth="1.5"/>
              <line x1="50" y1="50" x2="68" y2="68" stroke="#4D9FFF" strokeWidth="3" strokeLinecap="round"/>
              <circle cx="34" cy="34" r="5" fill="rgba(77,159,255,0.5)"/>
            </svg>
            <div style={{fontSize:16,color:'#E8F4FF',fontWeight:600,marginBottom:8}}>Global Search — M12</div>
            <div style={{fontSize:12,color:'#6B8BAF',lineHeight:1.6}}>Type at least 2 characters to search across<br/>Students · Admins · Exams · Questions · Navigation Tabs</div>
          </div>

          {/* Quick Nav Tiles */}
          <div style={{marginBottom:12}}>
            <div style={{fontSize:11,color:'#4D9FFF',fontWeight:700,letterSpacing:1.2,textTransform:'uppercase',marginBottom:10}}>⚡ Quick Navigation</div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(130px,1fr))',gap:8}}>
              {NAV_TABS.slice(0,12).map((t,i)=>(
                <div key={i} onClick={()=>setTab(t.tab)} style={{background:'rgba(0,28,52,0.6)',border:'1px solid rgba(77,159,255,0.12)',borderRadius:10,padding:'10px 12px',cursor:'pointer',display:'flex',alignItems:'center',gap:8,transition:'all 0.15s'}}
                  onMouseEnter={e=>(e.currentTarget.style.background='rgba(77,159,255,0.1)')}
                  onMouseLeave={e=>(e.currentTarget.style.background='rgba(0,28,52,0.6)')}>
                  <span style={{fontSize:16}}>{t.icon}</span>
                  <span style={{fontSize:11,color:'#E8F4FF',fontWeight:500}}>{t.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Science Fact */}
          <div style={{background:'linear-gradient(135deg,rgba(0,28,52,0.8),rgba(0,50,80,0.6))',border:'1px solid rgba(77,159,255,0.15)',borderRadius:12,padding:'14px 16px',display:'flex',gap:12,alignItems:'flex-start'}}>
            <span style={{fontSize:24}}>🔬</span>
            <div>
              <div style={{fontSize:10,color:'#4D9FFF',fontWeight:700,letterSpacing:1,marginBottom:4}}>SCIENCE FACT</div>
              <div style={{fontSize:12,color:'#B0C8E0',lineHeight:1.5}}>The human brain processes visual information 60,000× faster than text — that&apos;s why ProveRank uses visual dashboards for instant insights.</div>
            </div>
          </div>
        </div>
      )}

      {q.length>=2&&(
        <div style={S.dropdown}>
          <div style={S.tabs}>
            {sections.map(s=><button key={s.key} onClick={()=>setActiveSection(s.key)} style={tabBtn(activeSection===s.key)}>{s.icon} {s.label}</button>)}
          </div>
          {loading&&<div style={{textAlign:'center',padding:'20px',color:'#4D9FFF'}}>⏳ Searching...</div>}
          {!loading&&totalCount===0&&<div style={{textAlign:'center',padding:'28px',color:'#6B8BAF'}}>🔍 No results for "<span style={{color:'#4D9FFF'}}>{q}</span>"</div>}
          {!loading&&totalCount>0&&<div>
            {show('navigation')&&navResults.length>0&&<div>
              <div style={S.secTitle}>🗂️ Navigation / Tabs</div>
              {navResults.slice(0,6).map((t,i)=>(
                <div key={i} style={S.item} onClick={()=>setTab(t.tab)}
                  onMouseEnter={e=>(e.currentTarget.style.background='rgba(77,159,255,0.1)')}
                  onMouseLeave={e=>(e.currentTarget.style.background='transparent')}>
                  <span style={{fontSize:18}}>{t.icon}</span>
                  <span style={S.label}>{t.label}</span>
                  <span style={S.chip('rgba(77,159,255,0.15)','#4D9FFF')}>Tab</span>
                </div>
              ))}
              <div style={S.divider}/>
            </div>}
            {show('students')&&results?.students?.length>0&&<div>
              <div style={S.secTitle}>👥 Students ({results.students.length})</div>
              {results.students.map((s:any,i:number)=>(
                <div key={i} style={S.item} onClick={()=>setTab('students')}
                  onMouseEnter={e=>(e.currentTarget.style.background='rgba(77,159,255,0.1)')}
                  onMouseLeave={e=>(e.currentTarget.style.background='transparent')}>
                  <span style={{fontSize:18}}>👤</span>
                  <div style={{flex:1}}><div style={S.label}>{s.name||'—'}</div><div style={S.sub}>{s.email}{s.studentId?' · '+s.studentId:''}</div></div>
                  <span style={S.chip('rgba(0,200,100,0.15)','#00C864')}>Student</span>
                </div>
              ))}
              <div style={S.divider}/>
            </div>}
            {show('admins')&&results?.admins?.length>0&&<div>
              <div style={S.secTitle}>👤 Admins ({results.admins.length})</div>
              {results.admins.map((a:any,i:number)=>(
                <div key={i} style={S.item} onClick={()=>setTab('admins')}
                  onMouseEnter={e=>(e.currentTarget.style.background='rgba(77,159,255,0.1)')}
                  onMouseLeave={e=>(e.currentTarget.style.background='transparent')}>
                  <span style={{fontSize:18}}>🔑</span>
                  <div style={{flex:1}}><div style={S.label}>{a.name||'—'}</div><div style={S.sub}>{a.email}{a.adminId?' · '+a.adminId:''}</div></div>
                  <span style={S.chip('rgba(255,165,0,0.15)','#FFA500')}>{a.role==='superadmin'?'SuperAdmin':'Admin'}</span>
                </div>
              ))}
              <div style={S.divider}/>
            </div>}
            {show('exams')&&results?.exams?.length>0&&<div>
              <div style={S.secTitle}>📋 Exams ({results.exams.length})</div>
              {results.exams.map((ex:any,i:number)=>(
                <div key={i} style={S.item} onClick={()=>setTab('exams')}
                  onMouseEnter={e=>(e.currentTarget.style.background='rgba(77,159,255,0.1)')}
                  onMouseLeave={e=>(e.currentTarget.style.background='transparent')}>
                  <span style={{fontSize:18}}>📋</span>
                  <div style={{flex:1}}><div style={S.label}>{ex.title}</div><div style={S.sub}>{ex.status}</div></div>
                  <span style={S.chip('rgba(77,159,255,0.15)','#4D9FFF')}>Exam</span>
                </div>
              ))}
              <div style={S.divider}/>
            </div>}
            {show('questions')&&results?.questions?.length>0&&<div>
              <div style={S.secTitle}>📚 Questions ({results.questions.length})</div>
              {results.questions.map((qu:any,i:number)=>(
                <div key={i} style={S.item} onClick={()=>setTab('questions')}
                  onMouseEnter={e=>(e.currentTarget.style.background='rgba(77,159,255,0.1)')}
                  onMouseLeave={e=>(e.currentTarget.style.background='transparent')}>
                  <span style={{fontSize:18}}>❓</span>
                  <div style={{flex:1}}><div style={S.label}>{(qu.text||'').slice(0,65)}{(qu.text||'').length>65?'…':''}</div><div style={S.sub}>{qu.subject}{qu.chapter?' · '+qu.chapter:''}{qu.difficulty?' · '+qu.difficulty:''}</div></div>
                  <span style={S.chip('rgba(150,77,255,0.15)','#964DFF')}>Q</span>
                </div>
              ))}
              <div style={S.divider}/>
            </div>}
          </div>}
        </div>
      )}
    </div>
  )
})

// THEME CONSTANTS — N6 Neon Blue Arctic (from Login page)
// ══════════════════════════════════════════════════════════════
const BG_GRAD='radial-gradient(ellipse at 20% 50%,#001e38 0%,#000f22 60%,#000810 100%)'
const CRD='rgba(0,28,52,0.88)'
const CRD2='rgba(0,36,65,0.92)'
const ACC='#4D9FFF'
const BOR='rgba(77,159,255,0.18)'
const BOR2='rgba(77,159,255,0.3)'
const TS='#E8F4FF'
const DIM='#6B8FAF'
const SUC='#00C48C'
const DNG='#FF4D4D'
const WRN='#FFB84D'
const GOLD='#FFD700'

// Shared style objects
const inp:any={width:'100%',padding:'12px 14px',background:'rgba(0,22,40,0.85)',border:`1.5px solid ${BOR2}`,borderRadius:10,color:TS,fontSize:14,fontFamily:'Inter,sans-serif',outline:'none',boxSizing:'border-box',backdropFilter:'blur(8px)'}
const bp:any={background:`linear-gradient(135deg,${ACC},#0055CC)`,color:'#fff',border:'none',borderRadius:10,padding:'11px 22px',cursor:'pointer',fontWeight:700,fontSize:13,fontFamily:'Inter,sans-serif',boxShadow:`0 4px 16px rgba(77,159,255,0.35)`}
const bg_:any={background:'rgba(77,159,255,0.1)',color:ACC,border:`1px solid ${BOR2}`,borderRadius:10,padding:'9px 18px',cursor:'pointer',fontWeight:600,fontSize:12,fontFamily:'Inter,sans-serif',backdropFilter:'blur(8px)'}
const bd:any={background:'rgba(255,77,77,0.15)',color:DNG,border:'1px solid rgba(255,77,77,0.3)',borderRadius:10,padding:'9px 18px',cursor:'pointer',fontWeight:700,fontSize:12}
const bs:any={background:'rgba(0,196,140,0.12)',color:SUC,border:'1px solid rgba(0,196,140,0.3)',borderRadius:10,padding:'9px 18px',cursor:'pointer',fontWeight:700,fontSize:12}
const cs:any={background:CRD,border:`1px solid ${BOR}`,borderRadius:14,padding:18,marginBottom:14,backdropFilter:'blur(12px)'}
const lbl:any={display:'block',fontSize:11,color:DIM,marginBottom:5,fontFamily:'Inter,sans-serif',fontWeight:600,letterSpacing:0.5,textTransform:'uppercase'}
const pageTitle:any={fontFamily:'Playfair Display,serif',fontSize:22,fontWeight:700,color:TS,margin:'0 0 4px',background:`linear-gradient(90deg,${ACC},#fff)`,WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}
const pageSub:any={fontSize:12,color:DIM,marginBottom:20,fontFamily:'Inter,sans-serif'}

// ══════════════════════════════════════════════════════════════
// STAT BOX COMPONENT
// ══════════════════════════════════════════════════════════════
function StatBox({ico,lbl:label,val,sub,col=ACC}:{ico:string;lbl:string;val:any;sub?:string;col?:string}) {
  return (
    <div style={{background:CRD,border:`1px solid ${BOR}`,borderRadius:14,padding:'16px 12px',width:'100%',backdropFilter:'blur(12px)',position:'relative',overflow:'hidden'}}>
      <div style={{position:'absolute',right:-8,bottom:-8,fontSize:48,opacity:0.06}}>{ico}</div>
      <div style={{fontSize:22,marginBottom:6}}>{ico}</div>
      <div style={{fontSize:22,fontWeight:700,color:col,fontFamily:'Playfair Display,Georgia,serif',lineHeight:1}}>{val}</div>
      <div style={{fontSize:11,color:DIM,marginTop:4,fontWeight:600}}>{label}</div>
      {sub&&<div style={{fontSize:10,color:col,marginTop:2,opacity:0.8}}>{sub}</div>}
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// PAGE HERO — SVG + Title for each empty-state page
// ══════════════════════════════════════════════════════════════
function PageHero({icon,title,subtitle}:{icon:string;title:string;subtitle:string}) {
  return (
    <div style={{textAlign:'center',padding:'32px 20px 24px',background:`linear-gradient(135deg,rgba(0,22,40,0.8),rgba(0,31,58,0.6))`,borderRadius:16,border:`1px solid ${BOR}`,marginBottom:20,backdropFilter:'blur(12px)'}}>
      <div style={{fontSize:48,marginBottom:10}}>{icon}</div>
      <div style={{fontFamily:'Playfair Display,serif',fontSize:20,fontWeight:700,color:TS,marginBottom:6}}>{title}</div>
      <div style={{fontSize:13,color:DIM,maxWidth:400,margin:'0 auto',lineHeight:1.6}}>{subtitle}</div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════
// BADGE COMPONENT
// ══════════════════════════════════════════════════════════════
function Badge({label,col=ACC}:{label:string;col?:string}) {
  return <span style={{fontSize:10,padding:'3px 9px',borderRadius:20,background:`${col}22`,color:col,fontWeight:700,border:`1px solid ${col}44`,display:'inline-block'}}>{label}</span>
}

// ══════════════════════════════════════════════════════════════
// MAIN ADMIN PANEL COMPONENT
// ══════════════════════════════════════════════════════════════






export default function AdminPanel() {
  const router=useRouter()
  useEffect(()=>{},[]);
  const [role,setRole]=useState('')
  const [token,setToken]=useState('')
  const [mounted,setMounted]=useState(false)
  const [tab,setTab]=useState('dashboard')
  const [pendingTemplate,setPendingTemplate]=useState<any>(null) // Feature 29.13 — Apply Template → Wizard Step 1
  const _setTab=(id:string)=>{_setTab_orig(id);}
  const _setTab_orig=(t:string)=>{try{sessionStorage.setItem('pr_admin_tab',t)}catch{};setTab(t)}
  useEffect(()=>{
    const id='pr-nav-desktop-styles';
    if(document.getElementById(id))return;
    const s=document.createElement('style');
    s.id=id;
    s.textContent='@media(min-width:768px){#pr-top-nav{height:68px!important;}#pr-top-nav>div:first-child{gap:20px!important;}#pr-top-nav>div:first-child>button:first-child{width:44px!important;height:44px!important;}#pr-top-nav>div:last-child{gap:14px!important;}#pr-top-nav>div:last-child button{min-width:42px!important;height:42px!important;border-radius:10px!important;}#pr-top-nav .pr-brand-name{font-size:16px!important;}#pr-top-nav .pr-role-tag{font-size:8px!important;letter-spacing:1.2px!important;}#pr-top-nav .pr-brand{position:absolute!important;left:50%!important;top:50%!important;transform:translate(-50%,-50%)!important;z-index:1;}}';
    document.head.appendChild(s);
    return()=>{const el=document.getElementById(id);if(el)el.remove();};
  },[]);
  const [sideOpen,setSideOpen]=useState(false)
  const [toast,setToast]=useState<{msg:string;tp:'s'|'e'|'w'}|null>(null)
  const [notifOpen,setNotifOpen]=useState(false);
  const [notifDetail,setNotifDetail]=useState<any>(null);
const [topStudents,setTopStudents]=useState<{rank:number,name:string,bestScore:number,totalExams:number}[]>([])
  const [loading,setLoading]=useState(true)

  // Data states
  const [students,setStudents]=useState<Student[]>([])
  const [exams,setExams]=useState<Exam[]>([])
  const [questions,setQuestions]=useState<Question[]>([])
  const [flags,setFlags]=useState<Flag[]>([])
  const [logs,setLogs]=useState<Log[]>([])
  const [tickets,setTickets]=useState<Ticket[]>([])
  const [snapshots,setSnapshots]=useState<Snapshot[]>([])
  const [features,setFeatures]=useState<Feature[]>(DEF_FEATURES)
  const [stats,setStats]=useState<any>(null)
  const [batches,setBatches]=useState<Batch[]>([])
  const [testSeries,setTestSeries]=useState<any[]>([])
  const [adminUsers,setAdminUsers]=useState<AdminUser[]>([])
  const [results,setResults]=useState<Result[]>([])
  const [notifs,setNotifs]=useState<Notif[]>([])

  // Search/filter states
  const [stdSearch,setStdSearch]=useState('')
  const [stdFilter,setStdFilter]=useState<'all'|'active'|'banned'|'deleted'>('all')
  const [examSearch,setExamSearch]=useState('')
  const [qSearch,setQSearch]=useState('')
  const [qSubjFilter,setQSubjFilter]=useState('all')
  const [selStudent,setSelStudent]=useState<Student|null>(null)
  const [preview360Id,_setPreview360Id]=useState<string|null>(()=>{try{return sessionStorage.getItem('pr_preview360')||null}catch{return null}}) // F38B — persisted across refresh
  const setPreview360Id=(id:string|null)=>{try{id?sessionStorage.setItem('pr_preview360',id):sessionStorage.removeItem('pr_preview360')}catch{};_setPreview360Id(id)}

  // Exam Create refs (keyboard fix)
  const eTitleR=useRef('');
  const [archivedAdmins,setArchivedAdmins]=useState([] as any[]);
  const [profileAdmin,setProfileAdmin]=useState(null as any);
  const [profileLogs,setProfileLogs]=useState([] as any[]);
  const [showProfileModal,setShowProfileModal]=useState(false);
  const [profileLoading,setProfileLoading]=useState(false);const eDateR=useRef('')
  const eMarksR=useRef('720');const eDurR=useRef('200')
  const eCatR=useRef('Full Mock');const ePassR=useRef('')
  const eInstrR=useRef('')
  const [eStep,setEStep]=useState(1)
  const [createdEId,setCreatedEId]=useState('')
  const [createdETitle,setCreatedETitle]=useState('')
  const [qMeth,setQMeth]=useState<'copypaste'|'excel'|'pdf'|'manual'>('copypaste')
  const cpTxtR=useRef('');const cpKeyR=useRef('')
  const [excelF,setExcelF]=useState<File|null>(null)
  const [pdfF,setPdfF]=useState<File|null>(null)
  const [uploadingQ,setUploadingQ]=useState(false)
  const [creatingE,setCreatingE]=useState(false)
  const [upRes,setUpRes]=useState<{s:number;f:number;msg:string}|null>(null)

  // Question Bank refs
  const qTxtR=useRef('');const qHindiR=useRef('');const qChapR=useRef('');const qTopicR=useRef('');const qExpR=useRef('')
  const qA=useRef('');const qB=useRef('');const qC=useRef('');const qD=useRef('')
  const [qSubj,setQSubj]=useState('')
  const [qDiff,setQDiff]=useState('medium')
  const [qType,setQType]=useState('SCQ')
  const [qAns,setQAns]=useState('')
  const [qHindi,setQHindi]=useState('')
  const [qChap,setQChap]=useState('')
  const [qTopic,setQTopic]=useState('')
  const [qExp,setQExp]=useState('')
  const [qImg,setQImg]=useState('')
  //FIX_STATES_DONE
  const [savingQ,setSavingQ]=useState(false)
  const [qPreview,setQPreview]=useState(false)
const [showAddPreview,setShowAddPreview]=useState(false)
const [dupFound,setDupFound]=useState<any[]>([])
const [aiDupMap,setAiDupMap]=useState<Record<number,any>>({})
const [fmDupMap,setFmDupMap]=useState<Record<number,any>>({})
  const [qBV,setQBV]=useState(()=>{try{return sessionStorage.getItem('pr_qbv')||'home'}catch{return 'home'}})
  // FIX_PREVIEW_AUTOFETCH
  useEffect(()=>{
    if(qBV==='preview'&&token&&questions.length===0){
      fetch(`${API}/api/questions`,{headers:{Authorization:`Bearer ${token}`}})
        .then(r=>r.ok?r.json():null)
        .then(d=>{if(d)setQuestions(Array.isArray(d)?d:(d.questions||d.data||[]))})
        .catch(()=>{})
    }
  },[qBV,token])
  const [formKey,setFormKey]=useState(0)
  const [latexPrev,setLatexPrev]=useState(false)
  const [qTxtVal,setQTxtVal]=useState('')
  const [qTxtInit,setQTxtInit]=useState('')
  const [draftSaved,setDraftSaved]=useState(false)
  const [draftRestored,setDraftRestored]=useState(false)
  const [optInit,setOptInit]=useState({a:'',b:'',c:'',d:''})
  const [optImgsInit,setOptImgsInit]=useState({a:'',b:'',c:'',d:''})
  const [lbImg,setLbImg]=useState<string>('');
  const [draftKey,setDraftKey]=useState(0)
  const [optVals,setOptVals]=useState({a:'',b:'',c:'',d:''})
  const [qSec,setQSec]=useState('all')
  const [qBioSub,setQBioSub]=useState('all')
  const [qChapFilter,setQChapFilter]=useState('all')
  const [aiSelChap,setAiSelChap]=useState('')
  const [bulkSel,setBulkSel]=useState([])
  const longPressTimerRef=useRef(null)
  const longPressFiredRef=useRef(false)
  // ── QsBank Smart Filters (Feature 3) ──
  const [qfOpen,setQfOpen]=useState(false)
  const [qfApproval,setQfApproval]=useState('all')
  const [qfDiff2,setQfDiff2]=useState('all')
  const [qfType,setQfType]=useState('all')
  const [qfUsage,setQfUsage]=useState('all')
  const [qfLevel,setQfLevel]=useState('all')
  const [qfFormat,setQfFormat]=useState('all')
  const [qfDate,setQfDate]=useState('all')
  // ── QsBank -> Exam Integration (Feature 1) ──
  const [showA2E,setShowA2E]=useState(false)
  const [a2eTab,setA2eTab]=useState('existing')
  const [a2eExamId,setA2eExamId]=useState('')
  const [a2eTitle,setA2eTitle]=useState('')
  const [a2eDuration,setA2eDuration]=useState('180')
  const [a2eMarks,setA2eMarks]=useState('720')
  const [a2eExamsList,setA2eExamsList]=useState([])
  const [a2eSaving,setA2eSaving]=useState(false)
  // ── Bulk Edit (Feature 4) ──
  const [showBulkEdit,setShowBulkEdit]=useState(false)
  const [beFields,setBeFields]=useState({subject:'',difficulty:'',type:'',chapter:'',examLevel:''})
  const [beSaving,setBeSaving]=useState(false)
  // ── Per-Question Usage Stats (Feature 2) ──
  const [usageStatsQ,setUsageStatsQ]=useState(null)
  const [usageStatsData,setUsageStatsData]=useState(null)
  const [usageStatsLoading,setUsageStatsLoading]=useState(false)
  const [qPage,setQPage]=useState(1)
  const [selQId,setSelQId]=useState(null)
  const [editQD,setEditQD]=useState(null)
  const [savingEQ,setSavingEQ]=useState(false)
  const [stdPrv,setStdPrv]=useState(false)
  const [qLang,setQLang]=useState(function(){try{return localStorage.getItem('pr_qb_lang')||'en'}catch(e){return 'en'}})
  const [aiGO,setAiGO]=useState(false)
const [showAiPreview,setShowAiPreview]=useState(false)
const [aiEditIdx,setAiEditIdx]=useState<number|null>(null)
const [aiEditQ,setAiEditQ]=useState<any>(null)
  const [aiGStep,setAiGStep]=useState(1)
  const [aiGSub,setAiGSub]=useState('Physics')
  const [aiGCnt,setAiGCnt]=useState('10')
  const [aiGDiff,setAiGDiff]=useState('medium')
  const [aiGLoading,setAiGLoading]=useState(false)
  const [matMode,setMatMode]=useState('ncert')
  const [matList,setMatList]=useState([])
  const [matLoading,setMatLoading]=useState(false)
  const [matUploading,setMatUploading]=useState(false)
  const [matGenLoading,setMatGenLoading]=useState(false)
  const [matGenCnt,setMatGenCnt]=useState('10')
  const [matGenDiff,setMatGenDiff]=useState('medium')
  const [selMatId,setSelMatId]=useState('')
  const [aiGResult,setAiGResult]=useState([])
  const [aiGO_ncert,setAiGO_ncert]=useState(false)
  const [aiGO_files,setAiGO_files]=useState(false)
  const [fmSubj,setFmSubj]=useState('Physics')
  const [fmType,setFmType]=useState('SCQ')
  const [fmResult,setFmResult]=useState([])
  const [fmShowPreview,setFmShowPreview]=useState(false)
  const [fmEditIdx,setFmEditIdx]=useState(null)
  const [fmEditQ,setFmEditQ]=useState(null)
  const [fmExamLevel,setFmExamLevel]=useState('NEET')
  const [fmFormats,setFmFormats]=useState(['Random'])
  const [matTitle,setMatTitle]=useState('')
  const [matViewId,setMatViewId]=useState('')
  const [matViewTitle,setMatViewTitle]=useState('')
  const [matViewContent,setMatViewContent]=useState('')
  const [matViewLoading,setMatViewLoading]=useState(false)
  const aiChR=useRef('');const aiTopR=useRef('');const qImageR=useRef('')

  // Student management refs
  const banReaR=useRef('')
  const [banId,setBanId]=useState('')
  const [delConfirmId,setDelConfirmId]=useState('')
  const delReasonR=useRef('')
  const [deletedStds,setDeletedStds]=useState<any[]>([])
  const [stdDelLoading,setStdDelLoading]=useState(false)
  const [stdSort,setStdSort]=useState<'newest'|'name'|'active'>('newest')
  const [banT,setBanT]=useState<'permanent'|'temporary'>('permanent')

  // Announcement state now lives in AdminAnnouncements.tsx (F42A)

  // Branding refs
  const bNameR=useRef('ProveRank');const bTagR=useRef('Prove Your Rank')
  const [brandLoaded,setBrandLoaded]=useState({bName:'ProveRank',bTag:'Prove Your Rank',bMail:'support@proverank.com',bPhone:'',seoT:'ProveRank — NEET Online Test Platform',seoD:'',seoK:'NEET,online test,mock exam'})
  const bMailR=useRef('support@proverank.com');const bPhoneR=useRef('')
  const seoTR=useRef('ProveRank — NEET Online Test Platform')
  const seoDR=useRef('Best NEET mock test platform with AI analytics and anti-cheat proctoring.')
  const seoKR=useRef('NEET,online test,mock exam,ProveRank')
  const mainMsgR=useRef('Site under maintenance. We will be back shortly.')
  const maintWhitelistR=useRef('')
  const [savingWL,setSavingWL]=useState(false)
  const [wlText,setWlText]=useState('')
  const [savingB,setSavingB]=useState(false)
  const [mainOn,setMainOn]=useState(()=>{try{return localStorage.getItem('pr_maint')==='1'}catch{return false}})

  // Impersonate
  const [impId,setImpId]=useState('')

  // Permissions
  const [perms,setPerms]=useState({
  create_exam:false,edit_exam:false,delete_exam:false,clone_exam:false,bulk_exam:false,
  manage_questions:false,bulk_upload:false,ai_questions:false,pyq_access:false,
  view_students:false,ban_student:false,impersonate:false,export_data:false,
  download_reports:false,
  send_announcements:false,manage_doubts:false,manage_grievances:false,answer_key_challenge:false,
  manage_features:false,manage_branding:false,view_audit_logs:false,view_snapshots:false,manage_backup:false,manage_admins:false,
});
const [selectedPermAdmin,setSelectedPermAdmin]=useState(null);
const [adminOwnPerms,setAdminOwnPerms]=useState({});

  // Admin creation refs
  const admNameR=useRef('');const admEmailR=useRef('');const admPassR=useRef('')
  const [admRole,setAdmRole]=useState('admin')
  const [creatingAdm,setCreatingAdm]=useState(false)


  // AI Smart Generator
  const aiTopicR=useRef('');const aiChapR=useRef('')
  const [aiCount,setAiCount]=useState('10')
  const [aiSubj,setAiSubj]=useState('Physics')
  const [aiDiff,setAiDiff]=useState('medium')
const [aiType,setAiType]=useState('SCQ')
  const [aiLoading,setAiLoading]=useState(false)
  const [aiResult,setAiResult]=useState<any[]>([])
  const [aiSaving,setAiSaving]=useState(false)
const [aiExamLevel,setAiExamLevel]=useState('NEET')
const [aiFormats,setAiFormats]=useState(['Random'])
const [aiImageUrl,setAiImageUrl]=useState('')
const [aiQImgs,setAiQImgs]=useState({})

  // Task manager
  const [todos,setTodos]=useState([
    {id:'1',text:'Review upcoming exam questions before publish',done:false,priority:'high'},
    {id:'2',text:'Reply to pending student grievance tickets',done:false,priority:'medium'},
    {id:'3',text:'Check server health before exam day',done:false,priority:'high'},
    {id:'4',text:'Update PYQ bank with NEET 2024 questions',done:false,priority:'low'},
  ])
  const todoR=useRef('');const [todoPri,setTodoPri]=useState<'high'|'medium'|'low'>('medium')

  // Changelog
  const clogs=[
    {v:'V4.0',d:'Mar 2026',chg:['Complete redesign — Login page theme matched','All 62+ features active with real API wiring','Mobile keyboard fix — memo components','Upload endpoints corrected — copypaste/excel/pdf','Beautiful page designs with SVG illustrations','Superadmin/Admin role display in header'],t:'major'},
    {v:'V3.1',d:'Mar 2026',chg:['Fixed All Exams zero bug — fetchAll after create','Fixed field names: questionsText + answerKeyText','Added 9 missing features (M15,S102,S69,S71,S70,M9,M10,M12,S110)'],t:'minor'},
  ]

  // Email template refs
  const emailSubjR=useRef('');const emailBodyR=useRef('')
  const [emailType,setEmailType]=useState('welcome')
  const [sendingEmail,setSendingEmail]=useState(false)


  // Certificate
  const [certExamId,setCertExamId]=useState('')

  // PYQ filter
  const [pyqYear,setPyqYear]=useState('all')
  const [pyqSubj,setPyqSubj]=useState('all')
  const [pyqData,setPyqData]=useState<any[]>([])
  const [pyqLoading,setPyqLoading]=useState(false)

  // Bulk exam creator
  const [bulkExamFile,setBulkExamFile]=useState<File|null>(null)
  const [bulkExamLoading,setBulkExamLoading]=useState(false)
  const [bulkResult,setBulkResult]=useState<any>(null)

  // ══ TOAST ══
  const T=useCallback((msg:string,tp:'s'|'e'|'w'='s')=>{setToast({msg,tp});setTimeout(()=>setToast(null),4500)},[])

  // ══ AUTH HEADERS ══
  const H=useCallback(()=>({Authorization:`Bearer ${token}`}),[token])
  const HJ=useCallback(()=>({'Content-Type':'application/json',Authorization:`Bearer ${token}`}),[token])

  // ══ INIT ══
  useEffect(()=>{
    const t=getToken(),r=getRole()
    if(!t||!['admin','superadmin'].includes(r)){router.replace('/login');return}
    setToken(t);setRole(r);setMounted(true);if(typeof window!=='undefined'&&sessionStorage.getItem('pr_just_logged_in')){sessionStorage.removeItem('pr_just_logged_in');sessionStorage.removeItem('pr_admin_tab');setTab('dashboard');}else{const sv=typeof window!='undefined'&&sessionStorage.getItem('pr_admin_tab');if(sv)setTab(sv);};
    // If admin (not superadmin), fetch own permissions for nav filtering
    if(r==='admin'){
      fetch((process.env.NEXT_PUBLIC_API_URL||'https://proverank.onrender.com')+'/api/admin/manage/profile/me',{headers:{Authorization:'Bearer '+t}})
        .then(res=>res.json())
        .then(d=>{
          if(d.success&&d.admin&&d.admin.permissions){
            const p=d.admin.permissions;
            const obj=typeof p.forEach==='function'?Object.fromEntries(p):p;
            setAdminOwnPerms(obj||{});
          }
        })
        .catch(()=>{
          // fallback: try profile with own ID from token
        });
    }
  },[router])

  useEffect(()=>{if(token){fetchAll();fetchArchivedAdmins();}},[token])

  // ══ FETCH ALL DATA ══
    const fetchArchivedAdmins=async()=>{try{const r=await fetch(API+'/api/admin/manage/archived',{headers:{Authorization:'Bearer '+token}});const d=await r.json();if(d.success)setArchivedAdmins(d.admins||d.data||[]);else setArchivedAdmins([]);}catch(e){}};
  const viewAdminProfile=async(adminId:string)=>{setProfileLoading(true);setShowProfileModal(true);setProfileAdmin(null);setProfileLogs([]);try{const r=await fetch(API+'/api/admin/manage/profile/'+adminId,{headers:{Authorization:'Bearer '+token}});const d=await r.json();setProfileLoading(false);if(d.success){setProfileAdmin(d.admin);setProfileLogs(d.activityLogs||[]);}else{setShowProfileModal(false);}}catch(e){}setProfileLoading(false);};
  const restoreAdmin=async(adminId:string)=>{if(!confirm('Restore admin?'))return;try{const r=await fetch(API+'/api/admin/manage/restore/'+adminId,{method:'PUT',headers:{Authorization:'Bearer '+token}});const d=await r.json();if(d.success){T('Restored! ✅','s');fetchArchivedAdmins();fetchAdmins();}else T(d.message||'Failed','e');}catch(e){}};
  const fetchAll=useCallback(async()=>{
    if(!token)return
    setLoading(true)
    const get=async(u:string)=>{try{const r=await fetch(u,{headers:{Authorization:`Bearer ${token}`}});return r.ok?r.json():null}catch{return null}}
    const getFirst=async(...urls:string[])=>{for(const u of urls){try{const r=await fetch(u,{headers:{Authorization:`Bearer ${token}`}});if(r.ok){const d=await r.json();if(d)return d}}catch{}}return null}
    const [us,ex,qs,st,fl,al,tk,sn,ft,nf,bt,au,rs,mn,tsr]=await Promise.all([
      getFirst(`${API}/api/admin/users`,`${API}/api/admin/students`),
      get(`${API}/api/exams`),
      get(`${API}/api/questions`),
      getFirst(`${API}/api/admin/stats`,`${API}/api/admin/dashboard`),
      getFirst(`${API}/api/admin/manage/cheating-logs`,`${API}/api/admin/cheating-logs`),
      getFirst(`${API}/api/admin/manage/audit`,`${API}/api/admin/audit`),
      getFirst(`${API}/api/admin/manage/tickets`,`${API}/api/admin/tickets`),
      getFirst(`${API}/api/admin/manage/snapshots`,`${API}/api/admin/snapshots`),
      get(`${API}/api/admin/features`),
    fetch(`${API}/api/admin/notifications`,{headers:{Authorization:`Bearer ${getToken()}`}}).then(r=>r.json()),
      getFirst(`${API}/api/admin/batches`,`${API}/api/admin/manage/batches`),
      get(`${API}/api/admin/manage/admins`),
      getFirst(`${API}/api/results`,`${API}/api/admin/results`),
      get(`${API}/api/admin/maintenance`),
      getFirst(`${API}/api/admin/test-series-manager?limit=200`,`${API}/api/testseries`),
    ])
    if(Array.isArray(us))setStudents(us)
    else if(us&&Array.isArray(us.students))setStudents(us.students)
    else if(us&&Array.isArray(us.data))setStudents(us.data)
    else if(us&&Array.isArray(us.users))setStudents(us.users)
    if(Array.isArray(ex))setExams(ex)
    if(Array.isArray(qs))setQuestions(qs)
    if(st)setStats(st)
    if(Array.isArray(fl))setFlags(fl)
    if(Array.isArray(al))setLogs(al)
    if(Array.isArray(tk))setTickets(tk)
    if(Array.isArray(sn))setSnapshots(sn)
    if(Array.isArray(nf))setNotifs(nf)
else if(nf?.notifications&&Array.isArray(nf.notifications))setNotifs(nf.notifications)
    if(Array.isArray(bt))setBatches(bt)
    if(tsr&&Array.isArray(tsr.series))setTestSeries(tsr.series)
    else if(Array.isArray(tsr))setTestSeries(tsr)
    if(Array.isArray(au))setAdminUsers(au);else if(au&&Array.isArray(au.admins))setAdminUsers(au.admins)
    if(Array.isArray(rs))setResults(rs)
    if(mn&&mn.maintenance!=null){
      const s=mn.maintenance.enabled===true
      setMainOn(s)
      try{localStorage.setItem('pr_maint',s?'1':'0')}catch{}
      if(mn.maintenance.allowedEmails&&Array.isArray(mn.maintenance.allowedEmails)){
        const wl=mn.maintenance.allowedEmails.join('\n')
        maintWhitelistR.current=wl
        setWlText(wl)
      }
    }
    if(ft){
      if(Array.isArray(ft)&&ft.length)setFeatures(ft)
      else if(ft&&typeof ft==='object')setFeatures(DEF_FEATURES.map(f=>({...f,enabled:ft[f.key]!==undefined?Boolean(ft[f.key]):f.enabled})))
      }
    setLoading(false)
    // Fallback: 4 sec baad bhi loading true ho to force false
    setTimeout(()=>setLoading(false), 4000)
  },[token])

  // ══ CREATE EXAM (FIXED: correct fields) ══
  const createExamS1=useCallback(async()=>{
    const title=eTitleR.current,date=eDateR.current
    if(!title||!date){T('Exam title and date are both required.','e');return}
    setCreatingE(true)
    try{
      const body={title,scheduledAt:new Date(date).toISOString(),totalMarks:parseInt(eMarksR.current)||720,duration:parseInt(eDurR.current)||200,subject:'NEET',type:'NEET',difficulty:'Mixed',category:eCatR.current||'Full Mock',customInstructions:eInstrR.current||undefined,password:ePassR.current||undefined}
      const res=await fetch(`${API}/api/exams`,{method:'POST',headers:{...(()=>({'Content-Type':'application/json',Authorization:`Bearer ${token}`}))()},body:JSON.stringify(body)})
      if(res.ok||res.status===201){
        const d=await res.json()
        const eid=d?.exam?._id||d?.exam?.id||d?._id||d?.id||d?.examId||''
        const etitle=d?.exam?.title||d?.title||title
        if(eid){
          setCreatedEId(eid);setCreatedETitle(etitle)
          T('Exam created successfully! Now add questions.')
          setEStep(2)
          setTimeout(()=>fetchAll(),500)
        } else {
          setCreatedEId('');setCreatedETitle(etitle)
          T('Exam created. (ID not returned — use Question Bank to add questions)','w')
          setEStep(2)
          setTimeout(()=>fetchAll(),500)
        }
      } else {
        const e=await res.json().catch(()=>({}))
        T(`Error ${res.status}: ${e.message||e.error||'Check exam details.'}`, 'e')
      }
    } catch(err:any){T(`Network error: ${err.message||'Check connection.'}`, 'e')}
    setCreatingE(false)
  },[token,T,fetchAll])

  // ══ UPLOAD QUESTIONS (FIXED: correct endpoints + field names) ══
  const uploadQs=useCallback(async()=>{
    const examId=createdEId
    if(!examId){T('Complete Step 1 first to create the exam.','e');return}
    setUploadingQ(true);setUpRes(null)
    try{
      let res:Response|null=null
      if(qMeth==='copypaste'||qMeth==='manual'){
        const questionsText=cpTxtR.current
        const answerKeyText=cpKeyR.current
        if(!questionsText){T('Please paste the question text first.','e');setUploadingQ(false);return}
        const payload={examId,questionsText,answerKeyText,questions:questionsText,text:questionsText,answerKey:answerKeyText}
        for(const ep of [`${API}/api/upload/copypaste/questions`,`${API}/api/upload/copy-paste`,`${API}/api/questions/bulk`]){
          try{const r=await fetch(ep,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify(payload)});if(r.ok||r.status===201){res=r;break}}catch{}
        }
      } else if(qMeth==='excel'){
        if(!excelF){T('Please select an Excel file.','e');setUploadingQ(false);return}
        for(const ep of [`${API}/api/upload/excel/questions`,`${API}/api/excel/questions`,`${API}/api/upload/excel`]){
          try{const fd=new FormData();fd.append('file',excelF);fd.append('examId',examId);fd.append('exam_id',examId);const r=await fetch(ep,{method:'POST',headers:{Authorization:`Bearer ${token}`},body:fd});if(r.ok||r.status===201){res=r;break}}catch{}
        }
      } else if(qMeth==='pdf'){
        if(!pdfF){T('Please select a PDF file.','e');setUploadingQ(false);return}
        for(const ep of [`${API}/api/upload/pdf/questions`,`${API}/api/upload/pdf`,`${API}/api/questions/pdf`]){
          try{const fd=new FormData();fd.append('file',pdfF);fd.append('examId',examId);fd.append('exam_id',examId);const r=await fetch(ep,{method:'POST',headers:{Authorization:`Bearer ${token}`},body:fd});if(r.ok||r.status===201){res=r;break}}catch{}
        }
      }
      if(res&&(res.ok||res.status===201)){
        const d=await res.json().catch(()=>({}))
        const cnt=d.success||d.count||d.uploaded||d.inserted||d.saved||0
        setUpRes({s:cnt,f:d.failed||0,msg:`${cnt} questions uploaded successfully!`})
        T(`${cnt} questions uploaded to exam.`)
        setEStep(3)
        setTimeout(()=>fetchAll(),500)
      } else {
        setUpRes({s:0,f:0,msg:'Upload endpoint not available. Use Question Bank tab to add questions manually.'})
        T('Upload endpoint not available. Please use Question Bank instead.','w')
        setEStep(3)
      }
    } catch(err:any){
      setUpRes({s:0,f:0,msg:'Network error occurred.'})
      T('Network error. Check your connection.','w')
      setEStep(3)
    }
    setUploadingQ(false)
  },[createdEId,qMeth,excelF,pdfF,token,T,fetchAll])

  // ══ QUESTION BANK ══
  const editQF=async(id,data)=>{
    setSavingEQ(true)
    try{
      // Convert correctLetter to correct[] array for backend
      const ltrs=['A','B','C','D']
      const correctIdx=ltrs.indexOf(data.correctLetter||'A')
      const payload={
        text:data.text,hindiText:data.hindiText,subject:data.subject,
        chapter:data.chapter,topic:data.topic,difficulty:data.difficulty,
        type:data.type,options:data.options,explanation:data.explanation,
        correct:[correctIdx>=0?correctIdx:0],
        correctAnswer:data.correctLetter||'A',
        image:data.image||'',
        optionImages:data.optionImages||['','','','']
      }
      const r=await fetch(API+'/api/questions/'+id,{method:'PUT',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify(payload)})
      if(r.ok){
        T('✅ Question updated!')
        setQuestions(function(prev){return prev.map(function(q){return q._id===id?Object.assign({},q,payload,{correctAnswer:payload.correctAnswer,image:payload.image,optionImages:payload.optionImages}):q})})
        setEditQD(null)
        setTimeout(function(){fetchAll()},800)
      }
      else{const e=await r.json().catch(()=>({}));T(e.message||'Update failed','e')}
    }catch(ex){T(ex.message,'e')}
    setSavingEQ(false)
  }
  const copyToAddForm=(q)=>{
    qTxtR.current=q.text||'';setQTxtVal(q.text||'');setQTxtInit(q.text||'')
    setQSubj(q.subject||'Physics')
    setQDiff(q.difficulty||'medium')
    setQType(q.type||'SCQ')
    setQAns(q.correctAnswer||'')
    qHindiR.current=q.hindiText||'';setQHindi(q.hindiText||'')
    qChapR.current=q.chapter||'';setQChap(q.chapter||'')
    qTopicR.current=q.topic||'';setQTopic(q.topic||'')
    qExpR.current=q.explanation||'';setQExp(q.explanation||'')
    setQImg(q.image||'')
    qA.current=(q.options||[])[0]||'';qB.current=(q.options||[])[1]||'';qC.current=(q.options||[])[2]||'';qD.current=(q.options||[])[3]||''
    setOptInit({a:(q.options||[])[0]||'',b:(q.options||[])[1]||'',c:(q.options||[])[2]||'',d:(q.options||[])[3]||''})
    setOptImgsInit({a:(q.optionImages||[])[0]||'',b:(q.optionImages||[])[1]||'',c:(q.optionImages||[])[2]||'',d:(q.optionImages||[])[3]||''})
    setFormKey(function(k){return k+1})
    setQBV('add');try{sessionStorage.setItem('pr_qbv','add')}catch{}
    T('📋 Question copied to form — edit & save as new!')
  }
  const dupQF=async(q)=>{
    const d={text:'[COPY] '+q.text,subject:q.subject,chapter:q.chapter,topic:q.topic,difficulty:q.difficulty,type:q.type,options:q.options}
    try{
      const r=await fetch(API+'/api/questions',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify(d)})
      if(r.ok){T('Duplicated!');setTimeout(()=>fetchAll(),400)}else T('Failed','e')
    }catch{T('Network error','e')}
  }
  const aiGF=async()=>{
    const ch=aiChR.current,tp=aiTopR.current
    if(!ch||!tp){T('Chapter aur Topic fill karo','e');return}
    setAiGLoading(true)
    try{
      const r=await fetch(API+'/api/questions/generate',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({subject:aiGSub,chapter:ch,topic:tp,count:parseInt(aiGCnt)||10,difficulty:aiGDiff,type:aiType,examLevel:aiExamLevel,formats:aiFormats,imageUrl:aiImageUrl||''})})
      if(r.ok){const d=await r.json();const qs=d.questions||d.generated||[];setAiGResult(qs);T(qs.length+' generated!')}
      else T('AI failed','e')
    }catch{T('Network error','e')}
    setAiGLoading(false)
  }
  const fetchMats=async()=>{
    setMatLoading(true)
    try{
      const r=await fetch(API+'/api/materials',{headers:{Authorization:'Bearer '+token}})
      if(r.ok)setMatList(await r.json())
      else T('Failed to load materials ('+r.status+')','e')
    }catch(e){T('Network error loading materials','e')}
    setMatLoading(false)
  }
  const saveMat=async(title,content,fileType,fileSize)=>{
    try{
      const r=await fetch(API+'/api/materials',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({title,content,fileType:fileType||'txt',fileSize:fileSize||0})})
      if(r.ok){await fetchMats();T('📚 Material saved!')}
      else T('Save failed','e')
    }catch(e){T(e.message||'Error','e')}
  }
  const fetchMatContent=async(id,title)=>{
    setMatViewId(id)
    setMatViewTitle(title||'')
    setMatViewContent('')
    setMatViewLoading(true)
    try{
      const r=await fetch(API+'/api/materials/'+id,{headers:{Authorization:'Bearer '+token}})
      if(r.ok){const d=await r.json();setMatViewContent(d.content||'No content found')}
      else setMatViewContent('Failed to load content ('+r.status+')')
    }catch(e){setMatViewContent('Network error: '+e.message)}
    setMatViewLoading(false)
  }
  const deleteMat=async(id)=>{
    if(!window.confirm('Delete this material?'))return
    try{
      const r=await fetch(API+'/api/materials/'+id,{method:'DELETE',headers:{Authorization:'Bearer '+token}})
      if(r.ok){setMatList(function(p){return p.filter(function(m){return m._id!==id})});T('🗑️ Material deleted')}
      else T('Delete failed ('+r.status+')','e')
    }catch(e){T(e.message||'Network error','e')}
  }
  const generateFromMat=async(matId,cnt,diff)=>{
    setMatGenLoading(true)
    try{
      const genRes=await fetch(API+'/api/materials/generate',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({materialId:matId,count:parseInt(cnt)||10,difficulty:diff,examLevel:fmExamLevel,formats:fmFormats,subject:fmSubj,questionType:fmType,type:fmType})})
      if(!genRes.ok){T('Generation failed ('+genRes.status+')','e');setMatGenLoading(false);return}
      const qs=await genRes.json()
      if(Array.isArray(qs)&&qs.length>0){
        const tagged=qs.map(function(q){return Object.assign({},q,{subject:fmSubj,type:q.type||fmType,examLevel:q.examLevel||fmExamLevel})})
        setFmResult(tagged);const fmp:Record<number,any>={};tagged.forEach((q:any,j:number)=>{const d=findDups(q.text||'',q.options||[],questions);if(d.length)fmp[j]=d[0]});setFmDupMap(fmp);setFmShowPreview(true);T('✅ '+tagged.length+' Qs generated!')
      }
      else T('No questions generated. Try again.','e')
    }catch(e){T(e.message||'Failed','e')}
    setMatGenLoading(false)
  }
  const handleMatFile=async(file,customTitle)=>{
    if(!file)return
    if(file.size>10*1024*1024){T('File too large — max 10MB allowed','e');return}
    setMatUploading(true)
    try{
      const ext=(file.name.split('.').pop()||'').toLowerCase()
      let content=''
      if(['txt','csv','md','json','html'].includes(ext)){
        content=await new Promise(function(res,rej){const rd=new FileReader();rd.onload=function(e){res(e.target.result)};rd.onerror=rej;rd.readAsText(file)})
      }else{
        const b64=await new Promise(function(res,rej){const rd=new FileReader();rd.onload=function(e){res(e.target.result.split(',')[1])};rd.onerror=rej;rd.readAsDataURL(file)})
        const extResp=await fetch(API+'/api/materials/extract',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({base64:b64,fileName:file.name,isText:false})})
        if(!extResp.ok){T('Extraction failed ('+extResp.status+') — try TXT format','e');setMatUploading(false);return}
        const extData=await extResp.json()
        content=extData.content||''
      }
      if(content.trim()){await saveMat(customTitle||file.name,content,ext,file.size);setMatTitle('')}
      else T('No content extracted from file','e')
    }catch(e){T(e.message||'Upload failed','e')}
    setMatUploading(false)
  }
  const saveAiQs=async()=>{
    if(!aiGResult.length)return
    try{
      const r=await fetch(API+'/api/questions/bulk-save',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({questions:aiGResult})})
      if(r.ok){T(aiGResult.length+' saved!');setAiGResult([]);setAiGO_ncert(false);setTimeout(()=>fetchAll(),400)}
      else T('Save failed','e')
    }catch{T('Network error','e')}
  }
  const saveFmQs=async()=>{
    if(!fmResult.length)return
    try{
      const r=await fetch(API+'/api/questions/bulk-save',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({questions:fmResult.map(function(q){return Object.assign({},q,{subject:q.subject&&q.subject!=='General'?q.subject:fmSubj,type:q.type||fmType})})})})
      if(r.ok){T(fmResult.length+' questions saved!');setFmResult([]);setFmShowPreview(false);setTimeout(()=>fetchAll(),400)}
      else T('Save failed','e')
    }catch(e){T(e.message||'Error saving','e')}
  }

  // ── F24: Delete/Archive/Undo/Bulk functions ───────────────────────────────
  const [delModal,setDelModal]=useState<any|null>(null)
  const [delImpact,setDelImpact]=useState<any|null>(null)
  const [delLoading,setDelLoading]=useState(false)
  const [undoToast,setUndoToast]=useState<{msg:string;id:string}|null>(null)
  const [showBin,setShowBin]=useState(false)
  const [showArchived,setShowArchived]=useState(false)

  const openDeleteModal=async(q:any)=>{
    setDelModal(q);setDelImpact(null);
    try{const r=await fetch(API+'/api/questions/'+q._id+'/delete-impact',{headers:{Authorization:'Bearer '+token}});const d=await r.json();if(d.success)setDelImpact(d);}catch{}
  }
  const confirmDelete=async(reason:string)=>{
    if(!delModal)return;setDelLoading(true);
    try{const r=await fetch(API+'/api/questions/'+delModal._id+'/permanent',{method:'DELETE',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({reason})});const d=await r.json();
    if(d.success){T('Moved to Recycle Bin 🗑️','w');setUndoToast({msg:'Question deleted',id:delModal._id});setDelModal(null);setTimeout(()=>fetchAll(),400);}
    else T(d.message||'Delete failed','e');}catch{T('Error','e');}setDelLoading(false);
  }
  const confirmArchive=async(reason:string)=>{
    if(!delModal)return;setDelLoading(true);
    try{const r=await fetch(API+'/api/questions/'+delModal._id+'/archive',{method:'PATCH',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({reason})});const d=await r.json();
    if(d.success){T('Archived 🗂️','w');setUndoToast({msg:'Question archived',id:delModal._id});setDelModal(null);setTimeout(()=>fetchAll(),400);}
    else T(d.message||'Archive failed','e');}catch{T('Error','e');}setDelLoading(false);
  }
  const undoDeleteFn=async()=>{
    if(!undoToast)return;
    try{const r=await fetch(API+'/api/questions/'+undoToast.id+'/restore',{method:'PATCH',headers:{Authorization:'Bearer '+token}});const d=await r.json();
    if(d.success){T('↩️ Restored!','s');setUndoToast(null);setTimeout(()=>fetchAll(),400);}
    else T(d.message||'Undo failed','e');}catch{T('Error','e');}
  }
  const bulkDeleteFn=async(ids:string[],reason='')=>{
    try{const r=await fetch(API+'/api/questions/bulk/delete',{method:'PATCH',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({ids,reason})});const d=await r.json();
    if(d.success){T(d.modifiedCount+' Qs → Recycle Bin','w');setTimeout(()=>fetchAll(),400);return true;}
    else{T(d.message||'Failed','e');return false;}}catch{T('Error','e');return false;}
  }
  const bulkArchiveFn=async(ids:string[],reason='')=>{
    try{const r=await fetch(API+'/api/questions/bulk/archive',{method:'PATCH',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({ids,reason})});const d=await r.json();
    if(d.success){T(d.modifiedCount+' Qs archived 🗂️','w');setTimeout(()=>fetchAll(),400);return true;}
    else{T(d.message||'Failed','e');return false;}}catch{T('Error','e');return false;}
  }

  const blkDelQs=async()=>{
    if(!bulkSel.length||!confirm('Delete '+bulkSel.length+' questions?'))return
    for(const id of bulkSel){await fetch(API+'/api/questions/'+id,{method:'DELETE',headers:{Authorization:'Bearer '+token}})}
    setQuestions(p=>p.filter(q=>!bulkSel.includes(q._id)));setBulkSel([]);T('Bulk deleted.')
  }
  const blkApproveQs=async()=>{
    if(!bulkSel.length||!confirm('Approve '+bulkSel.length+' questions?'))return
    for(const id of bulkSel){await fetch(API+'/api/questions/'+id,{method:'PATCH',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({approvalStatus:'approved'})})}
    setQuestions(function(p){return p.map(function(q){return bulkSel.includes(q._id)?Object.assign({},q,{approvalStatus:'approved'}):q})})
    setBulkSel([]);T('✅ Bulk approved.')
  }
  // ── Feature 1: QsBank -> Exam Integration ──
  const fetchExamsForA2E=async()=>{
    try{
      const r=await fetch(API+'/api/exams',{headers:{Authorization:'Bearer '+token}})
      const d=await r.json()
      const list=Array.isArray(d)?d:(d.exams||[])
      setA2eExamsList(list)
    }catch(e){setA2eExamsList([])}
  }
  const openA2E=()=>{
    if(!bulkSel.length)return
    setA2eTab('existing');setA2eExamId('');setA2eTitle('');setA2eDuration('180');setA2eMarks('720')
    fetchExamsForA2E();setShowA2E(true)
  }
  const submitA2EExisting=async()=>{
    if(!a2eExamId)return T('Select an exam','e')
    setA2eSaving(true)
    try{
      const r=await fetch(API+'/api/exams/'+a2eExamId+'/questions',{method:'PATCH',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({questionIds:bulkSel})})
      if(r.ok){T(bulkSel.length+' questions added to exam!');setBulkSel([]);setShowA2E(false);setTimeout(function(){fetchAll()},500)}
      else{const d=await r.json().catch(function(){return{}});T(d.message||'Failed to add questions','e')}
    }catch(e){T('Failed: '+e.message,'e')}
    setA2eSaving(false)
  }
  const submitA2ENew=async()=>{
    if(!a2eTitle.trim())return T('Exam title required','e')
    if(!a2eDuration||Number(a2eDuration)<=0)return T('Valid duration required','e')
    setA2eSaving(true)
    try{
      const r=await fetch(API+'/api/exams',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({title:a2eTitle,duration:Number(a2eDuration),totalMarks:Number(a2eMarks)||720,questions:bulkSel})})
      const d=await r.json().catch(function(){return{}})
      if(r.ok){T('New exam created with '+bulkSel.length+' questions!');setBulkSel([]);setShowA2E(false);setTimeout(function(){fetchAll()},500)}
      else T(d.message||'Failed to create exam','e')
    }catch(e){T('Failed: '+e.message,'e')}
    setA2eSaving(false)
  }
  // ── Feature 4: Bulk Edit ──
  const openBulkEdit=()=>{
    if(!bulkSel.length)return
    setBeFields({subject:'',difficulty:'',type:'',chapter:'',examLevel:''});setShowBulkEdit(true)
  }
  const submitBulkEdit=async()=>{
    const fields={}
    Object.keys(beFields).forEach(function(k){if(beFields[k])fields[k]=beFields[k]})
    if(Object.keys(fields).length===0)return T('Fill at least 1 field','e')
    setBeSaving(true)
    try{
      const r=await fetch(API+'/api/questions/bulk-update',{method:'PATCH',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({ids:bulkSel,fields:fields})})
      const d=await r.json().catch(function(){return{}})
      if(r.ok){T(bulkSel.length+' questions updated!');setBulkSel([]);setShowBulkEdit(false);setTimeout(function(){fetchAll()},500)}
      else T(d.message||'Bulk edit failed','e')
    }catch(e){T('Failed: '+e.message,'e')}
    setBeSaving(false)
  }
  // ── Feature 2: Per-Question Usage Stats ──
  const fetchUsageStats=async(q)=>{
    setUsageStatsQ(q);setUsageStatsData(null);setUsageStatsLoading(true)
    try{
      const r=await fetch(API+'/api/questions/'+q._id+'/usage-stats',{headers:{Authorization:'Bearer '+token}})
      const d=await r.json()
      setUsageStatsData(d)
    }catch(e){setUsageStatsData({success:false,message:'Failed to load'})}
    setUsageStatsLoading(false)
  }
  const expQB=()=>{
    const hdr='ID\tText\tSubject\tChapter\tDifficulty\tType'
    const rows=(questions||[]).map(function(q){return[q._id||'',q.text||'',q.subject||'',q.chapter||'',q.difficulty||'',q.type||''].join('\t')})
    const blob=new Blob([hdr+'\n'+rows.join('\n')],{type:'text/csv'})
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='qbank.csv';a.click()
  }
  const expQBPdf=()=>{
    const qs=(questions||[])
    const w=window.open('','_blank')
    if(!w)return
    const rows=qs.map(function(q,i){
      const opts=(q.options||[]).map(function(o,j){return '<p style="margin:2px 0;font-size:13px">'+String.fromCharCode(65+j)+'. '+o+'</p>'}).join('')
      const ans=q.correctAnswer?'<p style="color:#059669;font-size:12px;margin-top:4px">✓ Answer: '+q.correctAnswer+'</p>':''
      const meta='<p style="color:#6B7280;font-size:11px;margin-top:2px">'+(q.subject||'')+(q.chapter?' · '+q.chapter:'')+(q.difficulty?' · '+q.difficulty:'')+'</p>'
      return '<div style="margin-bottom:18px;padding:12px;border:1px solid #e5e7eb;border-radius:6px;page-break-inside:avoid"><p style="font-weight:600;font-size:14px;margin-bottom:6px">Q'+(i+1)+'. '+q.text+'</p>'+opts+ans+meta+'</div>'
    }).join('')
    w.document.write('<!DOCTYPE html><html><head><title>ProveRank QBank</title><style>body{font-family:Arial,sans-serif;padding:24px;color:#111}h2{color:#4F46E5}button{padding:8px 18px;background:#4F46E5;color:#fff;border:none;border-radius:6px;cursor:pointer;margin-bottom:16px;font-size:14px}@media print{button{display:none}}</style></head><body><h2>📚 ProveRank Question Bank</h2><p style="color:#6B7280;margin-bottom:12px">Total: '+qs.length+' Questions · Exported '+new Date().toLocaleDateString()+'</p><button onclick="window.print()">🖨️ Print / Save as PDF</button><hr style="margin:12px 0"/>'+rows+'</body></html>')
    w.document.close()
  }
    useEffect(()=>{const t=setInterval(()=>{setQTxtVal(qTxtR.current||'');setOptVals({a:qA.current||'',b:qB.current||'',c:qC.current||'',d:qD.current||''})},800);return ()=>clearInterval(t);},[]);
  useEffect(()=>{const timer=setTimeout(()=>{const d={text:qTxtVal,subj:qSubj,diff:qDiff,type:qType,ans:qAns,hindi:qHindi,chap:qChap,topic:qTopic,exp:qExp,img:qImg,optA:qA.current,optB:qB.current,optC:qC.current,optD:qD.current};if(d.text||d.subj||d.hindi||d.optA){try{localStorage.setItem('pr_q_draft',JSON.stringify(d));setDraftSaved(true);setTimeout(()=>setDraftSaved(false),2000)}catch(ex){}}},2000);return ()=>clearTimeout(timer);},[qTxtVal,qSubj,qDiff,qType,qAns,qHindi,qChap,qTopic,qExp,qImg]);
  useEffect(()=>{try{const d=JSON.parse(localStorage.getItem('pr_q_draft')||'{}');if(d.text||d.subj||d.hindi||d.optA){if(d.text){qTxtR.current=d.text;setQTxtVal(d.text);setQTxtInit(d.text)}if(d.subj)setQSubj(d.subj);if(d.diff)setQDiff(d.diff);if(d.type)setQType(d.type);if(d.ans)setQAns(d.ans);if(d.hindi){qHindiR.current=d.hindi;setQHindi(d.hindi)}if(d.chap){qChapR.current=d.chap;setQChap(d.chap)}if(d.topic){qTopicR.current=d.topic;setQTopic(d.topic)}if(d.exp){qExpR.current=d.exp;setQExp(d.exp)}if(d.img)setQImg(d.img);if(d.optA||d.optB||d.optC||d.optD){qA.current=d.optA||'';qB.current=d.optB||'';qC.current=d.optC||'';qD.current=d.optD||'';qA.current=d.optA||'';qB.current=d.optB||'';qC.current=d.optC||'';qD.current=d.optD||'';setOptInit({a:d.optA||'',b:d.optB||'',c:d.optC||'',d:d.optD||''});setOptImgsInit({a:(d.optionImages&&d.optionImages[0])||'',b:(d.optionImages&&d.optionImages[1])||'',c:(d.optionImages&&d.optionImages[2])||'',d:(d.optionImages&&d.optionImages[3])||''});setDraftKey(k=>k+1)}setFormKey(function(k){return k+1});setDraftRestored(true);setTimeout(()=>setDraftRestored(false),3000)}}catch(e){}},[]);
  const findDups=useCallback((newText:string,opts:string[],bank:any[])=>{
    const nt=(newText||'').toLowerCase().trim()
    if(nt.length<10)return[]
    return bank.filter((q:any)=>{
      if((q.text||'').toLowerCase().trim()!==nt)return false
      const eo=(q.options||[]).map((o:string)=>(o||'').toLowerCase().trim()).sort().join('|')
      const no=opts.map((o:string)=>(o||'').toLowerCase().trim()).filter(Boolean).sort().join('|')
      return !no||eo===no
    })
  },[])
  const addQ=useCallback(()=>{
const text=qTxtR.current
if(!text){T('Question text is required.','e');return}
const dups=findDups(text,[qA.current,qB.current,qC.current,qD.current],questions)
setDupFound(dups)
setShowAddPreview(true)
},[qSubj,qDiff,qType,qAns,T,questions,findDups])
const confirmAndAdd=useCallback(async()=>{
    const text=qTxtR.current
    if(!text){T('Question text is required.','e');return}
    setSavingQ(true)
    const payload={
    text,
    hindiText:qHindi||undefined,
    subject:qSubj||'General',
    chapter:qChap||undefined,
    topic:qTopic||undefined,
    difficulty:qDiff||'medium',
    type:qType||'SCQ',
    options:['SCQ','MSQ'].includes(qType)?[qA.current||'',qB.current||'',qC.current||'',qD.current||'']:undefined,
      optionImages:[optImgsInit.a,optImgsInit.b,optImgsInit.c,optImgsInit.d],
    correct:(qType==='Integer'
      ?[parseInt(qAns)||0]
      :qType==='MSQ'
        ?(Array.isArray(qAns)?qAns:qAns?qAns.split(','):[]).map(function(x){return['A','B','C','D'].indexOf(x)}).filter(function(x){return x>=0})
        :[['A','B','C','D'].indexOf((qAns||'').replace('Option ','').trim())].filter(function(x){return x>=0})
    ),
    explanation:qExpR.current||qExp||undefined,
    image:qImg||qImageR.current||undefined,
      optionImages:[optImgsInit.a||'',optImgsInit.b||'',optImgsInit.c||'',optImgsInit.d||'']
  }
    try{
      const res=await fetch(`${API}/api/questions`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify(payload)})
      if(res.ok||res.status===201){
        T('Question added to bank successfully.')
        qTxtR.current='';qA.current='';qB.current='';qC.current='';qD.current='';setQHindi('');setQChap('');setQTopic('');setQExp('');setQImg('');setQSubj('');setQDiff('medium');setQType('SCQ');setQAns('');setFormKey(function(k){return k+1});try{localStorage.removeItem('pr_q_draft')}catch(e){};setQTxtVal('');setQTxtInit('');setLatexPrev(false)
        const r=await fetch(`${API}/api/questions`,{headers:{Authorization:`Bearer ${token}`}})
        if(r.ok){const qd=await r.json();setQuestions(Array.isArray(qd)?qd:(qd.questions||qd.data||[]))}
      } else {
        const e=await res.json().catch(()=>({}))
        T(e.message||`Error ${res.status}`,'e')
      }
    } catch(err:any){T(`Network error: ${err.message}`,'e')}
    setSavingQ(false)
  },[qSubj,qDiff,qType,qAns,token,T])

  // ══ BAN / UNBAN ══
  const banStd=useCallback(async()=>{
    const reason=banReaR.current
    if(!banId||!reason){T('Student ID and ban reason are both required.','e');return}
    try{
      const res=await fetch(`${API}/api/admin/ban/${banId}`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({banReason:reason,banType:banT})})
      if(res.ok){setStudents(p=>p.map(s=>s._id===banId?{...s,banned:true,banReason:reason}:s));T('Student has been banned.');setBanId('');banReaR.current=''}
      else{T('Failed to ban student.','e')}
    } catch{T('Network error.','e')}
  },[banId,banT,token,T])

  const unbanStd=useCallback(async(id:string)=>{
    try{
      const res=await fetch(`${API}/api/admin/unban/${id}`,{method:'POST',headers:{Authorization:`Bearer ${token}`}})
      if(res.ok){setStudents(p=>p.map(s=>s._id===id?{...s,banned:false,banReason:''}:s));T('Student unbanned successfully.')}
      else{T('Failed to unban student.','e')}
    } catch{T('Network error.','e')}
  },[token,T])

  // ── SOFT DELETE STUDENT (SuperAdmin only) ──
  const softDelStd=useCallback(async(id:string)=>{
    setStdDelLoading(true)
    try{
      const res=await fetch(`${API}/api/admin/delete/${id}`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({reason:delReasonR.current||'Removed by SuperAdmin'})})
      if(res.ok){
        setStudents((p:any)=>p.filter((s:any)=>s._id!==id))
        if(selStudent?._id===id) setSelStudent(null)
        setDelConfirmId('')
        delReasonR.current=''
        T('Student account archived successfully.','s')
      } else {
        const d=await res.json()
        T(d.error||'Delete failed. Try again.','e')
      }
    } catch{ T('Network error.','e') }
    finally{ setStdDelLoading(false) }
  },[token,T,selStudent])

  // ── RESTORE DELETED STUDENT (SuperAdmin only) ──
  const restoreStd=useCallback(async(id:string)=>{
    try{
      const res=await fetch(`${API}/api/admin/restore/${id}`,{method:'POST',headers:{Authorization:`Bearer ${token}`}})
      if(res.ok){
        setDeletedStds((p:any)=>p.filter((s:any)=>s._id!==id))
        T('Student account restored successfully! 🎉','s')
        fetchAll()
      } else { T('Restore failed. Try again.','e') }
    } catch{ T('Network error.','e') }
  },[token,T,fetchAll])

  // ── FETCH DELETED STUDENTS ──
  const fetchDeletedStds=useCallback(async()=>{
    try{
      const res=await fetch(`${API}/api/admin/deleted-students`,{headers:{Authorization:`Bearer ${token}`}})
      if(res.ok){
        const d=await res.json()
        setDeletedStds(Array.isArray(d)?d:(d.students||[]))
      }
    } catch{}
  },[token])


  // ══ FEATURE FLAGS ══
  const toggleFeat=useCallback(async(key:string)=>{
    const ft=features.find(f=>f.key===key);const ne=!ft?.enabled
    setFeatures(p=>p.map(f=>f.key===key?{...f,enabled:ne}:f))
    try{await fetch(`${API}/api/admin/features`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({key,enabled:ne})})}catch{}
    T(`${ft?.label||key} ${ne?'enabled':'disabled'}.`)
  },[features,token,T])

  // ══ ANNOUNCEMENTS — now fully handled inside AdminAnnouncements.tsx (F42A) ══

  // ══ EXAM ACTIONS ══
  const delExam=useCallback(async(id:string)=>{
    if(!confirm('Delete this exam? This cannot be undone.'))return
    try{
      const res=await fetch(`${API}/api/exams/${id}`,{method:'DELETE',headers:{Authorization:`Bearer ${token}`}})
      if(res.ok){setExams(p=>p.filter(e=>e._id!==id));T('Exam deleted.')}
      else{T('Failed to delete exam.','e')}
    } catch{T('Network error.','e')}
  },[token,T])

  const cloneExam=useCallback(async(id:string)=>{
    try{
      const res=await fetch(`${API}/api/exams/${id}/clone`,{method:'POST',headers:{Authorization:`Bearer ${token}`}})
      if(res.ok){T('Exam cloned successfully.');setTimeout(()=>fetchAll(),500)}
      else{T('Failed to clone exam.','e')}
    } catch{T('Network error.','e')}
  },[token,T,fetchAll])

  // ══ BRANDING ══
  useEffect(()=>{
  if(tab==='branding'){
    const tk=getToken();if(!tk)return
    fetch(API+'/api/admin/branding',{headers:{Authorization:'Bearer '+tk}})
      .then(r=>r.json()).then(d=>{
        if(d.success&&d.branding){
          const b=d.branding
          const loaded={bName:b.brandName||'ProveRank',bTag:b.tagline||'Prove Your Rank',bMail:b.supportEmail||'support@proverank.com',bPhone:b.phone||'',seoT:b.seoTitle||'ProveRank — NEET Online Test Platform',seoD:b.seoDesc||'',seoK:b.seoKeywords||'NEET,online test,mock exam'}
          setBrandLoaded(loaded)
          bNameR.current=loaded.bName;bTagR.current=loaded.bTag
          bMailR.current=loaded.bMail;bPhoneR.current=loaded.bPhone
          seoTR.current=loaded.seoT;seoDR.current=loaded.seoD;seoKR.current=loaded.seoK
        }
      }).catch(()=>{})
  }
},[tab])
  const saveBrand=useCallback(async()=>{
    setSavingB(true)
    try{
      const res=await fetch(`${API}/api/admin/branding`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({brandName:bNameR.current,tagline:bTagR.current,supportEmail:bMailR.current,phone:bPhoneR.current,seoTitle:seoTR.current,seoDesc:seoDR.current,seoKeywords:seoKR.current})})
      if(res.ok)T('Branding & SEO settings saved.')
      else T('Failed to save settings.','e')
    } catch{T('Network error.','e')}
    setSavingB(false)
  },[token,T])

  // ══ MAINTENANCE WHITELIST SAVE ══
  const saveWhitelist=useCallback(async()=>{
    setSavingWL(true)
    try{
      const emails=maintWhitelistR.current.split('\n').map(e=>e.trim()).filter(Boolean)
      const r=await fetch(`${API}/api/admin/maintenance`,{
        method:'POST',
        headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},
        body:JSON.stringify({enabled:mainOn,message:mainMsgR.current,allowedEmails:emails})
      })
      const d=await r.json()
      if(d.success) T('Whitelist saved successfully!')
      else T('Failed to save whitelist','e')
    }catch(e){T('Network error','e')}
    setSavingWL(false)
  },[mainOn,token,T])

  // ══ MAINTENANCE ══
  const toggleMaint=useCallback(async()=>{
    const nm=!mainOn
    setMainOn(nm)
    try{localStorage.setItem('pr_maint',nm?'1':'0')}catch{}
    const doPost=async()=>{
      const r=await fetch(`${API}/api/admin/maintenance`,{
        method:'POST',
        headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},
        body:JSON.stringify({enabled:nm,message:mainMsgR.current,allowedEmails:maintWhitelistR.current.split('\n').map(e=>e.trim()).filter(Boolean)})
      })
      return r.ok?r.json():null
    }
    try{
      let md=await doPost()
      if(!md||!md.success){
        await new Promise(r=>setTimeout(r,3000))
        md=await doPost()
      }
      if(md&&md.success){
        T(nm?'🔴 Maintenance ON — Students blocked':'🟢 Platform Live — Students can access','s')
      }else{
        setMainOn(!nm)
        T('Save failed — Render server busy, try again','e')
      }
    }catch(e){
      setMainOn(!nm)
      T('Network error — please try again','e')
    }
  },[mainOn,token,T])

  // ══ EXPORT ══
  const doExport=useCallback(async(url:string,fname:string)=>{
    try{
      const res=await fetch(url,{headers:{Authorization:`Bearer ${token}`}})
      if(res.ok){const b=await res.blob();const u=URL.createObjectURL(b);const a=document.createElement('a');a.href=u;a.download=fname;a.click();T('Download started.')}
      else{T('Export failed.','e')}
    } catch{T('Network error.','e')}
  },[token,T])

  // ══ BACKUP ══
  const doBackup=useCallback(async()=>{
    try{
      const res=await fetch(`${API}/api/admin/backup`,{method:'POST',headers:{Authorization:`Bearer ${token}`}})
      if(res.ok)T('Backup triggered successfully.')
      else T('Backup failed.','e')
    } catch{T('Network error.','e')}
  },[token,T])

  // ══ TICKETS ══
  const resolveTicket=useCallback(async(id:string)=>{
    try{
      const res=await fetch(`${API}/api/admin/tickets/${id}/resolve`,{method:'PATCH',headers:{Authorization:`Bearer ${token}`}})
      if(res.ok){setTickets(p=>p.map(t=>t._id===id?{...t,status:'resolved'}:t));T('Ticket resolved.')}
      else T('Failed.','e')
    } catch{T('Network error.','e')}
  },[token,T])

  // ══ AI GENERATOR ══
  const aiGen=useCallback(async()=>{
    if(!aiTopicR.current){T('Please enter a topic.','e');return}
    setAiLoading(true)
    try{
      const res=await fetch(`${API}/api/questions/generate`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({topic:aiTopicR.current,chapter:aiChapR.current||undefined,count:parseInt(aiCount)||10,subject:aiSubj,difficulty:aiDiff,type:aiType,examLevel:aiExamLevel,formats:aiFormats,imageUrl:aiImageUrl})})
      if(res.ok){const d=await res.json();const list=Array.isArray(d)?d:(d.questions||[]);setAiResult(list);setAiGResult(list);T(`${list.length} questions generated.`)}
      else T('AI generation failed. Check backend.','e')
    } catch{T('Network error.','e')}
    setAiLoading(false)
  },[aiCount,aiSubj,aiDiff,token,T])

  const aiSaveAll=useCallback(async()=>{
    if(!aiResult.length){T('No generated questions to save.','e');return}
    setAiSaving(true)
    try{
      const res=await fetch(`${API}/api/questions/bulk-save`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({questions:aiGResult.length?aiGResult:aiResult})})
      if(res.ok){T(`${aiResult.length} AI questions saved to bank.`);setAiResult([]);setAiQImgs({});setTimeout(()=>fetchAll(),500)}
      else T('Failed to save AI questions.','e')
    } catch{T('Network error.','e')}
    setAiSaving(false)
  },[aiResult,token,T,fetchAll])


  // ══ ADMIN CREATE ══
  const createAdmin=useCallback(async()=>{
    if(!admNameR.current||!admEmailR.current||!admPassR.current){T('Name, email and password all required.','e');return}
    setCreatingAdm(true)
    try{
      const res=await fetch(`${API}/api/admin/manage/create-admin`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({name:admNameR.current,email:admEmailR.current,password:admPassR.current,role:admRole})})
      if(res.ok){T('Admin account created.');try{const r=await fetch(`${API}/api/admin/manage/admins`,{headers:{Authorization:`Bearer ${token}`}});if(r.ok){const d=await r.json();setAdminUsers(Array.isArray(d)?d:(Array.isArray(d.admins)?d.admins:[]))}}catch(_e){}}
      else{const e=await res.json().catch(()=>({}));T(e.message||'Failed to create admin.','e')}
    } catch{T('Network error.','e')}
    setCreatingAdm(false)
  },[admRole,token,T])

  // ══ PERMISSIONS ══
  const savePerms=useCallback(async()=>{
  if(!selectedPermAdmin){T('Pehle koi admin select karo','e');return;}
  try{
    const r=await fetch(API+'/api/admin/manage/permissions/'+selectedPermAdmin._id,{method:'PUT',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({permissions:perms})});
    const d=await r.json();
    if(d.success) T('Permissions saved for '+selectedPermAdmin.name+' ✅');
    else T(d.message||'Failed to save permissions','e');
  }catch(e){T('Network error — check connection','e');}
},[perms,token,T,selectedPermAdmin]);

  // ══ IMPERSONATE ══
  const impersonate=useCallback(async()=>{
    if(!impId){T('Student ID required.','e');return}
    try{
      const res=await fetch(`${API}/api/admin/manage/impersonate/${impId}`,{method:'POST',headers:{Authorization:`Bearer ${token}`}})
      if(res.ok){const d=await res.json();T(`Viewing as: ${d.name||impId}`);window.open(`/dashboard?impersonate=${impId}`,'_blank')}
      else T('Impersonate failed.','e')
    } catch{T('Network error.','e')}
  },[impId,token,T])

  // ══ PYQ BANK ══
  const loadPyq=useCallback(async()=>{
    setPyqLoading(true)
    try{
      const params=new URLSearchParams()
      if(pyqYear!=='all')params.set('year',pyqYear)
      if(pyqSubj!=='all')params.set('subject',pyqSubj)
      const res=await fetch(`${API}/api/questions/pyq?${params}`,{headers:{Authorization:`Bearer ${token}`}})
      if(res.ok){const d=await res.json();setPyqData(Array.isArray(d)?d:(d.questions||[]))}
      else T('PYQ data not available.','w')
    } catch{T('Network error.','e')}
    setPyqLoading(false)
  },[pyqYear,pyqSubj,token,T])

  // ══ BULK EXAM CREATOR ══
  const bulkCreateExams=useCallback(async()=>{
    if(!bulkExamFile){T('Please select an Excel file.','e');return}
    setBulkExamLoading(true)
    try{
      const fd=new FormData();fd.append('file',bulkExamFile)
      const res=await fetch(`${API}/api/exams/bulk-create`,{method:'POST',headers:{Authorization:`Bearer ${token}`},body:fd})
      if(res.ok){const d=await res.json();setBulkResult(d);T(`${d.created||0} exams created successfully.`);setTimeout(()=>fetchAll(),500)}
      else T('Bulk create failed.','e')
    } catch{T('Network error.','e')}
    setBulkExamLoading(false)
  },[bulkExamFile,token,T,fetchAll])

  // ══ EMAIL TEMPLATES ══
  const sendEmail=useCallback(async()=>{
    if(!emailSubjR.current||!emailBodyR.current){T('Subject and body required.','e');return}
    setSendingEmail(true)
    try{
      const res=await fetch(`${API}/api/admin/email/send`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({type:emailType,subject:emailSubjR.current,body:emailBodyR.current})})
      const d=await res.json()
      if(res.ok)T(d.message||'Email sent successfully.')
      else T(d.error||'Failed to send email.','e')
    } catch{T('Network error.','e')}
    setSendingEmail(false)
  },[emailType,token,T])

  // ══ GUARD ══
  if(!mounted)return null

  // ══ COMPUTED DATA ══
  const fStds=(students||[]).filter((s:any)=>{
    if(s.deleted)return false  // hide archived from main list
    if(stdFilter==='deleted')return false  // archived shown separately
    const m=stdSearch.toLowerCase()
    const ok=!m||(s.name?.toLowerCase().includes(m)||s.email?.toLowerCase().includes(m)||s._id?.includes(m))
    if(stdFilter==='banned')return ok&&!!s.banned
    if(stdFilter==='active')return ok&&!s.banned
    return ok
  })
  const fExams=(exams||[]).filter(e=>!examSearch||e.title?.toLowerCase().includes(examSearch.toLowerCase()))
  const fQs=(questions||[]).filter(q=>{
    const mq=!qSearch||q.text?.toLowerCase().includes(qSearch.toLowerCase())||q.subject?.toLowerCase().includes(qSearch.toLowerCase())||q.chapter?.toLowerCase().includes(qSearch.toLowerCase())||q.topic?.toLowerCase().includes(qSearch.toLowerCase())
    const ms=qSubjFilter==='all'||q.subject===qSubjFilter
    const OS=['Physics','Chemistry','Biology','Math']
    const sec=qSec==='all'||(qSec==='Other'?!OS.includes(q.subject||''):q.subject===qSec)
    const bio=qSec!=='Biology'||qBioSub==='all'||(q.chapter||'').toLowerCase().includes(qBioSub.toLowerCase())||(q.topic||'').toLowerCase().includes(qBioSub.toLowerCase())
    const chap=qChapFilter==='all'||!q.chapter||(q.chapter||'')===(qChapFilter)
    // ── Smart Filters (Feature 3) ──
    const fApp=qfApproval==='all'||(q.approvalStatus||'approved')===qfApproval
    const fDiff=qfDiff2==='all'||(q.difficulty||'').toLowerCase()===qfDiff2.toLowerCase()
    const fType=qfType==='all'||q.type===qfType
    const uc=q.usageCount||0
    const fUsage=qfUsage==='all'||(qfUsage==='never'?uc===0:qfUsage==='1-5'?(uc>=1&&uc<=5):qfUsage==='5+'?uc>5:true)
    const fLevel=qfLevel==='all'||q.examLevel===qfLevel
    const fFormat=qfFormat==='all'||q.format===qfFormat
    const fDate=(function(){
      if(qfDate==='all')return true
      if(!q.createdAt)return false
      const days=qfDate==='7d'?7:30
      return (Date.now()-new Date(q.createdAt).getTime())<=days*24*60*60*1000
    })()
    return mq&&ms&&sec&&bio&&chap&&fApp&&fDiff&&fType&&fUsage&&fLevel&&fFormat&&fDate
  })
  const _fQsSorted=[...fQs].sort(function(a,b){return new Date(b.createdAt)-new Date(a.createdAt)})
  const _qTP=Math.ceil(_fQsSorted.length/25)||1
  const _qPg=Math.min(qPage,_qTP)
  const pagedQs=_fQsSorted.slice((_qPg-1)*25,_qPg*25)

  // ══ NAV ITEMS ══
  const NAV=[
    {id:'myprofile',ico:'👤',lbl:'My Profile',grp:'Overview',alwaysShow:true},
    {id:'dashboard',ico:'📊',lbl:'Dashboard',grp:'Overview'},
    {id:'global_search',ico:'🔎',lbl:'Global Search',grp:'Overview'},
    {id:'live',ico:'🔴',lbl:'Live Monitor',grp:'Overview'},
    {id:'exams',ico:'📝',lbl:'All Exams',grp:'Exams'},
    {id:'create_exam',ico:'➕',lbl:'Create Exam',grp:'Exams'},
    {id:'templates',ico:'📋',lbl:'Templates',grp:'Exams'},
    {id:'questions',ico:'❓',lbl:'Question Bank',grp:'Questions'},
    {id:'smart_gen',ico:'🤖',lbl:'Smart Generator',grp:'Questions'},
    {id:'ai_explain',ico:'💡',lbl:'AI Explanation',grp:'Questions'},
    {id:'creation_studio',ico:'⚡',lbl:'Content Forge',grp:'Questions'},
    {id:'pyq_bank',ico:'📚',lbl:'PYQ Bank',grp:'Questions'},
    {id:'students',ico:'👥',lbl:'Students',grp:'Students'},
    {id:'test_series',ico:'📚',lbl:'Test Series Management',grp:'Students'},
    {id:'admins',ico:'🛡️',lbl:'Admins',grp:'Admin'},
    {id:'permissions',ico:'🔐',lbl:'Permissions',grp:'Admin'},
    {id:'reports',ico:'📊',lbl:'Reports & Export',grp:'Results'},
    {id:'cheating',ico:'🚨',lbl:'Anti-Cheat Logs',grp:'Proctoring'},
    {id:'snapshots',ico:'📷',lbl:'Snapshots',grp:'Proctoring'},
    {id:'integrity',ico:'🤖',lbl:'AI Integrity',grp:'Proctoring'},
    {id:'entry_proctoring',ico:'🛡️',lbl:'Entry & Proctoring',grp:'Proctoring'},
    {id:'tickets',ico:'🎫',lbl:'Grievances',grp:'Support'},
    {id:'ans_challenge',ico:'⚔️',lbl:'Answer Challenges',grp:'Support'},
    {id:'re_eval',ico:'🔄',lbl:'Re-Evaluation',grp:'Support'},
    {id:'announcements',ico:'📢',lbl:'Announcements',grp:'Communication'},
    {id:'email_tmpl',ico:'📧',lbl:'Email Templates',grp:'Communication'},
    {id:'whatsapp_sms',ico:'💬',lbl:'WhatsApp & SMS',grp:'Communication'},
    {id:'features',ico:'🚩',lbl:'Feature Flags',grp:'Settings'},
    {id:'branding',ico:'🎨',lbl:'Branding & SEO',grp:'Settings'},
    {id:'maintenance',ico:'🔧',lbl:'Maintenance',grp:'Settings'},
    {id:'backup',ico:'💾',lbl:'Backup & Data',grp:'Settings'},
    {id:'transparency',ico:'🔍',lbl:'Transparency',grp:'Reports'},
    {id:'omr_view',ico:'📋',lbl:'OMR Sheet View',grp:'Reports'},
    {id:'proct_pdf',ico:'📄',lbl:'Proctoring PDF',grp:'Reports'},
    {id:'retention',ico:'📈',lbl:'Retention Analytics',grp:'Reports'},
    {id:'audit',ico:'📋',lbl:'Audit Logs',grp:'Logs'},
  {id:'store',ico:'🛒',lbl:'Store Management',grp:'Tools'},
  ]

  const navGroups=[...new Set(NAV.map(n=>n.grp))]

  // ── Admin role: filter NAV based on their permissions ──
  const PERM_TO_NAV:{[k:string]:string[]}={
    create_exam:['create_exam','templates'],
    edit_exam:['exams'],delete_exam:['exams'],clone_exam:['exams'],
    manage_questions:['questions'],
    ai_questions:['smart_gen'],
    pyq_access:['pyq_bank'],
    view_students:['students'],ban_student:['students'],impersonate:['students'],
    download_reports:['reports'],
    export_data:['reports'],
    send_announcements:['announcements'],
    manage_doubts:['tickets'],
    manage_grievances:['tickets'],
    answer_key_challenge:['ans_challenge'],
    view_audit_logs:['audit'],
    view_snapshots:['snapshots','cheating','integrity','entry_proctoring'],
    manage_features:['features'],
    manage_branding:['branding'],
    manage_backup:['backup'],
  }
  const ADMIN_HIDDEN=['admins','permissions','maintenance','transparency','omr_view','proct_pdf','retention','re_eval','whatsapp_sms','email_tmpl','global_search','live']
  const filteredNAV=role==='superadmin'?NAV:(()=>{
    const allowed=new Set(['dashboard','myprofile'])
    Object.entries(adminOwnPerms).forEach(([perm,val])=>{
      if(val&&PERM_TO_NAV[perm]) PERM_TO_NAV[perm].forEach(t=>allowed.add(t))
    })
    return NAV.filter(n=>(n.alwaysShow||allowed.has(n.id))&&!ADMIN_HIDDEN.includes(n.id))
  })()
  const filteredNavGroups=[...new Set(filteredNAV.map(n=>n.grp))]

  // ══════════════════════════════════════════════════════════════
  // RENDER
  // ══════════════════════════════════════════════════════════════

  const markAllRead=async()=>{const tk=getToken();if(!tk)return;try{await fetch(`${API}/api/admin/notifications/mark-read`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${tk}`},body:JSON.stringify({all:true})});setNotifs((prev:any[])=>prev.map((n:any)=>({...n,isRead:true})));}catch(e){}};
  const markOneRead=async(id:string,notif?:any)=>{const tk=getToken();if(notif)setNotifDetail(notif);if(!tk)return;try{await fetch(`${API}/api/admin/notifications/mark-read`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${tk}`},body:JSON.stringify({id})});setNotifs((prev:any[])=>prev.map((n:any)=>n._id===id?{...n,isRead:true}:n));}catch(e){}};

  return (
    <div style={{background:BG_GRAD,minHeight:'100vh',color:TS,fontFamily:'Inter,sans-serif',position:'relative'}}>


      {/* Particles Background */}
      <GalaxyBg />

      {/* Decorative hexagons like login page */}
      <div style={{position:'fixed',top:-60,left:-60,fontSize:280,color:'rgba(77,159,255,0.03)',pointerEvents:'none',zIndex:0,lineHeight:1}}>⬡</div>
      <div style={{position:'fixed',bottom:-60,right:-60,fontSize:280,color:'rgba(77,159,255,0.03)',pointerEvents:'none',zIndex:0,lineHeight:1}}>⬡</div>

      {/* Global styles */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Inter:wght@400;500;600;700&display=swap');
        @keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
        @keyframes pulse{0%,100%{opacity:0.5}50%{opacity:1}}
        @keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
        @keyframes slideIn{from{transform:translateX(-100%)}to{transform:translateX(0)}}
        * { box-sizing:border-box; }
        ::-webkit-scrollbar{width:4px;height:4px}
        ::-webkit-scrollbar-track{background:rgba(0,22,40,0.5)}
        ::-webkit-scrollbar-thumb{background:rgba(77,159,255,0.3);border-radius:4px}
        input,textarea,select{color-scheme:dark}
        .nav-btn:hover{background:rgba(77,159,255,0.12) !important;color:#4D9FFF !important}
        .card-hover:hover{border-color:rgba(77,159,255,0.4) !important;transform:translateY(-1px);transition:all 0.2s}
        .btn-hover:hover{opacity:0.88;transform:translateY(-1px);transition:all 0.15s}
      `}</style>

      {/* ══ FULL WIDTH TOAST ══ */}
      {toast&&(
        <div style={{position:'fixed',top:0,left:0,right:0,zIndex:9999,padding:'15px 24px',fontWeight:700,fontSize:14,background:toast.tp==='s'?`linear-gradient(90deg,${SUC},#00a87a)`:toast.tp==='w'?`linear-gradient(90deg,${WRN},#e6a200)`:`linear-gradient(90deg,${DNG},#cc0000)`,color:toast.tp==='w'?'#000':'#fff',textAlign:'center',boxShadow:'0 4px 30px rgba(0,0,0,0.6)',letterSpacing:0.3,animation:'fadeIn 0.3s ease'}}>
          {toast.tp==='e'?'❌':toast.tp==='w'?'⚠️':'✅'} {toast.msg}
        </div>
      )}

      {/* ══ TOP NAVIGATION BAR ══ */}
      <div style={{position:'sticky',top:0,zIndex:100,background:'rgba(0,10,24,0.95)',backdropFilter:'blur(20px)',borderBottom:`1px solid ${BOR}`,padding:'0 12px',height:56,display:'flex',alignItems:'center',justifyContent:'space-between',boxShadow:'0 2px 20px rgba(0,0,0,0.4)',overflow:'hidden'}} id="pr-top-nav">
        {/* premium gold accent hairline */}
        <div aria-hidden style={{position:'absolute',left:0,right:0,bottom:-1,height:2,background:`linear-gradient(90deg,transparent,${GOLD},#FFA500,transparent)`,opacity:.55,pointerEvents:'none'}}/>

        {/* Left: Hamburger + Logo */}
        <div style={{display:'flex',alignItems:'center',gap:12}}>
          <button onClick={()=>setSideOpen(p=>!p)} aria-label="Open menu" style={{background:'linear-gradient(135deg,rgba(255,215,0,0.16),rgba(255,165,0,0.06))',border:`1px solid ${BOR}`,color:GOLD,cursor:'pointer',width:36,height:36,borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
          </button>
          <div className="pr-brand" style={{display:'flex',alignItems:'center',gap:8}}>
            <PRLogo size={32}/>
            <div style={{display:'flex',flexDirection:'column',alignItems:'flex-start',gap:3}}>
              <div className="pr-brand-name" style={{fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:13,background:`linear-gradient(90deg,${ACC},#fff)`,WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent',lineHeight:1,whiteSpace:'nowrap'}}>
                ProveRank
              </div>
              {/* Role tag — small outline label, clearly smaller than "ProveRank" */}
              <div style={{display:'inline-flex',alignItems:'center',gap:3,padding:'1.5px 6px',borderRadius:5,whiteSpace:'nowrap',background:role==='superadmin'?'rgba(255,215,0,0.08)':'rgba(77,159,255,0.08)',border:`1px solid ${role==='superadmin'?'rgba(255,215,0,0.45)':'rgba(77,159,255,0.4)'}`}}>
                <span style={{width:3.5,height:3.5,borderRadius:'50%',flexShrink:0,background:role==='superadmin'?GOLD:ACC}}/>
                <span className="pr-role-tag" style={{fontSize:6.5,fontWeight:800,letterSpacing:1,color:role==='superadmin'?GOLD:ACC}}>{role.toUpperCase()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Notifs + Refresh + Logout — grouped premium capsule */}
        <div style={{display:'flex',gap:2,alignItems:'center',flexShrink:0,padding:3,borderRadius:14,background:'rgba(255,215,0,0.04)',border:`1px solid ${BOR}`}}>
          {loading&&<span style={{fontSize:10,color:DIM,animation:'pulse 1s infinite',padding:'0 4px'}}>⟳</span>}

          {/* Notifications */}
          <button onClick={()=>setNotifOpen(p=>!p)} aria-label="Notifications" style={{background:'transparent',border:'none',color:TS,fontSize:14,cursor:'pointer',position:'relative',width:32,height:32,borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
            🔔
            {(notifs||[]).filter(n=>!n.isRead).length>0&&<span style={{position:'absolute',top:2,right:2,background:DNG,color:'#fff',fontSize:8,borderRadius:'50%',width:14,height:14,display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700,border:'1.5px solid rgba(0,10,24,0.95)'}}>{(notifs||[]).filter(n=>!n.isRead).length}</span>}
          </button>

          <button onClick={fetchAll} title="Refresh" style={{background:'transparent',color:GOLD,border:'none',borderRadius:10,width:32,height:32,cursor:'pointer',fontSize:15,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>↻</button>

          <div aria-hidden style={{width:1,height:20,background:BOR,margin:'0 3px',flexShrink:0}}/>

          <button
  onClick={()=>{sessionStorage.removeItem('pr_admin_tab');clearAuth();window.location.href='/login'}}
  title="Logout"
  style={{
    background:'rgba(255,255,255,0.05)',
    color:'#94a3b8',
    border:'1px solid rgba(255,255,255,0.10)',
    borderRadius:10,
    height:32,
    minWidth:32,
    cursor:'pointer',
    fontWeight:600,
    fontSize:13,
    display:'flex',
    alignItems:'center',
    justifyContent:'center',
    flexShrink:0,
    gap:6,
    padding:'0 10px',
    transition:'all 0.18s ease',
    whiteSpace:'nowrap',
    letterSpacing:'0.02em'
  }}
  onMouseEnter={e=>{
    e.currentTarget.style.background='rgba(239,68,68,0.13)';
    e.currentTarget.style.color='#fca5a5';
    e.currentTarget.style.borderColor='rgba(239,68,68,0.28)';
  }}
  onMouseLeave={e=>{
    e.currentTarget.style.background='rgba(255,255,255,0.05)';
    e.currentTarget.style.color='#94a3b8';
    e.currentTarget.style.borderColor='rgba(255,255,255,0.10)';
  }}
>
  {/* Logout SVG icon */}
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2.2"
    strokeLinecap="round" strokeLinejoin="round">
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
    <polyline points="16 17 21 12 16 7"/>
    <line x1="21" y1="12" x2="9" y2="12"/>
  </svg>
  {/* Text: visible only on desktop (md and above) */}
  <span className="hidden md:inline">Logout</span>
</button>
        </div>
      </div>

      {/* ══ NOTIFICATION PANEL ══ */}
      {notifOpen&&(
    <div style={{position:'fixed',top:52,right:8,width:320,maxHeight:460,background:'#0d1b2e',border:'1px solid #1e3a5f',borderRadius:12,boxShadow:'0 8px 32px rgba(0,0,0,0.6)',zIndex:9999,display:'flex',flexDirection:'column',overflow:'hidden'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 14px',borderBottom:'1px solid #1e3a5f',background:'#0a1628'}}>
        <span style={{fontWeight:700,fontSize:14,color:'#e2e8f0'}}>🔔 Notifications</span>
        <div style={{display:'flex',gap:6,alignItems:'center'}}>
          {notifs.filter((n:any)=>!n.isRead).length>0&&(
            <button onClick={markAllRead} style={{fontSize:10,color:'#60a5fa',background:'none',border:'1px solid #1e3a5f',borderRadius:6,padding:'2px 7px',cursor:'pointer'}}>Mark all read</button>
          )}
          <button onClick={()=>setNotifOpen(false)} style={{background:'none',border:'none',color:'#64748b',fontSize:17,cursor:'pointer',lineHeight:1,padding:0}}>×</button>
        </div>
      </div>
      <div style={{overflowY:'auto',flex:1}}>
        {notifs.length===0?(
          <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'36px 16px',color:'#475569'}}>
            <div style={{fontSize:36,marginBottom:8}}>🔕</div>
            <div style={{fontSize:13,fontWeight:600}}>No notifications yet</div>
            <div style={{fontSize:11,marginTop:3}}>Alerts will appear here</div>
          </div>
        ):(
          notifs.slice(0,20).map((n:any,ni:number)=>{
            const sev=n.severity||n.type||'info';
            const cm:any={high:{bg:'rgba(220,38,38,0.12)',bd:'#dc2626',ic:'🔴'},warning:{bg:'rgba(245,158,11,0.12)',bd:'#f59e0b',ic:'⚠️'},suspicious:{bg:'rgba(168,85,247,0.12)',bd:'#a855f7',ic:'🚨'},success:{bg:'rgba(34,197,94,0.12)',bd:'#22c55e',ic:'✅'},info:{bg:'rgba(59,130,246,0.12)',bd:'#3b82f6',ic:'💬'}};
            const c=cm[sev]||cm.info;
            const ts=n.createdAt?new Date(n.createdAt).toLocaleString('en-IN',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}):'';
            return(
              <div key={n._id||ni} onClick={()=>markOneRead(n._id,n)} style={{padding:'10px 14px',borderBottom:'1px solid #1e3a5f',background:n.isRead?'transparent':c.bg,borderLeft:'3px solid '+(n.isRead?'#1e3a5f':c.bd),cursor:'pointer'}}>
                <div style={{display:'flex',gap:8,alignItems:'flex-start'}}>
                  <span style={{fontSize:14}}>{c.ic}</span>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{display:'flex',alignItems:'center',gap:5}}>
                      <span style={{fontSize:12,fontWeight:n.isRead?400:700,color:n.isRead?'#94a3b8':'#e2e8f0',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',flex:1}}>{n.title||n.message||'Alert'}</span>
                      {!n.isRead&&<span style={{width:6,height:6,borderRadius:'50%',background:c.bd,flexShrink:0,display:'inline-block'}}/>}
                    </div>
                    {n.message&&n.title&&<div style={{fontSize:10,color:'#64748b',marginTop:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{n.message}</div>}
                    {ts&&<div style={{fontSize:10,color:'#475569',marginTop:2}}>{ts}</div>}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
      {notifs.length>0&&(
        <div style={{padding:'8px 14px',borderTop:'1px solid #1e3a5f',background:'#0a1628',textAlign:'center'}}>
          <button onClick={()=>{setNotifOpen(false);setNotifDetail({_all:true,title:"All Notifications",items:notifs});}} style={{fontSize:11,color:"#60a5fa",cursor:"pointer",fontWeight:600,background:"none",border:"none",padding:0,textDecoration:"underline"}}>View All Notifications →</button>
        </div>
      )}
    </div>
  )}

      <div style={{display:'flex',position:'relative',zIndex:1}}>

        {/* ══ SIDEBAR ══ */}
        <div style={{position:'fixed',top:58,left:0,width:224,height:'calc(100vh - 58px)',background:'rgba(0,10,24,0.97)',borderRight:`1px solid ${BOR}`,zIndex:50,overflow:'auto',padding:'10px 6px 24px',transform:sideOpen?'translateX(0)':'translateX(-100%)',transition:'transform 0.28s cubic-bezier(0.4,0,0.2,1)',backdropFilter:'blur(20px)',boxShadow:'4px 0 24px rgba(0,0,0,0.4)'}}>
          {filteredNavGroups.map(grp=>(
            <div key={grp} style={{marginBottom:4}}>
              <div style={{fontSize:9,fontWeight:700,color:'rgba(107,143,175,0.5)',letterSpacing:1.5,textTransform:'uppercase',padding:'10px 14px 4px'}}>{grp}</div>
              {filteredNAV.filter(n=>n.grp===grp).map(n=>(
                <button key={n.id} className="nav-btn" onClick={()=>{_setTab(n.id);setSideOpen(false)}}
                  style={{display:'flex',alignItems:'center',gap:9,padding:'8px 12px',borderRadius:8,border:'none',background:tab===n.id?'rgba(77,159,255,0.15)':'transparent',color:tab===n.id?ACC:DIM,cursor:'pointer',fontFamily:'Inter,sans-serif',fontSize:12,fontWeight:tab===n.id?700:400,width:'100%',textAlign:'left',borderLeft:tab===n.id?`3px solid ${ACC}`:'3px solid transparent'}}>
                  <span style={{fontSize:14,width:18,textAlign:'center'}}>{n.ico}</span>
                  <span>{n.lbl}</span>
                </button>
              ))}
            </div>
          ))}
        </div>

        {/* ══ MAIN CONTENT ══ */}
        <div style={{flex:1,padding:'20px 16px',maxWidth:'100vw',overflow:'auto',animation:'fadeIn 0.4s ease',paddingBottom:32}}>

          {/* ══ DASHBOARD ══ */}
          {tab==='store'&&(<div style={{minHeight:'100vh'}}><StoreAdminTab /></div>)}
          {tab==='entry_proctoring'&&(<div style={{minHeight:'100vh'}}><EntryProctoringControlCenter /></div>)}
          {tab==='dashboard'&&(
            <div>
              <div style={{marginBottom:20}}>
                <div style={pageTitle}>📊 Dashboard Overview</div>
                <div style={pageSub}>Welcome back, {role==='superadmin'?'Super Admin':'Admin'} — Here is your platform at a glance</div>
              </div>

              {/* Stats Row */}
              <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:10,marginBottom:20}}>
                <StatBox ico='👥' lbl='Total Students' val={loading?'…':stats?.totalStudents||(students||[]).length||0} col={ACC}/>
                <StatBox ico='📝' lbl='Total Exams' val={loading?'…':stats?.totalExams||(exams||[]).length||0} col={GOLD}/>
                <StatBox ico='📈' lbl='Exam Attempts' val={loading?'…':stats?.totalAttempts??0} col={SUC}/>
                <StatBox ico='🟢' lbl='Active Today' val={loading?'…':stats?.activeStudents??0} col='#00E5FF'/>
                <StatBox ico='❓' lbl='Questions' val={loading?'…':stats?.totalQuestions||(questions||[]).length||0} col='#FF6B9D'/>
              </div>

              {/* Hero Banner */}
              <div style={{background:`linear-gradient(135deg,rgba(0,85,204,0.40),rgba(77,159,255,0.20))`,border:`1px solid rgba(77,159,255,0.25)`,borderRadius:16,padding:'24px 20px',marginBottom:20,position:'relative',overflow:'hidden'}}>
                <div style={{position:'absolute',right:-20,top:-20,fontSize:100,opacity:0.06}}>⬡</div>
                <div style={{position:'absolute',right:30,top:20,fontSize:60,opacity:0.08}}>⬡</div>
                <div style={{fontFamily:'Playfair Display,serif',fontSize:18,fontWeight:700,color:TS,marginBottom:6}}>🎯 ProveRank Admin Center</div>
                <div style={{fontSize:12,color:DIM,lineHeight:1.7,maxWidth:500}}>
                  Manage your complete NEET test platform from here. Create exams, monitor students, review analytics, and keep your platform running smoothly.
                </div>
                <div style={{display:'flex',flexWrap:'wrap',gap:8,marginTop:14}}>
                  {[['➕ Create Exam','create_exam',ACC],['👥 All Students','students',SUC],['🔴 Live Monitor','live',DNG],['📊 Reports','reports',GOLD]].map(([l,t,c])=>(
                    <button key={String(t)} onClick={()=>_setTab(String(t))} style={{padding:'8px 16px',background:`${c}22`,border:`1px solid ${c}44`,color:String(c),borderRadius:20,cursor:'pointer',fontSize:12,fontWeight:600}}>{String(l)}</button>
                  ))}
                </div>
              </div>

              {/* 2-col grid */}
              <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))',gap:14,marginBottom:14}}>
                {/* Recent Exams */}
                <div style={cs}>
                  <div style={{fontWeight:700,marginBottom:12,fontSize:13,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                    <span>📝 Recent Exams</span>
                    <button onClick={()=>_setTab('exams')} style={{...bg_,padding:'4px 10px',fontSize:10}}>View All</button>
                  </div>
                  {(exams||[]).length===0
                    ?<div style={{textAlign:'center',padding:'20px 0',color:DIM}}>
                      <div style={{fontSize:30,marginBottom:8}}>📭</div>
                      <div style={{fontSize:12}}>No exams yet</div>
                      <button onClick={()=>_setTab('create_exam')} style={{...bp,fontSize:11,padding:'6px 14px',marginTop:8}}>Create First Exam</button>
                    </div>
                    :(exams||[]).slice(0,4).map(e=>(
                      <div key={e._id} style={{display:'flex',justifyContent:'space-between',padding:'8px 0',borderBottom:`1px solid ${BOR}`,fontSize:12}}>
                        <div>
                          <div style={{fontWeight:600,color:TS}}>{e.title}</div>
                          <div style={{fontSize:10,color:DIM,marginTop:2}}>{e.scheduledAt?new Date(e.scheduledAt).toLocaleDateString():''}</div>
                        </div>
                        <Badge label={e.status||'draft'} col={e.status==='active'?SUC:e.status==='published'?ACC:DIM}/>
                      </div>
                    ))
                  }
                </div>

                {/* Alerts + Quick Actions */}
                <div>
                  <div style={{...cs,marginBottom:12}}>
                    <div style={{fontWeight:700,marginBottom:10,fontSize:13}}>🚨 Alerts</div>
                    {(flags||[]).length===0&&(tickets||[]).filter(t=>t.status==='open').length===0
                      ?<div style={{color:SUC,fontSize:12,display:'flex',alignItems:'center',gap:6}}><span style={{fontSize:20}}>✅</span> All clear — no alerts</div>
                      :<div>
                        {(flags||[]).length>0&&<div style={{fontSize:12,color:WRN,marginBottom:6,padding:'6px 10px',background:'rgba(255,184,77,0.08)',borderRadius:8}}>⚠️ {flags.length} cheating flag{flags.length>1?'s':''}</div>}
                        {(tickets||[]).filter(t=>t.status==='open').length>0&&<div style={{fontSize:12,color:ACC,padding:'6px 10px',background:'rgba(77,159,255,0.08)',borderRadius:8}}>🎫 {tickets.filter(t=>t.status==='open').length} open ticket{tickets.filter(t=>t.status==='open').length>1?'s':''}</div>}
                      </div>
                    }
                  </div>
                  <div style={cs}>
                    <div style={{fontWeight:700,marginBottom:10,fontSize:13}}>⚡ Quick Actions</div>
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6}}>
                      {[['➕ Exam','create_exam'],['❓ Question','questions'],['📢 Announce','announcements'],['💾 Backup','backup']].map(([l,t])=>(
                        <button key={String(t)} onClick={()=>_setTab(String(t))} style={{...bg_,textAlign:'center',fontSize:11,padding:'8px 6px'}}>{String(l)}</button>
                      ))}
                    </div>
                    <div style={{marginTop:10,fontSize:11,color:DIM,display:'flex',gap:12}}>
                      <span>📦 {(batches||[]).length} Batches</span>
                      <span>🛡️ {(adminUsers||[]).length} Admins</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom row */}
              <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))',gap:12}}>
                <div style={cs}>
                  <div style={{fontWeight:700,marginBottom:8,fontSize:12}}>🏆 Top Students</div>
{topStudents.length===0
  ?<div style={{fontSize:12,color:'#64748b',textAlign:'center',padding:'10px 0'}}>No exam data yet</div>
  :topStudents.slice(0,5).map((s,idx)=>(
    <div key={idx} style={{display:'flex',alignItems:'center',gap:8,padding:'5px 0',borderBottom:'1px solid rgba(255,255,255,0.05)'}}>
      <span style={{fontSize:12,fontWeight:700,minWidth:18,color:idx===0?'#fbbf24':idx===1?'#94a3b8':idx===2?'#b45309':'#64748b'}}>{idx+1}</span>
      <span style={{fontSize:12,color:'#e2e8f0',flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{s.name}</span>
      <span style={{fontSize:11,color:'#38bdf8',fontWeight:600}}>{s.bestScore}pts</span>
    </div>
  ))
}
                </div>
                <div style={cs}>
                  <div style={{fontWeight:700,marginBottom:8,fontSize:12}}>🚨 Recent Flags</div>
                  {(flags||[]).length===0
                    ?<div style={{color:SUC,fontSize:11,textAlign:'center',padding:'10px 0'}}>✅ No cheating flags</div>
                    :(flags||[]).slice(0,4).map((f,i)=>(
                      <div key={f._id||i} style={{fontSize:11,padding:'5px 0',borderBottom:`1px solid ${BOR}`,color:DIM}}>
                        <span style={{color:f.severity==='high'?DNG:WRN,fontWeight:600}}>{f.type}</span> — {f.studentName||'—'}
                      </div>
                    ))
                  }
                </div>
                <div style={cs}>
                  <div style={{fontWeight:700,marginBottom:8,fontSize:12}}>📊 Platform Health</div>
                  {[['Students',`${(students||[]).filter(s=>!s.banned).length}/${(students||[]).length}`,SUC],['Exams',`${(exams||[]).filter(e=>e.status==='active').length} active`,ACC],['Questions',`${(questions||[]).length} in bank`,GOLD],['Features',`${features.filter(f=>f.enabled).length}/${features.length} on`,'#FF6B9D']].map(([l,v,c])=>(
                    <div key={String(l)} style={{display:'flex',justifyContent:'space-between',fontSize:11,padding:'4px 0',borderBottom:`1px solid ${BOR}`}}>
                      <span style={{color:DIM}}>{String(l)}</span>
                      <span style={{color:String(c),fontWeight:600}}>{String(v)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* ══ SCIENCE ILLUSTRATION SECTION ══ */}
              <div style={{marginTop:20,display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))',gap:12}}>
                {[
                  {icon:<svg viewBox="0 0 80 80" width="48" height="48"><circle cx="40" cy="40" r="8" fill="none" stroke="#4D9FFF" strokeWidth="2"/><ellipse cx="40" cy="40" rx="30" ry="12" fill="none" stroke="#4D9FFF" strokeWidth="1.5" opacity="0.7"/><ellipse cx="40" cy="40" rx="30" ry="12" fill="none" stroke="#00D4FF" strokeWidth="1" transform="rotate(60 40 40)" opacity="0.5"/><ellipse cx="40" cy="40" rx="30" ry="12" fill="none" stroke="#7050FF" strokeWidth="1" transform="rotate(120 40 40)" opacity="0.5"/><circle cx="40" cy="40" r="3" fill="#4D9FFF"/></svg>,title:'Atomic Structure',fact:'An atom is 99.99% empty space'},
                  {icon:<svg viewBox="0 0 80 80" width="48" height="48"><path d="M20 20 Q40 5 60 20 Q75 40 60 60 Q40 75 20 60 Q5 40 20 20Z" fill="none" stroke="#00E5A0" strokeWidth="1.5"/><circle cx="30" cy="35" r="4" fill="#00E5A0" opacity="0.8"/><circle cx="50" cy="35" r="4" fill="#00E5A0" opacity="0.8"/><circle cx="40" cy="50" r="4" fill="#00E5A0" opacity="0.8"/><line x1="30" y1="35" x2="50" y2="35" stroke="#00E5A0" strokeWidth="1"/><line x1="30" y1="35" x2="40" y2="50" stroke="#00E5A0" strokeWidth="1"/><line x1="50" y1="35" x2="40" y2="50" stroke="#00E5A0" strokeWidth="1"/></svg>,title:'DNA Structure',fact:'Human DNA has ~3 billion base pairs'},
                  {icon:<svg viewBox="0 0 80 80" width="48" height="48"><rect x="15" y="15" width="50" height="50" rx="6" fill="none" stroke="#FF6B9D" strokeWidth="1.5"/><rect x="25" y="25" width="30" height="30" rx="4" fill="none" stroke="#FF6B9D" strokeWidth="1" opacity="0.6"/><circle cx="40" cy="40" r="6" fill="#FF6B9D" opacity="0.4"/><line x1="40" y1="15" x2="40" y2="25" stroke="#FF6B9D" strokeWidth="1.5"/><line x1="40" y1="55" x2="40" y2="65" stroke="#FF6B9D" strokeWidth="1.5"/><line x1="15" y1="40" x2="25" y2="40" stroke="#FF6B9D" strokeWidth="1.5"/><line x1="55" y1="40" x2="65" y2="40" stroke="#FF6B9D" strokeWidth="1.5"/></svg>,title:'Cell Nucleus',fact:'Cell nucleus contains 46 chromosomes'},
                  {icon:<svg viewBox="0 0 80 80" width="48" height="48"><polygon points="40,10 65,55 15,55" fill="none" stroke="#FFB84D" strokeWidth="1.5"/><polygon points="40,22 58,52 22,52" fill="none" stroke="#FFB84D" strokeWidth="1" opacity="0.5"/><circle cx="40" cy="10" r="3" fill="#FFB84D"/><circle cx="65" cy="55" r="3" fill="#FFB84D"/><circle cx="15" cy="55" r="3" fill="#FFB84D"/></svg>,title:'Geometry',fact:'Triangle has angle sum of exactly 180°'},
                  {icon:<svg viewBox="0 0 80 80" width="48" height="48"><path d="M20 60 Q30 20 40 40 Q50 60 60 20" fill="none" stroke="#4D9FFF" strokeWidth="2"/><circle cx="20" cy="60" r="3" fill="#4D9FFF"/><circle cx="60" cy="20" r="3" fill="#4D9FFF"/><line x1="10" y1="65" x2="70" y2="65" stroke="#4D9FFF" strokeWidth="1" opacity="0.4"/><line x1="15" y1="70" x2="15" y2="10" stroke="#4D9FFF" strokeWidth="1" opacity="0.4"/></svg>,title:'Wave Motion',fact:'Light travels at 3×10⁸ m/s in vacuum'},
                ].map((item,i)=>(
                  <div key={i} style={{background:'rgba(0,22,40,0.7)',border:'1px solid rgba(77,159,255,0.15)',borderRadius:14,padding:'16px 14px',textAlign:'center',backdropFilter:'blur(12px)',transition:'all 0.3s'}}>
                    <div style={{display:'flex',justifyContent:'center',marginBottom:10}}>{item.icon}</div>
                    <div style={{fontSize:11,fontWeight:700,color:'#E8F4FF',marginBottom:4}}>{item.title}</div>
                    <div style={{fontSize:10,color:'rgba(107,143,175,0.9)',lineHeight:1.5}}>{item.fact}</div>
                  </div>
                ))}
              </div>

              {/* ══ PLATFORM ACTIVITY STRIP ══ */}
              <div style={{marginTop:16,background:'linear-gradient(135deg,rgba(77,159,255,0.08),rgba(0,212,255,0.05))',border:'1px solid rgba(77,159,255,0.18)',borderRadius:14,padding:'16px 20px',display:'flex',flexWrap:'wrap',gap:16,alignItems:'center',justifyContent:'space-between'}}>
                <div>
                  <div style={{fontSize:12,fontWeight:700,color:'#E8F4FF',marginBottom:2}}>⚡ Platform Status</div>
                  <div style={{fontSize:10,color:'rgba(107,143,175,0.9)'}}>All systems operational · Backend connected · DB active</div>
                </div>
                <div style={{display:'flex',gap:12}}>
                  {[{l:'Backend',c:'#00E5A0',s:'Live'},{l:'Database',c:'#00E5A0',s:'Connected'},{l:'Auth',c:'#00E5A0',s:'Active'}].map(x=>(
                    <div key={x.l} style={{textAlign:'center'}}>
                      <div style={{width:8,height:8,borderRadius:'50%',background:x.c,margin:'0 auto 4px',boxShadow:`0 0 8px ${x.c}`}}/>
                      <div style={{fontSize:9,color:'rgba(107,143,175,0.8)'}}>{x.l}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ══ GLOBAL SEARCH ══ */}
          {tab==='global_search'&&(
            <div>
              <div style={pageTitle}>🔎 Global Search (M12)</div>
              <div style={pageSub}>Search across all students, exams, and questions instantly</div>
              <GlobalSearch students={students} exams={exams} questions={questions} setTab={setTab} setSelStudent={setSelStudent} token={token}/>
            </div>
          )}

          {/* ══ LIVE MONITOR ══ */}
          {tab==='live'&&(
            <div>
              <div style={pageTitle}>🔴 Live Monitor (S95)</div>
              <div style={pageSub}>Real-time exam monitoring — connected students, server health, active alerts</div>
              <PageHero icon="🔴" title="Live Exam Control Center" subtitle="Monitor all active exams in real-time. View connected students, server response time, and flag suspicious activity as it happens."/>
              <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))',gap:12,marginBottom:20}}>
                <StatBox ico='🟢' lbl='Active Exams' val={(exams||[]).filter(e=>e.status==='active').length} col={SUC}/>
                <StatBox ico='👥' lbl='Connected Now' val={stats?.activeStudents??0} col={ACC}/>
                <StatBox ico='🚨' lbl='Live Flags' val={(flags||[]).filter(f=>f.severity==='high').length} col={DNG}/>
                <StatBox ico='⚡' lbl='Server Status' val='Online' col={SUC}/>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
                <div style={cs}>
                  <div style={{fontWeight:700,marginBottom:12,fontSize:13}}>📡 Active Exams</div>
                  {(exams||[]).filter(e=>e.status==='active').length===0
                    ?<div style={{textAlign:'center',padding:'30px 0',color:DIM}}>
                      <div style={{fontSize:36,marginBottom:8}}>😴</div>
                      <div style={{fontSize:12}}>No exams currently active</div>
                      <div style={{fontSize:11,marginTop:4}}>Active exams will appear here</div>
                    </div>
                    :(exams||[]).filter(e=>e.status==='active').map(e=>(
                      <div key={e._id} style={{...cs,marginBottom:8}}>
                        <div style={{fontWeight:600,fontSize:13,color:TS}}>{e.title}</div>
                        <div style={{display:'flex',gap:8,marginTop:6,flexWrap:'wrap'}}>
                          <Badge label={`${e.duration} min`} col={ACC}/>
                          <Badge label={`${e.attempts||0} attempts`} col={GOLD}/>
                          <Badge label='LIVE' col={DNG}/>
                        </div>
                        <div style={{display:'flex',gap:6,marginTop:10}}>
                          <button onClick={()=>T('Live control panel connecting…')} style={{...bg_,fontSize:10,padding:'5px 10px'}}>⏸ Pause</button>
                          <button onClick={()=>T('Broadcast sent to all participants.')} style={{...bg_,fontSize:10,padding:'5px 10px'}}>📢 Broadcast</button>
                        </div>
                      </div>
                    ))
                  }
                </div>
                <div style={cs}>
                  <div style={{fontWeight:700,marginBottom:12,fontSize:13}}>🚨 Real-time Flags</div>
                  {(flags||[]).length===0
                    ?<div style={{textAlign:'center',padding:'30px 0',color:DIM}}>
                      <div style={{fontSize:36,marginBottom:8}}>✅</div>
                      <div style={{fontSize:12}}>No suspicious activity detected</div>
                    </div>
                    :(flags||[]).slice(0,6).map((f,i)=>(
                      <div key={f._id||i} style={{...cs,padding:'10px',marginBottom:6,borderLeft:`3px solid ${f.severity==='high'?DNG:WRN}`}}>
                        <div style={{display:'flex',justifyContent:'space-between',fontSize:11}}>
                          <span style={{fontWeight:700,color:f.severity==='high'?DNG:WRN}}>{f.type}</span>
                          <span style={{color:DIM}}>{f.count}x</span>
                        </div>
                        <div style={{fontSize:10,color:DIM,marginTop:2}}>{f.studentName||'—'} · {f.examTitle||'—'}</div>
                      </div>
                    ))
                  }
                </div>
              </div>
              <div style={{...cs,marginTop:4}}>
                <div style={{fontWeight:700,marginBottom:10,fontSize:13}}>🛠️ Live Controls</div>
                <div style={{display:'flex',flexWrap:'wrap',gap:8}}>
                  <button onClick={()=>T('Exam paused globally.')} style={{...bg_}}>⏸ Pause All Exams</button>
                  <button onClick={()=>T('Emergency broadcast sent.')} style={{...bg_}}>📢 Emergency Broadcast</button>
                  <button onClick={()=>T('Server health checked — all OK.')} style={{...bg_}}>💊 Check Server Health</button>
                  <button onClick={fetchAll} style={{...bp,padding:'9px 18px'}}>🔄 Refresh Live Data</button>
                </div>
              </div>
            </div>
          )}

          {/* ══ ALL EXAMS — Feature 33 ══ */}
          {tab==='exams'&&(
            <AllExams
              token={typeof window!=='undefined'?localStorage.getItem('pr_token')||'':''}
              API={API}
              T={T}
              onCreateNew={()=>_setTab('create_exam')}
            />
          )}

          {/* ══ CREATE EXAM (3-STEP WIZARD) ══ */}
          {tab==='create_exam'&&(
            <CreateExamWizard
              token={typeof window!=='undefined'?localStorage.getItem('pr_token')||'':''}
              API={API}
              T={T}
              fetchAll={fetchAll}
              batches={batches||[]}
              testSeries={testSeries||[]}
              exams={exams||[]}
              questions={questions||[]}
              pendingTemplate={pendingTemplate}
              onTemplateConsumed={()=>setPendingTemplate(null)}
            />
          )}

          {/* ══ EXAM TEMPLATES — Feature 29 ══ */}
          {tab==='templates'&&(
            <ExamTemplates
              token={typeof window!=='undefined'?localStorage.getItem('pr_token')||'':''}
              API={API}
              T={T}
              onApply={(payload:any)=>{setPendingTemplate(payload);_setTab('create_exam')}}
            />
          )}


          {/* ══ QUESTION BANK ══ */}
          {tab==='questions'&&(
            <div style={{position:'relative'}}>

              {/* HOME */}
              {qBV==='home'&&(
                <div>
                  <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:16,flexWrap:'wrap',gap:10}}>
                    <div><div style={pageTitle}>📚 Question Bank</div><div style={pageSub}>{(questions||[]).length} questions · NEET Pattern Ready</div></div>
                    <button onClick={expQB} style={{...bg_,fontSize:11,padding:'6px 12px'}}>⬇️ Export CSV</button>
                  </div>
                  <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:14}}>
                    {[{l:'⚛️ Physics',v:(questions||[]).filter(function(q){return q.subject==='Physics'}).length,c:'#60A5FA'},{l:'🧪 Chemistry',v:(questions||[]).filter(function(q){return q.subject==='Chemistry'}).length,c:'#F472B6'},{l:'🧬 Biology',v:(questions||[]).filter(function(q){return q.subject==='Biology'}).length,c:'#34D399'},{l:'📐 Math',v:(questions||[]).filter(function(q){return q.subject==='Math'}).length,c:'#FBBF24'}].map(function(x){return(
                      <div key={x.l} style={{display:'flex',alignItems:'center',gap:5,padding:'5px 12px',background:'rgba(255,255,255,0.03)',border:'1px solid '+x.c+'30',borderRadius:20}}>
                        <span style={{fontSize:11,fontWeight:700,color:x.c}}>{x.v}</span>
                        <span style={{fontSize:10,color:'#64748B'}}>{x.l}</span>
                      </div>)})}
                  </div>
                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16,maxWidth:660,margin:'0 auto 18px'}}>
                    <div onClick={function(){setQBV('add');try{sessionStorage.setItem('pr_qbv','add')}catch{}}} style={{cursor:'pointer',background:'linear-gradient(135deg,rgba(77,159,255,0.12),rgba(160,80,255,0.08))',border:'1.5px solid rgba(77,159,255,0.3)',borderRadius:18,padding:'24px 16px',textAlign:'center'}}>
                      <div style={{fontSize:36,marginBottom:8,filter:'drop-shadow(0 0 10px rgba(77,159,255,0.5))'}}>➕</div>
                      <div style={{fontSize:15,fontWeight:800,color:'#E2E8F0',marginBottom:4}}>Add Question</div>
                      <div style={{fontSize:11,color:'#64748B',marginBottom:14}}>Manually add or AI auto-generate</div>
                      <div style={{display:'inline-block',background:'rgba(77,159,255,0.15)',border:'1px solid rgba(77,159,255,0.4)',borderRadius:8,padding:'6px 14px',fontSize:11,color:'#4D9FFF',fontWeight:700}}>Add Questions →</div>
                    </div>
                    <div onClick={function(){setQBV('preview');setQSec('all');try{sessionStorage.setItem('pr_qbv','preview')}catch{}}} style={{cursor:'pointer',background:'linear-gradient(135deg,rgba(0,229,160,0.08),rgba(160,80,255,0.06))',border:'1.5px solid rgba(0,229,160,0.25)',borderRadius:18,padding:'24px 16px',textAlign:'center'}}>
                      <div style={{fontSize:36,marginBottom:8,filter:'drop-shadow(0 0 10px rgba(0,229,160,0.4))'}}>👁️</div>
                      <div style={{fontSize:15,fontWeight:800,color:'#E2E8F0',marginBottom:4}}>Preview All Questions</div>
                      <div style={{fontSize:11,color:'#64748B',marginBottom:14}}>Browse, filter, edit section-wise</div>
                      <div style={{display:'inline-block',background:'rgba(0,229,160,0.12)',border:'1px solid rgba(0,229,160,0.35)',borderRadius:8,padding:'6px 14px',fontSize:11,color:'#00E5A0',fontWeight:700}}>Preview Bank →</div>
                    </div>
                  </div>
                  {(questions||[]).length>0&&(function(){
                    const all=questions||[];const tot=all.length||1
                    const ez=all.filter(function(q){return q.difficulty==='easy'}).length
                    const md=all.filter(function(q){return q.difficulty==='medium'}).length
                    const hd=all.filter(function(q){return q.difficulty==='hard'}).length
                    const subs=[...new Set(all.map(function(q){return q.subject||'Other'}))].length
                    return(<div style={{background:'linear-gradient(135deg,rgba(167,139,250,0.07),rgba(96,165,250,0.05))',border:'1px solid rgba(167,139,250,0.18)',borderRadius:14,padding:'14px 16px',display:'flex',alignItems:'center',gap:14,flexWrap:'wrap'}}>
                      <div style={{flex:1,minWidth:180}}>
                        <div style={{fontSize:12,fontWeight:700,color:'#A78BFA',marginBottom:3}}>🎯 Bank Ready for NEET</div>
                        <div style={{fontSize:10,color:'#64748B',lineHeight:1.5}}>{all.length} questions across {subs} subjects — fully tagged & categorized</div>
                      </div>
                      <div style={{display:'flex',gap:8}}>
                        {[{l:'Easy',v:ez,c:'#00C864'},{l:'Med',v:md,c:'#FFB300'},{l:'Hard',v:hd,c:'#FF4D4D'}].map(function(x){return(
                          <div key={x.l} style={{textAlign:'center',padding:'6px 10px',background:'rgba(255,255,255,0.03)',borderRadius:8,border:'1px solid '+x.c+'25'}}>
                            <div style={{fontSize:13,fontWeight:800,color:x.c}}>{Math.round((x.v/tot)*100)}%</div>
                            <div style={{fontSize:8,color:'#64748B',marginTop:1}}>{x.l}</div>
                          </div>)})}
                      </div>
                    </div>)
                  })()}
                </div>
              )}

              {/* ADD QUESTION */}
              {qBV==='add'&&(
                <div>
                  <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:14}}>
                    <button onClick={function(){setQBV('home');try{sessionStorage.setItem('pr_qbv','home')}catch{}}} style={{...bg_,padding:'6px 12px',fontSize:12}}>← Back</button>
                    <div><div style={pageTitle}>➕ Add Question to Bank</div><div style={pageSub}>Fill all details — saves instantly</div></div>
                    <button onClick={function(){setQBV('preview');setQSec('all');try{sessionStorage.setItem('pr_qbv','preview')}catch{}}} style={{...bp,padding:'6px 14px',fontSize:11,marginLeft:'auto',whiteSpace:'nowrap'}}>📚 Preview All →</button>
                  </div>
                  <div key={formKey} style={cs}>
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:11}}>
                      <div style={{gridColumn:'1/-1'}}>
                        <label style={lbl}>📝 Question Text (English) *</label>
                        <STextarea init={qTxtInit} onSet={function(v){qTxtR.current=v}} ph='Type the full question here…' rows={3} style={{...inp,resize:'vertical'}}/>
                  <div style={{marginTop:6,display:'flex',alignItems:'center',gap:8,flexWrap:'wrap'}}>
                    <button type='button' onClick={()=>setLatexPrev(function(p){return !p})} style={{fontSize:10,padding:'3px 10px',borderRadius:4,background:'rgba(167,139,250,0.15)',border:'1px solid rgba(167,139,250,0.3)',color:'#A78BFA',cursor:'pointer'}}>{latexPrev?'\u25b2 Hide Math':'\u25bc Preview Math \u0192(x)'}</button>
                    {draftSaved&&<span style={{fontSize:10,color:'#22c55e',marginLeft:4}}>{'\u2713 Draft saved'}</span>}
                    {draftRestored&&<span style={{fontSize:10,color:'#A78BFA',marginLeft:4}}>{'\u21ba Draft restored'}</span>}
                  </div>
                  {latexPrev&&<div style={{marginTop:6,padding:'10px 14px',background:'rgba(255,255,255,0.04)',borderRadius:6,border:'1px solid rgba(255,255,255,0.08)',color:'#E2E8F0',fontSize:13,lineHeight:1.8}}>{qTxtVal&&<div style={{marginBottom:6}}><span style={{color:'#A78BFA',fontSize:10,fontWeight:700,marginRight:6}}>ENG</span><span dangerouslySetInnerHTML={{__html:renderLatex(qTxtVal)}}/></div>}{qHindi&&<div style={{marginBottom:6}}><span style={{color:'#60A5FA',fontSize:10,fontWeight:700,marginRight:6}}>HIN</span><span dangerouslySetInnerHTML={{__html:renderLatex(qHindi)}}/></div>}{optVals.a&&<div style={{marginBottom:4}}><span style={{color:'#34D399',fontSize:10,fontWeight:700,marginRight:6}}>A</span><span dangerouslySetInnerHTML={{__html:renderLatex(optVals.a)}}/></div>}{optVals.b&&<div style={{marginBottom:4}}><span style={{color:'#34D399',fontSize:10,fontWeight:700,marginRight:6}}>B</span><span dangerouslySetInnerHTML={{__html:renderLatex(optVals.b)}}/></div>}{optVals.c&&<div style={{marginBottom:4}}><span style={{color:'#34D399',fontSize:10,fontWeight:700,marginRight:6}}>C</span><span dangerouslySetInnerHTML={{__html:renderLatex(optVals.c)}}/></div>}{optVals.d&&<div style={{marginBottom:4}}><span style={{color:'#34D399',fontSize:10,fontWeight:700,marginRight:6}}>D</span><span dangerouslySetInnerHTML={{__html:renderLatex(optVals.d)}}/></div>}{qExp&&<div style={{marginTop:4}}><span style={{color:'#FCD34D',fontSize:10,fontWeight:700,marginRight:6}}>EXP</span><span dangerouslySetInnerHTML={{__html:renderLatex(qExp)}}/></div>}{!qTxtVal&&!qHindi&&!optVals.a&&<span style={{color:'#475569',fontStyle:'italic',fontSize:12}}>Type $x^2$ in any field...</span>}</div>}
                      </div>
                      <div style={{gridColumn:'1/-1'}}>
                        <label style={lbl}>🇮🇳 Hindi Text <span style={{color:'#475569',fontSize:10}}>(optional)</span></label>
                        <textarea value={qHindi} onChange={function(e){qHindiR.current=e.target.value;setQHindi(e.target.value)}} rows={2} placeholder='हिंदी में प्रश्न (वैकल्पिक)...' style={{...inp,resize:'vertical'}}/>
                      </div>
                      <div>
                        <label style={lbl}>📚 Subject *</label>
                        <select value={qSubj} onChange={function(e){setQSubj(e.target.value)}} style={{...inp,width:'100%'}}>
                          <option value=''>— Select Subject —</option>
                          <option value='Physics'>⚛️ Physics</option>
                          <option value='Chemistry'>🧪 Chemistry</option>
                          <option value='Biology'>🧬 Biology</option>
                          <option value='Math'>📐 Math</option>
                          <option value='Other'>📖 Other</option>
                        </select>
                      </div>
                      <div>
                        <label style={lbl}>🔢 Question Type</label>
                        <select value={qType} onChange={function(e){setQType(e.target.value)}} style={{...inp,width:'100%'}}>
                          <option value='SCQ'>SCQ — Single Correct</option>
                          <option value='MSQ'>MSQ — Multiple Correct</option>
                          <option value='Integer'>Integer Type</option>
                        </select>
                      </div>
                      <div>
                        <label style={lbl}>🎯 Difficulty</label>
                        <select value={qDiff} onChange={function(e){setQDiff(e.target.value)}} style={{...inp,width:'100%'}}>
                          <option value=''>— Select —</option>
                          <option value='easy'>🟢 Easy</option>
                          <option value='medium'>🟡 Medium</option>
                          <option value='hard'>🔴 Hard</option>
                        </select>
                      </div>
                      <div>
					{qType==='Integer'?(<input type='number' value={qAns} onChange={function(e){setQAns(e.target.value)}} style={{...inp,width:'100%'}} placeholder='Enter integer answer'/>):qType==='MSQ'?(<div style={{display:'flex',gap:'10px',flexWrap:'wrap',marginTop:'6px'}}>{['A','B','C','D'].map(function(opt){const sel=Array.isArray(qAns)?qAns:qAns?qAns.split(','):[];return(<label key={opt} style={{display:'flex',alignItems:'center',gap:'6px',cursor:'pointer',padding:'6px 12px',background:sel.includes(opt)?'rgba(77,159,255,0.25)':'rgba(255,255,255,0.05)',borderRadius:'8px',border:'1px solid rgba(77,159,255,0.3)'}}><input type='checkbox' checked={sel.includes(opt)} onChange={function(){const p=Array.isArray(qAns)?[...qAns]:qAns?qAns.split(','):[];const n=p.includes(opt)?p.filter(function(x){return x!==opt}):[...p,opt];setQAns(n);}}/><span style={{color:'#E2E8F0',fontSize:'13px'}}>Option {opt}</span></label>)})}</div>):(<select value={qAns} onChange={function(e){setQAns(e.target.value)}} style={{...inp,width:'100%'}}><option value={''}>— Select Answer —</option><option value='A'>Option A</option><option value='B'>Option B</option><option value='C'>Option C</option><option value='D'>Option D</option></select>)}
                      </div>
                      <div>
                        <label style={lbl}>📖 Chapter</label><input value={qChapR.current} onChange={e=>{qChapR.current=e.target.value;setQChap(e.target.value)}} placeholder='e.g. Laws of Motion' style={{...inp}}/></div><div><label style={lbl}>📌 Topic</label>
                        <input value={qTopic} onChange={function(e){qTopicR.current=e.target.value;setQTopic(e.target.value)}} placeholder='e.g. Coulombs Law' style={{...inp}}/>
                      </div>
                      {['SCQ','MSQ'].includes(qType)&&(<>
                        <div><label style={lbl}>Option A</label><input value={optInit.a} onChange={e=>{const v=e.target.value;qA.current=v;setOptInit(p=>({...p,a:v}))}} placeholder='Option A.' style={inp}/><input value={optImgsInit.a} onChange={e=>setOptImgsInit(p=>({...p,a:e.target.value}))} placeholder='🖼️ Image URL for Option A (optional)' style={{...inp,marginTop:4,fontSize:10,color:'#a5b4fc',borderColor:'rgba(99,102,241,0.3)'}}/></div>
                        <div><label style={lbl}>Option B</label><input value={optInit.b} onChange={e=>{const v=e.target.value;qB.current=v;setOptInit(p=>({...p,b:v}))}} placeholder='Option B.' style={inp}/><input value={optImgsInit.b} onChange={e=>setOptImgsInit(p=>({...p,b:e.target.value}))} placeholder='🖼️ Image URL for Option B (optional)' style={{...inp,marginTop:4,fontSize:10,color:'#a5b4fc',borderColor:'rgba(99,102,241,0.3)'}}/></div>
                        <div><label style={lbl}>Option C</label><input value={optInit.c} onChange={e=>{const v=e.target.value;qC.current=v;setOptInit(p=>({...p,c:v}))}} placeholder='Option C.' style={inp}/><input value={optImgsInit.c} onChange={e=>setOptImgsInit(p=>({...p,c:e.target.value}))} placeholder='🖼️ Image URL for Option C (optional)' style={{...inp,marginTop:4,fontSize:10,color:'#a5b4fc',borderColor:'rgba(99,102,241,0.3)'}}/></div>
                        <div><label style={lbl}>Option D</label><input value={optInit.d} onChange={e=>{const v=e.target.value;qD.current=v;setOptInit(p=>({...p,d:v}))}} placeholder='Option D.' style={inp}/><input value={optImgsInit.d} onChange={e=>setOptImgsInit(p=>({...p,d:e.target.value}))} placeholder='🖼️ Image URL for Option D (optional)' style={{...inp,marginTop:4,fontSize:10,color:'#a5b4fc',borderColor:'rgba(99,102,241,0.3)'}}/></div>
                      </>)}
                      <div style={{gridColumn:'1/-1'}}>
                        <label style={lbl}>💡 Explanation <span style={{color:'#475569',fontSize:10}}>(optional)</span></label>
                        <textarea value={qExp} onChange={function(e){qExpR.current=e.target.value;setQExp(e.target.value)}} rows={2} placeholder='Explain the correct answer...' style={{...inp,resize:'vertical'}}/>
                      </div>
                      <div style={{gridColumn:'1/-1'}}>
                        <label style={lbl}>🖼️ Image URL <span style={{color:'#475569',fontSize:10}}>(optional)</span></label>
                        <input value={qImg} onChange={function(e){qImageR.current=e.target.value;setQImg(e.target.value)}} placeholder='https://imgur.com/... (paste image link)' style={{...inp}}/>
                      </div>
                    </div>
                    <div style={{display:'flex',gap:10,marginTop:14,flexWrap:'wrap'}}>
                      <button onClick={()=>{const dups=findDups(qTxtR.current,[qA.current,qB.current,qC.current,qD.current],questions);setDupFound(dups);setShowAddPreview(true)}} disabled={savingQ} style={{...bp,flex:2,minWidth:150,opacity:savingQ?0.7:1}}>{savingQ?'⧐ Saving…':'✅ Add to Question Bank'}</button>
                      <button onClick={function(){
                        qTxtR.current='';qHindiR.current='';qA.current='';qB.current='';qC.current='';qD.current='';
                        qChapR.current='';qTopicR.current='';qExpR.current='';qImageR.current='';
                        setQSubj('');setQDiff('medium');setQType('SCQ');setQAns('');
                        setFormKey(function(k){return k+1});try{localStorage.removeItem('pr_q_draft')}catch(e){};setQTxtVal('');setQTxtInit('');setLatexPrev(false);setOptInit({a:'',b:'',c:'',d:''});setOptImgsInit({a:'',b:'',c:'',d:''});setOptVals({a:'',b:'',c:'',d:''});T('Form cleared')
                      }} style={{...bg_,padding:'8px 16px'}}>🗑️ Clear</button>
                    </div>
                  </div>
                  <div style={{marginTop:18}}>
                    <div style={{textAlign:'center',fontSize:9,fontWeight:700,color:'#475569',letterSpacing:2,marginBottom:10,textTransform:'uppercase'}}>⚡ AI Question Generator — Choose Mode</div>
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                      {/* ── LEFT: NCERT Mode ── */}
                      <div onClick={function(){setAiGO_ncert(true)}} style={{background:'linear-gradient(160deg,rgba(168,85,247,0.12),rgba(77,159,255,0.08))',border:'1.5px solid rgba(168,85,247,0.4)',borderRadius:16,padding:'14px 12px',cursor:'pointer',textAlign:'center',transition:'all 0.25s',animation:'ncertpulse 2.5s infinite'}}>
                        <div style={{width:40,height:40,borderRadius:'50%',background:'linear-gradient(135deg,#7C3AED,#4D9FFF)',display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 8px',boxShadow:'0 0 14px rgba(168,85,247,0.5)',fontSize:18}}>🤖</div>
                        <div style={{fontSize:12,fontWeight:800,color:'#E2E8F0',marginBottom:3}}>NCERT Mode</div>
                        <div style={{fontSize:9,color:'#A78BFA',marginBottom:8}}>NEET · JEE · CUET</div>
                        <div style={{textAlign:'left'}}>
                          <div style={{fontSize:9,color:'#64748B',marginBottom:2}}>✦ Subject → Chapter → Topic</div>
                          <div style={{fontSize:9,color:'#64748B',marginBottom:2}}>✦ Auto answers & explanations</div>
                          <div style={{fontSize:9,color:'#64748B'}}>✦ 11 question formats</div>
                        </div>
                      </div>
                      {/* ── RIGHT: Files Mode ── */}
                      <div onClick={function(){setAiGO_files(true);fetchMats()}} style={{background:'linear-gradient(160deg,rgba(0,200,100,0.1),rgba(0,150,200,0.07))',border:'1.5px solid rgba(0,200,100,0.35)',borderRadius:16,padding:'14px 12px',cursor:'pointer',textAlign:'center',transition:'all 0.25s',animation:'filespulse 2.5s infinite'}}>
                        <div style={{width:40,height:40,borderRadius:'50%',background:'linear-gradient(135deg,#059669,#0EA5E9)',display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 8px',boxShadow:'0 0 14px rgba(0,200,100,0.4)',fontSize:18}}>📁</div>
                        <div style={{fontSize:12,fontWeight:800,color:'#E2E8F0',marginBottom:3}}>From Files</div>
                        <div style={{fontSize:9,color:'#00C864',marginBottom:8}}>PDF · DOCX · TXT · Notes</div>
                        <div style={{textAlign:'left'}}>
                          <div style={{fontSize:9,color:'#64748B',marginBottom:2}}>✦ Upload your own material</div>
                          <div style={{fontSize:9,color:'#64748B',marginBottom:2}}>✦ AI extracts & generates Qs</div>
                          <div style={{fontSize:9,color:'#64748B'}}>✦ Paste text also supported</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <style dangerouslySetInnerHTML={{__html:'@keyframes ncertpulse{0%,100%{box-shadow:0 0 0 rgba(168,85,247,0.3)}50%{box-shadow:0 0 18px rgba(168,85,247,0.45),0 0 30px rgba(77,159,255,0.2)}}@keyframes filespulse{0%,100%{box-shadow:0 0 0 rgba(0,200,100,0.3)}50%{box-shadow:0 0 18px rgba(0,200,100,0.4),0 0 30px rgba(0,150,200,0.2)}}@keyframes qbpulse{0%,100%{box-shadow:0 0 20px rgba(168,85,247,0.4)}50%{box-shadow:0 0 35px rgba(168,85,247,0.7),0 0 55px rgba(77,159,255,0.3)}}'}}/>
                </div>
              )}

              {/* PREVIEW ALL */}
              {showAddPreview&&(
<div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.88)',zIndex:9999,display:'flex',alignItems:'center',justifyContent:'center',padding:'12px'}} onClick={()=>setShowAddPreview(false)}>
<div style={{background:'#0d1117',border:'1px solid rgba(168,85,247,0.45)',borderRadius:16,padding:'20px',maxWidth:620,width:'100%',maxHeight:'90vh',overflowY:'auto'}} onClick={e=>e.stopPropagation()}>
<div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
<span style={{color:'#A788BF',fontWeight:700,fontSize:15}}>📋 Question Preview — Confirm before adding</span>
<button onClick={()=>setShowAddPreview(false)} style={{background:'none',border:'none',color:'#666',fontSize:22,cursor:'pointer',lineHeight:1}}>✕</button>
</div>
<div style={{background:'rgba(168,85,247,0.07)',borderRadius:10,padding:'14px',marginBottom:12}}>
<div style={{color:'#e2e8f0',fontSize:14,lineHeight:1.7,marginBottom:8}} dangerouslySetInnerHTML={{__html:renderLatex(qTxtR.current||'')}}/>
{qHindiR.current&&<div style={{color:'#94a3b8',fontSize:12,marginTop:6}} dangerouslySetInnerHTML={{__html:renderLatex(qHindiR.current)}}/>}
{qImg&&<img src={qImg} style={{maxWidth:'100%',maxHeight:120,objectFit:'contain',borderRadius:8,marginTop:8,cursor:'pointer',display:'block'}} onClick={()=>setLbImg(qImg)} onError={e=>{(e.target as HTMLImageElement).style.display='none'}}/>}
</div>
{['SCQ','MSQ'].includes(qType)&&[qA.current,qB.current,qC.current,qD.current].map((opt,i)=>{
if(!opt)return null
const L=['A','B','C','D'][i]
const isAns=qAns==='Option '+L
return <div key={i} style={{padding:'8px 12px',borderRadius:8,marginBottom:6,background:isAns?'rgba(34,197,94,0.13)':'rgba(255,255,255,0.04)',border:isAns?'1px solid rgba(34,197,94,0.5)':'1px solid rgba(255,255,255,0.08)',fontSize:13,color:isAns?'#4ade80':'#e2e8f0'}}>
<b style={{marginRight:8}}>{L}.</b><span dangerouslySetInnerHTML={{__html:renderLatex(opt)}}/>{isAns&&<span style={{marginLeft:8,fontSize:11}}>✓ Correct</span>}{(optImgsInit as any)[['a','b','c','d'][i]]?<img src={(optImgsInit as any)[['a','b','c','d'][i]]} alt='' style={{height:64,width:64,minWidth:64,objectFit:'cover',borderRadius:6,marginTop:4,cursor:'pointer',border:'1px solid rgba(99,102,241,0.4)',display:'block',flexShrink:0}} onClick={()=>setLbImg(String((optImgsInit as any)[['a','b','c','d'][i]]||''))} onError={(e:any)=>{(e.target as HTMLImageElement).style.display='none'}}/>:null}
</div>
})}
{qAns&&qAns!=='— Select Answer —'&&<div style={{background:'rgba(34,197,94,0.1)',border:'1px solid rgba(34,197,94,0.3)',borderRadius:8,padding:'8px 12px',marginBottom:8,fontSize:12,color:'#4ade80'}}>✅ Correct Answer: <b>{qAns}</b></div>}
{qExpR.current&&<div style={{background:'rgba(252,211,77,0.08)',borderRadius:8,padding:'10px',margin:'10px 0',fontSize:12,color:'#fcd34d'}} dangerouslySetInnerHTML={{__html:'💡 '+renderLatex(qExpR.current)}}/>}
<div style={{display:'flex',flexWrap:'wrap',gap:6,margin:'10px 0'}}>
{qSubj&&<span style={{background:'rgba(168,85,247,0.2)',color:'#c084fc',padding:'3px 10px',borderRadius:20,fontSize:11}}>{qSubj}</span>}
{qChapR.current&&<span style={{background:'rgba(59,130,246,0.2)',color:'#60a5fa',padding:'3px 10px',borderRadius:20,fontSize:11}}>{qChapR.current}</span>}
{qTopicR.current&&<span style={{background:'rgba(20,184,166,0.2)',color:'#2dd4bf',padding:'3px 10px',borderRadius:20,fontSize:11}}>{qTopicR.current}</span>}
{qDiff&&<span style={{background:'rgba(245,158,11,0.2)',color:'#fbbf24',padding:'3px 10px',borderRadius:20,fontSize:11}}>{qDiff}</span>}
{qType&&<span style={{background:'rgba(99,102,241,0.2)',color:'#818cf8',padding:'3px 10px',borderRadius:20,fontSize:11}}>{qType}</span>}
</div>
{dupFound.length>0&&(<div style={{background:'rgba(239,68,68,0.1)',border:'1px solid rgba(239,68,68,0.45)',borderRadius:10,padding:'11px 14px',marginBottom:12,marginTop:10}}><div style={{color:'#f87171',fontWeight:700,fontSize:12,marginBottom:5}}>⚠️ Duplicate Detected — {dupFound.length} similar question{dupFound.length>1?'s are':' is'} already in the bank</div>{dupFound.slice(0,2).map((dq:any,di:number)=>(<div key={di} style={{fontSize:11,color:'#94a3b8',padding:'4px 8px',background:'rgba(239,68,68,0.07)',borderRadius:6,marginBottom:3}}>🔴 {(dq.text||'').slice(0,80)}{(dq.text||'').length>80?'…':''}</div>))}<div style={{fontSize:10,color:'#f87171',marginTop:5,opacity:0.8}}>You can still save — but duplicate questions reduce paper quality.</div></div>)}
<div style={{display:'flex',gap:10,justifyContent:'flex-end',marginTop:16}}>
<button onClick={()=>setShowAddPreview(false)} style={{padding:'10px 20px',borderRadius:8,background:'rgba(255,255,255,0.05)',border:'1px solid rgba(255,255,255,0.15)',color:'#94a3b8',cursor:'pointer',fontSize:13}}>✏️ Edit</button>
<button onClick={()=>{setShowAddPreview(false);confirmAndAdd()}} disabled={savingQ} style={{padding:'10px 24px',borderRadius:8,background:'linear-gradient(135deg,#7c3aed,#4f46e5)',border:'none',color:'#fff',cursor:'pointer',fontSize:13,fontWeight:700}}>{savingQ?'Adding...':'✅ Confirm & Add'}</button>
</div>
</div>
</div>
)}
{showAiPreview&&(
<div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.92)',zIndex:9999,display:'flex',alignItems:'center',justifyContent:'center',padding:'12px'}} onClick={()=>setShowAiPreview(false)}>
<div style={{background:'#0d1117',border:'1px solid rgba(168,85,247,0.4)',borderRadius:16,padding:'20px',maxWidth:660,width:'100%',maxHeight:'92vh',overflowY:'auto'}} onClick={e=>e.stopPropagation()}>
<div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
<span style={{color:'#A788BF',fontWeight:700,fontSize:15}}>🤖 AI Questions Preview ({aiResult.length})</span>
<button onClick={()=>setShowAiPreview(false)} style={{background:'none',border:'none',color:'#666',fontSize:22,cursor:'pointer'}}>✕</button>
</div>
<div style={{marginBottom:14}}>
{aiGResult.map((q:any,i:number)=>(
<div key={i} style={{background:'rgba(168,85,247,0.06)',border:'1px solid rgba(168,85,247,0.2)',borderRadius:10,padding:'12px',marginBottom:10,position:'relative'}}>
<div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:8}}>
<span style={{color:'#c084fc',fontSize:11,fontWeight:700}}>Q{i+1}</span>{aiDupMap[i]&&<span style={{background:'rgba(239,68,68,0.22)',color:'#f87171',fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:10,marginLeft:6,border:'1px solid rgba(239,68,68,0.5)'}}>⚠️ Duplicate in Bank</span>}
<div style={{display:'flex',gap:6}}>
<button onClick={()=>{setAiEditIdx(i);setAiEditQ({...q})}} style={{background:'rgba(59,130,246,0.2)',border:'1px solid rgba(59,130,246,0.4)',color:'#60a5fa',borderRadius:6,padding:'3px 10px',fontSize:11,cursor:'pointer'}}>✏️ Edit</button>
<button onClick={()=>setAiGResult((p:any[])=>p.filter((_:any,j:number)=>j!==i))} style={{background:'rgba(239,68,68,0.15)',border:'1px solid rgba(239,68,68,0.4)',color:'#f87171',borderRadius:6,padding:'3px 10px',fontSize:11,cursor:'pointer'}}>🗑️ Delete</button>
</div>
</div>
<div style={{color:'#e2e8f0',fontSize:13,marginBottom:6}} dangerouslySetInnerHTML={{__html:renderLatex(q.text||q.question||'')}}/>
{q.options&&q.options.map((opt:string,j:number)=>{
const L=['A','B','C','D'][j]
const isAns=q.correctAnswer===('Option '+L)||q.correctAnswer===L||q.correctLetter===L||q.correct_answer===('Option '+L)||q.correct_answer===L||(Array.isArray(q.correct)&&q.correct.includes(j))
return <div key={j} style={{fontSize:12,padding:'4px 8px',borderRadius:6,marginBottom:3,background:isAns?'rgba(34,197,94,0.12)':'rgba(255,255,255,0.03)',border:isAns?'1px solid rgba(34,197,94,0.4)':'1px solid rgba(255,255,255,0.06)',color:isAns?'#4ade80':'#94a3b8'}}>
<b>{L}.</b> <span dangerouslySetInnerHTML={{__html:renderLatex((opt||'').replace(/^[A-Da-d][\.\)\:]\s*/,'').trim())}}/>{isAns&&<span style={{marginLeft:6,fontSize:10}}>✓</span>}
</div>
})}
{(q.explanation||q.exp)&&<div style={{fontSize:11,color:'#fcd34d',marginTop:6,padding:'4px 8px',background:'rgba(252,211,77,0.07)',borderRadius:6}}>💡 <span dangerouslySetInnerHTML={{__html:renderLatex(formatQText(q.explanation||q.exp||''))}}/></div>}
{aiDupMap[i]&&<div style={{background:'rgba(239,68,68,0.09)',border:'1px solid rgba(239,68,68,0.35)',borderRadius:7,padding:'7px 10px',marginTop:6,fontSize:11,color:'#f87171'}}>⚠️ Already in bank: <span style={{color:'#94a3b8'}}>{(aiDupMap[i].text||'').slice(0,70)}{(aiDupMap[i].text||'').length>70?'…':''}</span></div>}
</div>
))}
</div>
{aiGResult.length===0&&<div style={{color:'#f87171',textAlign:'center',padding:'20px'}}>All questions deleted!</div>}
<div style={{display:'flex',gap:10,justifyContent:'flex-end'}}>
<button onClick={()=>setShowAiPreview(false)} style={{padding:'10px 20px',borderRadius:8,background:'rgba(255,255,255,0.05)',border:'1px solid rgba(255,255,255,0.15)',color:'#94a3b8',cursor:'pointer',fontSize:13}}>Cancel</button>
<button onClick={()=>{setShowAiPreview(false);saveAiQs()}} disabled={aiGResult.length===0||aiSaving} style={{padding:'10px 24px',borderRadius:8,background:'linear-gradient(135deg,#7c3aed,#4f46e5)',border:'none',color:'#fff',cursor:'pointer',fontSize:13,fontWeight:700}}>{aiSaving?'Saving...':'✅ Confirm Save All ('+aiGResult.length+')'}</button>
</div>
</div>
</div>
)}

{aiEditQ!==null&&aiEditIdx!==null&&(
<div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.92)',zIndex:10000,display:'flex',alignItems:'center',justifyContent:'center',padding:'12px'}} onClick={()=>setAiEditQ(null)}>
<div style={{background:'#0d1117',border:'1px solid rgba(168,85,247,0.4)',borderRadius:16,padding:'20px',maxWidth:600,width:'100%',maxHeight:'90vh',overflowY:'auto'}} onClick={e=>e.stopPropagation()}>
<div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
<span style={{color:'#A788BF',fontWeight:700,fontSize:15}}>✏️ Edit Q{(aiEditIdx||0)+1}</span>
<button onClick={()=>setAiEditQ(null)} style={{background:'none',border:'none',color:'#666',fontSize:22,cursor:'pointer'}}>✕</button>
</div>
<div style={{marginBottom:10}}><label style={lbl}>Question Text</label><textarea value={aiEditQ.text||aiEditQ.question||''} onChange={e=>setAiEditQ((p:any)=>({...p,text:e.target.value,question:e.target.value}))} rows={3} style={{...inp,resize:'vertical' as any}}/></div>
{[0,1,2,3].map(j=>(
<div key={j} style={{marginBottom:8}}><label style={lbl}>Option {['A','B','C','D'][j]}</label>
<input value={aiEditQ.options?.[j]||''} onChange={e=>setAiEditQ((p:any)=>{const o=[...(p.options||['','','',''])];o[j]=e.target.value;return{...p,options:o}})} style={{...inp}}/>
</div>
))}
<div style={{marginBottom:10}}><label style={lbl}>Correct Answer</label>
<select value={aiEditQ.correctAnswer||aiEditQ.correct_answer||''} onChange={e=>setAiEditQ((p:any)=>({...p,correctAnswer:e.target.value,correct_answer:e.target.value}))} style={{...inp,width:'100%'}}>
<option value=''>Select</option>
{['A','B','C','D'].map(l=><option key={l} value={'Option '+l}>Option {l}</option>)}
</select></div>
<div style={{marginBottom:10}}><label style={lbl}>Explanation</label><textarea value={aiEditQ.explanation||aiEditQ.exp||''} onChange={e=>setAiEditQ((p:any)=>({...p,explanation:e.target.value,exp:e.target.value}))} rows={2} style={{...inp,resize:'vertical' as any}}/></div>
<div style={{display:'flex',gap:10,justifyContent:'flex-end',marginTop:16}}>
<button onClick={()=>setAiEditQ(null)} style={{padding:'10px 20px',borderRadius:8,background:'rgba(255,255,255,0.05)',border:'1px solid rgba(255,255,255,0.15)',color:'#94a3b8',cursor:'pointer'}}>Cancel</button>
<button onClick={()=>{setAiGResult((p:any[])=>{const a=[...p];const _q={...aiEditQ};const _optMap={'Option A':0,'Option B':1,'Option C':2,'Option D':3};const _ci=_optMap[_q.correctAnswer];if(_ci!==undefined){_q.correct=[_ci];_q.correctLetter=['A','B','C','D'][_ci];}a[aiEditIdx as number]=_q;return a});setAiEditQ(null)}} style={{padding:'10px 24px',borderRadius:8,background:'linear-gradient(135deg,#7c3aed,#4f46e5)',border:'none',color:'#fff',cursor:'pointer',fontWeight:700}}>💾 Save</button>
</div>
</div>
</div>
)}

{qBV==='preview'&&(
                <PreviewAllQuestions
                  questions={questions||[]}
                  exams={exams||[]}
                  token={typeof window!=='undefined'?localStorage.getItem('pr_token')||'':''}
                  API={API}
                  T={T}
                  fetchAll={fetchAll}
                  onBack={function(){setQBV('home');setBulkSel([]);try{sessionStorage.setItem('pr_qbv','home')}catch{}}}
                  onGoAdd={function(){setQBV('add');try{sessionStorage.setItem('pr_qbv','add')}catch{}}}
                  qLang={qLang} setQLang={setQLang}
                  qSec={qSec} setQSec={setQSec}
                  qBioSub={qBioSub} setQBioSub={setQBioSub}
                  qChapFilter={qChapFilter} setQChapFilter={setQChapFilter}
                  qSearch={qSearch} setQSearch={setQSearch}
                  qPage={_qPg} setQPage={setQPage}
                  qfApproval={qfApproval} setQfApproval={setQfApproval}
                  qfDiff2={qfDiff2} setQfDiff2={setQfDiff2}
                  qfType={qfType} setQfType={setQfType}
                  qfUsage={qfUsage} setQfUsage={setQfUsage}
                  qfLevel={qfLevel} setQfLevel={setQfLevel}
                  qfFormat={qfFormat} setQfFormat={setQfFormat}
                  qfDate={qfDate} setQfDate={setQfDate}
                  stdPrv={stdPrv} setStdPrv={setStdPrv}
                  bulkSel={bulkSel} setBulkSel={setBulkSel}
                  openA2E={openA2E}
                  fQs={fQs} pagedQs={pagedQs} _fQsSorted={_fQsSorted} _qPg={_qPg} _qTP={_qTP}
                  setSelQId={setSelQId}
                  fetchUsageStats={fetchUsageStats}
                  setEditQD={setEditQD}
                  copyToAddForm={copyToAddForm}
                  expQB={expQB}
                  expQBPdf={expQBPdf}
                  longPressTimerRef={longPressTimerRef}
                  longPressFiredRef={longPressFiredRef}
                  blkApproveQs={blkApproveQs}
                />
              )}

              {/* ════════════════════════════════════════════════════ */}
              {/* NCERT MODE MODAL — Fully Independent               */}
              {/* ════════════════════════════════════════════════════ */}
              {/* ── Feature 1.2: Floating Bottom Bar ── */}
              {bulkSel.length>0&&(
                <div style={{position:'fixed',bottom:0,left:0,right:0,zIndex:998,background:'linear-gradient(135deg,#0D1B2A,#142840)',borderTop:'1.5px solid rgba(77,159,255,0.35)',padding:'10px 16px',display:'flex',alignItems:'center',justifyContent:'center',gap:12,boxShadow:'0 -4px 20px rgba(0,0,0,0.4)',flexWrap:'wrap'}}>
                  <span style={{fontSize:12,color:'#E8F4FF',fontWeight:700}}>{bulkSel.length} Questions Selected</span>
                  <button onClick={openA2E} style={{...bp,fontSize:12,padding:'8px 18px'}}>➕ Add to Exam →</button>
                </div>
              )}

              {/* ── Feature 1.3: Add to Exam Modal ── */}
              {showA2E&&(
                <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.85)',zIndex:1001,display:'flex',alignItems:'center',justifyContent:'center',padding:14}}>
                  <div style={{background:'linear-gradient(160deg,#0D1B2A,#0F1E30)',border:'1px solid rgba(77,159,255,0.35)',borderRadius:18,padding:18,width:'100%',maxWidth:440,maxHeight:'90vh',overflowY:'auto'}}>
                    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
                      <div style={{fontSize:14,fontWeight:800,color:'#E2E8F0'}}>➕ Add {bulkSel.length} Question(s) to Exam</div>
                      <button onClick={function(){setShowA2E(false)}} style={{...bg_,padding:'4px 10px',fontSize:12}}>✕</button>
                    </div>
                    <div style={{display:'flex',gap:6,marginBottom:14}}>
                      <button onClick={function(){setA2eTab('existing')}} style={{...(a2eTab==='existing'?bp:bg_),flex:1,fontSize:11,padding:'8px 6px'}}>📋 Existing Exam</button>
                      <button onClick={function(){setA2eTab('new')}} style={{...(a2eTab==='new'?bp:bg_),flex:1,fontSize:11,padding:'8px 6px'}}>🆕 New Exam</button>
                    </div>
                    {a2eTab==='existing'?(
                      <div>
                        <label style={lbl}>Select Exam</label>
                        <select value={a2eExamId} onChange={function(e){setA2eExamId(e.target.value)}} style={{...inp,width:'100%',marginBottom:12}}>
                          <option value=''>— Select Exam —</option>
                          {(a2eExamsList||[]).map(function(e){return <option key={e._id} value={e._id}>{e.title}{e.questions?' ('+e.questions.length+' Qs)':''}</option>})}
                        </select>
                        {a2eExamsList.length===0&&<div style={{fontSize:10,color:'#64748B',marginBottom:10}}>No exams found — create a new one in the other tab.</div>}
                        <button onClick={submitA2EExisting} disabled={a2eSaving||!a2eExamId} style={{...bp,width:'100%',opacity:(a2eSaving||!a2eExamId)?0.6:1}}>{a2eSaving?'⧐ Adding…':'✅ Add to Selected Exam'}</button>
                      </div>
                    ):(
                      <div>
                        <label style={lbl}>Exam Title *</label>
                        <input value={a2eTitle} onChange={function(e){setA2eTitle(e.target.value)}} placeholder='e.g. NEET Mock Test 12' style={{...inp,width:'100%',marginBottom:10}}/>
                        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:12}}>
                          <div><label style={lbl}>Duration (min) *</label><input type='number' value={a2eDuration} onChange={function(e){setA2eDuration(e.target.value)}} style={{...inp,width:'100%'}}/></div>
                          <div><label style={lbl}>Total Marks</label><input type='number' value={a2eMarks} onChange={function(e){setA2eMarks(e.target.value)}} style={{...inp,width:'100%'}}/></div>
                        </div>
                        <button onClick={submitA2ENew} disabled={a2eSaving} style={{...bp,width:'100%',opacity:a2eSaving?0.6:1}}>{a2eSaving?'⧐ Creating…':'✅ Create Exam with '+bulkSel.length+' Questions'}</button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ── Feature 4: Bulk Edit Modal ── */}
              {showBulkEdit&&(
                <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.85)',zIndex:1001,display:'flex',alignItems:'center',justifyContent:'center',padding:14}}>
                  <div style={{background:'linear-gradient(160deg,#0D1B2A,#0F1E30)',border:'1px solid rgba(167,139,250,0.35)',borderRadius:18,padding:18,width:'100%',maxWidth:440,maxHeight:'90vh',overflowY:'auto'}}>
                    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
                      <div style={{fontSize:14,fontWeight:800,color:'#E2E8F0'}}>✏️ Bulk Edit {bulkSel.length} Question(s)</div>
                      <button onClick={function(){setShowBulkEdit(false)}} style={{...bg_,padding:'4px 10px',fontSize:12}}>✕</button>
                    </div>
                    <div style={{fontSize:10,color:'#64748B',marginBottom:10}}>Only filled fields will be applied. Leave blank to skip.</div>
                    <div style={{marginBottom:10}}><label style={lbl}>Subject</label>
                      <select value={beFields.subject} onChange={function(e){setBeFields(function(p){return Object.assign({},p,{subject:e.target.value})})}} style={{...inp,width:'100%'}}>
                        <option value=''>— Skip —</option><option value='Physics'>Physics</option><option value='Chemistry'>Chemistry</option><option value='Biology'>Biology</option><option value='Math'>Math</option>
                      </select></div>
                    <div style={{marginBottom:10}}><label style={lbl}>Difficulty</label>
                      <select value={beFields.difficulty} onChange={function(e){setBeFields(function(p){return Object.assign({},p,{difficulty:e.target.value})})}} style={{...inp,width:'100%'}}>
                        <option value=''>— Skip —</option><option value='Easy'>Easy</option><option value='Medium'>Medium</option><option value='Hard'>Hard</option>
                      </select></div>
                    <div style={{marginBottom:10}}><label style={lbl}>Type</label>
                      <select value={beFields.type} onChange={function(e){setBeFields(function(p){return Object.assign({},p,{type:e.target.value})})}} style={{...inp,width:'100%'}}>
                        <option value=''>— Skip —</option><option value='SCQ'>SCQ</option><option value='MSQ'>MSQ</option><option value='Integer'>Integer</option>
                      </select></div>
                    <div style={{marginBottom:10}}><label style={lbl}>Chapter</label>
                      <input value={beFields.chapter} onChange={function(e){setBeFields(function(p){return Object.assign({},p,{chapter:e.target.value})})}} placeholder='— Skip —' style={{...inp,width:'100%'}}/></div>
                    <div style={{marginBottom:14}}><label style={lbl}>Exam Level</label>
                      <select value={beFields.examLevel} onChange={function(e){setBeFields(function(p){return Object.assign({},p,{examLevel:e.target.value})})}} style={{...inp,width:'100%'}}>
                        <option value=''>— Skip —</option><option value='NEET'>NEET</option><option value='JEE_MAINS'>JEE_MAINS</option><option value='JEE_ADVANCED'>JEE_ADVANCED</option><option value='CUET'>CUET</option><option value='BOARD'>BOARD</option>
                      </select></div>
                    <button onClick={submitBulkEdit} disabled={beSaving} style={{...bp,width:'100%',opacity:beSaving?0.6:1}}>{beSaving?'⧐ Applying…':'✅ Apply to '+bulkSel.length+' Questions'}</button>
                  </div>
                </div>
              )}

              {/* ── Feature 2: Usage Stats Modal ── */}
              {usageStatsQ&&(
                <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.85)',zIndex:1001,display:'flex',alignItems:'center',justifyContent:'center',padding:14}}>
                  <div style={{background:'linear-gradient(160deg,#0D1B2A,#0F1E30)',border:'1px solid rgba(96,165,250,0.35)',borderRadius:18,padding:18,width:'100%',maxWidth:400}}>
                    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
                      <div style={{fontSize:14,fontWeight:800,color:'#E2E8F0'}}>📊 Question Usage Stats</div>
                      <button onClick={function(){setUsageStatsQ(null);setUsageStatsData(null)}} style={{...bg_,padding:'4px 10px',fontSize:12}}>✕</button>
                    </div>
                    <div style={{fontSize:11,color:'#94A3B8',marginBottom:12,lineHeight:1.5}}>{(usageStatsQ.text||'').slice(0,100)}{(usageStatsQ.text||'').length>100?'…':''}</div>
                    {usageStatsLoading?(
                      <div style={{textAlign:'center',padding:20,fontSize:12,color:'#64748B'}}>⧐ Loading stats…</div>
                    ):usageStatsData&&usageStatsData.success?(
                      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8}}>
                        <div style={{background:'rgba(96,165,250,0.08)',border:'1px solid rgba(96,165,250,0.25)',borderRadius:10,padding:'12px 6px',textAlign:'center'}}>
                          <div style={{fontSize:20,fontWeight:800,color:'#60A5FA'}}>{usageStatsData.examsUsedIn}</div>
                          <div style={{fontSize:9,color:'#64748B',marginTop:2}}>Exams Used In</div>
                        </div>
                        <div style={{background:'rgba(167,139,250,0.08)',border:'1px solid rgba(167,139,250,0.25)',borderRadius:10,padding:'12px 6px',textAlign:'center'}}>
                          <div style={{fontSize:20,fontWeight:800,color:'#A78BFA'}}>{usageStatsData.timesAttempted}</div>
                          <div style={{fontSize:9,color:'#64748B',marginTop:2}}>Times Attempted</div>
                        </div>
                        <div style={{background:'rgba(0,200,100,0.08)',border:'1px solid rgba(0,200,100,0.25)',borderRadius:10,padding:'12px 6px',textAlign:'center'}}>
                          <div style={{fontSize:20,fontWeight:800,color:'#00C864'}}>{usageStatsData.successRate}%</div>
                          <div style={{fontSize:9,color:'#64748B',marginTop:2}}>Success Rate</div>
                        </div>
                      </div>
                    ):(
                      <div style={{textAlign:'center',padding:20,fontSize:12,color:'#F87171'}}>Failed to load stats</div>
                    )}
                  </div>
                </div>
              )}

              {aiGO_ncert&&(function(){
                const NCERT={"Physics":{"11th - Physical World":["Nature of Physical Laws","Fundamental Forces"],"11th - Units & Measurements":["SI Units","Significant Figures","Errors in Measurement","Dimensional Analysis"],"11th - Motion in Straight Line":["Distance & Displacement","Velocity & Acceleration","Equations of Motion","Relative Motion"],"11th - Motion in a Plane":["Vectors","Projectile Motion","Circular Motion","Relative Velocity"],"11th - Laws of Motion":["Newtons Laws","Friction","Inertia","Momentum","Conservation of Momentum"],"11th - Work Energy Power":["Work Done","Kinetic Energy","Potential Energy","Conservation of Energy","Power"],"11th - System of Particles":["Centre of Mass","Angular Momentum","Torque","Rotational Motion"],"11th - Gravitation":["Keplers Laws","Universal Gravitation","Gravitational Potential Energy","Satellites","Escape Velocity"],"11th - Mechanical Properties Solids":["Stress & Strain","Youngs Modulus","Bulk Modulus","Shear Modulus"],"11th - Mechanical Properties Fluids":["Pressure","Archimedes Principle","Bernoullis Theorem","Viscosity","Surface Tension"],"11th - Thermal Properties":["Temperature","Thermal Expansion","Calorimetry","Heat Transfer","Radiation"],"11th - Thermodynamics":["Zeroth Law","First Law","Second Law","Carnot Engine","Entropy"],"11th - Kinetic Theory":["Kinetic Theory of Gases","Mean Free Path","Degrees of Freedom","Specific Heat Capacity"],"11th - Oscillations":["Simple Harmonic Motion","Time Period","Amplitude","Damped Oscillations","Resonance"],"11th - Waves":["Wave Motion","Speed of Sound","Superposition","Stationary Waves","Doppler Effect"],"12th - Electric Charges & Fields":["Coulombs Law","Electric Field","Gauss Law","Electric Dipole","Electric Flux"],"12th - Electrostatic Potential":["Electric Potential","Potential Energy","Capacitance","Dielectrics","Van de Graaff"],"12th - Current Electricity":["Ohms Law","Kirchhoffs Laws","Wheatstone Bridge","Potentiometer","EMF & Internal Resistance"],"12th - Moving Charges & Magnetism":["Biot Savart Law","Amperes Law","Cyclotron","Magnetic Force on Current"],"12th - Magnetism & Matter":["Magnetic Dipole","Earths Magnetism","Diamagnetic Paramagnetic Ferromagnetic","Hysteresis"],"12th - Electromagnetic Induction":["Faradays Law","Lenzs Law","Mutual Inductance","Self Inductance","Eddy Currents"],"12th - Alternating Current":["AC Generator","RMS Values","Impedance","Resonance","Power Factor","Transformer"],"12th - Electromagnetic Waves":["Displacement Current","EM Spectrum","Properties of EM Waves"],"12th - Ray Optics":["Reflection","Refraction","Total Internal Reflection","Lenses","Optical Instruments","Prism"],"12th - Wave Optics":["Huygens Principle","Interference","Diffraction","Polarisation","Youngs Double Slit"],"12th - Dual Nature of Radiation":["Photoelectric Effect","De Broglie Wavelength","Davisson Germer"],"12th - Atoms":["Bohr Model","Hydrogen Spectrum","Atomic Spectra"],"12th - Nuclei":["Nuclear Binding Energy","Radioactivity","Nuclear Fission & Fusion","Half Life"],"12th - Semiconductor Electronics":["P-N Junction","Diode","Transistor","Logic Gates","Rectification"]},"Chemistry":{"11th - Basic Concepts":["Mole Concept","Stoichiometry","Limiting Reagent","Atomic Mass","Molecular Formula"],"11th - Structure of Atom":["Bohr Model","Quantum Numbers","Orbitals","Electronic Configuration","Aufbau Principle"],"11th - Classification of Elements":["Modern Periodic Table","Periodicity","Atomic Radius","Ionisation Enthalpy","Electronegativity"],"11th - Chemical Bonding":["Ionic Bond","Covalent Bond","VSEPR Theory","Hybridisation","Hydrogen Bond","Molecular Orbital Theory"],"11th - States of Matter":["Ideal Gas Equation","Kinetic Molecular Theory","Real Gases","Van der Waals"],"11th - Thermodynamics":["Enthalpy","Entropy","Gibbs Energy","Hess Law","Bond Enthalpy"],"11th - Equilibrium":["Law of Mass Action","Kp Kc","Le Chateliers Principle","Buffer Solution","pH & Ionic Equilibrium"],"11th - Redox Reactions":["Oxidation Reduction","Oxidation Number","Balancing Redox","Electrochemical Series"],"11th - Hydrogen":["Hydrogen Bonding","Water","Heavy Water","Hydrogen Peroxide"],"11th - s-Block Elements":["Alkali Metals","Alkaline Earth Metals","Sodium Potassium Compounds","Calcium Compounds"],"11th - p-Block Elements":["Group 13 14","Borax","Carbon Allotropes","Nitrogen Compounds","Phosphorus"],"11th - Organic Chemistry Basics":["Hybridisation","Functional Groups","Homologous Series","IUPAC Nomenclature","Isomerism"],"11th - Hydrocarbons":["Alkanes","Alkenes","Alkynes","Benzene","Aromaticity","Conformations"],"11th - Environmental Chemistry":["Air Pollution","Water Pollution","Greenhouse Effect","Ozone Depletion"],"12th - Solid State":["Crystal Systems","Packing Efficiency","Defects in Crystals","Magnetic Properties"],"12th - Solutions":["Molarity Molality","Raoults Law","Colligative Properties","Osmosis","Van t Hoff Factor"],"12th - Electrochemistry":["Galvanic Cells","Electrode Potential","Nernst Equation","Electrolysis","Faradays Laws"],"12th - Chemical Kinetics":["Rate of Reaction","Order of Reaction","Arrhenius Equation","Activation Energy","Collision Theory"],"12th - Surface Chemistry":["Adsorption","Catalysis","Colloids","Emulsions","Micelles"],"12th - General Principles Isolation":["Thermodynamics of Extraction","Ellingham Diagram","Refining Methods"],"12th - p-Block 15to18":["Nitrogen Family","Oxygen & Sulphur","Halogens","Noble Gases","Interhalogen Compounds"],"12th - d-Block Elements":["Transition Metals","Properties","Potassium Dichromate","Potassium Permanganate"],"12th - Coordination Compounds":["Ligands","CFSE","Crystal Field Theory","Isomerism","Bonding"],"12th - Haloalkanes Haloarenes":["Nomenclature","SN1 SN2","Elimination","Aryl Halides"],"12th - Alcohols Phenols Ethers":["Preparation","Properties","Reactions","Lucas Test","Victor Meyer"],"12th - Aldehydes & Ketones":["Nucleophilic Addition","Aldol Condensation","Cannizzaro","Tollens Fehlings"],"12th - Carboxylic Acids":["Acidity","Esterification","Hell Volhard Zelinsky","Derivatives"],"12th - Amines":["Basicity","Diazonium Salts","Coupling Reactions","Hoffmann Bromamide"],"12th - Biomolecules":["Carbohydrates","Proteins","Nucleic Acids","Vitamins","Enzymes"],"12th - Polymers":["Addition Polymerisation","Condensation","Rubber","Plastics","Biodegradable"],"12th - Chemistry Everyday Life":["Drugs","Food Preservatives","Cleansing Agents","Antimicrobials"]},"Biology":{"11th - The Living World":["Characteristics of Living Organisms","Biodiversity","Taxonomy","Nomenclature","Keys"],"11th - Biological Classification":["Five Kingdom Classification","Monera","Protista","Fungi","Viruses","Lichens"],"11th - Plant Kingdom":["Algae","Bryophyta","Pteridophyta","Gymnosperms","Angiosperms","Alternation of Generations"],"11th - Animal Kingdom":["Basis of Classification","Porifera","Coelenterata","Platyhelminthes","Annelida","Arthropoda","Chordata"],"11th - Morphology of Flowering Plants":["Root Modifications","Stem Modifications","Leaf Modifications","Inflorescence","Flower","Fruit & Seed"],"11th - Anatomy of Flowering Plants":["Meristematic Tissue","Permanent Tissue","Anatomy of Root Stem Leaf"],"11th - Structural Organisation Animals":["Epithelial Tissue","Connective Tissue","Muscle Tissue","Neural Tissue","Frog Anatomy"],"11th - Cell Unit of Life":["Cell Theory","Prokaryotic Cell","Eukaryotic Cell","Cell Organelles","Nucleus"],"11th - Biomolecules":["Carbohydrates","Proteins","Lipids","Nucleic Acids","Enzymes","Metabolism"],"11th - Cell Cycle & Division":["Cell Cycle","Mitosis","Meiosis","Significance"],"11th - Transport in Plants":["Absorption","Apoplast Symplast","Transpiration","Ascent of Sap","Translocation"],"11th - Mineral Nutrition":["Essential Elements","Mineral Deficiency","Nitrogen Fixation","Hydroponics"],"11th - Photosynthesis":["Light Reaction","Calvin Cycle","C4 Pathway","CAM","Photorespiration"],"11th - Respiration in Plants":["Glycolysis","Krebs Cycle","Electron Transport Chain","Fermentation"],"11th - Plant Growth":["Phases of Growth","Plant Hormones","Auxin Gibberellin Cytokinin","Photoperiodism"],"11th - Digestion & Absorption":["Human Digestive System","Digestion Process","Absorption","Disorders"],"11th - Breathing & Exchange":["Respiratory System","Mechanism of Breathing","Gas Exchange","Respiratory Disorders"],"11th - Body Fluids":["Blood Composition","Blood Groups","Coagulation","Lymph","Circulatory System","ECG"],"11th - Locomotion & Movement":["Types of Movement","Muscle Contraction","Skeletal System","Joints","Disorders"],"11th - Neural Control":["Neuron Structure","Nerve Impulse","Synapse","Human Brain","Spinal Cord","Sense Organs"],"11th - Chemical Coordination":["Endocrine Glands","Hormones","Feedback Mechanism","Disorders"],"12th - Reproduction in Organisms":["Modes of Reproduction","Vegetative Propagation","Asexual Reproduction"],"12th - Sexual Reproduction Plants":["Flower Structure","Microsporogenesis","Megasporogenesis","Fertilisation","Embryo Development"],"12th - Human Reproduction":["Male Reproductive System","Female Reproductive System","Gametogenesis","Menstrual Cycle","Fertilisation"],"12th - Reproductive Health":["Contraception","Infertility","STDs","Amniocentesis"],"12th - Principles of Inheritance":["Mendels Laws","Chromosomal Theory","Linkage","Mutation","Sex Determination"],"12th - Molecular Basis of Inheritance":["DNA Structure","Replication","Transcription","Translation","Genetic Code","Regulation"],"12th - Evolution":["Origin of Life","Darwins Theory","Natural Selection","Speciation","Human Evolution"],"12th - Human Health Disease":["Immunity","Vaccines","Common Diseases","Cancer","Drugs & Alcohol"],"12th - Strategies Enhancement":["Animal Breeding","Plant Breeding","Biofortification","SCP","Tissue Culture"],"12th - Microbes Human Welfare":["Biogas","Biocontrol","Biofertilisers","Industrial Microbiology"],"12th - Biotechnology Principles":["Recombinant DNA","Restriction Enzymes","Vectors","PCR","Gel Electrophoresis"],"12th - Biotechnology Applications":["Transgenic Organisms","GM Crops","Gene Therapy","Molecular Diagnosis"],"12th - Organisms & Populations":["Habitat & Niche","Population Interactions","Adaptations","Population Attributes"],"12th - Ecosystem":["Ecosystem Structure","Food Chain","Energy Flow","Nutrient Cycling","Ecological Succession"],"12th - Biodiversity":["Levels of Biodiversity","Loss of Biodiversity","Conservation Strategies","Hotspots"],"12th - Environmental Issues":["Air Pollution","Water Pollution","Solid Waste","Greenhouse Effect","Ozone Depletion"]},"Math":{"11th - Sets":["Types of Sets","Set Operations","Venn Diagrams","De Morgans Laws"],"11th - Relations & Functions":["Types of Relations","Types of Functions","Composition","Domain Range"],"11th - Trigonometric Functions":["Angles","Basic Identities","Values of Standard Angles","Graphs","Equations"],"11th - Mathematical Induction":["Principle of Induction","Problems on Induction"],"11th - Complex Numbers":["Algebra of Complex Numbers","Modulus Argument","Polar Form","De Moivres Theorem"],"11th - Linear Inequalities":["Algebraic Solutions","Graphical Solutions","System of Inequalities"],"11th - Permutations & Combinations":["Fundamental Principle","Permutations","Combinations","Applications"],"11th - Binomial Theorem":["Binomial Expansion","General Term","Middle Term","Properties"],"11th - Sequences & Series":["AP","GP","HP","Sum of Series","AM GM Inequality"],"11th - Straight Lines":["Slope","Forms of Line Equation","Distance","Family of Lines"],"11th - Conic Sections":["Circle","Parabola","Ellipse","Hyperbola","Standard Equations"],"11th - 3D Geometry Intro":["Coordinates","Distance","Section Formula","Locus"],"11th - Limits & Derivatives":["Limit of Function","Standard Limits","Derivatives","Differentiation Rules"],"11th - Statistics":["Mean Median Mode","Variance","Standard Deviation","Coefficient of Variation"],"11th - Probability":["Random Experiments","Events","Axiomatic Approach","Addition Theorem"],"12th - Relations & Functions":["Binary Operations","Inverse Functions","Composition"],"12th - Inverse Trigonometry":["Inverse Trig Functions","Properties","Equations"],"12th - Matrices":["Matrix Operations","Types","Transpose","Adjoint","Inverse"],"12th - Determinants":["Properties","Minors Cofactors","Area of Triangle","Cramers Rule"],"12th - Continuity & Differentiability":["Continuity","Differentiability","Rolle Mean Value Theorem","Logarithmic Differentiation"],"12th - Applications of Derivatives":["Rate of Change","Increasing Decreasing","Tangent Normal","Maxima Minima"],"12th - Integrals":["Indefinite Integrals","Methods of Integration","Definite Integrals","Properties"],"12th - Applications of Integrals":["Area Under Curves","Area Between Curves"],"12th - Differential Equations":["Order & Degree","Formation","Variable Separable","Linear Equations"],"12th - Vector Algebra":["Vectors","Addition","Dot Product","Cross Product","Scalar Triple Product"],"12th - 3D Geometry":["Direction Cosines","Lines in Space","Planes","Angle Between"],"12th - Linear Programming":["LPP","Graphical Method","Corner Point","Optimal Solution"],"12th - Probability":["Conditional Probability","Bayes Theorem","Random Variables","Binomial Distribution"]}}

                const subj=aiGSub
                const chapters=subj&&NCERT[subj]?Object.keys(NCERT[subj]):[]
                const topics=aiSelChap&&NCERT[subj]&&NCERT[subj][aiSelChap]?NCERT[subj][aiSelChap]:[]
                return(
                  <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.88)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center',padding:14,overflowY:'auto'}}>
                    <div style={{background:'linear-gradient(160deg,#0D1B2A,#0F1E30)',border:'1px solid rgba(168,85,247,0.35)',borderRadius:20,padding:20,width:'100%',maxWidth:480,maxHeight:'95vh',overflowY:'auto',boxShadow:'0 20px 60px rgba(0,0,0,0.6)'}}>
                      {/* Header */}
                      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
                        <div>
                          <div style={{fontSize:14,fontWeight:800,color:'#E2E8F0'}}>🤖 NCERT AI Generator</div>
                          <div style={{fontSize:10,color:'#A78BFA',marginTop:2}}>NCERT Based · Auto answers & explanations</div>
                        </div>
                        <button onClick={function(){setAiGO_ncert(false);setAiGResult([])}} style={{...bg_,padding:'4px 10px',fontSize:12}}>✕</button>
                      </div>
                      {/* Subject */}
                      <div style={{marginBottom:12}}>
                        <label style={lbl}>📚 Subject *</label>
                        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:6}}>
                          {['Physics','Chemistry','Biology','Math'].map(function(s){return(
                            <div key={s} onClick={function(){setAiGSub(s);aiChR.current='';aiTopR.current='';setAiSelChap('')}} style={{padding:'8px 4px',borderRadius:8,border:'1.5px solid '+(aiGSub===s?'rgba(168,85,247,0.5)':'rgba(255,255,255,0.08)'),background:aiGSub===s?'rgba(168,85,247,0.12)':'rgba(255,255,255,0.02)',cursor:'pointer',textAlign:'center'}}>
                              <div style={{fontSize:11,fontWeight:700,color:aiGSub===s?'#A78BFA':'#94A3B8'}}>{s}</div>
                            </div>
                          )})}
                        </div>
                      </div>
                      {/* Chapter */}
                      <div style={{marginBottom:10}}>
                        <label style={lbl}>📖 Chapter * <span style={{color:'#475569',fontSize:9}}>(select or type)</span></label>
                        <select onChange={function(e){if(e.target.value){aiChR.current=e.target.value;setAiSelChap(e.target.value)}}} style={{...inp,width:'100%',marginBottom:5}}>
                          <option value=''>— Select NCERT Chapter —</option>
                          {chapters.map(function(c){const dn=c.includes(' - ')?c.split(' - ').slice(1).join(' - '):c;return <option key={c} value={c}>{dn}</option>})}
                        </select>
                        <input defaultValue='' placeholder='Or type custom chapter…' onChange={function(e){aiChR.current=e.target.value;setAiSelChap(e.target.value)}} style={{...inp,width:'100%',fontSize:11}}/>
                      </div>
                      {/* Topic */}
                      <div style={{marginBottom:10}}>
                        <label style={lbl}>📌 Topic * <span style={{color:'#475569',fontSize:9}}>(select or type)</span></label>
                        <select onChange={function(e){if(e.target.value)aiTopR.current=e.target.value}} style={{...inp,width:'100%',marginBottom:5}}>
                          <option value=''>— Select NCERT Topic —</option>
                          {topics.map(function(tp){return <option key={tp} value={tp}>{tp}</option>})}
                        </select>
                        <input defaultValue='' placeholder='Or type custom topic…' onChange={function(e){aiTopR.current=e.target.value}} style={{...inp,width:'100%',fontSize:11}}/>
                      </div>
                      {/* Count + Difficulty */}
                      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:10}}>
                        <div>
                          <label style={lbl}>🔢 Count (1–30)</label>
                          <input type='number' min='1' max='30' defaultValue='10' onChange={function(e){setAiGCnt(e.target.value)}} style={{...inp,width:'100%'}}/>
                        </div>
                        <div>
                          <label style={lbl}>🎯 Difficulty</label>
                          <select value={aiGDiff} onChange={function(e){setAiGDiff(e.target.value)}} style={{...inp,width:'100%'}}>
                            <option value='easy'>🟢 Easy</option>
                            <option value='medium'>🟡 Medium</option>
                            <option value='hard'>🔴 Hard</option>
                          </select>
                        </div>
                      </div>
                      {/* Question Type */}
                      <div style={{marginBottom:10}}>
                        <label style={lbl}>📋 Question Type</label>
                        <div style={{display:'flex',gap:6}}>
                          {['SCQ','MSQ','Integer'].map(function(tp){return(
                            <button key={tp} style={{...bg_,fontSize:10,padding:'4px 10px',flex:1,background:aiType===tp?'rgba(168,85,247,0.25)':'transparent',border:aiType===tp?'1px solid rgba(168,85,247,0.8)':'1px solid rgba(255,255,255,0.1)',color:aiType===tp?'#fff':'#94a3b8'}} onClick={function(){setAiType(tp)}}>{tp}</button>
                          )})}
                        </div>
                      </div>
                      {/* Exam Level */}
                      <div style={{marginBottom:10}}>
                        <div style={{fontSize:11,fontWeight:700,color:'#A78BFA',letterSpacing:1,marginBottom:6}}>🎯 EXAM LEVEL</div>
                        <div style={{display:'flex',flexWrap:'wrap',gap:5}}>
                          {(['NEET','JEE_MAINS','JEE_ADVANCED','CUET','BOARD','OTHER'] as const).map(lvl=>(
                            <button key={lvl} onClick={()=>setAiExamLevel(lvl)} style={{padding:'4px 10px',borderRadius:6,fontSize:11,fontWeight:600,border:'none',cursor:'pointer',background:aiExamLevel===lvl?'#7C3AED':'rgba(124,58,237,0.15)',color:aiExamLevel===lvl?'#fff':'#C4B5FD',transition:'all 0.2s'}}>{lvl.replace(/_/g,' ')}</button>
                          ))}
                        </div>
                      </div>
                      {/* Format */}
                      <div style={{marginBottom:10}}>
                        <div style={{fontSize:11,fontWeight:700,color:'#A78BFA',letterSpacing:1,marginBottom:4}}>📋 FORMAT <span style={{fontWeight:400,color:'#888'}}>(multi-select)</span></div>
                        <div style={{display:'flex',flexWrap:'wrap',gap:4}}>
                          {(['Random','Statement_Based','Assertion_Reason','True_False','Numerical','Fill_Blanks','Match_Column','Passage_Based','Sequence_Based','Graph_Data_Based','Diagram_Based'] as const).map(fmt=>{
                            const sel=aiFormats.includes(fmt);
                            return(<button key={fmt} onClick={()=>setAiFormats((p:string[])=>{if(fmt==='Random')return['Random'];const filtered=p.filter((x:string)=>x!=='Random');const already=filtered.includes(fmt);const next=already?filtered.filter((x:string)=>x!==fmt):[...filtered,fmt];return next.length===0?['Random']:next;})} style={{padding:'3px 8px',borderRadius:5,fontSize:10,fontWeight:600,border:'none',cursor:'pointer',background:sel?'#059669':'rgba(5,150,105,0.15)',color:sel?'#fff':'#6EE7B7',transition:'all 0.2s'}}>{fmt.replace(/_/g,' ')}</button>);
                          })}
                        </div>
                      </div>
                      {/* Diagram URL */}
                      {aiFormats.includes('Diagram_Based')&&(
                        <div style={{marginBottom:10}}>
                          <div style={{fontSize:11,fontWeight:700,color:'#F59E0B',marginBottom:4}}>🖼️ DIAGRAM IMAGE URL <span style={{fontWeight:400,color:'#888'}}>(optional)</span></div>
                          <input value={aiImageUrl} onChange={(e:React.ChangeEvent<HTMLInputElement>)=>setAiImageUrl(e.target.value)} placeholder="Paste image URL…" style={{width:'100%',padding:'6px 10px',background:'rgba(245,158,11,0.08)',border:'1px solid rgba(245,158,11,0.3)',borderRadius:6,color:'#fff',fontSize:11,outline:'none',boxSizing:'border-box'}}/>
                        </div>
                      )}
                      {/* Result preview */}
                      {aiGResult.length>0&&(
                        <div style={{marginBottom:12}}>
                          <div style={{fontSize:11,fontWeight:700,color:'#00C864',marginBottom:6}}>✅ {aiGResult.length} Questions Generated!</div>
                          <div style={{maxHeight:100,overflowY:'auto',display:'flex',flexDirection:'column',gap:3,marginBottom:8}}>
                            {aiGResult.map(function(q:any,i:number){return(<div key={i} style={{padding:'4px 8px',background:'rgba(0,200,100,0.05)',borderRadius:5,fontSize:10,color:'#CBD5E1'}}>Q{i+1}: {(q.text||'').slice(0,65)}…</div>)})}
                          </div>
                          <button onClick={()=>{const m:Record<number,any>={};aiGResult.forEach((q:any,i:number)=>{const d=findDups(q.text||q.question||'',q.options||[],questions);if(d.length)m[i]=d[0]});setAiDupMap(m);setShowAiPreview(true)}} style={{...bp,width:'100%',fontSize:11,marginBottom:8}}>💾 Review & Save All {aiGResult.length} Questions</button>
                        </div>
                      )}
                      {/* Generate Button */}
                      <button onClick={aiGF} disabled={aiGLoading} style={{...bp,width:'100%',opacity:aiGLoading?0.7:1}}>
                        {aiGLoading?'⟳ Generating NCERT Questions…':'🤖 Generate Questions'}
                      </button>
                      <div style={{fontSize:9,color:'#475569',textAlign:'center',marginTop:6}}>NCERT-based questions · auto answers & explanations</div>
                    </div>
                  </div>
                )
              })()}

              {/* ════════════════════════════════════════════════════ */}
              {/* FILES MODE MODAL — Fully Independent               */}
              {/* ════════════════════════════════════════════════════ */}
              {aiGO_files&&(function(){
                return(
                  <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.88)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center',padding:14,overflowY:'auto'}}>
                    <div style={{background:'linear-gradient(160deg,#071A12,#0A1E18)',border:'1px solid rgba(0,200,100,0.3)',borderRadius:20,padding:20,width:'100%',maxWidth:480,maxHeight:'95vh',overflowY:'auto',boxShadow:'0 20px 60px rgba(0,0,0,0.6)'}}>
                      {/* Header */}
                      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
                        <div>
                          <div style={{fontSize:14,fontWeight:800,color:'#E2E8F0'}}>📁 AI from Files</div>
                          <div style={{fontSize:10,color:'#00C864',marginTop:2}}>Upload PDF/DOCX/TXT → AI generates questions</div>
                        </div>
                        <button onClick={function(){setAiGO_files(false);setFmResult([]);setSelMatId('');setMatTitle('')}} style={{...bg_,padding:'4px 10px',fontSize:12}}>✕</button>
                      </div>
                      {/* Upload section */}
                      <div style={{background:'rgba(0,200,100,0.05)',border:'1px dashed rgba(0,200,100,0.3)',borderRadius:12,padding:'12px 14px',marginBottom:12}}>
                        <div style={{fontSize:11,fontWeight:700,color:'#00C864',marginBottom:5}}>📤 Upload Material</div>
                        <div style={{fontSize:10,color:'#64748B',marginBottom:8}}>PDF, DOCX, TXT, CSV, MD — max 10MB</div>
                        <input
                          type='text'
                          value={matTitle}
                          onChange={function(e){setMatTitle(e.target.value)}}
                          placeholder='📝 Title (e.g. Chapter 5 Notes)'
                          disabled={matUploading}
                          style={{...inp,width:'100%',marginBottom:6,fontSize:11,opacity:matUploading?0.5:1}}
                        />
                        <div style={{display:'flex',gap:6}}>
                          <label style={{flex:1,padding:'7px 12px',borderRadius:8,border:'1px solid rgba(0,200,100,0.3)',background:'rgba(0,200,100,0.08)',color:'#00C864',fontSize:10,cursor:matUploading?'not-allowed':'pointer',textAlign:'center',fontWeight:600,opacity:matUploading?0.6:1}}>
                            {matUploading?'⟳ Extracting…':'📁 Choose File'}
                            <input type='file' accept='.pdf,.docx,.txt,.csv,.md,.html,.json' style={{display:'none'}} disabled={matUploading} onChange={function(e){const f=e.target.files?.[0];if(f)handleMatFile(f,matTitle||f.name);e.target.value=''}}/>
                          </label>
                          <button
                            disabled={matUploading}
                            onClick={function(){const t=prompt('📋 Paste your notes/content:');if(t&&t.trim()){const ttl=matTitle||'Pasted Notes';setMatTitle('');saveMat(ttl,t,'txt',t.length)}}}
                            style={{...bg_,fontSize:10,padding:'7px 10px',flexShrink:0,opacity:matUploading?0.5:1}}>📋 Paste</button>
                        </div>
                      </div>
                      {/* Materials list */}
                      <div style={{marginBottom:12}}>
                        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
                          <div style={{fontSize:11,fontWeight:700,color:'#E2E8F0'}}>📚 Saved Materials ({matList.length})</div>
                          <button onClick={fetchMats} style={{...bg_,fontSize:9,padding:'2px 7px'}}>{matLoading?'⟳':'↻ Refresh'}</button>
                        </div>
                        {matLoading&&<div style={{textAlign:'center',padding:'16px',color:'#475569',fontSize:11}}>⟳ Loading…</div>}
                        {!matLoading&&matList.length===0&&<div style={{textAlign:'center',padding:'20px',color:'#475569',fontSize:11,background:'rgba(255,255,255,0.02)',borderRadius:8}}>No materials yet — upload a file above!</div>}
                        {matList.map(function(m:any){
                          const isS=selMatId===m._id
                          const icons:any={pdf:'📄',docx:'📝',txt:'📃',csv:'📊',md:'📋'}
                          return(
                            <div key={m._id} onClick={function(){setSelMatId(isS?'':m._id)}} style={{padding:'9px 12px',borderRadius:10,border:'1.5px solid '+(isS?'rgba(0,200,100,0.5)':'rgba(255,255,255,0.07)'),background:isS?'rgba(0,200,100,0.08)':'rgba(255,255,255,0.02)',cursor:'pointer',marginBottom:6,transition:'all 0.2s'}}>
                              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                                <div style={{display:'flex',alignItems:'center',gap:7,flex:1,minWidth:0}}>
                                  <span style={{fontSize:16,flexShrink:0}}>{icons[m.fileType]||'📄'}</span>
                                  <div style={{flex:1,minWidth:0}}>
                                    <div style={{fontSize:11,fontWeight:600,color:isS?'#00C864':'#E2E8F0',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{m.title}</div>
                                    <div style={{fontSize:9,color:'#475569',marginTop:1}}>{m.fileType.toUpperCase()} · {m.fileSize>1024?(Math.round(m.fileSize/1024)+'KB'):(m.fileSize+'B')} · {new Date(m.createdAt).toLocaleDateString()}</div>
                                  </div>
                                </div>
                                <div style={{display:'flex',gap:4,flexShrink:0,marginLeft:6}}>
                                    <button onClick={function(e){e.stopPropagation();fetchMatContent(m._id,m.title)}} title='View extracted content' style={{...bg_,fontSize:10,padding:'2px 7px',color:'#60A5FA',border:'1px solid rgba(96,165,250,0.3)',borderRadius:5}}>👁️</button>
                                    <button onClick={function(e){e.stopPropagation();deleteMat(m._id)}} style={{...bg_,fontSize:10,padding:'2px 7px',color:'#F87171',border:'1px solid rgba(248,113,113,0.3)',borderRadius:5}}>🗑️</button>
                                  </div>
                              </div>
                              {isS&&<div style={{fontSize:9,color:'#00C864',marginTop:4}}>✓ Selected — configure below ↓</div>}
                            </div>
                          )
                        })}
                      </div>
                      {/* Generation config — only when material selected */}
                      {selMatId&&(
                        <div style={{background:'rgba(0,200,100,0.04)',border:'1px solid rgba(0,200,100,0.2)',borderRadius:12,padding:'14px'}}>
                          <div style={{fontSize:11,fontWeight:700,color:'#00C864',marginBottom:10}}>⚡ Configure Generation</div>
                          {/* Subject */}
                          <div style={{marginBottom:10}}>
                            <label style={lbl}>📚 Subject (for tagging)</label>
                            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:5}}>
                              {['Physics','Chemistry','Biology','Math'].map(function(s){return(
                                <div key={s} onClick={function(){setFmSubj(s)}} style={{padding:'6px 4px',borderRadius:7,border:'1.5px solid '+(fmSubj===s?'rgba(0,200,100,0.5)':'rgba(255,255,255,0.08)'),background:fmSubj===s?'rgba(0,200,100,0.12)':'rgba(255,255,255,0.02)',cursor:'pointer',textAlign:'center'}}>
                                  <div style={{fontSize:10,fontWeight:700,color:fmSubj===s?'#00C864':'#94A3B8'}}>{s}</div>
                                </div>
                              )})}
                            </div>
                          </div>
                          {/* Count + Difficulty */}
                          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:10}}>
                            <div>
                              <label style={lbl}>🔢 Count (1-30)</label>
                              <input type='number' min='1' max='30' value={matGenCnt} onChange={function(e){setMatGenCnt(e.target.value)}} style={{...inp,width:'100%'}}/>
                            </div>
                            <div>
                              <label style={lbl}>🎯 Difficulty</label>
                              <select value={matGenDiff} onChange={function(e){setMatGenDiff(e.target.value)}} style={{...inp,width:'100%'}}>
                                <option value='easy'>🟢 Easy</option>
                                <option value='medium'>🟡 Medium</option>
                                <option value='hard'>🔴 Hard</option>
                              </select>
                            </div>
                          </div>
                          {/* Question Type */}
                          <div style={{marginBottom:10}}>
                            <label style={lbl}>📋 Question Type</label>
                            <div style={{display:'flex',gap:6}}>
                              {['SCQ','MSQ','Integer'].map(function(tp){return(
                                <button key={tp} onClick={function(){setFmType(tp)}} style={{...bg_,fontSize:10,padding:'4px 10px',flex:1,background:fmType===tp?'rgba(0,200,100,0.2)':'transparent',border:fmType===tp?'1px solid rgba(0,200,100,0.6)':'1px solid rgba(255,255,255,0.1)',color:fmType===tp?'#00C864':'#94a3b8'}}>{tp}</button>
                              )})}
                            </div>
                          </div>
                          {/* Exam Level */}
                          <div style={{marginBottom:10}}>
                            <div style={{fontSize:11,fontWeight:700,color:'#00C864',letterSpacing:1,marginBottom:6}}>🎯 EXAM LEVEL</div>
                            <div style={{display:'flex',flexWrap:'wrap',gap:5}}>
                              {(['NEET','JEE_MAINS','JEE_ADVANCED','CUET','BOARD','OTHER'] as const).map(lvl=>(
                                <button key={lvl} onClick={()=>setFmExamLevel(lvl)} style={{padding:'4px 10px',borderRadius:6,fontSize:10,fontWeight:600,border:'none',cursor:'pointer',background:fmExamLevel===lvl?'#059669':'rgba(5,150,105,0.15)',color:fmExamLevel===lvl?'#fff':'#6EE7B7',transition:'all 0.2s'}}>{lvl.replace(/_/g,' ')}</button>
                              ))}
                            </div>
                          </div>
                          {/* Formats */}
                          <div style={{marginBottom:12}}>
                            <div style={{fontSize:11,fontWeight:700,color:'#00C864',letterSpacing:1,marginBottom:4}}>📋 FORMAT <span style={{fontWeight:400,color:'#888'}}>(multi-select)</span></div>
                            <div style={{display:'flex',flexWrap:'wrap',gap:4}}>
                              {(['Random','Statement_Based','Assertion_Reason','True_False','Numerical','Fill_Blanks','Match_Column','Passage_Based','Sequence_Based','Graph_Data_Based','Diagram_Based'] as const).map(fmt=>{
                                const sel=fmFormats.includes(fmt);
                                return(<button key={fmt} onClick={()=>setFmFormats((p:string[])=>{if(fmt==='Random')return['Random'];const filtered=p.filter((x:string)=>x!=='Random');const already=filtered.includes(fmt);const next=already?filtered.filter((x:string)=>x!==fmt):[...filtered,fmt];return next.length===0?['Random']:next;})} style={{padding:'3px 8px',borderRadius:5,fontSize:10,fontWeight:600,border:'none',cursor:'pointer',background:sel?'#059669':'rgba(5,150,105,0.15)',color:sel?'#fff':'#6EE7B7',transition:'all 0.2s'}}>{fmt.replace(/_/g,' ')}</button>);
                              })}
                            </div>
                          </div>
                          {/* Generate Button */}
                          <button onClick={function(){generateFromMat(selMatId,parseInt(matGenCnt)||10,matGenDiff)}} disabled={matGenLoading} style={{...bp,width:'100%',opacity:matGenLoading?0.7:1,background:'linear-gradient(135deg,#059669,#10b981)',border:'none'}}>
                            {matGenLoading?'⟳ AI generating from material…':'🚀 Generate '+matGenCnt+' Questions from File'}
                          </button>
                        </div>
                      )}
                      {/* No material hint */}
                      {!selMatId&&matList.length>0&&(
                        <div style={{textAlign:'center',padding:'14px',color:'#475569',fontSize:11,background:'rgba(0,200,100,0.03)',borderRadius:8,border:'1px solid rgba(0,200,100,0.1)'}}>
                          ☝️ Select a material above to configure generation
                        </div>
                      )}
                    </div>
                    {/* Material Content Viewer Modal */}
                    {matViewId&&(
                      <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.92)',zIndex:10002,display:'flex',alignItems:'center',justifyContent:'center',padding:14}} onClick={function(){setMatViewId('')}}>
                        <div style={{background:'#0d1117',border:'1px solid rgba(96,165,250,0.4)',borderRadius:16,padding:20,width:'100%',maxWidth:640,maxHeight:'90vh',display:'flex',flexDirection:'column'}} onClick={function(e){e.stopPropagation()}}>
                          {/* Header */}
                          <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:14,gap:10}}>
                            <div style={{flex:1,minWidth:0}}>
                              <div style={{fontSize:13,fontWeight:800,color:'#60A5FA',marginBottom:3}}>👁️ Extracted Content</div>
                              <div style={{fontSize:11,color:'#94A3B8',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{matViewTitle}</div>
                            </div>
                            <button onClick={function(){setMatViewId('')}} style={{background:'none',border:'none',color:'#666',fontSize:22,cursor:'pointer',flexShrink:0}}>✕</button>
                          </div>
                          {/* Stats bar */}
                          {!matViewLoading&&matViewContent&&matViewContent.length>10&&(
                            <div style={{display:'flex',gap:10,marginBottom:10,flexWrap:'wrap'}}>
                              <div style={{padding:'3px 10px',borderRadius:6,background:'rgba(96,165,250,0.1)',border:'1px solid rgba(96,165,250,0.2)',fontSize:10,color:'#60A5FA'}}>
                                📝 {matViewContent.length.toLocaleString()} chars
                              </div>
                              <div style={{padding:'3px 10px',borderRadius:6,background:'rgba(96,165,250,0.1)',border:'1px solid rgba(96,165,250,0.2)',fontSize:10,color:'#60A5FA'}}>
                                📄 ~{Math.round(matViewContent.split(/s+/).filter(Boolean).length)} words
                              </div>
                              <div style={{padding:'3px 10px',borderRadius:6,background:'rgba(0,200,100,0.08)',border:'1px solid rgba(0,200,100,0.2)',fontSize:10,color:'#00C864'}}>
                                ✅ Extraction successful
                              </div>
                            </div>
                          )}
                          {/* Content area */}
                          <div style={{flex:1,overflowY:'auto',background:'rgba(255,255,255,0.02)',border:'1px solid rgba(255,255,255,0.06)',borderRadius:10,padding:14,minHeight:200,maxHeight:'60vh'}}>
                            {matViewLoading?(
                              <div style={{textAlign:'center',padding:'40px 0',color:'#475569'}}>
                                <div style={{fontSize:24,marginBottom:8}}>⟳</div>
                                <div style={{fontSize:12}}>Loading extracted content…</div>
                              </div>
                            ):matViewContent?(
                              <pre style={{fontSize:11,color:'#CBD5E1',lineHeight:1.7,whiteSpace:'pre-wrap',wordBreak:'break-word',margin:0,fontFamily:'inherit'}}>{matViewContent}</pre>
                            ):(
                              <div style={{textAlign:'center',padding:'40px 0',color:'#475569',fontSize:12}}>No content available</div>
                            )}
                          </div>
                          {/* Footer */}
                          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:12,gap:10}}>
                            <div style={{fontSize:10,color:'#475569'}}>
                              {!matViewLoading&&matViewContent&&matViewContent.length>4000?'⚠️ Large content — AI uses first 5000 chars for generation':''}
                            </div>
                            <div style={{display:'flex',gap:6}}>
                              <button onClick={function(){
                                const blob=new Blob([matViewContent],{type:'text/plain'});
                                const a=document.createElement('a');
                                a.href=URL.createObjectURL(blob);
                                a.download=(matViewTitle||'extracted')+'.txt';
                                a.click();URL.revokeObjectURL(a.href);
                              }} style={{padding:'8px 14px',borderRadius:8,background:'rgba(0,200,100,0.1)',border:'1px solid rgba(0,200,100,0.3)',color:'#00C864',cursor:'pointer',fontSize:12,fontWeight:600}}>⬇️ TXT</button>
                              <button onClick={function(){
                                const w=window.open('','_blank');
                                if(!w)return;
                                w.document.write('<html><head><title>'+(matViewTitle||'Content')+'</title><style>body{font-family:Arial,sans-serif;font-size:13px;line-height:1.8;padding:40px;max-width:800px;margin:0 auto;white-space:pre-wrap;word-break:break-word;}h2{color:#333;border-bottom:1px solid #ddd;padding-bottom:8px;}@media print{body{padding:20px}}</style></head><body><h2>'+matViewTitle+'</h2><pre>'+matViewContent.replace(/</g,'&lt;').replace(/>/g,'&gt;')+'</pre></body></html>');
                                w.document.close();
                                setTimeout(function(){w.print();},400);
                              }} style={{padding:'8px 14px',borderRadius:8,background:'rgba(239,68,68,0.1)',border:'1px solid rgba(239,68,68,0.3)',color:'#f87171',cursor:'pointer',fontSize:12,fontWeight:600}}>⬇️ PDF</button>
                              <button onClick={function(){setMatViewId('')}} style={{padding:'8px 20px',borderRadius:8,background:'rgba(96,165,250,0.12)',border:'1px solid rgba(96,165,250,0.3)',color:'#60A5FA',cursor:'pointer',fontSize:12,fontWeight:600}}>Close</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
    {/* Files Mode — Question Preview Modal (Full) */}
                    {fmShowPreview&&(
                      <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.92)',zIndex:10000,display:'flex',alignItems:'center',justifyContent:'center',padding:'12px'}} onClick={function(){setFmShowPreview(false)}}>
                        <div style={{background:'#0d1117',border:'1px solid rgba(0,200,100,0.4)',borderRadius:16,padding:'20px',maxWidth:660,width:'100%',maxHeight:'92vh',overflowY:'auto'}} onClick={function(e){e.stopPropagation()}}>
                          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
                            <span style={{color:'#00C864',fontWeight:700,fontSize:15}}>📁 Files Questions Preview ({fmResult.length})</span>
                            <button onClick={function(){setFmShowPreview(false)}} style={{background:'none',border:'none',color:'#666',fontSize:22,cursor:'pointer'}}>✕</button>
                          </div>
                          <div style={{marginBottom:14}}>
                            {fmResult.map(function(q:any,i:number){
                              return(
                                <div key={i} style={{background:'rgba(0,200,100,0.06)',border:'1px solid rgba(0,200,100,0.2)',borderRadius:10,padding:'12px',marginBottom:10,position:'relative'}}>
                                  <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:8}}>
                                    <span style={{color:'#00C864',fontSize:11,fontWeight:700}}>Q{i+1}</span>{fmDupMap[i]&&<span style={{background:'rgba(239,68,68,0.22)',color:'#f87171',fontSize:10,fontWeight:700,padding:'2px 8px',borderRadius:10,marginLeft:6,border:'1px solid rgba(239,68,68,0.5)'}}>⚠️ Duplicate in Bank</span>}
                                    <div style={{display:'flex',gap:6}}>
                                      <button onClick={function(){setFmEditIdx(i);setFmEditQ(Object.assign({},q))}} style={{background:'rgba(59,130,246,0.2)',border:'1px solid rgba(59,130,246,0.4)',color:'#60a5fa',borderRadius:6,padding:'3px 10px',fontSize:11,cursor:'pointer'}}>✏️ Edit</button>
                                      <button onClick={function(){setFmResult(function(p:any[]){return p.filter(function(_:any,j:number){return j!==i})})}} style={{background:'rgba(239,68,68,0.15)',border:'1px solid rgba(239,68,68,0.4)',color:'#f87171',borderRadius:6,padding:'3px 10px',fontSize:11,cursor:'pointer'}}>🗑️ Delete</button>
                                    </div>
                                  </div>
                                  <div style={{color:'#e2e8f0',fontSize:13,marginBottom:6,lineHeight:1.6}} dangerouslySetInnerHTML={{__html:renderLatex(q.text||q.question||'')}}/>
                                  {(q.options||[]).map(function(opt:string,j:number){
                                    const L=['A','B','C','D'][j]
                                    const isAns=q.correctAnswer===('Option '+L)||q.correctAnswer===L||q.correctLetter===L||q.correct_answer===('Option '+L)||q.correct_answer===L||(Array.isArray(q.correct)&&q.correct.includes(j))
                                    const cleanOpt=(opt||'').replace(/^[A-Da-d][.):]s*/,'').trim()
                                    return <div key={j} style={{fontSize:12,padding:'4px 8px',borderRadius:6,marginBottom:3,background:isAns?'rgba(34,197,94,0.12)':'rgba(255,255,255,0.03)',border:isAns?'1px solid rgba(34,197,94,0.4)':'1px solid rgba(255,255,255,0.06)',color:isAns?'#4ade80':'#94a3b8'}}>
                                      <b>{L}.</b> <span dangerouslySetInnerHTML={{__html:renderLatex(cleanOpt)}}/>{isAns&&<span style={{marginLeft:6,fontSize:10}}>✓</span>}
                                    </div>
                                  })}
                                  {(q.explanation||q.exp)&&<div style={{fontSize:11,color:'#fcd34d',marginTop:6,padding:'4px 8px',background:'rgba(252,211,77,0.07)',borderRadius:6}}>💡 <span dangerouslySetInnerHTML={{__html:renderLatex(formatQText(q.explanation||q.exp||''))}}/></div>}
                                  {fmDupMap[i]&&<div style={{background:'rgba(239,68,68,0.09)',border:'1px solid rgba(239,68,68,0.35)',borderRadius:7,padding:'7px 10px',marginTop:6,fontSize:11,color:'#f87171'}}>⚠️ Already in bank: <span style={{color:'#94a3b8'}}>{(fmDupMap[i].text||'').slice(0,70)}{(fmDupMap[i].text||'').length>70?'…':''}</span></div>}
                                </div>
                              )
                            })}
                          </div>
                          {fmResult.length===0&&<div style={{color:'#f87171',textAlign:'center',padding:'20px'}}>All questions deleted!</div>}
                          <div style={{display:'flex',gap:10,justifyContent:'flex-end'}}>
                            <button onClick={function(){setFmShowPreview(false)}} style={{padding:'10px 20px',borderRadius:8,background:'rgba(255,255,255,0.05)',border:'1px solid rgba(255,255,255,0.15)',color:'#94a3b8',cursor:'pointer',fontSize:13}}>Cancel</button>
                            <button onClick={function(){setFmShowPreview(false);saveFmQs()}} disabled={fmResult.length===0||aiSaving} style={{padding:'10px 24px',borderRadius:8,background:'linear-gradient(135deg,#059669,#10b981)',border:'none',color:'#fff',cursor:'pointer',fontSize:13,fontWeight:700}}>✅ Confirm Save All ({fmResult.length})</button>
                          </div>
                        </div>
                      </div>
                    )}
                    {/* Files Mode — Edit Question Modal */}
                    {fmEditQ!==null&&fmEditIdx!==null&&(
                      <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.92)',zIndex:10001,display:'flex',alignItems:'center',justifyContent:'center',padding:'12px'}} onClick={function(){setFmEditQ(null)}}>
                        <div style={{background:'#0d1117',border:'1px solid rgba(0,200,100,0.4)',borderRadius:16,padding:'20px',maxWidth:600,width:'100%',maxHeight:'90vh',overflowY:'auto'}} onClick={function(e){e.stopPropagation()}}>
                          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
                            <span style={{color:'#00C864',fontWeight:700,fontSize:15}}>✏️ Edit Q{(fmEditIdx||0)+1}</span>
                            <button onClick={function(){setFmEditQ(null)}} style={{background:'none',border:'none',color:'#666',fontSize:22,cursor:'pointer'}}>✕</button>
                          </div>
                          <div style={{marginBottom:10}}><label style={lbl}>Question Text</label><textarea value={fmEditQ.text||fmEditQ.question||''} onChange={function(e){setFmEditQ(function(p:any){return Object.assign({},p,{text:e.target.value,question:e.target.value})})}} rows={3} style={{...inp,resize:'vertical' as any}}/></div>
                          {[0,1,2,3].map(function(j){return(
                            <div key={j} style={{marginBottom:8}}><label style={lbl}>Option {['A','B','C','D'][j]}</label>
                            <input value={(fmEditQ.options||[])[j]||''} onChange={function(e){setFmEditQ(function(p:any){const o=[...(p.options||['','','',''])];o[j]=e.target.value;return Object.assign({},p,{options:o})})}} style={{...inp}}/>
                            </div>
                          )})}
                          <div style={{marginBottom:10}}><label style={lbl}>Correct Answer</label>
                            <select value={fmEditQ.correctAnswer||fmEditQ.correct_answer||''} onChange={function(e){setFmEditQ(function(p:any){return Object.assign({},p,{correctAnswer:e.target.value,correct_answer:e.target.value})})}} style={{...inp,width:'100%'}}>
                              <option value=''>Select</option>
                              {['A','B','C','D'].map(function(l){return <option key={l} value={'Option '+l}>Option {l}</option>})}
                            </select>
                          </div>
                          <div style={{marginBottom:10}}><label style={lbl}>Explanation</label><textarea value={fmEditQ.explanation||fmEditQ.exp||''} onChange={function(e){setFmEditQ(function(p:any){return Object.assign({},p,{explanation:e.target.value,exp:e.target.value})})}} rows={2} style={{...inp,resize:'vertical' as any}}/></div>
                          <div style={{display:'flex',gap:10,justifyContent:'flex-end',marginTop:16}}>
                            <button onClick={function(){setFmEditQ(null)}} style={{padding:'10px 20px',borderRadius:8,background:'rgba(255,255,255,0.05)',border:'1px solid rgba(255,255,255,0.15)',color:'#94a3b8',cursor:'pointer'}}>Cancel</button>
                            <button onClick={function(){setFmResult(function(p:any[]){const a=[...p];const _q=Object.assign({},fmEditQ);const _map={'Option A':0,'Option B':1,'Option C':2,'Option D':3};const _ci=_map[_q.correctAnswer];if(_ci!==undefined){_q.correct=[_ci];_q.correctLetter=['A','B','C','D'][_ci];}a[fmEditIdx]=_q;return a});setFmEditQ(null)}} style={{padding:'10px 24px',borderRadius:8,background:'linear-gradient(135deg,#059669,#10b981)',border:'none',color:'#fff',cursor:'pointer',fontWeight:700}}>💾 Save</button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )
              })()}

              {/* QUESTION PREVIEW MODAL */}
              {selQId&&(function(){
                const qi=(questions||[]).findIndex(function(q){return q._id===selQId})
                const q=(questions||[])[qi]
                if(!q)return null
                const sCol=q.subject==='Physics'?'#60A5FA':q.subject==='Chemistry'?'#F472B6':q.subject==='Biology'?'#34D399':'#A78BFA'
                const dCol=q.difficulty==='hard'?'#FF4D4D':q.difficulty==='easy'?'#00C864':'#FFB300'
                return(
                  <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.9)',zIndex:1000,display:'flex',alignItems:'center',justifyContent:'center',padding:14}}>
                    <div style={{background:'linear-gradient(160deg,#0D1B2A,#0F1E30)',border:'1px solid rgba(77,159,255,0.2)',borderRadius:20,padding:20,width:'100%',maxWidth:500,maxHeight:'90vh',overflowY:'auto'}}>
                      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:12}}>
                        <div>
                          <div style={{display:'flex',gap:4,flexWrap:'wrap',marginBottom:4}}>
                            <span style={{fontSize:9,fontWeight:600,padding:'2px 7px',borderRadius:4,background:sCol+'18',color:sCol,border:'1px solid '+sCol+'30'}}>{q.subject||'General'}</span>
                            <span style={{fontSize:9,fontWeight:600,padding:'2px 7px',borderRadius:4,background:dCol+'18',color:dCol,border:'1px solid '+dCol+'30'}}>{q.difficulty||'?'}</span>
                            <span style={{fontSize:9,padding:'2px 7px',borderRadius:4,background:'rgba(77,159,255,0.1)',color:'#4D9FFF'}}>{q.type||'SCQ'}</span>
                          </div>
                          <div style={{fontSize:10,color:'#475569'}}>Q{qi+1} of {(questions||[]).length}</div>
                        </div>
                        <button onClick={function(){setSelQId(null)}} style={{...bg_,padding:'3px 8px',fontSize:11}}>✕</button>
                      </div>
                      {/* Language Toggle */}
                      <div style={{display:'flex',gap:6,marginBottom:10}}>
                        <button onClick={function(){setQLang('en');try{localStorage.setItem('pr_qb_lang','en')}catch{}}} style={{padding:'4px 12px',borderRadius:6,fontSize:10,fontWeight:700,cursor:'pointer',background:qLang==='en'?'rgba(77,159,255,0.22)':'rgba(255,255,255,0.04)',color:qLang==='en'?'#4D9FFF':'#64748B',border:'1px solid '+(qLang==='en'?'rgba(77,159,255,0.5)':'rgba(255,255,255,0.1)')}}>🇺🇸 English</button>
                        {q.hindiText
                          ?<button onClick={function(){setQLang('hi');try{localStorage.setItem('pr_qb_lang','hi')}catch{}}} style={{padding:'4px 12px',borderRadius:6,fontSize:10,fontWeight:700,cursor:'pointer',background:qLang==='hi'?'rgba(251,146,60,0.22)':'rgba(255,255,255,0.04)',color:qLang==='hi'?'#FB923C':'#64748B',border:'1px solid '+(qLang==='hi'?'rgba(251,146,60,0.5)':'rgba(255,255,255,0.1)')}}>🇮🇳 हिंदी</button>
                          :<span style={{fontSize:9,color:'#6366f1',display:'flex',alignItems:'center',gap:4,padding:'4px 10px',borderRadius:6,border:'1px solid rgba(99,102,241,0.25)',background:'rgba(99,102,241,0.06)'}}><span style={{width:6,height:6,borderRadius:'50%',background:'#6366f1',display:'inline-block'}}></span>हिंदी अनुवाद हो रहा है...</span>
                        }
                      </div>
                      <div style={{fontSize:13,color:'#E2E8F0',lineHeight:1.7,marginBottom:10,padding:'11px 13px',background:'rgba(255,255,255,0.03)',borderRadius:10,border:'1px solid rgba(255,255,255,0.06)'}} dangerouslySetInnerHTML={{__html:renderLatex(formatQText(qLang==='hi'&&q.hindiText?q.hindiText:q.text||''))}}/>{q.image&&<div style={{margin:'8px 0',borderRadius:8,background:'rgba(255,255,255,0.03)',padding:6}}><img src={q.image} alt='' onError={function(e){e.currentTarget.style.display='none';var fb=document.getElementById('imgfb_'+q._id);if(fb)fb.style.display='flex'}} style={{width:'100%',maxHeight:160,objectFit:'contain',borderRadius:8,marginBottom:8,cursor:'pointer',background:'rgba(255,255,255,0.03)',display:'block'}} onClick={()=>setLbImg(q.image||'')}/><div id={'imgfb_'+q._id} style={{display:'none',alignItems:'center',gap:6,padding:'4px 0'}}><span style={{fontSize:10,color:'#94A3B8'}}>🖼️ Image URL:</span><a href={q.image} target='_blank' style={{fontSize:10,color:'#60A5FA',wordBreak:'break-all'}}>{q.image.length>50?q.image.substring(0,50)+'...':q.image}</a></div></div>}
                      {(q.options||[]).length>0&&(<div style={{display:'flex',flexDirection:'column',gap:5,marginBottom:10}}>
                        {(q.options||[]).map(function(opt,oi){
                          const ltr=String.fromCharCode(65+oi)
                          const cIdx=Array.isArray(q.correct)&&q.correct.length>0?q.correct:q.correct!==undefined?[q.correct]:[]
                          const isC=(Array.isArray(cIdx)?cIdx.includes(oi):cIdx===oi)||(q.correctAnswer&&q.correctAnswer===ltr)
                          return(<div key={oi} style={{padding:'7px 11px',borderRadius:7,border:'1px solid '+(isC?'rgba(0,200,100,0.4)':'rgba(255,255,255,0.07)'),background:isC?'rgba(0,200,100,0.08)':'rgba(255,255,255,0.02)',display:'flex',alignItems:'flex-start'}}>
                            <span style={{fontWeight:700,color:isC?'#00C864':'#4D9FFF',marginRight:8,flexShrink:0,minWidth:20,paddingTop:1}}>{ltr}.</span>
                            <div style={{flex:1,minWidth:0}}><span style={{fontSize:12,color:isC?'#E2E8F0':'#94A3B8'}} dangerouslySetInnerHTML={{__html:renderLatex(((qLang==='hi'&&(q.hindiOptions||[])[oi]?q.hindiOptions[oi]:opt)||'').replace(/^[A-Da-d][\.\)\:]s*/,'').trim())}}></span>
                            {isC&&<span style={{marginLeft:8,fontSize:10,color:'#00C864',fontWeight:700}}>✓ Correct</span>}{(q.optionImages as any)?.[oi]?<img src={(q.optionImages as any)[oi]} alt='' style={{width:'100%',maxHeight:110,objectFit:'contain',borderRadius:8,marginTop:6,cursor:'pointer',border:'1px solid rgba(99,102,241,0.3)',background:'rgba(255,255,255,0.04)',display:'block'}} onClick={()=>setLbImg(String((q.optionImages as any)?.[oi]||''))} onError={(e:any)=>{(e.target as HTMLImageElement).style.display='none'}}/>:null}</div>
                          </div>)
                        })}
                      </div>)}
                      {(q.chapter||q.topic||q.explanation)&&(<div style={{fontSize:11,color:'#64748B',marginBottom:10,lineHeight:1.6}}>
                        {q.chapter&&<div>📖 {q.chapter}{q.topic?' › '+q.topic:''}</div>}
                        {(q.explanation||q.hindiExplanation)&&<div style={{color:'#94A3B8',marginTop:4}} dangerouslySetInnerHTML={{__html:'💡 '+renderLatex(formatQText(qLang==='hi'&&q.hindiExplanation?q.hindiExplanation:q.explanation||''))}}/>}
                      </div>)}
                      <div style={{display:'flex',gap:7}}>
                        <button onClick={function(){if(qi>0)setSelQId((questions||[])[qi-1]._id)}} disabled={qi===0} style={{...bg_,flex:1,opacity:qi===0?0.35:1,fontSize:11}}>← Prev</button>
                        <button onClick={function(){
                          const ltrs=['A','B','C','D']
                          const cIdx=Array.isArray(q.correct)&&q.correct.length>0?q.correct[0]:(q.correctAnswer?ltrs.indexOf(q.correctAnswer):0)
                          setEditQD(Object.assign({},q,{correctLetter:ltrs[cIdx>=0?cIdx:0]||'A'}))
                          setSelQId(null)
                        }} style={{...bp,flex:1,fontSize:11}}>✏️ Edit</button>
                        <button onClick={function(){if(qi<(questions||[]).length-1)setSelQId((questions||[])[qi+1]._id)}} disabled={qi>=(questions||[]).length-1} style={{...bg_,flex:1,opacity:qi>=(questions||[]).length-1?0.35:1,fontSize:11}}>Next →</button>
                      </div>
                    </div>
                  </div>
                )
              })()}

              {/* EDIT MODAL */}
              {editQD&&(
                <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.9)',zIndex:1001,display:'flex',alignItems:'center',justifyContent:'center',padding:14}}>
                  <div style={{background:'linear-gradient(160deg,#0D1B2A,#0F1E30)',border:'1px solid rgba(255,184,0,0.25)',borderRadius:20,padding:20,width:'100%',maxWidth:490,maxHeight:'90vh',overflowY:'auto'}}>
                    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
                      <div style={{fontSize:13,fontWeight:800,color:'#E2E8F0'}}>✏️ Edit Question</div>
                      <button onClick={function(){setEditQD(null)}} style={{...bg_,padding:'3px 8px',fontSize:11}}>✕</button>
                    </div>
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:12}}>
                      <div style={{gridColumn:'1/-1'}}>
                        <label style={lbl}>Question Text *</label>
                        <textarea value={editQD.text||''} onChange={function(e){setEditQD(function(p){return Object.assign({},p,{text:e.target.value})})}} rows={3} style={{...inp,width:'100%',resize:'vertical'}}/>
                      </div>
                      <div style={{gridColumn:'1/-1'}}>
                        <label style={lbl}>Hindi Text <span style={{color:'#475569',fontSize:9}}>(optional)</span></label>
                        <textarea value={editQD.hindiText||''} onChange={function(e){setEditQD(function(p){return Object.assign({},p,{hindiText:e.target.value})})}} rows={2} style={{...inp,width:'100%',resize:'vertical'}}/>
                      </div>
                      <div>
                        <label style={lbl}>Subject</label>
                        <select value={editQD.subject||'Physics'} onChange={function(e){setEditQD(function(p){return Object.assign({},p,{subject:e.target.value})})}} style={{...inp,width:'100%'}}>
                          {['Physics','Chemistry','Biology','Math','Other'].map(function(s){return <option key={s} value={s}>{s}</option>})}
                        </select>
                      </div>
                      <div>
                        <label style={lbl}>Difficulty</label>
                        <select value={editQD.difficulty||'medium'} onChange={function(e){setEditQD(function(p){return Object.assign({},p,{difficulty:e.target.value})})}} style={{...inp,width:'100%'}}>
                          {['easy','medium','hard'].map(function(d){return <option key={d} value={d}>{d}</option>})}
                        </select>
                      </div>
                      <div>
                        <label style={lbl}>Chapter</label>
                        <input value={editQD.chapter||''} onChange={function(e){setEditQD(function(p){return Object.assign({},p,{chapter:e.target.value})})}} style={{...inp,width:'100%'}}/>
                      </div>
                      <div>
                        <label style={lbl}>Topic</label>
                        <input value={editQD.topic||''} onChange={function(e){setEditQD(function(p){return Object.assign({},p,{topic:e.target.value})})}} style={{...inp,width:'100%'}}/>
                      </div>
                      {(editQD.options&&editQD.options.length>0?editQD.options:['','','','']).map(function(opt,oi){return(
                        <div key={oi}>
                          <label style={lbl}>Option {String.fromCharCode(65+oi)}</label>
                          <input value={opt||''} onChange={function(e){
                            const opts=[...((editQD.options&&editQD.options.length>0)?editQD.options:['','','',''])]
                            opts[oi]=e.target.value
                            setEditQD(function(p){return Object.assign({},p,{options:opts})})
                          }} style={{...inp,width:'100%'}}/>
                        </div>
                      )})}
                      <div style={{gridColumn:'1/-1'}}>
                        <label style={lbl}>✅ Correct Answer</label>
                        <select value={editQD.correctLetter||'A'} onChange={function(e){setEditQD(function(p){return Object.assign({},p,{correctLetter:e.target.value})})}} style={{...inp,width:'100%'}}>
                          <option value='A'>Option A</option>
                          <option value='B'>Option B</option>
                          <option value='C'>Option C</option>
                          <option value='D'>Option D</option>
                        </select>
                      </div>
                      <div style={{gridColumn:'1/-1'}}>
                        <label style={lbl}>Explanation</label>
                        <textarea value={editQD.explanation||''} onChange={function(e){setEditQD(function(p){return Object.assign({},p,{explanation:e.target.value})})}} rows={2} style={{...inp,width:'100%',resize:'vertical'}}/>
                      </div>
                      <div>
                        <label style={lbl}>📷 Question Image URL</label>
                        <input value={editQD.image||''} onChange={function(e){setEditQD(function(p){return Object.assign({},p,{image:e.target.value})})}} placeholder='https://… (leave blank to remove)' style={{...inp,width:'100%'}}/>
                      </div>
                      <div>
                        <label style={lbl}>🖼️ Option Images URL (A/B/C/D)</label>
                        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6}}>
                        {['A','B','C','D'].map(function(l,i){return(
                          <div key={l}>
                            <label style={{fontSize:9,color:'#64748B',marginBottom:2,display:'block'}}>Option {l}</label>
                            <input value={(editQD.optionImages||['','','',''])[i]||''} onChange={function(e){setEditQD(function(p){const imgs=[...((p.optionImages)||['','','',''])];imgs[i]=e.target.value;return Object.assign({},p,{optionImages:imgs})})}} placeholder='https://…' style={{...inp,width:'100%',fontSize:10}}/>
                          </div>)})}
                        </div>
                      </div>
                    </div>
                    <div style={{display:'flex',gap:8}}>
                      <button onClick={function(){setEditQD(null)}} style={{...bg_,flex:1,fontSize:11}}>Cancel</button>
                      <button onClick={function(){editQF(editQD._id,editQD)}} disabled={savingEQ} style={{...bp,flex:2,fontSize:11,opacity:savingEQ?0.7:1}}>{savingEQ?'⟳ Saving…':'💾 Save Changes'}</button>
                    </div>
                  </div>
                </div>
              )}

            </div>
          )}

          {/* ══ SMART GENERATOR ══ */}
          {tab==='smart_gen'&&(
            <SmartPaperGen API={API} token={typeof window!=='undefined'?localStorage.getItem('pr_token')||'':''} batches={batches||[]} testSeries={testSeries||[]} />
          )}

          {/* ══ AI EXPLANATION GENERATOR ══ */}
          {tab==='ai_explain'&&(
            <AIExplainTab API={API} token={typeof window!=='undefined'?localStorage.getItem('pr_token')||'':''} />
          )}

          {/* ══ CREATION STUDIO ══ */}
          {tab==='creation_studio'&&(
            <ContentForge API={API} token={typeof window!=='undefined'?localStorage.getItem('pr_token')||'':''} />
          )}

          {/* ══ PYQ BANK ══ */}
          {tab==='pyq_bank'&&(
            <AdminPYQBankTab
              token={typeof window!=='undefined'?localStorage.getItem('pr_token')||'':''}
              API={API}
              toast={T}
            />
          )}

          {/* ══ STUDENTS ══ */}
          {tab==='students'&&(
            <div>
              {/* ── HEADER ───────────────────────────────────── */}
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:20,flexWrap:'wrap',gap:12}}>
                <div>
                  <div style={pageTitle}>👥 Student Management</div>
                  <div style={pageSub}>
                    {(students||[]).filter((s:any)=>!s.deleted).length} registered
                    &nbsp;·&nbsp;{(students||[]).filter((s:any)=>s.banned&&!s.deleted).length} banned
                    {typeof window!=='undefined'&&localStorage.getItem('pr_role')==='superadmin'&&(
                      <span style={{color:'#FFB84D'}}>&nbsp;·&nbsp;{deletedStds.length} archived</span>
                    )}
                  </div>
                </div>
                <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
                  <button onClick={()=>doExport(`${API}/api/admin/export/students`,'students.csv')} style={{...bg_,fontSize:11}}>📥 Export CSV</button>
                  <button onClick={()=>_setTab('import_students')} style={{...bg_,fontSize:11}}>📤 Import CSV</button>
                </div>
              </div>

              {/* ── STATS ROW ────────────────────────────────── */}
              <div style={{display:'grid',gridTemplateColumns:`repeat(${typeof window!=='undefined'&&localStorage.getItem('pr_role')==='superadmin'?4:3},1fr)`,gap:10,marginBottom:20}}>
                {[
                  {ico:'👥',lbl:'Total Students',val:(students||[]).filter((s:any)=>!s.deleted).length,col:'#4D9FFF'},
                  {ico:'✅',lbl:'Active',val:(students||[]).filter((s:any)=>!s.banned&&!s.deleted).length,col:'#00C48C'},
                  {ico:'🚫',lbl:'Banned',val:(students||[]).filter((s:any)=>s.banned&&!s.deleted).length,col:'#FF4757'},
                  ...(typeof window!=='undefined'&&localStorage.getItem('pr_role')==='superadmin'
                    ?[{ico:'🗃️',lbl:'Archived',val:deletedStds.length,col:'#FFB84D'}]
                    :[])
                ].map((s,i)=>(
                  <div key={i} style={{
                    background:`linear-gradient(135deg,${s.col}18 0%,${s.col}06 100%)`,
                    border:`1px solid ${s.col}35`,
                    borderRadius:14,
                    padding:'14px 12px',
                    textAlign:'center',
                    transition:'transform 0.2s',
                    cursor:'default'
                  }}>
                    <div style={{fontSize:22,marginBottom:5}}>{s.ico}</div>
                    <div style={{fontSize:24,fontWeight:800,color:s.col,lineHeight:1}}>{s.val}</div>
                    <div style={{fontSize:10,color:'#8899AA',marginTop:4,letterSpacing:'0.3px'}}>{s.lbl}</div>
                  </div>
                ))}
              </div>

              {/* ── SEARCH + FILTER BAR ───────────────────────── */}
              <div style={{display:'flex',gap:10,marginBottom:16,flexWrap:'wrap',alignItems:'center'}}>
                <SInput init={stdSearch} onSet={setStdSearch} ph='🔍 Search by name, email, ID…' style={{flex:1,minWidth:200,background:'rgba(0,22,40,0.7)',border:'1px solid rgba(77,159,255,0.2)',borderRadius:10,padding:'9px 14px',color:'#E8F4FD',fontSize:12,outline:'none'}}/>
                <div style={{display:'flex',gap:5,flexWrap:'wrap'}}>
                  {(['all','active','banned'] as const).map(f=>(
                    <button key={f} onClick={()=>setStdFilter(f)} style={{
                      padding:'8px 14px',
                      borderRadius:8,
                      border:`1px solid ${stdFilter===f?'#4D9FFF':'rgba(77,159,255,0.15)'}`,
                      background:stdFilter===f?'rgba(77,159,255,0.18)':'rgba(0,22,40,0.6)',
                      color:stdFilter===f?'#4D9FFF':'#8899AA',
                      cursor:'pointer',fontSize:11,fontWeight:stdFilter===f?700:500,
                      transition:'all 0.2s',
                      textTransform:'capitalize' as const
                    }}>{f}</button>
                  ))}
                  {typeof window!=='undefined'&&localStorage.getItem('pr_role')==='superadmin'&&(
                    <button onClick={()=>{setStdFilter('deleted' as any);fetchDeletedStds()}} style={{
                      padding:'8px 14px',borderRadius:8,
                      border:`1px solid ${stdFilter==='deleted'?'#FFB84D':'rgba(255,184,77,0.2)'}`,
                      background:stdFilter==='deleted'?'rgba(255,184,77,0.15)':'rgba(0,22,40,0.6)',
                      color:stdFilter==='deleted'?'#FFB84D':'#8899AA',
                      cursor:'pointer',fontSize:11,fontWeight:stdFilter==='deleted'?700:500,
                      transition:'all 0.2s'
                    }}>🗃️ Archived</button>
                  )}
                </div>
                <select
                  value={stdSort}
                  onChange={(e:any)=>setStdSort(e.target.value)}
                  style={{background:'rgba(0,22,40,0.7)',border:'1px solid rgba(77,159,255,0.2)',borderRadius:8,padding:'8px 10px',color:'#8899AA',fontSize:11,cursor:'pointer',outline:'none'}}
                >
                  <option value='newest'>🕐 Newest First</option>
                  <option value='name'>🔤 Name A–Z</option>
                  <option value='active'>✅ Active First</option>
                </select>
              </div>

              {/* ── SELECTED STUDENT DETAIL PANEL ─────────────── */}
              {selStudent&&(
                <div style={{
                  borderRadius:16,
                  border:'2px solid rgba(77,159,255,0.3)',
                  background:'linear-gradient(135deg,rgba(0,22,40,0.97) 0%,rgba(0,31,58,0.95) 100%)',
                  padding:'18px',
                  marginBottom:18,
                  boxShadow:'0 8px 32px rgba(77,159,255,0.1)'
                }}>
                  <div style={{display:'flex',gap:16,alignItems:'flex-start',flexWrap:'wrap'}}>
                    {/* Avatar */}
                    <div style={{
                      width:58,height:58,borderRadius:16,flexShrink:0,
                      background:'linear-gradient(135deg,#4D9FFF,#0055CC)',
                      display:'flex',alignItems:'center',justifyContent:'center',
                      fontSize:24,fontWeight:800,color:'#fff',
                      boxShadow:'0 6px 20px rgba(77,159,255,0.4)'
                    }}>
                      {(selStudent.name||'?').charAt(0).toUpperCase()}
                    </div>
                    {/* Details */}
                    <div style={{flex:1,minWidth:180}}>
                      <div style={{fontFamily:'Playfair Display,serif',fontSize:17,fontWeight:700,color:'#E8F4FD',marginBottom:4}}>{selStudent.name}</div>
                      <div style={{fontSize:12,color:'#8899AA',marginBottom:2}}>✉️ {selStudent.email}</div>
                      {selStudent.phone&&<div style={{fontSize:11,color:'#8899AA',marginBottom:2}}>📱 {selStudent.phone}</div>}
                      {(selStudent as any).city&&<div style={{fontSize:11,color:'#8899AA',marginBottom:2}}>📍 {(selStudent as any).city}</div>}
                      {(selStudent as any).school&&<div style={{fontSize:11,color:'#8899AA',marginBottom:2}}>🏫 {(selStudent as any).school}</div>}
                      {(selStudent as any).targetExam&&<div style={{fontSize:11,color:'#8899AA',marginBottom:2}}>🎯 Target: {(selStudent as any).targetExam}</div>}
                      {(selStudent as any).dob&&<div style={{fontSize:11,color:'#8899AA',marginBottom:2}}>🎂 DOB: {(selStudent as any).dob}</div>}
                      {(selStudent as any).qualifications&&<div style={{fontSize:11,color:'#8899AA',marginBottom:4}}>🎓 {(selStudent as any).qualifications}</div>}
                      <div style={{fontSize:10,color:'#8899AA',marginBottom:8}}>📅 Joined: {selStudent.createdAt?new Date(selStudent.createdAt).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}):'-'}</div>
                      <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                        {selStudent.banned&&<span style={{fontSize:10,background:'rgba(255,71,87,0.15)',color:'#FF4757',padding:'2px 8px',borderRadius:6,border:'1px solid rgba(255,71,87,0.3)'}}>🚫 Banned</span>}
                        {selStudent.group&&<Badge label={selStudent.group} col='#FFD700'/>}
                        {selStudent.integrityScore!==undefined&&(
                          <span style={{fontSize:10,background:`rgba(${selStudent.integrityScore>70?'0,196,140':selStudent.integrityScore>40?'255,184,77':'255,71,87'},0.15)`,color:selStudent.integrityScore>70?'#00C48C':selStudent.integrityScore>40?'#FFB84D':'#FF4757',padding:'2px 8px',borderRadius:6,border:`1px solid rgba(${selStudent.integrityScore>70?'0,196,140':selStudent.integrityScore>40?'255,184,77':'255,71,87'},0.3)`}}>
                            🤖 Integrity {selStudent.integrityScore}/100
                          </span>
                        )}
                      </div>
                    </div>
                    {/* Action Buttons */}
                    <div style={{display:'flex',flexDirection:'column' as const,gap:7,alignItems:'stretch',minWidth:120}}>
                      <button onClick={()=>{setImpId(selStudent._id);impersonate()}} style={{...bg_,fontSize:11,textAlign:'center' as const}}>👁️ View as Student</button>
                      {selStudent.banned
                        ?<button onClick={()=>unbanStd(selStudent._id)} style={{...bs,fontSize:11}}>🔓 Unban</button>
                        :<button onClick={()=>{setBanId(selStudent._id)}} style={{...bd,fontSize:11}}>🚫 Ban</button>
                      }
                      {typeof window!=='undefined'&&localStorage.getItem('pr_role')==='superadmin'&&(
                        <button
                          onClick={()=>setDelConfirmId(selStudent._id)}
                          style={{background:'rgba(255,71,87,0.08)',border:'1px solid rgba(255,71,87,0.35)',color:'#FF4757',borderRadius:10,padding:'9px 14px',cursor:'pointer',fontSize:11,fontWeight:600}}
                        >🗑️ Delete Account</button>
                      )}
                      <button onClick={()=>setSelStudent(null)} style={{background:'none',border:'1px solid rgba(77,159,255,0.15)',color:'#8899AA',borderRadius:10,padding:'7px',cursor:'pointer',fontSize:12,textAlign:'center' as const}}>✕ Close</button>
                    </div>
                  </div>
                  {/* Login History */}
                  {role==='superadmin'&&selStudent.loginHistory&&selStudent.loginHistory.length>0&&(
                    <div style={{marginTop:14,paddingTop:12,borderTop:'1px solid rgba(77,159,255,0.12)'}}>
                      <div style={{fontWeight:700,fontSize:10,color:'#8899AA',marginBottom:8,letterSpacing:'0.8px',textTransform:'uppercase' as const}}>📊 Recent Login Activity (S48)</div>
                      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(170px,1fr))',gap:6}}>
                        {selStudent.loginHistory.slice(0,4).map((l:any,i:number)=>(
                          <div key={i} style={{background:'rgba(0,22,40,0.7)',borderRadius:8,padding:'8px 10px',border:'1px solid rgba(77,159,255,0.1)'}}>
                            <div style={{fontSize:10,color:'#E8F4FD',fontWeight:600}}>📍 {l.city||'Unknown'}</div>
                            <div style={{fontSize:10,color:'#8899AA',marginTop:2}}>{l.device||'—'}</div>
                            <div style={{fontSize:9,color:'#8899AA',marginTop:1}}>{l.ip||'—'}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              

              {/* ── DELETE CONFIRMATION MODAL (SuperAdmin only) ── */}
{delConfirmId&&(
                <div style={{position:'fixed' as const,top:0,left:0,right:0,bottom:0,background:'rgba(0,0,0,0.75)',backdropFilter:'blur(4px)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:9999,padding:16}}>
                  <div style={{
                    background:'linear-gradient(135deg,rgba(5,10,20,0.99),rgba(10,18,35,0.98))',
                    border:'2px solid rgba(255,71,87,0.4)',
                    borderRadius:20,
                    padding:'28px 24px',
                    maxWidth:400,width:'100%',
                    boxShadow:'0 20px 60px rgba(0,0,0,0.6)'
                  }}>
                    <div style={{fontSize:44,textAlign:'center' as const,marginBottom:10}}>⚠️</div>
                    <div style={{fontWeight:800,fontSize:16,color:'#FF4757',textAlign:'center' as const,marginBottom:6,fontFamily:'Playfair Display,serif'}}>Delete Student Account</div>
                    <div style={{fontSize:12,color:'#8899AA',textAlign:'center' as const,marginBottom:6,lineHeight:1.7}}>
                      Ye account active list se hata diya jayega.<br/>
                      Superadmin ise kabhi bhi restore kar sakta hai.
                    </div>
                    <div style={{fontSize:11,color:'#00C48C',textAlign:'center' as const,marginBottom:16,padding:'8px 12px',background:'rgba(0,196,140,0.08)',borderRadius:8,border:'1px solid rgba(0,196,140,0.2)'}}>
                      ✅ Student same email se fresh account bana sakta hai
                    </div>
                    <div style={{marginBottom:16}}>
                      <label style={{fontSize:11,color:'#8899AA',display:'block',marginBottom:6,fontWeight:600}}>Delete Reason (SuperAdmin archive mein save hoga)</label>
                      <STextarea init='' onSet={(v:string)=>{delReasonR.current=v}} ph='e.g. Test account, Rules violation, Duplicate account…' rows={2} style={{width:'100%',background:'rgba(255,71,87,0.06)',border:'1px solid rgba(255,71,87,0.3)',borderRadius:10,padding:'10px 12px',color:'#E8F4FD',fontSize:12,outline:'none',resize:'vertical' as const}}/>
                    </div>
                    <div style={{display:'flex',gap:10}}>
                      <button
                        onClick={()=>softDelStd(delConfirmId)}
                        disabled={stdDelLoading}
                        style={{flex:1,padding:'12px',background:'linear-gradient(135deg,#FF4757,#CC0020)',border:'none',borderRadius:12,color:'#fff',fontWeight:700,cursor:stdDelLoading?'not-allowed' as const:'pointer' as const,opacity:stdDelLoading?0.7:1,fontSize:13}}
                      >{stdDelLoading?'⟳ Deleting…':'🗑️ Confirm Delete'}</button>
                      <button onClick={()=>setDelConfirmId('')} style={{...bg_,padding:'12px 18px'}}>Cancel</button>
                    </div>
                  </div>
                </div>
              )}

              {/* ── ARCHIVED STUDENTS (SuperAdmin only, deleted filter) ── */}
              {stdFilter==='deleted'&&typeof window!=='undefined'&&localStorage.getItem('pr_role')==='superadmin'&&(
                <div>
                  <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:14,flexWrap:'wrap',gap:8}}>
                    <div>
                      <div style={{fontWeight:700,fontSize:13,color:'#FFB84D'}}>🗃️ Archived Student Accounts</div>
                      <div style={{fontSize:11,color:'#8899AA',marginTop:3}}>{deletedStds.length} archived · Only visible to SuperAdmin · Restore anytime</div>
                    </div>
                    <button onClick={fetchDeletedStds} style={{...bg_,fontSize:11}}>🔄 Refresh</button>
                  </div>
                  {deletedStds.length===0
                    ?<div style={{background:'rgba(255,184,77,0.05)',border:'1px solid rgba(255,184,77,0.15)',borderRadius:16,padding:'40px 20px',textAlign:'center' as const}}>
                      <div style={{fontSize:48,marginBottom:12}}>🗃️</div>
                      <div style={{fontWeight:700,fontSize:14,color:'#E8F4FD',marginBottom:6}}>No Archived Students</div>
                      <div style={{fontSize:12,color:'#8899AA'}}>Deleted student accounts will appear here. You can restore them anytime.</div>
                    </div>
                    :<div style={{display:'grid',gap:10}}>
                      {deletedStds.map((s:any)=>(
                        <div key={s._id} style={{
                          background:'linear-gradient(135deg,rgba(255,184,77,0.05),rgba(0,22,40,0.8))',
                          border:'1px solid rgba(255,184,77,0.2)',
                          borderRadius:14,
                          padding:'14px 16px',
                          display:'flex',gap:12,alignItems:'center',flexWrap:'wrap' as const,justifyContent:'space-between' as const
                        }}>
                          <div style={{display:'flex',gap:12,alignItems:'center',flex:1,minWidth:180}}>
                            <div style={{width:44,height:44,borderRadius:12,background:'linear-gradient(135deg,rgba(255,184,77,0.5),rgba(255,71,87,0.5))',display:'flex',alignItems:'center',justifyContent:'center',fontSize:18,fontWeight:800,color:'#fff',flexShrink:0}}>
                              {(s.name||'?').charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div style={{fontWeight:700,fontSize:13,color:'#E8F4FD'}}>{s.name||'—'}</div>
                              <div style={{fontSize:11,color:'#8899AA'}}>✉️ {s.studentId&&<span style={{fontSize:10,fontWeight:700,color:'#4D9FFF',fontFamily:'monospace',letterSpacing:1,display:'inline-flex',alignItems:'center',gap:3}}>{s.studentId}</span>} {s.email}</div>
                              {s.phone&&<div style={{fontSize:10,color:'#8899AA'}}>📱 {s.phone}</div>}
                              <div style={{display:'flex',gap:6,marginTop:5,flexWrap:'wrap' as const}}>
                                {s.group&&<span style={{fontSize:9,background:'rgba(255,215,0,0.15)',color:'#FFD700',padding:'2px 7px',borderRadius:5,border:'1px solid rgba(255,215,0,0.3)'}}>{s.group}</span>}
                                {s._snapshot?.targetExam&&<span style={{fontSize:9,background:'rgba(77,159,255,0.12)',color:'#4D9FFF',padding:'2px 7px',borderRadius:5,border:'1px solid rgba(77,159,255,0.25)'}}>🎯 {s._snapshot.targetExam}</span>}
                              </div>
                              {s.deleteReason&&<div style={{fontSize:10,color:'#FF4757',marginTop:4}}>Reason: {s.deleteReason}</div>}
                              {s.deletedAt&&<div style={{fontSize:10,color:'#8899AA',marginTop:2}}>🗑️ Archived: {new Date(s.deletedAt).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}</div>}
                            </div>
                          </div>
                          <button
                            onClick={()=>restoreStd(s._id)}
                            style={{background:'rgba(0,196,140,0.1)',border:'1px solid rgba(0,196,140,0.3)',color:'#00C48C',borderRadius:10,padding:'9px 16px',cursor:'pointer',fontSize:11,fontWeight:700}}
                          >🔄 Restore</button>
                        </div>
                      ))}
                    </div>
                  }
                </div>
              )}

              {/* ── ACTIVE STUDENT LIST ──────────────────────── */}
              {stdFilter!=='deleted'&&(
                <>
                  {fStds.filter((s:any)=>!s.deleted).length===0
                    ?<PageHero icon="👥" title="No Students Found" subtitle="Students will appear here after they register. Use bulk import to add multiple students at once."/>
                    :(()=>{
                      const raw=fStds.filter((s:any)=>!s.deleted);
                      const sorted=stdSort==='name'
                        ?[...raw].sort((a,b)=>(a.name||'').localeCompare(b.name||''))
                        :stdSort==='active'
                        ?[...raw].sort((a,b)=>Number(!!a.banned)-Number(!!b.banned))
                        :[...raw].sort((a,b)=>new Date(b.createdAt||0).getTime()-new Date(a.createdAt||0).getTime());
                      const avatarColors=['#4D9FFF','#00C48C','#A78BFA','#FF6B9D','#FFD700','#00E5FF','#FF8C42','#7CFC00'];
                      return sorted.map((s:any,idx:number)=>(
                        <div
                          key={s._id}
                          className="card-hover"
                          style={{
                            background:selStudent?._id===s._id?'rgba(77,159,255,0.08)':'rgba(0,22,40,0.75)',
                            border:`1px solid ${s.banned?'rgba(255,71,87,0.3)':selStudent?._id===s._id?'rgba(77,159,255,0.4)':'rgba(77,159,255,0.12)'}`,
                            borderLeft:`3px solid ${s.banned?'#FF4757':avatarColors[idx%8]}`,
                            borderRadius:14,
                            padding:'12px 14px',
                            marginBottom:8,
                            display:'flex',gap:12,alignItems:'center',flexWrap:'wrap' as const,
                            justifyContent:'space-between' as const,
                            cursor:'pointer',
                            transition:'all 0.22s'
                          }}
                          onClick={()=>{
                            const isSuper = typeof window!=='undefined' && localStorage.getItem('pr_role')==='superadmin'
                            if (isSuper) setPreview360Id(s._id)
                            else setSelStudent(s)
                          }}
                        >
                          <div style={{display:'flex',gap:12,alignItems:'center',flex:1,minWidth:150}}>
                            {/* Color Avatar */}
                            <div style={{
                              width:42,height:42,borderRadius:12,flexShrink:0,
                              background:`linear-gradient(135deg,${avatarColors[idx%8]},${avatarColors[(idx+3)%8]})`,
                              display:'flex',alignItems:'center',justifyContent:'center',
                              fontSize:17,fontWeight:800,color:'#fff',
                              boxShadow:`0 3px 10px ${avatarColors[idx%8]}44`
                            }}>
                              {(s.name||'?').charAt(0).toUpperCase()}
                            </div>
                            <div style={{flex:1}}>
                              <div style={{display:'flex',alignItems:'center',gap:6,flexWrap:'wrap' as const,marginBottom:2}}>
                                <span style={{fontWeight:700,fontSize:13,color:'#E8F4FD'}}>{s.name||'—'}</span>
                                {s.banned&&<span style={{fontSize:9,background:'rgba(255,71,87,0.15)',color:'#FF4757',padding:'1px 6px',borderRadius:5,border:'1px solid rgba(255,71,87,0.3)'}}>BANNED</span>}
                                {s.group&&<span style={{fontSize:9,background:'rgba(255,215,0,0.12)',color:'#FFD700',padding:'1px 6px',borderRadius:5,border:'1px solid rgba(255,215,0,0.25)'}}>{s.group}</span>}
                              </div>
                              {(s as any).studentId&&<div style={{display:'inline-flex',alignItems:'center',gap:5,marginBottom:3,padding:'2px 8px',background:'rgba(77,159,255,0.08)',borderRadius:5,border:'1px solid rgba(77,159,255,0.18)',width:'fit-content'}}><span style={{fontSize:9,fontWeight:800,color:'#4D9FFF',fontFamily:'monospace',letterSpacing:1.5}}>{(s as any).studentId}</span></div>}
                <div style={{fontSize:11,color:'#8899AA'}}>{s.email}</div>
                              <div style={{display:'flex',gap:10,marginTop:2,fontSize:10,color:'#8899AA',flexWrap:'wrap' as const}}>
                                {s.phone&&<span>📱 {s.phone}</span>}
                                <span>📅 {s.createdAt?new Date(s.createdAt).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}):'-'}</span>
                              </div>
                              {s.integrityScore!==undefined&&(
                                <div style={{display:'flex',alignItems:'center',gap:7,marginTop:5}}>
                                  <div style={{width:70,height:3,background:'rgba(255,255,255,0.07)',borderRadius:2}}>
                                    <div style={{width:`${Math.min(s.integrityScore,100)}%`,height:'100%',borderRadius:2,background:s.integrityScore>70?'#00C48C':s.integrityScore>40?'#FFB84D':'#FF4757',transition:'width 0.5s'}}/>
                                  </div>
                                  <span style={{fontSize:9,color:s.integrityScore>70?'#00C48C':s.integrityScore>40?'#FFB84D':'#FF4757',fontWeight:600}}>{s.integrityScore}/100</span>
                                </div>
                              )}
                            </div>
                          </div>
                          {/* Action Buttons */}
                          <div style={{display:'flex',gap:6,flexWrap:'wrap' as const}} onClick={(e:any)=>e.stopPropagation()}>
                            <button onClick={(e:any)=>{e.stopPropagation();setSelStudent(s)}} style={{...bg_,fontSize:10,padding:'6px 10px'}}>👁️ View</button>
                            {typeof window!=='undefined'&&localStorage.getItem('pr_role')==='superadmin'&&(
                              <button
                                onClick={(e:any)=>{e.stopPropagation();setPreview360Id(s._id)}}
                                title="360° Profile Preview (SuperAdmin only)"
                                style={{background:'rgba(168,85,247,0.1)',border:'1px solid rgba(168,85,247,0.35)',color:'#C084FC',borderRadius:8,padding:'6px 10px',cursor:'pointer',fontSize:10,fontWeight:700}}
                              >🔎 360°</button>
                            )}
                            {s.banned
                              ?<button onClick={(e:any)=>{e.stopPropagation();unbanStd(s._id)}} style={{...bs,fontSize:10,padding:'6px 10px'}}>🔓 Unban</button>
                              :<button onClick={(e:any)=>{e.stopPropagation();setBanId(s._id)}} style={{...bd,fontSize:10,padding:'6px 10px'}}>🚫 Ban</button>
                            }
                            {typeof window!=='undefined'&&localStorage.getItem('pr_role')==='superadmin'&&(
                              <button
                                onClick={(e:any)=>{e.stopPropagation();setDelConfirmId(s._id)}}
                                title="Delete account (SuperAdmin only)"
                                style={{background:'rgba(255,71,87,0.08)',border:'1px solid rgba(255,71,87,0.3)',color:'#FF4757',borderRadius:8,padding:'6px 10px',cursor:'pointer',fontSize:10,fontWeight:700}}
                              >🗑️</button>
                            )}
                          </div>
                        </div>
                      ));
                    })()
                  }
                </>
              )}

              {/* ── BAN PANEL ────────────────────────────────── */}
              {banId&&(
                <div style={{
                  background:'linear-gradient(135deg,rgba(255,71,87,0.05),rgba(0,22,40,0.95))',
                  border:'2px solid rgba(255,71,87,0.3)',
                  borderRadius:16,
                  padding:'18px',
                  marginTop:16
                }}>
                  <div style={{fontWeight:700,fontSize:14,color:'#FF4757',marginBottom:14}}>🚫 Ban Student</div>
                  <div style={{marginBottom:12}}>
                    <label style={{fontSize:11,color:'#8899AA',display:'block',marginBottom:6,fontWeight:600}}>Ban Reason *</label>
                    <STextarea init='' onSet={(v:string)=>{banReaR.current=v}} ph='Explain why this student is being banned…' rows={2} style={{width:'100%',background:'rgba(0,22,40,0.7)',border:'1px solid rgba(77,159,255,0.2)',borderRadius:10,padding:'10px 12px',color:'#E8F4FD',fontSize:12,outline:'none',resize:'vertical' as const}}/>
                  </div>
                  <div style={{marginBottom:14}}>
                    <label style={{fontSize:11,color:'#8899AA',display:'block',marginBottom:6,fontWeight:600}}>Ban Type</label>
                    <SSelect val={banT} onChange={(v:string)=>setBanT(v as 'permanent'|'temporary')} opts={[{v:'permanent',l:'Permanent Ban'},{v:'temporary',l:'Temporary Ban (30 days)'}]} style={{width:'100%',background:'rgba(0,22,40,0.7)',border:'1px solid rgba(77,159,255,0.2)',borderRadius:10,padding:'10px 12px',color:'#E8F4FD',fontSize:12,outline:'none'}}/>
                  </div>
                  <div style={{display:'flex',gap:10}}>
                    <button onClick={banStd} style={{...bd,flex:1,padding:'11px',fontSize:13}}>🚫 Confirm Ban</button>
                    <button onClick={()=>setBanId('')} style={{...bg_,padding:'11px 20px'}}>Cancel</button>
                  </div>
                </div>
              )}
            </div>
          )}


          {tab==='test_series'&&(<TestSeriesManagerUltra token={token} API={API}/>)}
                    {/* ══ ADMINS ══ */}
          {showProfileModal&&(
                <div onClick={()=>setShowProfileModal(false)} style={{position:'fixed' as const,top:0,left:0,right:0,bottom:0,background:'rgba(0,0,0,0.82)',backdropFilter:'blur(6px)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:9999,padding:16}}>
                  <div onClick={e=>e.stopPropagation()} style={{background:'linear-gradient(135deg,rgba(5,10,24,0.99),rgba(8,16,36,0.98))',border:'1.5px solid rgba(0,180,255,0.25)',borderRadius:20,padding:'28px 24px',maxWidth:520,width:'100%',maxHeight:'88vh',overflowY:'auto' as const,boxShadow:'0 24px 80px rgba(0,180,255,0.12)'}}>
                    <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:20}}>
                      <div style={{fontWeight:800,fontSize:18,color:'#00B4FF',fontFamily:'Playfair Display,serif'}}>👤 Admin Profile</div>
                      <button onClick={()=>setShowProfileModal(false)} style={{background:'rgba(255,71,87,0.12)',border:'1px solid rgba(255,71,87,0.3)',color:'#FF4757',borderRadius:8,padding:'4px 12px',cursor:'pointer',fontSize:13}}>✕ Close</button>
                    </div>
                    {profileLoading?(
                      <div style={{textAlign:'center' as const,padding:'40px 0',color:'#4D9FFF',fontSize:14}}>⏳ Loading profile...</div>
                    ):profileAdmin?(
                      <div>
                        <div style={{display:'flex',alignItems:'center',gap:16,marginBottom:20,padding:16,background:'rgba(0,180,255,0.06)',borderRadius:14,border:'1px solid rgba(0,180,255,0.15)'}}>
                          <div style={{width:60,height:60,background:'linear-gradient(135deg,rgba(0,180,255,0.2),rgba(77,159,255,0.3))',border:'2px solid rgba(0,180,255,0.4)',borderRadius:14,display:'flex',alignItems:'center',justifyContent:'center',fontSize:26,fontWeight:900,color:'#00B4FF',flexShrink:0}}>{(profileAdmin.name||'A')[0].toUpperCase()}</div>
                          <div>
                            <div style={{fontWeight:700,fontSize:16,color:'#E8F4FF'}}>{profileAdmin.name||'—'}</div>
                  {profileAdmin.adminId&&<div style={{fontSize:11,color:'#00B4FF',background:'rgba(0,180,255,0.1)',border:'1px solid rgba(0,180,255,0.3)',borderRadius:12,padding:'3px 12px',marginTop:6,fontWeight:700,letterSpacing:1,display:'inline-block'}}>&#x1FA96; {profileAdmin.adminId}</div>}
                            <div style={{fontSize:12,color:'#6B8FAF',marginTop:3}}>{profileAdmin.email||'—'}</div>
                            <div style={{marginTop:6,display:'flex',gap:6}}>
                              <span style={{fontSize:10,background:'rgba(0,180,255,0.12)',color:'#00B4FF',borderRadius:20,padding:'2px 10px',fontWeight:600}}>{(profileAdmin.role||'admin').toUpperCase()}</span>
                              <span style={{fontSize:10,background:profileAdmin.frozen?'rgba(255,165,0,0.12)':'rgba(0,220,130,0.12)',color:profileAdmin.frozen?'#FFA500':'#00DC82',borderRadius:20,padding:'2px 10px',fontWeight:600}}>{profileAdmin.frozen?'FROZEN':'ACTIVE'}</span>
                            </div>
                          </div>
                        </div>
                        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:16}}>
                          {[['📧 Email',profileAdmin.email],['📱 Phone',profileAdmin.phone||'—'],['🗓️ Joined',profileAdmin.createdAt?new Date(profileAdmin.createdAt).toLocaleDateString('en-IN'):'—'],['🔐 2FA',profileAdmin.twoFactorEnabled?'Enabled':'Disabled']].map(([label,val])=>(
                            <div key={label as string} style={{background:'rgba(0,10,28,0.6)',border:'1px solid rgba(0,180,255,0.1)',borderRadius:10,padding:'10px 12px'}}>
                              <div style={{fontSize:10,color:'#6B8FAF',marginBottom:3}}>{label as string}</div>
                              <div style={{fontSize:12,color:'#C8D8E8',fontWeight:600,wordBreak:'break-all' as const}}>{val as string}</div>
                            </div>
                          ))}
                        </div>
                        {profileAdmin.permissions&&Object.keys(profileAdmin.permissions).length>0&&(
                          <div style={{marginBottom:16}}>
                            <div style={{fontSize:12,color:'#6B8FAF',fontWeight:600,marginBottom:8}}>🔑 PERMISSIONS</div>
                            <div style={{display:'flex',flexWrap:'wrap' as const,gap:6}}>
                              {Object.entries(profileAdmin.permissions).filter(([,v])=>v).map(([k])=>(
                                <span key={k} style={{fontSize:10,background:'rgba(0,180,255,0.1)',color:'#00B4FF',borderRadius:20,padding:'3px 10px',fontWeight:600}}>{k.replace(/_/g,' ')}</span>
                              ))}
                            </div>
                          </div>
                        )}
                        {profileLogs&&profileLogs.length>0&&(
                          <div>
                            <div style={{fontSize:12,color:'#6B8FAF',fontWeight:600,marginBottom:8}}>📋 RECENT ACTIVITY</div>
                            <div style={{maxHeight:160,overflowY:'auto' as const,display:'flex',flexDirection:'column' as const,gap:6}}>
                              {profileLogs.slice(0,10).map((log:any,i:number)=>(
                                <div key={i} style={{background:'rgba(0,10,28,0.5)',border:'1px solid rgba(0,180,255,0.08)',borderRadius:8,padding:'8px 10px',fontSize:11}}>
                                  <span style={{color:'#00B4FF',fontWeight:600}}>{log.action||log.type||'Action'}</span>
                                  <span style={{color:'#4D6080',marginLeft:8}}>{log.createdAt?new Date(log.createdAt).toLocaleString('en-IN'):''}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ):(
                      <div style={{textAlign:'center' as const,padding:'40px 0',color:'#FF4757',fontSize:13}}>❌ Failed to load profile. Please try again.</div>
                    )}
                  </div>
                </div>
              )}
      {tab==='admins'&&(
            <div>

              {/* ─── PREMIUM HEADER ─── */}
              <div style={{background:'linear-gradient(135deg,rgba(4,30,60,0.97),rgba(0,18,42,0.99))',border:'1px solid rgba(77,159,255,0.22)',borderRadius:20,padding:'22px 22px 18px',marginBottom:20,position:'relative',overflow:'hidden'}}>
                <div style={{position:'absolute',top:-50,right:-50,width:200,height:200,borderRadius:'50%',background:'radial-gradient(circle,rgba(77,159,255,0.09),transparent 70%)',pointerEvents:'none'}}></div>
                <div style={{display:'flex',alignItems:'center',gap:16,position:'relative',zIndex:1}}>
                  <div style={{width:54,height:54,background:'linear-gradient(135deg,rgba(77,159,255,0.2),rgba(0,212,255,0.1))',border:'1.5px solid rgba(77,159,255,0.4)',borderRadius:16,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,boxShadow:'0 6px 24px rgba(77,159,255,0.18)'}}>
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none"><path d="M12 2L3 7v5c0 5.25 3.75 10.15 9 11.35C17.25 22.15 21 17.25 21 12V7L12 2z" fill="rgba(77,159,255,0.22)" stroke="#4D9FFF" strokeWidth="1.6" strokeLinejoin="round"/><circle cx="12" cy="10" r="2.6" fill="#4D9FFF"/><path d="M7.5 16.5c.5-2 2.3-3.5 4.5-3.5s4 1.5 4.5 3.5" stroke="#4D9FFF" strokeWidth="1.5" strokeLinecap="round"/></svg>
                  </div>
                  <div>
                    <div style={{fontFamily:'Playfair Display,serif',fontSize:22,fontWeight:700,background:'linear-gradient(90deg,#4D9FFF,#00D4FF)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent',lineHeight:1.3}}>Admin Management</div>
                    <div style={{display:'flex',alignItems:'center',gap:8,marginTop:5,flexWrap:'wrap'}}>
                      <span style={{background:'rgba(77,159,255,0.15)',color:'#4D9FFF',borderRadius:20,padding:'2px 10px',fontSize:10,fontWeight:700,border:'1px solid rgba(77,159,255,0.3)'}}>S37</span>
                      <span style={{fontSize:11,color:'#6B8FAF'}}>Create · Freeze · Archive · Restore sub-admin accounts</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* ─── STATS ROW ─── */}
              <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,marginBottom:20}}>
                {[
                  {icon:'👥',label:'Total',val:(adminUsers||[]).length+archivedAdmins.length,col:'#4D9FFF',brd:'rgba(77,159,255,0.22)'},
                  {icon:'✅',label:'Active',val:(adminUsers||[]).filter(a=>!a.frozen).length,col:'#00C48C',brd:'rgba(0,196,140,0.22)'},
                  {icon:'🔒',label:'Frozen',val:(adminUsers||[]).filter(a=>a.frozen).length,col:'#FFB84D',brd:'rgba(255,184,77,0.22)'},
                  {icon:'🗃️',label:'Archived',val:archivedAdmins.length,col:'#FF6B6B',brd:'rgba(255,107,107,0.22)'},
                ].map((s,i)=>(
                  <div key={i} style={{background:'rgba(0,18,36,0.9)',border:`1px solid ${s.brd}`,borderRadius:14,padding:'14px 10px',textAlign:'center'}}>
                    <div style={{fontSize:20,marginBottom:6}}>{s.icon}</div>
                    <div style={{fontSize:20,fontWeight:800,color:s.col,lineHeight:1}}>{s.val}</div>
                    <div style={{fontSize:10,color:'#6B8FAF',marginTop:5,fontWeight:600}}>{s.label}</div>
                  </div>
                ))}
              </div>

              {/* ─── CREATE FORM ─── */}
              <div style={{...cs,marginBottom:20,border:'1px solid rgba(77,159,255,0.22)',padding:'0'}}>
                <div style={{background:'linear-gradient(90deg,rgba(77,159,255,0.1),rgba(0,212,255,0.04))',borderBottom:'1px solid rgba(77,159,255,0.12)',padding:'14px 18px',display:'flex',alignItems:'center',gap:10,flexWrap:'wrap'}}>
                  <div style={{width:32,height:32,background:'rgba(77,159,255,0.15)',borderRadius:9,display:'flex',alignItems:'center',justifyContent:'center',fontSize:15,border:'1px solid rgba(77,159,255,0.25)',flexShrink:0}}>➕</div>
                  <div style={{fontWeight:700,fontSize:13,color:'#E8F4FF',flex:1}}>Create New Admin Account</div>
                  <span style={{fontSize:10,color:'#4D9FFF',background:'rgba(77,159,255,0.1)',borderRadius:20,padding:'2px 10px',border:'1px solid rgba(77,159,255,0.2)',fontWeight:600}}>SuperAdmin Only</span>
                </div>
                <div style={{padding:'16px 18px'}}>
                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                    <div><label style={lbl}>Full Name *</label><SInput init='' onSet={v=>{admNameR.current=v}} ph='Admin full name' style={inp}/></div>
                    <div><label style={lbl}>Email *</label><SInput init='' onSet={v=>{admEmailR.current=v}} ph='admin@proverank.com' type='email' style={inp}/></div>
                    <div><label style={lbl}>Password *</label><SInput init='' onSet={v=>{admPassR.current=v}} ph='Strong password' type='password' style={inp}/></div>
                    <div><label style={lbl}>Role</label><SSelect val={admRole} onChange={setAdmRole} opts={[{v:'admin',l:'🛡️ Admin'},{v:'moderator',l:'🔍 Moderator'},{v:'superadmin',l:'👑 Super Admin'}]} style={{...inp}}/></div>
                  </div>
                  <button onClick={createAdmin} disabled={creatingAdm} style={{...bp,width:'100%',marginTop:14,opacity:creatingAdm?0.7:1}}>
                    {creatingAdm?'⟳ Creating…':'🛡️ Create Admin Account'}
                  </button>
                </div>
              </div>

              {/* ─── ACTIVE ADMINS LABEL ─── */}
              <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:12,padding:'0 2px'}}>
                <div style={{width:3,height:20,background:'linear-gradient(180deg,#4D9FFF,#00D4FF)',borderRadius:4,flexShrink:0}}></div>
                <span style={{fontWeight:700,fontSize:13,color:'#E8F4FF'}}>Active Admins</span>
                <span style={{background:'rgba(77,159,255,0.14)',color:'#4D9FFF',borderRadius:20,padding:'2px 10px',fontSize:11,fontWeight:700,border:'1px solid rgba(77,159,255,0.25)'}}>{(adminUsers||[]).length}</span>
              </div>

              {/* ─── ACTIVE ADMINS LIST ─── */}
              {(adminUsers||[]).length===0
                ?<div style={{...cs,textAlign:'center',padding:'32px 20px',marginBottom:20,border:'1px dashed rgba(77,159,255,0.2)'}}>
                  <div style={{fontSize:36,marginBottom:8,opacity:0.4}}>🛡️</div>
                  <div style={{fontSize:12,color:DIM}}>No sub-admins yet. Use the form above to create one.</div>
                </div>
                :<div style={{display:'flex',flexDirection:'column',gap:10,marginBottom:20}}>
                  {(adminUsers||[]).map(au=>(
                    <div key={au._id} style={{background:au.frozen?'rgba(36,18,0,0.9)':'rgba(0,20,42,0.9)',border:`1px solid ${au.frozen?'rgba(255,184,77,0.3)':'rgba(77,159,255,0.18)'}`,borderRadius:16,padding:'14px 16px',position:'relative',overflow:'hidden'}}>
                      <div style={{position:'absolute',top:0,left:0,right:0,height:2,background:au.frozen?'linear-gradient(90deg,#FFB84D,#FF9800)':'linear-gradient(90deg,#4D9FFF,#00D4FF)'}}></div>
                      <div style={{display:'flex',alignItems:'center',gap:12,flexWrap:'wrap'}}>
                        <div style={{width:46,height:46,background:au.frozen?'rgba(80,40,0,0.8)':'rgba(77,159,255,0.15)',border:`2px solid ${au.frozen?'rgba(255,184,77,0.4)':'rgba(77,159,255,0.35)'}`,borderRadius:13,display:'flex',alignItems:'center',justifyContent:'center',fontSize:18,fontWeight:900,color:au.frozen?'#FFB84D':'#4D9FFF',flexShrink:0,fontFamily:'Inter,sans-serif'}}>
                          {(au.name||'A')[0].toUpperCase()}
                        </div>
                        <div style={{flex:1,minWidth:140}}>
                          <div style={{display:'flex',alignItems:'center',gap:8,flexWrap:'wrap',marginBottom:3}}>
                            <span style={{fontWeight:700,fontSize:14,color:'#E8F4FF'}}>{au.name}</span>
                            {au.frozen&&<span style={{fontSize:10,background:'rgba(255,184,77,0.16)',color:'#FFB84D',borderRadius:20,padding:'1px 8px',fontWeight:700,border:'1px solid rgba(255,184,77,0.3)'}}>🔒 FROZEN</span>}
                          </div>
                          <div style={{fontSize:11,color:'#6B8FAF',marginBottom:6}}>{au.email}</div>
                          <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                            <span style={{fontSize:10,background:'rgba(77,159,255,0.12)',color:'#4D9FFF',borderRadius:20,padding:'2px 9px',fontWeight:700,border:'1px solid rgba(77,159,255,0.22)'}}>{(au.role||'admin').toUpperCase()}</span>
                            {!au.frozen&&<span style={{fontSize:10,background:'rgba(0,196,140,0.1)',color:'#00C48C',borderRadius:20,padding:'2px 8px',fontWeight:600,border:'1px solid rgba(0,196,140,0.2)'}}>● Active</span>}
                          </div>
                        </div>
                        <div style={{display:'flex',gap:7,flexShrink:0,flexWrap:'wrap'}}>
                          <button onClick={()=>viewAdminProfile(au._id)} style={{background:'rgba(0,180,255,0.09)',border:'1px solid rgba(0,180,255,0.24)',color:'#00B4FF',borderRadius:10,padding:'7px 12px',fontSize:11,cursor:'pointer',fontWeight:600}}>👁️ Profile</button>
                          <button onClick={async()=>{const r=await fetch(`${API}/api/admin/manage/freeze/${au._id}`,{method:'PUT',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify({frozen:!au.frozen})});const d=await r.json();if(d.success){T(au.frozen?'Admin unfrozen.':'Admin frozen — cannot login now.');setAdminUsers(p=>p.map(a=>a._id===au._id?{...a,frozen:!au.frozen}:a))}else T(d.message||'Failed','e')}} style={{background:au.frozen?'rgba(0,196,140,0.09)':'rgba(255,184,77,0.09)',border:`1px solid ${au.frozen?'rgba(0,196,140,0.28)':'rgba(255,184,77,0.28)'}`,color:au.frozen?'#00C48C':'#FFB84D',borderRadius:10,padding:'7px 12px',fontSize:11,cursor:'pointer',fontWeight:600}}>{au.frozen?'🔓 Unfreeze':'🔒 Freeze'}</button>
                          <button onClick={async()=>{if(confirm('Archive this admin? They will not be able to login.')){const r=await fetch(`${API}/api/admin/manage/archive/${au._id}`,{method:'PUT',headers:{Authorization:`Bearer ${token}`}});const d=await r.json();if(d.success){T('Admin archived.');setAdminUsers(p=>p.filter(a=>a._id!==au._id));fetchArchivedAdmins();}else T(d.message||'Failed','e')}}} style={{background:'rgba(255,77,77,0.08)',border:'1px solid rgba(255,77,77,0.22)',color:'#FF6B6B',borderRadius:10,padding:'7px 12px',fontSize:11,cursor:'pointer',fontWeight:600}}>🗑️ Archive</button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              }

              {/* ─── ARCHIVED ADMINS (INSIDE TAB) ─── */}
              <div style={{background:'rgba(4,12,30,0.97)',border:'1.5px solid rgba(77,159,255,0.2)',borderRadius:18,overflow:'hidden'}}>
                <div style={{background:'rgba(77,159,255,0.06)',borderBottom:'1px solid rgba(77,159,255,0.12)',padding:'14px 18px',display:'flex',alignItems:'center',justifyContent:'space-between',flexWrap:'wrap',gap:8}}>
                  <div style={{display:'flex',alignItems:'center',gap:10}}>
                    <div style={{width:32,height:32,background:'rgba(77,159,255,0.12)',borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,border:'1px solid rgba(77,159,255,0.25)',flexShrink:0}}>🗃️</div>
                    <div>
                      <div style={{fontWeight:700,fontSize:13,color:'#7BB8FF'}}>Archived Admins</div>
                      <div style={{fontSize:10,color:'#4D6A8F',marginTop:1}}>Restore anytime to reactivate login access</div>
                    </div>
                    <span style={{background:'rgba(77,159,255,0.14)',color:'#4D9FFF',borderRadius:20,padding:'2px 10px',fontSize:11,fontWeight:700,border:'1px solid rgba(77,159,255,0.28)'}}>{archivedAdmins.length}</span>
                  </div>
                  <button onClick={fetchArchivedAdmins} style={{background:'rgba(77,159,255,0.09)',border:'1px solid rgba(77,159,255,0.22)',color:'#4D9FFF',borderRadius:9,padding:'7px 13px',fontSize:11,cursor:'pointer',fontWeight:600}}>🔄 Refresh</button>
                </div>
                <div style={{padding:'16px 18px'}}>
                  {archivedAdmins.length===0
                    ?<div style={{textAlign:'center',padding:'24px 0'}}>
                      <div style={{fontSize:28,marginBottom:8,opacity:0.4}}>✅</div>
                      <div style={{color:'#4D6A8F',fontSize:12,fontWeight:600}}>No archived admins — All admins are active</div>
                    </div>
                    :<div style={{display:'flex',flexDirection:'column',gap:10}}>
                      {archivedAdmins.map(aa=>(
                        <div key={aa._id} style={{background:'rgba(0,10,28,0.6)',border:'1px solid rgba(77,159,255,0.12)',borderRadius:13,padding:'13px 15px',display:'flex',alignItems:'center',gap:12,flexWrap:'wrap'}}>
                          <div style={{width:40,height:40,background:'rgba(77,159,255,0.12)',border:'1.5px solid rgba(77,159,255,0.25)',borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,fontWeight:900,color:'#7BB8FF',flexShrink:0}}>
                            {(aa.name||'A')[0].toUpperCase()}
                          </div>
                          <div style={{flex:1,minWidth:130}}>
                            <div style={{fontWeight:600,fontSize:13,color:'#C8D4E0'}}>{aa.name||'Unknown'}</div>
                            <div style={{fontSize:11,color:'#667788',marginTop:2}}>{aa.email}</div>
                            <div style={{display:'flex',gap:5,marginTop:5,flexWrap:'wrap'}}>
                              <span style={{background:'rgba(160,80,255,0.14)',color:'#C090FF',borderRadius:20,padding:'1px 8px',fontSize:10,fontWeight:600}}>{(aa.role||'admin').toUpperCase()}</span>
                              <span style={{background:'rgba(120,80,255,0.14)',color:'#A080FF',borderRadius:20,padding:'1px 8px',fontSize:10,fontWeight:600}}>🗃️ ARCHIVED</span>
                              {aa.archivedAt&&<span style={{fontSize:10,color:'#3D5A7A'}}>📅 {new Date(aa.archivedAt).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}</span>}
                              {aa.archivedBy&&<span style={{fontSize:10,color:'#445566'}}>by {aa.archivedBy}</span>}
                            </div>
                          </div>
                          <div style={{display:'flex',gap:7,flexShrink:0}}>
                            <button onClick={()=>viewAdminProfile(aa._id)} style={{background:'rgba(0,180,255,0.09)',border:'1px solid rgba(0,180,255,0.24)',color:'#00B4FF',borderRadius:9,padding:'6px 12px',fontSize:11,cursor:'pointer',fontWeight:600}}>👁️ Profile</button>
                            <button onClick={()=>restoreAdmin(aa._id)} style={{background:'rgba(0,196,140,0.09)',border:'1px solid rgba(0,196,140,0.26)',color:'#00C48C',borderRadius:9,padding:'6px 12px',fontSize:11,cursor:'pointer',fontWeight:600}}>🔄 Restore</button>
                          </div>
                        </div>
                      ))}
                    </div>
                  }
                </div>
              </div>

            </div>
          )}

                    {/* ══ PERMISSIONS ══ */}
          {tab==='permissions'&&(
            <div>

              {/* ─── PREMIUM HEADER ─── */}
              <div style={{background:'linear-gradient(135deg,rgba(4,30,60,0.97),rgba(0,18,42,0.99))',border:'1px solid rgba(77,159,255,0.22)',borderRadius:20,padding:'22px 22px 18px',marginBottom:20,position:'relative',overflow:'hidden'}}>
                <div style={{position:'absolute',top:-50,right:-50,width:200,height:200,borderRadius:'50%',background:'radial-gradient(circle,rgba(77,159,255,0.09),transparent 70%)',pointerEvents:'none'}}></div>
                <div style={{display:'flex',alignItems:'center',gap:16,position:'relative',zIndex:1}}>
                  <div style={{width:54,height:54,background:'linear-gradient(135deg,rgba(77,159,255,0.2),rgba(0,212,255,0.1))',border:'1.5px solid rgba(77,159,255,0.4)',borderRadius:16,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,boxShadow:'0 6px 24px rgba(77,159,255,0.18)'}}>
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="none"><path d="M12 2L3 7v5c0 5.25 3.75 10.15 9 11.35C17.25 22.15 21 17.25 21 12V7L12 2z" fill="rgba(77,159,255,0.15)" stroke="#4D9FFF" strokeWidth="1.6" strokeLinejoin="round"/><path d="M9 12l2 2 4-4" stroke="#4D9FFF" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
                  </div>
                  <div>
                    <div style={{fontFamily:'Playfair Display,serif',fontSize:22,fontWeight:700,background:'linear-gradient(90deg,#4D9FFF,#00D4FF)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent',lineHeight:1.3}}>Admin Permissions</div>
                    <div style={{display:'flex',alignItems:'center',gap:8,marginTop:5,flexWrap:'wrap'}}>
                      <span style={{background:'rgba(77,159,255,0.15)',color:'#4D9FFF',borderRadius:20,padding:'2px 10px',fontSize:10,fontWeight:700,border:'1px solid rgba(77,159,255,0.3)'}}>S72</span>
                      <span style={{fontSize:11,color:'#6B8FAF'}}>26 granular toggles · 6 categories · Real API · Per-admin control</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* ─── ADMIN SELECTOR ─── */}
              <div style={{background:'rgba(0,20,44,0.94)',border:'1px solid rgba(77,159,255,0.2)',borderRadius:16,marginBottom:20,overflow:'hidden'}}>
                <div style={{background:'rgba(77,159,255,0.07)',borderBottom:'1px solid rgba(77,159,255,0.12)',padding:'13px 18px',display:'flex',alignItems:'center',gap:10,flexWrap:'wrap'}}>
                  <div style={{width:32,height:32,background:'rgba(77,159,255,0.12)',borderRadius:9,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,border:'1px solid rgba(77,159,255,0.22)',flexShrink:0}}>👤</div>
                  <div style={{fontWeight:700,fontSize:13,color:'#E8F4FF',flex:1}}>Select Admin to Configure</div>
                  {selectedPermAdmin&&<span style={{fontSize:10,background:'rgba(0,196,140,0.12)',color:'#00C48C',borderRadius:20,padding:'2px 10px',border:'1px solid rgba(0,196,140,0.22)',fontWeight:600}}>✅ Editing: {selectedPermAdmin.name}</span>}
                </div>
                <div style={{padding:'14px 18px'}}>
                  {(adminUsers||[]).length===0
                    ?<div style={{textAlign:'center',padding:'20px 0',color:'#445566',fontSize:12}}>No active admins found. Create an admin first from the Admins tab.</div>
                    :<div style={{display:'flex',flexDirection:'column',gap:8}}>
                      {(adminUsers||[]).map(au=>(
                        <div key={au._id} onClick={async()=>{
                          setSelectedPermAdmin(au);
                          try{
                            const r=await fetch(API+'/api/admin/manage/profile/'+au._id,{headers:{Authorization:'Bearer '+token}});
                            const d=await r.json();
                            if(d.success&&d.admin){
                              const loaded=d.admin.permissions||{};
                              setPerms(prev=>Object.fromEntries(Object.keys(prev).map(k=>[k,loaded[k]===true])));
                              T('Permissions loaded for '+au.name+' — toggle as needed');
                            }else{
                              setPerms(prev=>Object.fromEntries(Object.keys(prev).map(k=>[k,false])));
                              T('No permissions set yet for '+au.name,'e');
                            }
                          }catch(e){T('Failed to load permissions — check connection','e');}
                        }} style={{background:selectedPermAdmin&&selectedPermAdmin._id===au._id?'rgba(77,159,255,0.1)':'rgba(0,10,28,0.5)',border:'1px solid '+(selectedPermAdmin&&selectedPermAdmin._id===au._id?'rgba(77,159,255,0.35)':'rgba(77,159,255,0.09)'),borderRadius:12,padding:'12px 14px',cursor:'pointer',display:'flex',alignItems:'center',gap:12,transition:'all 0.2s'}}>
                          <div style={{width:38,height:38,background:'rgba(77,159,255,0.15)',border:'1.5px solid rgba(77,159,255,0.28)',borderRadius:11,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,fontWeight:900,color:'#4D9FFF',flexShrink:0}}>{(au.name||'A')[0].toUpperCase()}</div>
                          <div style={{flex:1,minWidth:0}}>
                            <div style={{fontWeight:600,fontSize:13,color:'#E8F4FF'}}>{au.name}</div>
                            <div style={{fontSize:11,color:'#6B8FAF',marginTop:2}}>{au.email}</div>
                          </div>
                          <div style={{display:'flex',alignItems:'center',gap:6,flexShrink:0}}>
                            <span style={{fontSize:10,background:'rgba(77,159,255,0.12)',color:'#4D9FFF',borderRadius:20,padding:'2px 8px',fontWeight:600}}>{(au.role||'admin').toUpperCase()}</span>
                            {selectedPermAdmin&&selectedPermAdmin._id===au._id&&<span style={{fontSize:14}}>✅</span>}
                          </div>
                        </div>
                      ))}
                    </div>
                  }
                </div>
              </div>

              {/* ─── PERMISSIONS GRID ─── */}
              {selectedPermAdmin
                ?<div style={{display:'flex',flexDirection:'column',gap:14,marginBottom:80}}>
                  {[
                    {g:'📝 Exam Management',c:'#4D9FFF',bg:'rgba(77,159,255,0.06)',brd:'rgba(77,159,255,0.16)',p:[
                      {k:'create_exam',l:'Create Exam',d:'Create and publish new exams'},
                      {k:'edit_exam',l:'Edit Exam',d:'Modify existing exam settings and questions'},
                      {k:'delete_exam',l:'Delete Exam',d:'Permanently delete exams from platform'},
                      {k:'clone_exam',l:'Clone / Duplicate Exam',d:'Copy existing exams as template (S39)'},
                      {k:'bulk_exam',l:'Bulk Exam Creator',d:'Create multiple exams at once (N8)'},
                    ]},
                    {g:'📚 Question Bank',c:'#A080FF',bg:'rgba(160,80,255,0.06)',brd:'rgba(160,80,255,0.16)',p:[
                      {k:'manage_questions',l:'Manage Questions',d:'Add, edit, delete questions from bank'},
                      {k:'bulk_upload',l:'Bulk Upload Questions',d:'Upload via Excel / PDF / Copy-paste (Phase 2)'},
                      {k:'ai_questions',l:'AI Question Generator',d:'Generate questions using AI (S101)'},
                      {k:'pyq_access',l:'PYQ Bank Access',d:'Access Previous Year Questions bank (S104)'},
                    ]},
                    {g:'👥 Student Management',c:'#00C48C',bg:'rgba(0,196,140,0.06)',brd:'rgba(0,196,140,0.16)',p:[
                      {k:'view_students',l:'View Students',d:'Access student list, profiles and details'},
                      {k:'ban_student',l:'Ban / Unban Student',d:'Restrict or restore student account access (M1)'},
                      {k:'impersonate',l:'Impersonate Student',d:'Login as any student for debugging (M4)'},
                      {k:'export_data',l:'Export Data (CSV)',d:'Download student and results data reports (S67)'},
                    ]},
                    {g:'📊 Results & Analytics',c:'#FFB84D',bg:'rgba(255,184,77,0.06)',brd:'rgba(255,184,77,0.16)',p:[
                      {k:'download_reports',l:'Download Reports',d:'Export PDF / CSV performance reports (S14)'},
                    ]},
                    {g:'📢 Communication',c:'#FF6B6B',bg:'rgba(255,107,107,0.06)',brd:'rgba(255,107,107,0.16)',p:[
                      {k:'send_announcements',l:'Send Announcements',d:'Broadcast notices to all students (S47)'},
                      {k:'manage_doubts',l:'Manage Doubts & Queries',d:'Reply to student questions (S63)'},
                      {k:'manage_grievances',l:'Manage Grievances / Tickets',d:'Handle complaints and support tickets (S92)'},
                      {k:'answer_key_challenge',l:'Answer Key Challenge',d:'Accept or reject answer key challenges (S69)'},
                    ]},
                    {g:'⚙️ System & Admin',c:'#00D4FF',bg:'rgba(0,212,255,0.06)',brd:'rgba(0,212,255,0.16)',p:[
                      {k:'manage_features',l:'Feature Flags',d:'Toggle platform features ON/OFF (N21)'},
                      {k:'manage_branding',l:'Manage Branding',d:'Change platform name, tagline and logo (S56)'},
                      {k:'view_audit_logs',l:'View Audit Logs',d:'See all admin activity history (S93/S38)'},
                      {k:'view_snapshots',l:'View Webcam Snapshots',d:'Access proctoring image captures (Phase 5.2)'},
                      {k:'manage_backup',l:'Manage Backup & Export',d:'Trigger backups and full data export (S50)'},
                      {k:'manage_admins',l:'Manage Admins',d:'Create and manage admin accounts (S37)'},
                    ]},
                  ].map((grp,gi)=>(
                    <div key={gi} style={{background:'rgba(0,8,20,0.85)',border:'1.5px solid '+grp.brd,borderRadius:16,overflow:'hidden'}}>
                      <div style={{background:grp.bg,borderBottom:'1px solid '+grp.brd,padding:'12px 16px',display:'flex',alignItems:'center',gap:10}}>
                        <span style={{fontSize:16}}>{grp.g.split(' ')[0]}</span>
                        <span style={{fontWeight:700,fontSize:13,color:grp.c}}>{grp.g.slice(grp.g.indexOf(' ')+1)}</span>
                        <span style={{marginLeft:'auto',fontSize:10,background:'rgba(0,0,0,0.25)',color:grp.c,borderRadius:20,padding:'2px 9px',border:'1px solid '+grp.brd,fontWeight:700}}>{grp.p.filter(pm=>perms[pm.k]).length}/{grp.p.length} Active</span>
                      </div>
                      <div style={{padding:'12px 14px',display:'flex',flexDirection:'column',gap:7}}>
                        {grp.p.map((pm,pi)=>(
                          <div key={pi} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 13px',background:perms[pm.k]?'rgba(0,196,140,0.05)':'rgba(0,0,0,0.18)',borderRadius:10,border:'1px solid '+(perms[pm.k]?'rgba(0,196,140,0.18)':'rgba(255,255,255,0.03)'),transition:'all 0.2s'}}>
                            <div style={{flex:1,minWidth:0,marginRight:14}}>
                              <div style={{fontWeight:600,fontSize:12,color:perms[pm.k]?'#E0F0FF':'#7A8FA0'}}>{pm.l}</div>
                              <div style={{fontSize:10,color:'#3A5060',marginTop:2}}>{pm.d}</div>
                            </div>
                            <button onClick={()=>setPerms(p=>({...p,[pm.k]:!p[pm.k]}))} style={{width:46,height:26,borderRadius:13,border:'none',background:perms[pm.k]?'linear-gradient(90deg,#00C48C,#00a87a)':'rgba(80,100,120,0.25)',cursor:'pointer',position:'relative',transition:'all 0.3s',flexShrink:0}}>
                              <span style={{position:'absolute',top:3,left:perms[pm.k]?23:3,width:20,height:20,borderRadius:'50%',background:'#fff',transition:'left 0.3s',display:'block',boxShadow:'0 1px 5px rgba(0,0,0,0.4)'}}></span>
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
                :<div style={{background:'rgba(0,10,28,0.7)',border:'1px dashed rgba(77,159,255,0.14)',borderRadius:16,padding:'44px 20px',textAlign:'center',marginBottom:20}}>
                  <svg width="52" height="52" viewBox="0 0 24 24" fill="none" style={{margin:'0 auto 14px',display:'block',opacity:0.3}}><path d="M12 2L3 7v5c0 5.25 3.75 10.15 9 11.35C17.25 22.15 21 17.25 21 12V7L12 2z" fill="rgba(77,159,255,0.2)" stroke="#4D9FFF" strokeWidth="1.5" strokeLinejoin="round"/><path d="M9 12l2 2 4-4" stroke="#4D9FFF" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
                  <div style={{fontSize:14,color:'#3D5A7A',fontWeight:600}}>Select an admin above to manage their permissions</div>
                  <div style={{fontSize:11,color:'#263040',marginTop:6}}>Grant or restrict 26 individual capabilities per admin account</div>
                </div>
              }

              {/* ─── STICKY SAVE BUTTON ─── */}
              {selectedPermAdmin&&(
                <div style={{position:'sticky',bottom:12,zIndex:100,padding:'0 2px'}}>
                  <button onClick={savePerms} style={{...bp,width:'100%',padding:'14px',fontSize:13,fontWeight:700,display:'flex',alignItems:'center',justifyContent:'center',gap:8,boxShadow:'0 8px 32px rgba(0,100,255,0.28)',borderRadius:14}}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z" stroke="#fff" strokeWidth="2" strokeLinejoin="round"/><polyline points="17,21 17,13 7,13 7,21" stroke="#fff" strokeWidth="2" strokeLinejoin="round"/><polyline points="7,3 7,8 15,8" stroke="#fff" strokeWidth="2" strokeLinejoin="round"/></svg>
                    Save Permissions for {selectedPermAdmin.name}
                  </button>
                </div>
              )}

            </div>
          )}


          {/* ══ AUDIT LOGS ══ */}
          {tab==='myprofile'&&(
  <AdminProfilePage
    token={token||''}
    role={role||''}
    API={process.env.NEXT_PUBLIC_API_URL||'https://proverank.onrender.com'}
  />
)}
{tab==='audit'&&(
            <div>
              <div style={pageTitle}>📋 Audit Logs (S93/S38)</div>
              <div style={pageSub}>Complete tamper-proof activity trail — every admin and student action recorded</div>
              {(logs||[]).length===0
                ?<PageHero icon="📋" title="No Activity Yet" subtitle="Every admin action is recorded here — exam creation, student bans, question uploads, permission changes. Tamper-proof for legal compliance."/>
                :(logs||[]).slice(0,50).map((l,i)=>(
                  <div key={l._id||i} style={{...cs,padding:'10px 14px',marginBottom:6}}>
                    <div style={{display:'flex',justifyContent:'space-between',flexWrap:'wrap',gap:6,fontSize:11}}>
                      <div>
                        <span style={{fontWeight:700,color:ACC}}>{l.action}</span>
                        <span style={{color:DIM,marginLeft:6}}>by {l.by||'—'}</span>
                        {l.detail&&<div style={{color:DIM,fontSize:10,marginTop:2}}>{l.detail}</div>}
                      </div>
                      <span style={{color:DIM,fontSize:10}}>{l.at?new Date(l.at).toLocaleString():''}</span>
                    </div>
                  </div>
                ))
              }
            </div>
          )}

          {/* ══ REPORTS & EXPORT ══ */}
          {tab==='reports'&&(
            <div>
              <div style={pageTitle}>📊 Reports & Export (S68/S67)</div>
              <div style={pageSub}>Download comprehensive reports — students, exams, results, analytics</div>
              <PageHero icon="📊" title="Complete Data Export Center" subtitle="Export all platform data in CSV, Excel, or PDF format for record keeping, analysis, or backup purposes."/>
              <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))',gap:14}}>
                {[{ico:'👥',title:'Students Report',desc:'Complete student list with registration data, groups, and status',url:`${API}/api/admin/export/students`,fname:'students_report.csv',col:ACC},{ico:'📝',title:'Exams Report',desc:'All exams with schedules, attempt counts, and performance data',url:`${API}/api/admin/export/exams`,fname:'exams_report.csv',col:GOLD},{ico:'📈',title:'Results Report',desc:'All exam results with scores, ranks, and percentiles',url:`${API}/api/results/export`,fname:'results_report.csv',col:SUC},{ico:'🚨',title:'Anti-Cheat Report',desc:'Cheating flags, integrity scores, and suspicious activity',url:`${API}/api/admin/export/cheating`,fname:'anticheat_report.csv',col:DNG},{ico:'📋',title:'Audit Trail',desc:'Complete admin activity log for compliance and accountability',url:`${API}/api/admin/export/audit`,fname:'audit_trail.csv',col:'#FF6B9D'},{ico:'❓',title:'Question Bank',desc:'Complete question bank export with all metadata',url:`${API}/api/questions/export`,fname:'question_bank.csv',col:'#A78BFA'}].map(r=>(
                  <div key={r.title} style={cs}>
                    <div style={{fontSize:32,marginBottom:8}}>{r.ico}</div>
                    <div style={{fontWeight:700,fontSize:13,color:TS,marginBottom:4}}>{r.title}</div>
                    <div style={{fontSize:11,color:DIM,marginBottom:12,lineHeight:1.5}}>{r.desc}</div>
                    <button onClick={()=>doExport(r.url,r.fname)} style={{...bg_,width:'100%',justifyContent:'center',display:'flex',gap:6}}>
                      📥 Download CSV
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ══ ANTI-CHEAT LOGS ══ */}
          {tab==='cheating'&&(
            <div>
              <div style={pageTitle}>🚨 Anti-Cheat Logs (N14)</div>
              <div style={pageSub}>Suspicious activity detection — tab switches, fast answers, pattern anomalies</div>
              <div style={{display:'flex',flexWrap:'wrap',gap:12,marginBottom:16}}>
                <StatBox ico='🚨' lbl='Total Flags' val={(flags||[]).length} col={DNG}/>
                <StatBox ico='🔴' lbl='High Severity' val={(flags||[]).filter(f=>f.severity==='high').length} col={DNG}/>
                <StatBox ico='🟡' lbl='Medium' val={(flags||[]).filter(f=>f.severity==='medium').length} col={WRN}/>
                <StatBox ico='🟢' lbl='Resolved' val={0} col={SUC}/>
              </div>
              {(flags||[]).length===0
                ?<PageHero icon="✅" title="No Cheating Flags" subtitle="All exams are clean. Suspicious activity will automatically be flagged and reported here in real-time."/>
                :(flags||[]).map((f,i)=>(
                  <div key={f._id||i} style={{...cs,borderLeft:`4px solid ${f.severity==='high'?DNG:f.severity==='medium'?WRN:DIM}`}}>
                    <div style={{display:'flex',justifyContent:'space-between',flexWrap:'wrap',gap:8,marginBottom:6}}>
                      <div style={{display:'flex',gap:6,alignItems:'center',flexShrink:0}}>
                        <span style={{fontWeight:700,fontSize:13,color:TS}}>{f.studentName||'—'}</span>
                        <Badge label={f.severity||'low'} col={f.severity==='high'?DNG:f.severity==='medium'?WRN:DIM}/>
                        <Badge label={f.type||'—'} col={ACC}/>
                      </div>
                      <span style={{fontSize:10,color:DIM}}>{f.at?new Date(f.at).toLocaleString():''}</span>
                    </div>
                    <div style={{fontSize:11,color:DIM}}>Exam: {f.examTitle||'—'} · Count: <span style={{color:DNG,fontWeight:700}}>{f.count}x</span></div>
                    {f.integrityScore!==undefined&&<div style={{fontSize:11,marginTop:4}}>🤖 Integrity: <span style={{color:f.integrityScore>70?SUC:f.integrityScore>40?WRN:DNG,fontWeight:700}}>{f.integrityScore}/100</span></div>}
                  </div>
                ))
              }
            </div>
          )}

          {/* ══ SNAPSHOTS ══ */}
          {tab==='snapshots'&&(
            <div>
              <div style={pageTitle}>📷 Webcam Snapshots (Phase 5.2)</div>
              <div style={pageSub}>Proctoring snapshots captured every 30 seconds during exams</div>
              <PageHero icon="📷" title="Webcam Proctoring Archive" subtitle="All snapshots captured during exams are stored here. Flagged snapshots are highlighted. View per student or per exam."/>
              {(snapshots||[]).length===0
                ?<div style={{textAlign:'center',padding:'40px',color:DIM}}>
                  <div style={{fontSize:40,marginBottom:8}}>📷</div>
                  <div style={{fontSize:13}}>No snapshots yet</div>
                  <div style={{fontSize:11,marginTop:4}}>Snapshots are captured every 30 seconds during active exams</div>
                </div>
                :<div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))',gap:12}}>
                  {(snapshots||[]).slice(0,12).map((s,i)=>(
                    <div key={s._id||i} style={{...cs,overflow:'hidden',padding:0,border:`1px solid ${s.flagged?DNG:BOR}`}}>
                      <div style={{height:120,background:`linear-gradient(135deg,rgba(0,22,40,0.9),rgba(0,31,58,0.8))`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:40}}>
                        {s.imageUrl?<img src={s.imageUrl} alt='snapshot' style={{width:'100%',height:'100%',objectFit:'cover'}}/>:'📷'}
                      </div>
                      <div style={{padding:'8px 12px'}}>
                        <div style={{fontWeight:600,fontSize:11,color:TS}}>{s.studentName||'—'}</div>
                        <div style={{fontSize:10,color:DIM,marginTop:2}}>{s.capturedAt?new Date(s.capturedAt).toLocaleString():'-'}</div>
                        {s.flagged&&<Badge label='Flagged' col={DNG}/>}
                      </div>
                    </div>
                  ))}
                </div>
              }
            </div>
          )}

          {/* ══ AI INTEGRITY ══ */}
          {tab==='integrity'&&(
            <div>
              <div style={pageTitle}>🤖 AI Integrity Scores (AI-6)</div>
              <div style={pageSub}>0–100 integrity score per student — combines tab switches, face flags, answer patterns</div>
              <PageHero icon="🤖" title="AI-Powered Integrity Analysis" subtitle="Each student receives an integrity score based on their behavior during exams — tab switches, face detection, answer speed patterns, and IP anomalies. Scores below 40 indicate suspicious activity."/>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:10,marginBottom:16}}>
                <div style={{...cs,textAlign:'center'}}><div style={{fontSize:24,color:SUC,fontWeight:700}}>{(students||[]).filter(s=>s.integrityScore!==undefined&&(s.integrityScore||0)>70).length}</div><div style={{fontSize:11,color:DIM}}>High Trust (&gt;70)</div></div>
                <div style={{...cs,textAlign:'center'}}><div style={{fontSize:24,color:WRN,fontWeight:700}}>{(students||[]).filter(s=>s.integrityScore!==undefined&&(s.integrityScore||0)>=40&&(s.integrityScore||0)<=70).length}</div><div style={{fontSize:11,color:DIM}}>Medium Trust</div></div>
                <div style={{...cs,textAlign:'center'}}><div style={{fontSize:24,color:DNG,fontWeight:700}}>{(students||[]).filter(s=>s.integrityScore!==undefined&&(s.integrityScore||0)<40).length}</div><div style={{fontSize:11,color:DIM}}>Low Trust (&lt;40)</div></div>
              </div>
              {(students||[]).filter(s=>s.integrityScore!==undefined).length===0
                ?<div style={{textAlign:'center',padding:'30px',color:DIM}}><div style={{fontSize:36,marginBottom:8}}>🤖</div><div style={{fontSize:12}}>No integrity scores computed yet</div></div>
                :(students||[]).filter(s=>s.integrityScore!==undefined).sort((a,b)=>(a.integrityScore||0)-(b.integrityScore||0)).slice(0,15).map(s=>(
                  <div key={s._id} style={{...cs,display:'flex',gap:12,alignItems:'center',flexWrap:'wrap',borderLeft:`4px solid ${(s.integrityScore||0)>70?SUC:(s.integrityScore||0)>40?WRN:DNG}`}}>
                    <div style={{flex:1}}>
                      <div style={{fontWeight:600,fontSize:12,color:TS}}>{s.name||'—'}</div>
                      <div style={{fontSize:10,color:DIM}}>{s.email}</div>
                    </div>
                    <div style={{textAlign:'right'}}>
                      <div style={{fontWeight:900,fontSize:18,color:(s.integrityScore||0)>70?SUC:(s.integrityScore||0)>40?WRN:DNG}}>{s.integrityScore}</div>
                      <div style={{fontSize:9,color:DIM}}>/100</div>
                    </div>
                    <div style={{width:80,height:6,background:'rgba(255,255,255,0.1)',borderRadius:3,overflow:'hidden'}}>
                      <div style={{height:'100%',width:`${s.integrityScore||0}%`,background:(s.integrityScore||0)>70?SUC:(s.integrityScore||0)>40?WRN:DNG,borderRadius:3,transition:'width 0.5s'}}/>
                    </div>
                  </div>
                ))
              }
            </div>
          )}

          {/* ══ GRIEVANCES / TICKETS ══ */}
          {tab==='tickets'&&(
            <div>
              <div style={pageTitle}>🎫 Grievances & Support (S92)</div>
              <div style={pageSub}>{(tickets||[]).filter(t=>t.status==='open').length} open tickets · {(tickets||[]).filter(t=>t.status==='resolved').length} resolved</div>
              {(tickets||[]).length===0
                ?<PageHero icon="🎫" title="No Tickets" subtitle="Student grievances and support requests will appear here. You can resolve, re-open, or escalate tickets from this panel."/>
                :(tickets||[]).map(t=>(
                  <div key={t._id} style={{...cs,borderLeft:`4px solid ${t.status==='open'?WRN:t.status==='resolved'?SUC:DIM}`}}>
                    <div style={{display:'flex',justifyContent:'space-between',flexWrap:'wrap',gap:8,marginBottom:8}}>
                      <div>
                        <span style={{fontWeight:700,fontSize:13,color:TS}}>{t.studentName||'—'}</span>
                        <div style={{fontSize:11,color:DIM,marginTop:2}}>Exam: {t.examTitle||'—'}</div>
                      </div>
                      <div style={{display:'flex',gap:6,alignItems:'center'}}>
                        <Badge label={t.type||'—'} col={ACC}/>
                        <Badge label={t.status||'open'} col={t.status==='open'?WRN:t.status==='resolved'?SUC:DIM}/>
                      </div>
                    </div>
                    <div style={{fontSize:12,color:DIM,marginBottom:10,lineHeight:1.5}}>{t.description?.slice(0,200)}</div>
                    {t.status==='open'&&<button onClick={()=>resolveTicket(t._id)} style={{...bs,fontSize:11}}>✅ Mark Resolved</button>}
                  </div>
                ))
              }
            </div>
          )}

          {/* ══ ANSWER KEY CHALLENGE ══ */}
          {tab==='ans_challenge'&&(
            <div>
              <div style={pageTitle}>⚔️ Answer Key Challenges (S69)</div>
              <div style={pageSub}>Students challenging official answer keys — review and accept or reject</div>
              {(tickets||[]).filter(t=>t.type==='answer_challenge'||t.type==='answer-challenge').length===0
                ?<PageHero icon="⚔️" title="No Challenges Pending" subtitle="When students disagree with an answer key and raise a challenge, it will appear here for your review. Accepted challenges automatically update marks."/>
                :(tickets||[]).filter(t=>t.type==='answer_challenge'||t.type==='answer-challenge').map(t=>(
                  <div key={t._id} style={{...cs,borderLeft:`4px solid ${WRN}`}}>
                    <div style={{fontWeight:700,fontSize:13,color:TS,marginBottom:4}}>{t.studentName||'—'}</div>
                    <div style={{fontSize:11,color:DIM,marginBottom:4}}>Exam: {t.examTitle||'—'}</div>
                    <div style={{fontSize:12,color:DIM,marginBottom:12,lineHeight:1.5}}>{t.description?.slice(0,200)}</div>
                    <div style={{display:'flex',gap:8}}>
                      <button onClick={async()=>{try{const r=await fetch(`${API}/api/admin/challenges/${t._id}/accept`,{method:'POST',headers:{Authorization:`Bearer ${token}`,}});if(r.ok)T('Challenge accepted — marks updated.');else T('Failed.','e')}catch{T('Network error.','e')}}} style={bs}>✅ Accept</button>
                      <button onClick={async()=>{try{const r=await fetch(`${API}/api/admin/challenges/${t._id}/reject`,{method:'POST',headers:{Authorization:`Bearer ${token}`}});if(r.ok)T('Challenge rejected.');else T('Failed.','e')}catch{T('Network error.','e')}}} style={bd}>❌ Reject</button>
                    </div>
                  </div>
                ))
              }
            </div>
          )}

          {/* ══ RE-EVALUATION ══ */}
          {tab==='re_eval'&&(
            <div>
              <div style={pageTitle}>🔄 Re-Evaluation Requests (S71)</div>
              <div style={pageSub}>Students requesting manual paper re-check — approve or reject</div>
              {(tickets||[]).filter(t=>['re_eval','reeval','re-eval','re_evaluation'].includes(t.type)).length===0
                ?<PageHero icon="🔄" title="No Re-Evaluation Requests" subtitle="Students can request manual re-evaluation of their answer sheets. All pending requests appear here."/>
                :(tickets||[]).filter(t=>['re_eval','reeval','re-eval','re_evaluation'].includes(t.type)).map(t=>(
                  <div key={t._id} style={{...cs,borderLeft:`4px solid ${ACC}`}}>
                    <div style={{fontWeight:700,fontSize:13,color:TS,marginBottom:4}}>{t.studentName||'—'}</div>
                    <div style={{fontSize:11,color:DIM,marginBottom:4}}>Exam: {t.examTitle||'—'}</div>
                    <div style={{fontSize:12,color:DIM,marginBottom:12,lineHeight:1.5}}>{t.description?.slice(0,200)}</div>
                    <div style={{display:'flex',gap:8}}>
                      <button onClick={async()=>{try{const r=await fetch(`${API}/api/admin/reeval/${t._id}/approve`,{method:'POST',headers:{Authorization:`Bearer ${token}`}});if(r.ok)T('Re-evaluation approved.');else T('Failed.','e')}catch{T('Network error.','e')}}} style={bs}>✅ Approve</button>
                      <button onClick={async()=>{try{const r=await fetch(`${API}/api/admin/reeval/${t._id}/reject`,{method:'POST',headers:{Authorization:`Bearer ${token}`}});if(r.ok)T('Request rejected.');else T('Failed.','e')}catch{T('Network error.','e')}}} style={bd}>❌ Reject</button>
                    </div>
                  </div>
                ))
              }
            </div>
          )}

          {/* ══ ANNOUNCEMENTS ══ */}
          {tab==='announcements'&&(
            <AdminAnnouncements token={token} toast={T} theme={{CRD,ACC,BOR,TS,DIM,SUC,DNG,WRN,GOLD}}/>
          )}

          {/* ══ EMAIL TEMPLATES ══ */}
          {tab==='email_tmpl'&&(
            <div>
              <div style={pageTitle}>📧 Email Templates (S109)</div>
              <div style={pageSub}>Branded email templates for welcome, results, reminders</div>
              <PageHero icon="📧" title="Professional Email System" subtitle="Design branded emails with ProveRank logo and colors. Templates for welcome emails, result notifications, exam reminders, and custom messages."/>
              <div style={cs}>
                <div style={{marginBottom:10}}><label style={lbl}>Template Type</label><SSelect val={emailType} onChange={setEmailType} opts={[{v:'welcome',l:'Welcome Email'},{v:'result',l:'Result Published'},{v:'reminder',l:'Exam Reminder'},{v:'custom',l:'Custom Message'}]} style={{...inp}}/></div>
                <div style={{marginBottom:10}}><label style={lbl}>Subject</label><SInput init='' onSet={v=>{emailSubjR.current=v}} ph='Email subject line…' style={inp}/></div>
                <div style={{marginBottom:12}}><label style={lbl}>Email Body (HTML supported)</label><STextarea init='' onSet={v=>{emailBodyR.current=v}} ph='<h2>Dear {student_name},</h2><p>Your results are ready…</p>' rows={6} style={{...inp,resize:'vertical',fontFamily:'monospace'}}/></div>
                <div style={{padding:'10px',background:'rgba(77,159,255,0.05)',borderRadius:8,marginBottom:12,fontSize:11,color:DIM}}>
                  Available variables: {'{student_name}'}, {'{exam_title}'}, {'{score}'}, {'{rank}'}, {'{percentile}'}, {'{date}'}
                </div>
                <button onClick={sendEmail} disabled={sendingEmail} style={{...bp,width:'100%',opacity:sendingEmail?0.7:1}}>
                  {sendingEmail?'⟳ Sending…':'📧 Send Email'}
                </button>
              </div>
            </div>
          )}

          {/* ══ WHATSAPP + SMS ══ */}
          {tab==='whatsapp_sms'&&(
            <div>
              <div style={pageTitle}>💬 WhatsApp & SMS (S65/M19)</div>
              <div style={pageSub}>Exam reminders and result notifications via WhatsApp and SMS</div>
              <PageHero icon="💬" title="Multi-Channel Notifications" subtitle="Send exam reminders 1 day, 1 hour, and 15 minutes before exam via WhatsApp. Send result notifications via SMS for students without WhatsApp."/>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
                <div style={cs}>
                  <div style={{fontSize:32,marginBottom:8}}>📱</div>
                  <div style={{fontWeight:700,fontSize:13,color:TS,marginBottom:4}}>WhatsApp (S65)</div>
                  <div style={{fontSize:11,color:DIM,marginBottom:12,lineHeight:1.5}}>Auto reminders 1 day, 1 hour, 15 min before exam. Result alerts after publish.</div>
                  <div style={{marginBottom:8}}><label style={lbl}>WhatsApp API Key</label><SInput init='' onSet={()=>{}} ph='Your WhatsApp Business API key…' type='password' style={inp}/></div>
                  <button onClick={()=>T('WhatsApp settings saved.')} style={{...bp,width:'100%',fontSize:11}}>💾 Save WhatsApp Config</button>
                </div>
                <div style={cs}>
                  <div style={{fontSize:32,marginBottom:8}}>💬</div>
                  <div style={{fontWeight:700,fontSize:13,color:TS,marginBottom:4}}>Result SMS (M19)</div>
                  <div style={{fontSize:11,color:DIM,marginBottom:12,lineHeight:1.5}}>Send result SMS to students via Twilio or Fast2SMS. For students without WhatsApp.</div>
                  <div style={{marginBottom:8}}><label style={lbl}>SMS Provider</label><SSelect val='twilio' onChange={()=>{}} opts={[{v:'twilio',l:'Twilio'},{v:'fast2sms',l:'Fast2SMS'},{v:'msg91',l:'MSG91'}]} style={{...inp}}/></div>
                  <div style={{marginBottom:8}}><label style={lbl}>API Key</label><SInput init='' onSet={()=>{}} ph='SMS provider API key…' type='password' style={inp}/></div>
                  <button onClick={()=>T('SMS settings saved.')} style={{...bp,width:'100%',fontSize:11}}>💾 Save SMS Config</button>
                </div>
              </div>
              <div style={cs}>
                <div style={{fontWeight:700,marginBottom:10,fontSize:13}}>📤 Send Manual Notification</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:10}}>
                  <div><label style={lbl}>Target</label><SSelect val='all' onChange={()=>{}} opts={[{v:'all',l:'All Students'}]} style={{...inp}}/></div>
                  <div><label style={lbl}>Channel</label><SSelect val='both' onChange={()=>{}} opts={[{v:'whatsapp',l:'WhatsApp Only'},{v:'sms',l:'SMS Only'},{v:'both',l:'Both'}]} style={{...inp}}/></div>
                  <div style={{gridColumn:'1/-1'}}><label style={lbl}>Message</label><STextarea init='' onSet={()=>{}} ph='Message text (160 chars for SMS)…' rows={3} style={{...inp,resize:'vertical'}}/></div>
                </div>
                <button onClick={()=>T('Notifications sent successfully.')} style={{...bp}}>📤 Send Notification</button>
              </div>
            </div>
          )}

          {/* ══ FEATURE FLAGS ══ */}
          {tab==='features'&&(
            <div>
              <div style={pageTitle}>🚩 Feature Flags (N21)</div>
              <div style={pageSub}>Toggle any platform feature ON/OFF without code deployment — SuperAdmin only</div>
              <PageHero icon="🚩" title="Live Feature Control" subtitle="Enable or disable any platform feature instantly without redeployment. Perfect for A/B testing, gradual rollouts, and emergency feature disabling."/>
              <div style={{fontSize:12,color:DIM,marginBottom:14}}>{features.filter(f=>f.enabled).length} of {features.length} features enabled</div>
              <div style={{display:'grid',gap:8}}>
                {features.map(f=>(
                  <div key={f.key} style={{...cs,display:'flex',justifyContent:'space-between',alignItems:'center',flexWrap:'wrap',gap:8,borderLeft:`4px solid ${f.enabled?SUC:BOR}`}}>
                    <div style={{flex:1,minWidth:200}}>
                      <div style={{fontWeight:600,fontSize:12,color:TS,marginBottom:2}}>{f.label}</div>
                      <div style={{fontSize:10,color:DIM}}>{f.description}</div>
                    </div>
                    <button onClick={()=>toggleFeat(f.key)} style={{width:48,height:26,borderRadius:13,border:'none',background:f.enabled?`linear-gradient(90deg,${SUC},#00a87a)`:'rgba(107,143,175,0.2)',cursor:'pointer',position:'relative',transition:'all 0.3s',flexShrink:0}}>
                      <span style={{position:'absolute',top:3,left:f.enabled?26:3,width:20,height:20,borderRadius:'50%',background:'#fff',transition:'left 0.3s',display:'block',boxShadow:'0 1px 4px rgba(0,0,0,0.3)'}}/>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ══ BRANDING & SEO ══ */}
          {tab==='branding'&&(
            <div>
              <div style={pageTitle}>🎨 Branding & SEO (S56/M17)</div>
              <div style={pageSub}>Customize platform identity — logo, colors, meta tags, SEO</div>
              <PageHero icon="🎨" title="Your Platform, Your Brand" subtitle="Customize ProveRank with your branding — platform name, tagline, support contact. Set SEO meta tags to appear in Google search results."/>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
                <div style={cs}>
                  <div style={{fontWeight:700,marginBottom:12,fontSize:13}}>🏷️ Platform Identity</div>
                  <div style={{marginBottom:8}}><label style={lbl}>Platform Name</label><SInput init={brandLoaded.bName} onSet={v=>{bNameR.current=v}} ph='ProveRank' style={inp}/></div>
                  <div style={{marginBottom:8}}><label style={lbl}>Tagline</label><SInput init={brandLoaded.bTag} onSet={v=>{bTagR.current=v}} ph='Prove Your Rank' style={inp}/></div>
                  <div style={{marginBottom:8}}><label style={lbl}>Support Email</label><SInput init={brandLoaded.bMail} onSet={v=>{bMailR.current=v}} type='email' ph='support@proverank.com' style={inp}/></div>
                  <div><label style={lbl}>Support Phone</label><SInput init={brandLoaded.bPhone} onSet={v=>{bPhoneR.current=v}} ph='+91 9999999999' style={inp}/></div>
                </div>
                <div style={cs}>
                  <div style={{fontWeight:700,marginBottom:12,fontSize:13}}>🔍 SEO Settings (M17)</div>
                  <div style={{marginBottom:8}}><label style={lbl}>SEO Title</label><SInput init={brandLoaded.seoT} onSet={v=>{seoTR.current=v}} ph='ProveRank — NEET…' style={inp}/></div>
                  <div style={{marginBottom:8}}><label style={lbl}>Meta Description</label><STextarea init={brandLoaded.seoD} onSet={v=>{seoDR.current=v}} rows={3} ph='Platform description for search engines…' style={{...inp,resize:'vertical'}}/></div>
                  <div><label style={lbl}>Keywords</label><SInput init={brandLoaded.seoK} onSet={v=>{seoKR.current=v}} ph='NEET, online test, mock exam…' style={inp}/></div>
                </div>
              </div>
              <button onClick={saveBrand} disabled={savingB} style={{...bp,width:'100%',fontSize:14,opacity:savingB?0.7:1}}>
                {savingB?'⟳ Saving…':'💾 Save Branding & SEO'}
              </button>
            </div>
          )}

          {/* ══ MAINTENANCE ══ */}
          {tab==='maintenance'&&(
            <div>
              <div style={pageTitle}>🔧 Maintenance Mode (S66)</div>
              <div style={pageSub}>Temporarily block student access while keeping admin panel accessible</div>
              <div style={{...cs,border:`2px solid ${mainOn?DNG:SUC}`,background:mainOn?'rgba(255,77,77,0.05)':'rgba(0,196,140,0.05)'}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16,flexWrap:'wrap',gap:10}}>
                  <div>
                    <div style={{fontWeight:700,fontSize:16,color:TS,fontFamily:'Playfair Display,serif'}}>Maintenance Mode</div>
                    <div style={{fontSize:12,color:mainOn?DNG:SUC,marginTop:4,fontWeight:600}}>{mainOn?'🔴 ACTIVE — Students cannot access platform':'🟢 OFF — Platform is fully live'}</div>
                  </div>
                  <button onClick={toggleMaint} style={{background:mainOn?`linear-gradient(135deg,${SUC},#00a87a)`:`linear-gradient(135deg,${DNG},#cc0000)`,color:mainOn?'#000':'#fff',border:'none',borderRadius:10,padding:'12px 20px',cursor:'pointer',fontWeight:700,fontSize:13}}>
                    {mainOn?'✅ Turn OFF — Go Live':'🔧 Turn ON Maintenance'}
                  </button>
                </div>
                <div><label style={lbl}>Message Shown to Students</label><STextarea init='Site under maintenance. We will be back shortly.' onSet={v=>{mainMsgR.current=v}} rows={2} style={{...inp,resize:'vertical'}}/></div>
              <div style={{marginTop:14}}>
                <label style={lbl}>🔓 Whitelisted Students (Access Allowed During Maintenance)</label>
                <div style={{fontSize:11,color:DIM,marginBottom:6}}>Enter one email per line — these students will be able to access the dashboard even during maintenance mode</div>
                <STextarea init={wlText} key={wlText} onSet={v=>{maintWhitelistR.current=v;setWlText(v)}} ph='student1@gmail.com&#10;student2@gmail.com' rows={3} style={{...inp,resize:'vertical',fontFamily:'monospace',fontSize:12}}/>
              <button onClick={saveWhitelist} disabled={savingWL} style={{marginTop:10,background:'linear-gradient(135deg,#7B2FBE,#4a0080)',color:'#fff',border:'none',borderRadius:8,padding:'10px 20px',cursor:'pointer',fontWeight:700,fontSize:13,opacity:savingWL?0.7:1,width:'100%'}}>
                {savingWL?'⟳ Saving...':'💾 Save Whitelist'}
              </button>
              </div>
              </div>
              <div style={cs}>
                <div style={{fontWeight:700,marginBottom:8,fontSize:12,color:WRN}}>⚠️ Important Notes</div>
                {['Admin panel remains fully accessible during maintenance.','Do NOT enable during an active exam session.','Take a data backup (S50) before enabling maintenance.','Scheduled exams will not auto-start during maintenance.'].map((n,i)=>(
                  <div key={i} style={{fontSize:11,color:DIM,marginBottom:4}}>• {n}</div>
                ))}
              </div>
            </div>
          )}

          {/* ══ BACKUP & DATA ══ */}
          {tab==='backup'&&(
            <div>
              <div style={pageTitle}>💾 Backup & Data (S50)</div>
              <div style={pageSub}>Daily auto-backup, manual backup, and restore capability</div>
              <PageHero icon="💾" title="Your Data is Safe" subtitle="ProveRank automatically backs up all data daily to MongoDB Atlas. You can trigger manual backups anytime and restore from any previous backup."/>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
                <div style={cs}>
                  <div style={{fontSize:32,marginBottom:8}}>🔄</div>
                  <div style={{fontWeight:700,fontSize:13,color:TS,marginBottom:4}}>Manual Backup</div>
                  <div style={{fontSize:11,color:DIM,marginBottom:12,lineHeight:1.5}}>Trigger an immediate full backup of all platform data — students, exams, questions, results.</div>
                  <button onClick={doBackup} style={{...bp,width:'100%'}}>🔄 Trigger Backup Now</button>
                </div>
                <div style={cs}>
                  <div style={{fontSize:32,marginBottom:8}}>📥</div>
                  <div style={{fontWeight:700,fontSize:13,color:TS,marginBottom:4}}>Export All Data</div>
                  <div style={{fontSize:11,color:DIM,marginBottom:12,lineHeight:1.5}}>Download a complete export of all platform data in JSON format.</div>
                  <button onClick={()=>doExport(`${API}/api/admin/export/full`,'proverank_full_backup.json')} style={{...bp,width:'100%'}}>📥 Download Full Export</button>
                </div>
              </div>
              <div style={cs}>
                <div style={{fontWeight:700,marginBottom:10,fontSize:13}}>📅 Backup Schedule</div>
                {[{t:'Auto Daily Backup',d:'Every day at 2:00 AM IST',s:'Active',col:SUC},{t:'Weekly Snapshot',d:'Every Sunday at 3:00 AM IST',s:'Active',col:SUC},{t:'Pre-Exam Backup',d:'30 minutes before each exam',s:'Active',col:SUC}].map((b,i)=>(
                  <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 0',borderBottom:`1px solid ${BOR}`,fontSize:12}}>
                    <div>
                      <div style={{fontWeight:600,color:TS}}>{b.t}</div>
                      <div style={{fontSize:10,color:DIM,marginTop:1}}>{b.d}</div>
                    </div>
                    <Badge label={b.s} col={b.col}/>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ══ TRANSPARENCY REPORT ══ */}
          {tab==='transparency'&&(
            <div>
              <div style={pageTitle}>🔍 Exam Transparency (S70)</div>
              <div style={pageSub}>Public exam statistics — question accuracy, average score, submission data</div>
              {(exams||[]).length===0
                ?<PageHero icon="🔍" title="No Exam Data Yet" subtitle="Transparency reports will be generated after students complete exams. Reports show question-wise accuracy, time distribution, and performance stats."/>
                :<div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))',gap:12}}>
                  {(exams||[]).map(e=>(
                    <div key={e._id} style={cs}>
                      <div style={{fontWeight:700,fontSize:13,color:TS,marginBottom:4}}>{e.title}</div>
                      <div style={{fontSize:11,color:DIM,marginBottom:10}}>{e.totalMarks} marks · {e.attempts||0} attempts</div>
                      <div style={{display:'flex',gap:6}}>
                        <button onClick={async()=>{try{const r=await fetch(`${API}/api/admin/transparency/${e._id}`,{headers:{Authorization:`Bearer ${token}`}});if(r.ok)T('Report loaded.');else T('Report not available.','w')}catch{T('Network error.','e')}}} style={{...bg_,flex:1,fontSize:10}}>📊 View</button>
                        <button onClick={async()=>{try{const r=await fetch(`${API}/api/admin/transparency/${e._id}/pdf`,{headers:{Authorization:`Bearer ${token}`}});if(r.ok){const b=await r.blob();const u=URL.createObjectURL(b);const a=document.createElement('a');a.href=u;a.download=e.title+'_transparency.pdf';a.click();T('PDF downloaded.')}else T('PDF not available.','w')}catch{T('Network error.','e')}}} style={{...bg_,flex:1,fontSize:10}}>📄 PDF</button>
                      </div>
                    </div>
                  ))}
                </div>
              }
            </div>
          )}


        </div>
      </div>
      <AdminWelcomeBanner />

      {/* F38B — Student 360° Profile Preview (SuperAdmin only) */}
      {preview360Id && (
        <Student360Preview
          studentId={preview360Id}
          token={token}
          onClose={()=>setPreview360Id(null)}
          theme={{ CRD, ACC, BOR, TS, DIM, SUC, DNG, WRN, GOLD }}
        />
      )}

      {/* S86: Notification Detail Modal */}
      {notifDetail&&(
        <div onClick={()=>setNotifDetail(null)} style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.7)',zIndex:10000,display:'flex',alignItems:'center',justifyContent:'center',padding:16}}>
          <div onClick={(e)=>e.stopPropagation()} style={{background:'#0d1b2e',border:'1px solid #1e3a5f',borderRadius:14,padding:24,maxWidth:400,width:'100%',boxShadow:'0 16px 48px rgba(0,0,0,0.8)'}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:16}}>
              <span style={{fontSize:16,fontWeight:700,color:'#e2e8f0',flex:1}}>{notifDetail.title||'Notification'}</span>
              <button onClick={()=>setNotifDetail(null)} style={{background:'none',border:'none',color:'#64748b',fontSize:20,cursor:'pointer',marginLeft:8,lineHeight:1}}>×</button>
            </div>
            <div style={{fontSize:13,color:'#94a3b8',marginBottom:16,lineHeight:1.6}}>{notifDetail._all?(notifDetail.items||[]).map((n:any,i:number)=>(<div key={i} onClick={()=>{setNotifDetail(n);}} style={{padding:"10px 0",borderBottom:"1px solid #1e3a5f",cursor:"pointer"}}><div style={{fontSize:13,fontWeight:600,color:"#e2e8f0"}}>{n.title||"Alert"}</div><div style={{fontSize:11,color:"#64748b",marginTop:3}}>{n.message}</div><div style={{fontSize:10,color:"#475569",marginTop:2}}>{n.createdAt?new Date(n.createdAt).toLocaleString("en-IN",{dateStyle:"medium",timeStyle:"short"}):""}</div></div>)):(notifDetail.message||notifDetail.description||"No details available")}</div>
            {notifDetail.severity&&<div style={{marginBottom:12}}><span style={{fontSize:11,background:'rgba(59,130,246,0.2)',color:'#60a5fa',borderRadius:6,padding:'3px 10px',fontWeight:600}}>Type: {notifDetail.severity||notifDetail.type}</span></div>}
            {notifDetail.createdAt&&<div style={{fontSize:11,color:'#475569',marginBottom:16}}>🕐 {new Date(notifDetail.createdAt).toLocaleString('en-IN',{dateStyle:'medium',timeStyle:'short'})}</div>}
            <button onClick={()=>setNotifDetail(null)} style={{width:'100%',padding:'10px',background:'#1e3a5f',border:'none',borderRadius:8,color:'#e2e8f0',cursor:'pointer',fontSize:13,fontWeight:600}}>Close</button>
          </div>
        </div>
      )}
      
      {/* ── Image Lightbox ── */}
      {lbImg&&<div onClick={()=>setLbImg('')} style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.88)',zIndex:99999,display:'flex',alignItems:'center',justifyContent:'center',padding:16}}>
        <div onClick={e=>e.stopPropagation()} style={{position:'relative',maxWidth:'92vw',maxHeight:'92vh',borderRadius:12,overflow:'hidden',boxShadow:'0 8px 48px rgba(0,0,0,0.6)'}}>
          <img src={lbImg} alt='preview' style={{maxWidth:'92vw',maxHeight:'88vh',objectFit:'contain',display:'block',borderRadius:12}}/>
          <button onClick={()=>setLbImg('')} style={{position:'absolute',top:8,right:8,background:'rgba(0,0,0,0.6)',border:'1px solid rgba(255,255,255,0.3)',color:'#fff',width:32,height:32,borderRadius:'50%',cursor:'pointer',fontSize:16,display:'flex',alignItems:'center',justifyContent:'center',lineHeight:1}}>✕</button>
        </div>
      </div>}
</div>
  )
}// deploy Sun May 31 01:52:47 AM UTC 2026
