'use client'
import { useState, useEffect, useCallback } from 'react'

// ── Design tokens (locked: Neon Blue + Glassmorphism + Playfair/Inter) ──
const ACC='#4D9FFF', TS='#E8F4FF', DIM='#6B8FAF', GOLD='#FFD700'
const SUC='#00C48C', DNG='#FF4D4D', WRN='#FFB84D', PRP='#A78BFA'
const BOR='rgba(77,159,255,0.16)', CRD='rgba(0,15,35,0.88)'

const bp:any={background:`linear-gradient(135deg,${PRP},#6D28D9)`,color:'#fff',border:'none',borderRadius:10,padding:'11px 22px',cursor:'pointer',fontWeight:700,fontSize:13,transition:'all 0.2s'}
const bpAcc:any={...bp,background:`linear-gradient(135deg,${ACC},#0055CC)`}
const bg_:any={background:'rgba(0,25,55,0.7)',color:TS,border:`1px solid ${BOR}`,borderRadius:10,padding:'10px 18px',cursor:'pointer',fontSize:12,transition:'all 0.2s'}
const inp:any={width:'100%',padding:'10px 13px',background:'rgba(0,12,30,0.9)',border:`1.5px solid ${BOR}`,borderRadius:10,color:TS,fontSize:13,outline:'none',boxSizing:'border-box' as any,fontFamily:'Inter,sans-serif'}
const lbl:any={display:'block',fontSize:10,color:DIM,marginBottom:5,fontWeight:700,letterSpacing:0.6,textTransform:'uppercase' as any}
const cs:any={background:CRD,border:`1px solid ${BOR}`,borderRadius:16,padding:'18px',backdropFilter:'blur(14px)'}

// ── Status mapping — real schema enum (draft/scheduled/live/ended) shown as
// the spec's own labels (Draft/Upcoming/Active/Completed) — 33.3 / 33.19 ──
const STATUS_META: Record<string,{label:string,color:string,icon:string}> = {
  draft:     { label:'Draft',     color: DIM, icon:'📝' },
  scheduled: { label:'Upcoming',  color: ACC, icon:'⏳' },
  live:      { label:'Active',    color: SUC, icon:'🟢' },
  ended:     { label:'Completed', color: PRP, icon:'✅' },
}
const STATUS_ORDER = ['draft','scheduled','live','ended']

interface Props { token:string; API:string; T:(m:string,t?:'s'|'e'|'w')=>void; onCreateNew:()=>void }

function fmtDate(d:any){ if(!d) return null; const dt=new Date(d); return isNaN(dt.getTime())?null:dt }
function fmtDateStr(d:any){ const dt=fmtDate(d); return dt? dt.toLocaleString('en-IN',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}) : 'No schedule set' }

function countdownLabel(startTime:any, now:number){
  const dt = fmtDate(startTime)
  if(!dt) return null
  const diff = dt.getTime() - now
  if(diff<=0) return null
  const mins = Math.floor(diff/60000)
  if(mins<60) return `Starts in ${mins}m`
  const hrs = Math.floor(mins/60)
  if(hrs<24) return `Starts in ${hrs}h`
  const days = Math.floor(hrs/24)
  return `Starts in ${days}d`
}

function Chip({ico,label,col}:{ico:string;label:string;col?:string}){
  const c = col || DIM
  return <span style={{display:'inline-flex',alignItems:'center',gap:4,fontSize:10,fontWeight:600,color:c,background:`${c}14`,border:`1px solid ${c}2E`,borderRadius:7,padding:'3px 8px',whiteSpace:'nowrap' as any}}>{ico} {label}</span>
}

function EmptyIllustration(){
  return (
    <svg width="120" height="120" viewBox="0 0 120 120" fill="none" style={{opacity:0.85}}>
      <rect x="28" y="14" width="64" height="92" rx="10" fill="rgba(77,159,255,0.08)" stroke={ACC} strokeWidth="2"/>
      <rect x="44" y="6" width="32" height="14" rx="5" fill="#0A1830" stroke={PRP} strokeWidth="2"/>
      <line x1="40" y1="40" x2="80" y2="40" stroke={DIM} strokeWidth="3" strokeLinecap="round"/>
      <line x1="40" y1="52" x2="80" y2="52" stroke={DIM} strokeWidth="3" strokeLinecap="round"/>
      <line x1="40" y1="64" x2="64" y2="64" stroke={DIM} strokeWidth="3" strokeLinecap="round"/>
      <circle cx="72" cy="86" r="16" fill="rgba(0,196,140,0.12)" stroke={SUC} strokeWidth="2.5"/>
      <path d="M65 86l4.5 4.5L80 79" stroke={SUC} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    </svg>
  )
}

export default function AllExams({ token, API, T, onCreateNew }: Props) {
  const isSuperAdmin = typeof window!=='undefined' && localStorage.getItem('pr_role')==='superadmin'
  const hdrs = { 'Content-Type':'application/json', Authorization:`Bearer ${token}` }

  const [exams, setExams] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState<any>({total:0,draft:0,scheduled:0,live:0,ended:0})
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [now, setNow] = useState(Date.now())

  const [searchInput, setSearchInput] = useState('')
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<string[]>([])
  const [categoryFilter, setCategoryFilter] = useState('')
  const [subjectFilter, setSubjectFilter] = useState('')
  const [batchFilter, setBatchFilter] = useState('')
  const [seriesFilter, setSeriesFilter] = useState('')
  const [dateStart, setDateStart] = useState('')
  const [dateEnd, setDateEnd] = useState('')
  const [sort, setSort] = useState('newest')
  const [mine, setMine] = useState(false)
  const [viewAsAdmin, setViewAsAdmin] = useState('')
  const [needsAttention, setNeedsAttention] = useState(false)
  const [showFilters, setShowFilters] = useState(false)
  const [viewMode, setViewMode] = useState<'list'|'calendar'>('list')
  const [bulkMode, setBulkMode] = useState(false)
  const [selectedIds, setSelectedIds] = useState<string[]>([])

  const [filterOptions, setFilterOptions] = useState<any>({categories:[],subjects:[],batches:[],series:[]})
  const [realBatches, setRealBatches] = useState<any[]>([]) // synced live from Batch Manager (/api/admin/batch-controls)
  const [admins, setAdmins] = useState<any[]>([])

  const [analyticsExam, setAnalyticsExam] = useState<any>(null)
  const [analyticsData, setAnalyticsData] = useState<any>(null)
  const [analyticsLoading, setAnalyticsLoading] = useState(false)

  const [previewExam, setPreviewExam] = useState<any>(null)
  const [previewQuestions, setPreviewQuestions] = useState<any[]>([])
  const [previewLoading, setPreviewLoading] = useState(false)
  const [previewLang, setPreviewLang] = useState<'en'|'hi'>('en')
  const [expandedExplain, setExpandedExplain] = useState<Record<string,boolean>>({})

  const [editExam, setEditExam] = useState<any>(null)
  const [editForm, setEditForm] = useState<any>({})
  const [savingEdit, setSavingEdit] = useState(false)

  // ── Feature 34 — rich delete flow (replaces the old simple deleteConfirm) ───
  const [deleteImpact, setDeleteImpact] = useState<any>(null) // {exam, data}
  const [deleteImpactLoading, setDeleteImpactLoading] = useState(false)
  const [deleteMode, setDeleteMode] = useState<'archive'|'permanent'>('archive')
  const [deleteReasonInput, setDeleteReasonInput] = useState('')
  const [confirmTitleInput, setConfirmTitleInput] = useState('')
  const [deleteCascadeOpen, setDeleteCascadeOpen] = useState(false)
  const [undoToast, setUndoToast] = useState<any>(null) // {exam, secondsLeft, timer, payload}
  const [trashView, setTrashView] = useState(false)
  const [trashExams, setTrashExams] = useState<any[]>([])
  const [trashLoading, setTrashLoading] = useState(false)

  const [busyId, setBusyId] = useState<string|null>(null)
  const [bulkBusy, setBulkBusy] = useState(false)

  // ── Feature 31 — clone dialog, success toast, history, compare ──────────────
  const [cloneDialogExam, setCloneDialogExam] = useState<any>(null)
  const [cloneForm, setCloneForm] = useState<any>({newTitle:'',startTime:'',endTime:'',targetBatch:'',seriesName:''})
  const [cloning, setCloning] = useState(false)
  const [cloneSuccessToast, setCloneSuccessToast] = useState<any>(null)
  const [cloneInfoExam, setCloneInfoExam] = useState<any>(null)
  const [cloneInfoData, setCloneInfoData] = useState<any>(null)
  const [cloneInfoLoading, setCloneInfoLoading] = useState(false)
  const [compareData, setCompareData] = useState<any>(null)
  const [compareLoading, setCompareLoading] = useState(false)

  const [calExams, setCalExams] = useState<any[]>([])
  const [calLoading, setCalLoading] = useState(false)
  const [calMonth, setCalMonth] = useState(()=>{ const d=new Date(); return new Date(d.getFullYear(),d.getMonth(),1) })

  // ── countdown ticker (33.16/33.26 stay fresh) ───────────────────────────────
  useEffect(()=>{ const iv=setInterval(()=>setNow(Date.now()),60000); return ()=>clearInterval(iv) },[])

  // ── debounce search (33.2) ───────────────────────────────────────────────────
  useEffect(()=>{ const tm=setTimeout(()=>setSearch(searchInput),350); return ()=>clearTimeout(tm) },[searchInput])

  // ── reset to page 1 whenever a filter changes ───────────────────────────────
  useEffect(()=>{ setPage(1) },[search,statusFilter,categoryFilter,subjectFilter,batchFilter,seriesFilter,dateStart,dateEnd,sort,mine,viewAsAdmin,needsAttention])

  const buildParams = useCallback((forExport?:boolean)=>{
    const p = new URLSearchParams()
    if(search.trim()) p.set('search',search.trim())
    if(statusFilter.length) p.set('status',statusFilter.join(','))
    if(categoryFilter) p.set('category',categoryFilter)
    if(subjectFilter) p.set('subject',subjectFilter)
    if(batchFilter) p.set('batch',batchFilter)
    if(seriesFilter) p.set('series',seriesFilter)
    if(dateStart) p.set('startDate',dateStart)
    if(dateEnd) p.set('endDate',dateEnd)
    if(sort!=='newest') p.set('sort',sort)
    if(mine) p.set('mine','true')
    if(!mine && viewAsAdmin) p.set('createdBy',viewAsAdmin)
    if(needsAttention) p.set('needsAttention','true')
    if(!forExport){ p.set('page',String(page)); p.set('limit','20') }
    return p
  },[search,statusFilter,categoryFilter,subjectFilter,batchFilter,seriesFilter,dateStart,dateEnd,sort,mine,viewAsAdmin,needsAttention,page])

  const fetchExams = useCallback(async ()=>{
    setLoading(true)
    try {
      const p = buildParams()
      const r = await fetch(`${API}/api/exams-manage/list?${p.toString()}`,{headers:{Authorization:`Bearer ${token}`}})
      const d = await r.json()
      if(d.success){ setExams(d.exams||[]); setStats(d.stats||stats); setTotalPages(d.totalPages||1) }
    } catch {}
    setLoading(false)
  },[API,token,buildParams])

  useEffect(()=>{ fetchExams() },[fetchExams])

  const fetchFilterOptions = useCallback(async ()=>{
    try {
      const r = await fetch(`${API}/api/exams-manage/filter-options`,{headers:{Authorization:`Bearer ${token}`}})
      const d = await r.json()
      if(d.success) setFilterOptions({categories:d.categories||[],subjects:d.subjects||[],batches:d.batches||[],series:d.series||[]})
    } catch {}
  },[API,token])

  // ── synced live from the real Batch Manager — not just batch names already
  // used on past exams, so a brand-new batch with zero exams still shows up ──
  const fetchRealBatches = useCallback(async ()=>{
    try {
      const r = await fetch(`${API}/api/admin/batch-controls`,{headers:{Authorization:`Bearer ${token}`}})
      const d = await r.json()
      setRealBatches(d.batches||[])
    } catch {}
  },[API,token])

  const fetchAdmins = useCallback(async ()=>{
    try {
      const r = await fetch(`${API}/api/exams-manage/admins`,{headers:{Authorization:`Bearer ${token}`}})
      const d = await r.json()
      if(d.success) setAdmins(d.admins||[])
    } catch {}
  },[API,token])

  useEffect(()=>{ fetchFilterOptions() },[fetchFilterOptions])
  useEffect(()=>{ fetchRealBatches() },[fetchRealBatches])
  useEffect(()=>{ if(isSuperAdmin) fetchAdmins() },[isSuperAdmin,fetchAdmins])

  // ── 33.15 — calendar view data (separate, wider, date-bounded fetch) ────────
  const fetchCalendar = useCallback(async ()=>{
    setCalLoading(true)
    try {
      const start = new Date(calMonth.getFullYear(), calMonth.getMonth(), 1)
      const end = new Date(calMonth.getFullYear(), calMonth.getMonth()+1, 0, 23, 59, 59)
      const p = new URLSearchParams()
      p.set('startDate', start.toISOString()); p.set('endDate', end.toISOString())
      p.set('limit','100')
      if(mine) p.set('mine','true')
      if(!mine && viewAsAdmin) p.set('createdBy',viewAsAdmin)
      const r = await fetch(`${API}/api/exams-manage/list?${p.toString()}`,{headers:{Authorization:`Bearer ${token}`}})
      const d = await r.json()
      if(d.success) setCalExams(d.exams||[])
    } catch {}
    setCalLoading(false)
  },[API,token,calMonth,mine,viewAsAdmin])

  useEffect(()=>{ if(viewMode==='calendar') fetchCalendar() },[viewMode,fetchCalendar])

  // ── 33.20 — pin toggle ────────────────────────────────────────────────────────
  const togglePin = async (exam:any) => {
    setExams(p=>p.map(x=>x._id===exam._id?{...x,isPinned:!x.isPinned}:x))
    try {
      const r = await fetch(`${API}/api/exams-manage/${exam._id}/pin`,{method:'PATCH',headers:hdrs})
      await r.json()
      fetchExams()
    } catch { fetchExams() }
  }

  // ── 33.11 — quick status toggle ───────────────────────────────────────────────
  const togglePublish = async (exam:any) => {
    setBusyId(exam._id)
    try {
      const r = await fetch(`${API}/api/exams-manage/${exam._id}/publish`,{method:'PATCH',headers:hdrs})
      const d = await r.json()
      if(d.success){ T(d.message||'Status updated ✅'); fetchExams() } else T(d.message||'Failed','e')
    } catch { T('Network error','e') }
    setBusyId(null)
  }

  // ════════════════════════════════════════════════════════════════════════
  // FEATURE 31 — Clone dialog (31.1-31.6, 31.8), success toast (31.14),
  // clone history (31.9/31.10/31.15), compare (31.11)
  // ════════════════════════════════════════════════════════════════════════
  const openCloneDialog = (exam:any) => {
    setCloneDialogExam(exam)
    setCloneForm({ newTitle: `Copy of ${exam.title}`, startTime:'', endTime:'', targetBatch: exam.batch||'', seriesName: exam.seriesName||'' })
  }

  const submitClone = async () => {
    if (!cloneDialogExam) return
    setCloning(true)
    try {
      const r = await fetch(`${API}/api/exams-manage/${cloneDialogExam._id}/clone-advanced`,{method:'POST',headers:hdrs,body:JSON.stringify(cloneForm)})
      const d = await r.json()
      if (d.success) { setCloneDialogExam(null); setCloneSuccessToast(d.exam); fetchExams() } else T(d.message||'Failed','e')
    } catch { T('Network error','e') }
    setCloning(false)
  }

  const openCloneInfo = async (exam:any) => {
    setCloneInfoExam(exam); setCloneInfoLoading(true); setCloneInfoData(null); setCompareData(null)
    try {
      const r = await fetch(`${API}/api/exams-manage/${exam._id}/clone-info`,{headers:{Authorization:`Bearer ${token}`}})
      const d = await r.json()
      if (d.success) setCloneInfoData(d)
    } catch {}
    setCloneInfoLoading(false)
  }

  const openCompare = async (idA:string, idB:string) => {
    setCompareLoading(true); setCompareData(null)
    try {
      const r = await fetch(`${API}/api/exams-manage/compare?a=${idA}&b=${idB}`,{headers:{Authorization:`Bearer ${token}`}})
      const d = await r.json()
      if (d.success) setCompareData(d)
    } catch {}
    setCompareLoading(false)
  }

  // ════════════════════════════════════════════════════════════════════════
  // FEATURE 34 — Delete impact (34.3/34.11/34.13), archive (34.5/34.9),
  // permanent delete with safety checks (34.6/34.14/34.15/34.17),
  // 10s undo (34.16/34.20), Recycle Bin (34.10/34.24)
  // ════════════════════════════════════════════════════════════════════════
  const openDeleteModal = async (exam:any) => {
    setDeleteImpact({ exam, data:null }); setDeleteImpactLoading(true)
    setDeleteMode('archive'); setDeleteReasonInput(''); setConfirmTitleInput(''); setDeleteCascadeOpen(false)
    try {
      const r = await fetch(`${API}/api/exams-manage/${exam._id}/delete-impact`,{headers:{Authorization:`Bearer ${token}`}})
      const d = await r.json()
      if (d.success) { setDeleteImpact({ exam, data: d }) } else { T(d.message||'Failed','e') }
    } catch { T('Network error','e') }
    setDeleteImpactLoading(false)
  }

  const confirmArchive = async () => {
    if (!deleteImpact) return
    setBusyId(deleteImpact.exam._id)
    try {
      const r = await fetch(`${API}/api/exams-manage/${deleteImpact.exam._id}/archive`,{method:'PATCH',headers:hdrs})
      const d = await r.json()
      if (d.success) { T(d.message||'Archived ✅'); setDeleteImpact(null); fetchExams() } else T(d.message||'Failed','e')
    } catch { T('Network error','e') }
    setBusyId(null)
  }

  const executePermanentDelete = async (exam:any, payload:any) => {
    try {
      const r = await fetch(`${API}/api/exams-manage/${exam._id}/permanent`,{method:'DELETE',headers:hdrs,body:JSON.stringify(payload)})
      const d = await r.json()
      if (d.success) { T(`Exam deleted — ${d.deletedAttempts||0} attempt(s) and ${d.deletedResults||0} result(s) were also cascade-deleted`); setExams(p=>p.filter(x=>x._id!==exam._id)) }
      else T(d.message||'Delete failed','e')
    } catch { T('Network error','e') }
  }

  const startUndoCountdown = (exam:any, payload:any) => {
    let seconds = 10
    const timer = setInterval(()=>{
      seconds -= 1
      setUndoToast((p:any)=> (p && p.exam._id===exam._id) ? {...p, secondsLeft:seconds} : p)
      if (seconds<=0) {
        clearInterval(timer)
        setUndoToast(null)
        executePermanentDelete(exam, payload)
      }
    },1000)
    setUndoToast({ exam, secondsLeft: seconds, timer, payload })
  }

  const cancelUndo = () => {
    if (undoToast?.timer) clearInterval(undoToast.timer)
    setUndoToast(null)
    T('Delete cancelled — the exam is safe ✅')
  }

  const confirmPermanentDelete = () => {
    if (!deleteImpact) return
    const { exam, data } = deleteImpact
    if (data?.requiresTypeToConfirm && confirmTitleInput !== exam.title) { T('Type the exact exam title to confirm','e'); return }
    if (data?.requiresReason && !deleteReasonInput.trim()) { T('A reason is required to delete a completed exam','e'); return }
    const payload = { confirmTitle: confirmTitleInput, reason: deleteReasonInput }
    setDeleteImpact(null)
    startUndoCountdown(exam, payload) // 34.16 — 10s grace period before the real API call fires
  }

  // ── Recycle Bin (34.10/34.24) ─────────────────────────────────────────────────
  const fetchTrash = useCallback(async ()=>{
    setTrashLoading(true)
    try {
      const r = await fetch(`${API}/api/exams-manage/trash`,{headers:{Authorization:`Bearer ${token}`}})
      const d = await r.json()
      if (d.success) setTrashExams(d.exams||[])
    } catch {}
    setTrashLoading(false)
  },[API,token])
  useEffect(()=>{ if(trashView) fetchTrash() },[trashView,fetchTrash])

  const restoreExam = async (exam:any) => {
    setBusyId(exam._id)
    try {
      const r = await fetch(`${API}/api/exams-manage/${exam._id}/restore`,{method:'PATCH',headers:hdrs})
      const d = await r.json()
      if (d.success) { T('Exam restored ✅'); fetchTrash(); fetchExams() } else T(d.message||'Failed','e')
    } catch { T('Network error','e') }
    setBusyId(null)
  }

  const purgeFromTrash = async (exam:any) => {
    if (!window.confirm(`Permanently delete "${exam.title}"? This cannot be undone.`)) return
    setBusyId(exam._id)
    try {
      const r = await fetch(`${API}/api/exams-manage/${exam._id}/permanent`,{method:'DELETE',headers:hdrs,body:JSON.stringify({confirmTitle:exam.title})})
      const d = await r.json()
      if (d.success) { T('Permanently deleted'); setTrashExams(p=>p.filter(x=>x._id!==exam._id)) } else T(d.message||'Failed','e')
    } catch { T('Network error','e') }
    setBusyId(null)
  }

  // ── 34.12 — bulk archive (safer alternative to bulk permanent delete) ───────
  const bulkArchive = async () => {
    if (!selectedIds.length) return
    setBulkBusy(true)
    try {
      const r = await fetch(`${API}/api/exams-manage/bulk-archive`,{method:'POST',headers:hdrs,body:JSON.stringify({ids:selectedIds})})
      const d = await r.json()
      if (d.success) { T(d.message||'Archived ✅'); setSelectedIds([]); fetchExams() } else T(d.message||'Failed','e')
    } catch { T('Network error','e') }
    setBulkBusy(false)
  }

  // ── 33.9 — quick edit ─────────────────────────────────────────────────────────
  const openEdit = (exam:any) => {
    setEditExam(exam)
    setEditForm({
      title: exam.title||'', category: exam.category||'Full Mock', subject: exam.subject||'NEET', type: exam.type||'NEET',
      duration: exam.duration||60, totalMarks: exam.totalMarks||0,
      correctMarks: exam.markingScheme?.correct ?? 4, incorrectMarks: exam.markingScheme?.incorrect ?? -1,
      batch: exam.batch||'', seriesName: exam.seriesName||'', watermark: !!exam.watermark,
      customInstructions: exam.customInstructions||'', status: exam.status||'draft',
      startTime: exam.schedule?.startTime ? new Date(exam.schedule.startTime).toISOString().slice(0,16) : '',
      endTime: exam.schedule?.endTime ? new Date(exam.schedule.endTime).toISOString().slice(0,16) : ''
    })
  }

  const saveEdit = async () => {
    if(!editExam) return
    setSavingEdit(true)
    try {
      const r = await fetch(`${API}/api/exams-manage/${editExam._id}/quick-edit`,{method:'PUT',headers:hdrs,body:JSON.stringify(editForm)})
      const d = await r.json()
      if(d.success){ T('Exam updated ✅'); setEditExam(null); fetchExams() } else T(d.message||'Failed','e')
    } catch { T('Network error','e') }
    setSavingEdit(false)
  }

  // ── NEW — Preview Exam (verify question/option content renders correctly,
  // before students attempt it). Read-only, creates no attempt record. ───────
  const openPreview = async (exam:any) => {
    setPreviewExam(exam); setPreviewLoading(true); setPreviewQuestions([])
    setPreviewLang('en'); setExpandedExplain({})
    try {
      const r = await fetch(`${API}/api/exams-manage/${exam._id}/preview`,{headers:{Authorization:`Bearer ${token}`}})
      const d = await r.json()
      if(d.success) setPreviewQuestions(d.questions||[])
      else T(d.message||'Preview load nahi ho payi','e')
    } catch { T('Network error','e') }
    setPreviewLoading(false)
  }

  const toggleExplain = (qid:string) => setExpandedExplain(p=>({...p,[qid]:!p[qid]}))

  // ── 33.14 — analytics side panel ─────────────────────────────────────────────
  const openAnalytics = async (exam:any) => {
    setAnalyticsExam(exam); setAnalyticsLoading(true); setAnalyticsData(null)
    try {
      const r = await fetch(`${API}/api/exams-manage/${exam._id}/analytics`,{headers:{Authorization:`Bearer ${token}`}})
      const d = await r.json()
      if(d.success) setAnalyticsData(d)
    } catch {}
    setAnalyticsLoading(false)
  }

  // ── 33.27 — bulk actions ──────────────────────────────────────────────────────
  const toggleSelect = (id:string) => setSelectedIds(p=>p.includes(id)?p.filter(x=>x!==id):[...p,id])
  const selectAllOnPage = () => setSelectedIds(exams.map(e=>e._id))
  const clearSelection = () => setSelectedIds([])

  const bulkDelete = async () => {
    if(!selectedIds.length) return
    setBulkBusy(true)
    try {
      const r = await fetch(`${API}/api/exams-manage/bulk-delete`,{method:'POST',headers:hdrs,body:JSON.stringify({ids:selectedIds})})
      const d = await r.json()
      if(d.success){ T(d.message||'Deleted ✅'); setSelectedIds([]); fetchExams() } else T(d.message||'Failed','e')
    } catch { T('Network error','e') }
    setBulkBusy(false)
  }

  const bulkPublish = async () => {
    if(!selectedIds.length) return
    setBulkBusy(true)
    try {
      const r = await fetch(`${API}/api/exams-manage/bulk-publish`,{method:'POST',headers:hdrs,body:JSON.stringify({ids:selectedIds})})
      const d = await r.json()
      if(d.success){ T(d.message||'Published ✅'); setSelectedIds([]); fetchExams() } else T(d.message||'Failed','e')
    } catch { T('Network error','e') }
    setBulkBusy(false)
  }

  // ── 33.17 — export ────────────────────────────────────────────────────────────
  const exportList = async (format:'xlsx'|'csv') => {
    try {
      const p = buildParams(true)
      p.set('format',format)
      const r = await fetch(`${API}/api/exams-manage/export?${p.toString()}`,{headers:{Authorization:`Bearer ${token}`}})
      if(!r.ok){ T('Export failed','e'); return }
      const blob = await r.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url; a.download = format==='csv'?'ProveRank_Exams.csv':'ProveRank_Exams.xlsx'
      document.body.appendChild(a); a.click(); a.remove()
      window.URL.revokeObjectURL(url)
      T('Export downloaded ✅')
    } catch { T('Export failed','e') }
  }

  const toggleStatusFilter = (s:string) => setStatusFilter(p=>p.includes(s)?p.filter(x=>x!==s):[...p,s])
  const clearAllFilters = () => { setSearchInput(''); setStatusFilter([]); setCategoryFilter(''); setSubjectFilter(''); setBatchFilter(''); setSeriesFilter(''); setDateStart(''); setDateEnd(''); setSort('newest'); setMine(false); setViewAsAdmin(''); setNeedsAttention(false) }
  const activeFilterCount = [statusFilter.length>0,!!categoryFilter,!!subjectFilter,!!batchFilter,!!seriesFilter,!!dateStart||!!dateEnd,mine,!!viewAsAdmin,needsAttention].filter(Boolean).length

  return (
    <div style={{fontFamily:'Inter,sans-serif'}}>
      <style dangerouslySetInnerHTML={{__html:`
        @keyframes aeFadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
        @keyframes aeSpin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
        @keyframes aePulse{0%,100%{box-shadow:0 0 0 0 ${ACC}66}50%{box-shadow:0 0 0 6px ${ACC}00}}
        .ae-card{animation:aeFadeIn 0.3s ease}
        .ae-spin{animation:aeSpin 0.8s linear infinite;display:inline-block}
        .ae-countdown{animation:aePulse 1.8s ease infinite}
      `}}/>
      <datalist id="series-suggestions">
        {filterOptions.series.map((s:string)=><option key={s} value={s}/>)}
      </datalist>

      {/* ══ HEADER ══════════════════════════════════════════════════════════════ */}
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',gap:12,marginBottom:16,flexWrap:'wrap' as any}}>
        <div>
          <div style={{fontFamily:'Playfair Display,serif',fontWeight:800,fontSize:22,color:TS,display:'flex',alignItems:'center',gap:8}}>📝 All Exams</div>
          <div style={{fontSize:12,color:DIM,marginTop:3}}>Every exam, one place — search, filter, manage, monitor</div>
        </div>
        <div style={{display:'flex',gap:8,flexWrap:'wrap' as any}}>
          <button onClick={()=>exportList('xlsx')} style={{...bg_,fontSize:12}}>⬇️ Export</button>
          <button onClick={onCreateNew} style={{...bp,fontSize:13,boxShadow:`0 4px 18px ${PRP}44`}}>+ Create Exam</button>
        </div>
      </div>

      {/* ══ STATS BAR — 33.21 ═══════════════════════════════════════════════════ */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(110px,1fr))',gap:8,marginBottom:14}}>
        {[
          {label:'Total',val:stats.total,col:ACC,ico:'📊'},
          {label:'Draft',val:stats.draft,col:DIM,ico:'📝'},
          {label:'Upcoming',val:stats.scheduled,col:ACC,ico:'⏳'},
          {label:'Active',val:stats.live,col:SUC,ico:'🟢'},
          {label:'Completed',val:stats.ended,col:PRP,ico:'✅'},
        ].map(s=>(
          <div key={s.label} style={{...cs,padding:'12px 14px',textAlign:'center' as any}}>
            <div style={{fontSize:18,fontWeight:800,color:s.col}}>{s.ico} {s.val}</div>
            <div style={{fontSize:10,color:DIM,fontWeight:700,letterSpacing:0.4,textTransform:'uppercase' as any,marginTop:2}}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* ══ TOOLBAR — search + view toggle + bulk toggle — 33.24/33.25/33.27 ════ */}
      <div style={{...cs,padding:'14px',marginBottom:12}}>
        <div style={{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap' as any}}>
          <input value={searchInput} onChange={e=>setSearchInput(e.target.value)} placeholder="🔍 Search exams by title..." style={{...inp,flex:1,minWidth:200}}/>
          <button onClick={()=>setShowFilters(p=>!p)} style={{...bg_,fontSize:12,background:activeFilterCount>0?`${ACC}22`:bg_.background,borderColor:activeFilterCount>0?ACC:BOR}}>
            🎛 Filters{activeFilterCount>0?` (${activeFilterCount})`:''}
          </button>
          <div style={{display:'flex',background:'rgba(255,255,255,0.04)',borderRadius:10,border:`1px solid ${BOR}`,padding:2}}>
            <button onClick={()=>setViewMode('list')} title="List view" style={{background:viewMode==='list'?`${ACC}33`:'transparent',border:'none',color:viewMode==='list'?TS:DIM,borderRadius:8,padding:'7px 11px',cursor:'pointer',fontSize:13}}>≡</button>
            <button onClick={()=>setViewMode('calendar')} title="Calendar view" style={{background:viewMode==='calendar'?`${ACC}33`:'transparent',border:'none',color:viewMode==='calendar'?TS:DIM,borderRadius:8,padding:'7px 11px',cursor:'pointer',fontSize:13}}>📅</button>
          </div>
          <button onClick={()=>{setBulkMode(p=>!p);setSelectedIds([])}} style={{...bg_,fontSize:12,background:bulkMode?`${PRP}22`:bg_.background,borderColor:bulkMode?PRP:BOR,color:bulkMode?PRP:TS}}>☑️ Bulk Select</button>
          <button onClick={()=>setTrashView(p=>!p)} style={{...bg_,fontSize:12,background:trashView?`${DNG}22`:bg_.background,borderColor:trashView?DNG:BOR,color:trashView?DNG:TS}}>🗑 Trash{trashExams.length>0?` (${trashExams.length})`:''}</button>
        </div>

        {showFilters && (
          <div style={{marginTop:14,paddingTop:14,borderTop:`1px solid ${BOR}`,display:'flex',flexDirection:'column' as any,gap:12}}>
            {/* status pills — 33.3 */}
            <div>
              <label style={lbl}>Status</label>
              <div style={{display:'flex',gap:6,flexWrap:'wrap' as any}}>
                {STATUS_ORDER.map(s=>{
                  const m = STATUS_META[s]; const active = statusFilter.includes(s)
                  return (
                    <button key={s} onClick={()=>toggleStatusFilter(s)} style={{display:'flex',alignItems:'center',gap:5,padding:'6px 12px',borderRadius:18,fontSize:11,fontWeight:700,cursor:'pointer',background:active?m.color:`${m.color}14`,color:active?'#fff':m.color,border:`1px solid ${m.color}44`}}>
                      {m.icon} {m.label}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* category / subject — 33.4 */}
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
              <div>
                <label style={lbl}>Category</label>
                <select value={categoryFilter} onChange={e=>setCategoryFilter(e.target.value)} style={inp}>
                  <option value="">All Categories</option>
                  {filterOptions.categories.map((c:string)=><option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label style={lbl}>Subject</label>
                <select value={subjectFilter} onChange={e=>setSubjectFilter(e.target.value)} style={inp}>
                  <option value="">All Subjects</option>
                  {filterOptions.subjects.map((s:string)=><option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>

            {/* batch / series — 33.5 */}
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
              <div>
                <label style={lbl}>Batch</label>
                <select value={batchFilter} onChange={e=>setBatchFilter(e.target.value)} style={inp}>
                  <option value="">All Batches</option>
                  {filterOptions.batches.map((b:string)=><option key={b} value={b}>{b}</option>)}
                </select>
              </div>
              <div>
                <label style={lbl}>Test Series</label>
                <select value={seriesFilter} onChange={e=>setSeriesFilter(e.target.value)} style={inp}>
                  <option value="">All Series</option>
                  {filterOptions.series.map((s:string)=><option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>

            {/* date range — 33.6 */}
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
              <div>
                <label style={lbl}>From Date</label>
                <input type="date" value={dateStart} onChange={e=>setDateStart(e.target.value)} style={inp}/>
              </div>
              <div>
                <label style={lbl}>To Date</label>
                <input type="date" value={dateEnd} onChange={e=>setDateEnd(e.target.value)} style={inp}/>
              </div>
            </div>

            {/* sort — 33.8 */}
            <div>
              <label style={lbl}>Sort By</label>
              <select value={sort} onChange={e=>setSort(e.target.value)} style={inp}>
                <option value="newest">Newest First</option>
                <option value="oldest">Oldest First</option>
                <option value="dateAsc">Exam Date — Ascending</option>
                <option value="dateDesc">Exam Date — Descending</option>
              </select>
            </div>

            {/* my created exams / admin picker — 33.12 */}
            <div style={{display:'flex',gap:10,alignItems:'center',flexWrap:'wrap' as any}}>
              <label style={{display:'flex',alignItems:'center',gap:7,fontSize:12,color:TS,cursor:'pointer'}}>
                <input type="checkbox" checked={mine} onChange={e=>{setMine(e.target.checked); if(e.target.checked) setViewAsAdmin('')}}/>
                My Created Exams
              </label>
              {isSuperAdmin && !mine && (
                <select value={viewAsAdmin} onChange={e=>setViewAsAdmin(e.target.value)} style={{...inp,maxWidth:240}}>
                  <option value="">All Admins</option>
                  {admins.map(a=><option key={a._id} value={a._id}>{a.name||a.email} ({a.examCount})</option>)}
                </select>
              )}
            </div>

            {/* needs attention — 33.18 */}
            <label style={{display:'flex',alignItems:'center',gap:7,fontSize:12,color:WRN,cursor:'pointer'}}>
              <input type="checkbox" checked={needsAttention} onChange={e=>setNeedsAttention(e.target.checked)}/>
              ⚠️ Needs Attention (no batch assigned / 0 questions)
            </label>

            {activeFilterCount>0 && <button onClick={clearAllFilters} style={{...bg_,fontSize:11,alignSelf:'flex-start' as any,color:DNG,borderColor:`${DNG}33`}}>✕ Clear All Filters</button>}
          </div>
        )}
      </div>

      {/* ══ BULK ACTION BAR — 33.27 ══════════════════════════════════════════════ */}
      {!trashView && bulkMode && selectedIds.length>0 && (
        <div style={{...cs,padding:'10px 16px',marginBottom:12,display:'flex',alignItems:'center',justifyContent:'space-between',gap:10,flexWrap:'wrap' as any,borderColor:`${PRP}44`}}>
          <span style={{fontSize:12,color:TS,fontWeight:600}}>{selectedIds.length} exam(s) selected</span>
          <div style={{display:'flex',gap:8,flexWrap:'wrap' as any}}>
            <button onClick={selectAllOnPage} style={{...bg_,fontSize:11}}>Select all on page</button>
            <button onClick={clearSelection} style={{...bg_,fontSize:11}}>Clear</button>
            <button onClick={bulkPublish} disabled={bulkBusy} style={{...bg_,fontSize:11,color:SUC,borderColor:`${SUC}33`}}>{bulkBusy?<span className="ae-spin">⟳</span>:'📢 Publish Selected'}</button>
            <button onClick={bulkArchive} disabled={bulkBusy} style={{...bg_,fontSize:11,color:ACC,borderColor:`${ACC}33`}}>{bulkBusy?<span className="ae-spin">⟳</span>:'📥 Archive Selected'}</button>
            <button onClick={bulkDelete} disabled={bulkBusy} style={{...bg_,fontSize:11,color:DNG,borderColor:`${DNG}33`}}>{bulkBusy?<span className="ae-spin">⟳</span>:'🗑 Delete Selected (drafts only)'}</button>
          </div>
        </div>
      )}

      {/* ══ FEATURE 34 — RECYCLE BIN (34.10/34.24) ════════════════════════════════ */}
      {trashView && (
        <div style={cs}>
          <div style={{fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:15,color:TS,marginBottom:4}}>🗑 Recycle Bin</div>
          <div style={{fontSize:11,color:DIM,marginBottom:14}}>Archived exams are automatically and permanently deleted after 30 days.</div>
          {trashLoading ? (
            <div style={{textAlign:'center' as any,padding:'40px 0',color:DIM}}><span className="ae-spin" style={{fontSize:22}}>⟳</span></div>
          ) : trashExams.length===0 ? (
            <div style={{textAlign:'center' as any,padding:'30px 0',color:DIM,fontSize:12}}>The Recycle Bin is empty.</div>
          ) : (
            <div style={{display:'flex',flexDirection:'column' as any,gap:10}}>
              {trashExams.map(e=>{
                const daysLeft = e.archivedAt ? Math.max(0,30-Math.floor((Date.now()-new Date(e.archivedAt).getTime())/86400000)) : 30
                return (
                  <div key={e._id} style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:10,padding:'10px 14px',background:'rgba(255,255,255,0.03)',borderRadius:10,border:`1px solid ${BOR}`,flexWrap:'wrap' as any}}>
                    <div>
                      <div style={{fontSize:13,color:TS,fontWeight:600}}>{e.title}</div>
                      <div style={{fontSize:10,color:WRN,marginTop:2}}>⏳ Auto-deletes in {daysLeft} day{daysLeft!==1?'s':''}</div>
                    </div>
                    <div style={{display:'flex',gap:6}}>
                      <button onClick={()=>restoreExam(e)} disabled={busyId===e._id} style={{...bg_,fontSize:11,color:SUC,borderColor:`${SUC}33`}}>{busyId===e._id?<span className="ae-spin">⟳</span>:'↺ Restore'}</button>
                      <button onClick={()=>purgeFromTrash(e)} disabled={busyId===e._id} style={{...bg_,fontSize:11,color:DNG,borderColor:`${DNG}33`}}>🗑 Delete Forever</button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      )}

      {/* ══ LIST VIEW ════════════════════════════════════════════════════════════ */}
      {!trashView && viewMode==='list' && (loading ? (
        <div style={{textAlign:'center' as any,padding:'60px 20px',color:DIM}}><span className="ae-spin" style={{fontSize:24}}>⟳</span><div style={{marginTop:10,fontSize:12}}>Loading exams...</div></div>
      ) : exams.length===0 ? (
        <div style={{...cs,textAlign:'center' as any,padding:'48px 24px'}}>
          <div style={{display:'flex',justifyContent:'center',marginBottom:10}}><EmptyIllustration/></div>
          <div style={{fontFamily:'Playfair Display,serif',fontSize:17,fontWeight:700,color:TS,marginBottom:6}}>No exams yet</div>
          <div style={{fontSize:12,color:DIM,marginBottom:20}}>Create your first exam to get started →</div>
          <button onClick={onCreateNew} style={{...bp,fontSize:13}}>+ Create Your First Exam</button>
        </div>
      ) : (
        <div style={{display:'flex',flexDirection:'column' as any,gap:12}}>
          {exams.map(e=>{
            const meta = STATUS_META[e.status] || STATUS_META.draft
            const cd = e.status==='scheduled' ? countdownLabel(e.schedule?.startTime, now) : null
            const needsAttn = (!e.batch) || (e.questionCount===0)
            const selected = selectedIds.includes(e._id)
            const busy = busyId===e._id
            return (
              <div key={e._id} className="ae-card" style={{position:'relative' as any,overflow:'hidden',borderRadius:16,background:CRD,border:`1px solid ${BOR}`,borderLeft:`4px solid ${meta.color}`,backdropFilter:'blur(14px)',boxShadow:'0 4px 18px rgba(0,0,0,0.3)'}}>
                <div style={{position:'absolute',top:0,left:0,right:0,height:3,background:`linear-gradient(90deg,${meta.color},${meta.color}00 85%)`}}/>

                <div style={{padding:'14px 16px 12px',display:'flex',gap:10,alignItems:'flex-start'}}>
                  {bulkMode && (
                    <input type="checkbox" checked={selected} onChange={()=>toggleSelect(e._id)} style={{marginTop:4,width:16,height:16,cursor:'pointer',flexShrink:0}}/>
                  )}
                  <div style={{flex:1,minWidth:0,cursor:'pointer'}} onClick={()=>openAnalytics(e)}>
                    <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8,flexWrap:'wrap' as any}}>
                      {e.isPinned && <span title="Pinned" style={{color:GOLD,fontSize:13}}>📌</span>}
                      <span style={{fontWeight:700,fontSize:14,color:TS,fontFamily:'Playfair Display,serif'}}>{e.title}</span>
                      <span style={{display:'inline-flex',alignItems:'center',gap:4,fontSize:10,fontWeight:700,color:meta.color,background:`${meta.color}18`,border:`1px solid ${meta.color}44`,borderRadius:20,padding:'3px 10px',boxShadow:e.status==='live'?`0 0 10px ${SUC}66`:'none'}}>{meta.icon} {meta.label}</span>
                      {cd && <span className="ae-countdown" style={{fontSize:10,fontWeight:700,color:WRN,background:`${WRN}18`,border:`1px solid ${WRN}44`,borderRadius:20,padding:'3px 10px'}}>⏰ {cd}</span>}
                      {needsAttn && <span title="Needs attention" style={{fontSize:10,fontWeight:700,color:DNG,background:`${DNG}18`,border:`1px solid ${DNG}44`,borderRadius:20,padding:'3px 10px'}}>⚠️ Needs attention</span>}
                    </div>
                    <div style={{display:'flex',gap:6,flexWrap:'wrap' as any}}>
                      <Chip ico="📅" label={fmtDateStr(e.schedule?.startTime)} col={ACC}/>
                      <Chip ico="⏱" label={`${e.duration||0} min`} col={ACC}/>
                      <Chip ico="📊" label={`${e.totalMarks||0} marks`} col={GOLD}/>
                      <Chip ico="👥" label={`${e.studentCount||0} students`} col={SUC}/>
                      <Chip ico="❓" label={`${e.questionCount||0} Qs`} col={PRP}/>
                      {e.category && <Chip ico="📐" label={e.category} col={DIM}/>}
                      {e.batch && <Chip ico="📦" label={e.batch} col={DIM}/>}
                      {e.clonedFrom && <Chip ico="🔗" label={`Source: ${e.clonedFrom.title||'…'}`} col={PRP}/>}
                      {e.cloneCount>0 && (
                        <span onClick={(ev:any)=>{ev.stopPropagation();openCloneInfo(e)}} style={{cursor:'pointer'}}>
                          <Chip ico="🔗" label={`Cloned ${e.cloneCount}x`} col={ACC}/>
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div style={{height:1,background:'rgba(255,255,255,0.06)',margin:'0 16px'}}/>

                <div style={{display:'flex',gap:6,padding:'10px 14px',overflowX:'auto' as any}}>
                  <button onClick={()=>togglePin(e)} title={e.isPinned?'Unpin':'Pin to top'} style={{...bg_,flexShrink:0,padding:'7px 12px',fontSize:11,color:e.isPinned?GOLD:DIM,borderColor:e.isPinned?`${GOLD}44`:BOR}}>📌 {e.isPinned?'Pinned':'Pin'}</button>
                  <button onClick={()=>togglePublish(e)} disabled={busy} title="Toggle status" style={{...bg_,flexShrink:0,padding:'7px 12px',fontSize:11,color:e.status==='draft'?SUC:WRN,borderColor:e.status==='draft'?`${SUC}44`:`${WRN}44`}}>
                    {busy?<span className="ae-spin">⟳</span>:(e.status==='draft'?'📢 Publish':'↩️ Unpublish')}
                  </button>
                  <div style={{width:1,background:'rgba(255,255,255,0.08)',flexShrink:0,margin:'2px 2px'}}/>
                  <button onClick={()=>openPreview(e)} title="Preview as student — check questions/options render correctly" style={{...bg_,flexShrink:0,padding:'7px 11px',fontSize:13,color:ACC}}>👁</button>
                  <button onClick={()=>openEdit(e)} title="Edit" style={{...bg_,flexShrink:0,padding:'7px 11px',fontSize:13}}>✏️</button>
                  <button onClick={()=>openCloneDialog(e)} title="Clone this exam" style={{...bg_,flexShrink:0,padding:'7px 11px',fontSize:13}}>📋</button>
                  <button onClick={()=>openAnalytics(e)} title="View Results" style={{...bg_,flexShrink:0,padding:'7px 11px',fontSize:13}}>📈</button>
                  {e.status==='live' ? (
                    <button title="Live exam — end/unpublish it first to delete or archive" style={{...bg_,flexShrink:0,padding:'7px 11px',fontSize:13,color:DNG,opacity:0.6,cursor:'not-allowed'}}>🔒</button>
                  ) : (
                    <button onClick={()=>openDeleteModal(e)} title="Delete / Archive" style={{...bg_,flexShrink:0,padding:'7px 11px',fontSize:13,color:DNG,borderColor:`${DNG}33`}}>🗑</button>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      ))}

      {/* ══ PAGINATION — 33.10 ══════════════════════════════════════════════════ */}
      {!trashView && viewMode==='list' && !loading && exams.length>0 && totalPages>1 && (
        <div style={{display:'flex',justifyContent:'center',alignItems:'center',gap:10,marginTop:18}}>
          <button onClick={()=>setPage(p=>Math.max(1,p-1))} disabled={page<=1} style={{...bg_,fontSize:12,opacity:page<=1?0.4:1}}>← Prev</button>
          <span style={{fontSize:12,color:DIM}}>Page {page} of {totalPages}</span>
          <button onClick={()=>setPage(p=>Math.min(totalPages,p+1))} disabled={page>=totalPages} style={{...bg_,fontSize:12,opacity:page>=totalPages?0.4:1}}>Next →</button>
        </div>
      )}

      {/* ══ CALENDAR VIEW — 33.15 ════════════════════════════════════════════════ */}
      {!trashView && viewMode==='calendar' && (
        <div style={cs}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
            <button onClick={()=>setCalMonth(d=>new Date(d.getFullYear(),d.getMonth()-1,1))} style={{...bg_,fontSize:12,padding:'6px 12px'}}>←</button>
            <div style={{fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:15,color:TS}}>{calMonth.toLocaleString('en-IN',{month:'long',year:'numeric'})}</div>
            <button onClick={()=>setCalMonth(d=>new Date(d.getFullYear(),d.getMonth()+1,1))} style={{...bg_,fontSize:12,padding:'6px 12px'}}>→</button>
          </div>
          {calLoading ? (
            <div style={{textAlign:'center' as any,padding:'40px 0',color:DIM}}><span className="ae-spin" style={{fontSize:22}}>⟳</span></div>
          ) : (
            <CalendarGrid month={calMonth} exams={calExams} onDayClick={(d:Date)=>{ setDateStart(d.toISOString().slice(0,10)); setDateEnd(d.toISOString().slice(0,10)); setViewMode('list'); setShowFilters(true) }} onExamClick={openAnalytics}/>
          )}
        </div>
      )}

      {/* ══ FEATURE 34 — RICH DELETE MODAL (34.2/34.3/34.4/34.9/34.11/34.14/34.17/34.19/34.21/34.22/34.23) ══ */}
      {deleteImpact && (
        <div style={{position:'fixed' as any,inset:0,background:'rgba(0,4,14,0.75)',backdropFilter:'blur(4px)',zIndex:9210,display:'flex',alignItems:'flex-start',justifyContent:'center',padding:'76px 14px 20px',overflowY:'auto' as any}} onClick={()=>setDeleteImpact(null)}>
          <div onClick={e=>e.stopPropagation()} style={{...cs,width:'100%',maxWidth:420,marginTop:10,border:`1.5px solid ${DNG}44`}}>
            <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:10}}>
              <span style={{fontSize:20}}>⚠️</span>
              <div style={{fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:15,color:TS}}>Delete "{deleteImpact.exam.title}"?</div>
            </div>

            {deleteImpactLoading ? (
              <div style={{textAlign:'center' as any,padding:'30px 0',color:DIM}}><span className="ae-spin" style={{fontSize:20}}>⟳</span></div>
            ) : !deleteImpact.data ? (
              <div style={{fontSize:12,color:DNG}}>Stats load nahi ho payi.</div>
            ) : deleteImpact.data.isLive ? (
              <div style={{padding:'14px',background:`${DNG}14`,border:`1px solid ${DNG}44`,borderRadius:10,fontSize:12,color:DNG,marginBottom:14}}>
                🔒 This exam is currently LIVE/Active — it cannot be deleted or archived. End/unpublish it first (using the 📢/↩️ button), then try again.
              </div>
            ) : (
              <>
                <div style={{display:'flex',gap:6,flexWrap:'wrap' as any,marginBottom:14}}>
                  <span style={{fontSize:11,fontWeight:700,color:WRN,background:`${WRN}18`,border:`1px solid ${WRN}44`,borderRadius:8,padding:'5px 10px'}}>👥 {deleteImpact.data.studentsAttempted} student(s) attempted</span>
                  <span style={{fontSize:11,fontWeight:700,color:WRN,background:`${WRN}18`,border:`1px solid ${WRN}44`,borderRadius:8,padding:'5px 10px'}}>📝 {deleteImpact.data.attemptCount} attempts</span>
                </div>

                <div style={{marginBottom:14}}>
                  <button onClick={()=>setDeleteCascadeOpen(p=>!p)} style={{...bg_,fontSize:11,width:'100%',textAlign:'left' as any}}>
                    {deleteCascadeOpen?'🔽':'▶️'} What will be deleted? (cascade details)
                  </button>
                  {deleteCascadeOpen && (
                    <div style={{marginTop:8,padding:'10px 12px',background:'rgba(255,255,255,0.03)',borderRadius:8,fontSize:11,color:DIM,lineHeight:1.7}}>
                      • {deleteImpact.data.attemptCount} attempt record(s)<br/>
                      • {deleteImpact.data.resultCount} result(s)<br/>
                      • Future certificates (once that feature is built) will also automatically become invalid<br/>
                      • This action only happens with "Permanent Delete" — "Archive" keeps the data safe
                    </div>
                  )}
                </div>

                <div style={{display:'flex',gap:8,marginBottom:14}}>
                  <button onClick={()=>setDeleteMode('archive')} style={{...bg_,flex:1,fontSize:11,background:deleteMode==='archive'?`${ACC}22`:bg_.background,borderColor:deleteMode==='archive'?ACC:BOR,color:deleteMode==='archive'?ACC:TS}}>📥 Archive (reversible)</button>
                  <button onClick={()=>setDeleteMode('permanent')} style={{...bg_,flex:1,fontSize:11,background:deleteMode==='permanent'?`${DNG}22`:bg_.background,borderColor:deleteMode==='permanent'?DNG:BOR,color:deleteMode==='permanent'?DNG:TS}}>🗑 Permanent Delete</button>
                </div>

                {deleteMode==='archive' && (
                  <div style={{fontSize:11,color:DIM,marginBottom:14,lineHeight:1.5}}>The exam will move to the Recycle Bin — you can restore it within 30 days, after which it will be auto-deleted.</div>
                )}

                {deleteMode==='permanent' && (
                  <>
                    <div style={{fontSize:11,color:DNG,marginBottom:10,fontWeight:600}}>⚠️ This action cannot be undone (you'll get a 10-second grace period).</div>
                    {deleteImpact.data.requiresReason && (
                      <div style={{marginBottom:10}}>
                        <label style={lbl}>Delete Reason (mandatory — completed exam)</label>
                        <textarea value={deleteReasonInput} onChange={e=>setDeleteReasonInput(e.target.value)} rows={2} style={{...inp,resize:'vertical' as any}} placeholder="Kyun delete kar rahe ho?"/>
                      </div>
                    )}
                    {deleteImpact.data.requiresTypeToConfirm && (
                      <div style={{marginBottom:10}}>
                        <label style={lbl}>Type the exam title to confirm: <b style={{color:TS}}>{deleteImpact.exam.title}</b></label>
                        <input value={confirmTitleInput} onChange={e=>setConfirmTitleInput(e.target.value)} style={inp} placeholder="Type the exam title here"/>
                      </div>
                    )}
                  </>
                )}

                <div style={{display:'flex',gap:8,marginTop:6}}>
                  <button onClick={()=>setDeleteImpact(null)} style={{...bg_,flex:1}}>Cancel</button>
                  {deleteMode==='archive' ? (
                    <button onClick={confirmArchive} disabled={busyId===deleteImpact.exam._id} style={{...bpAcc,flex:1}}>{busyId===deleteImpact.exam._id?<span className="ae-spin">⟳</span>:'📥 Archive Now'}</button>
                  ) : (
                    <button onClick={confirmPermanentDelete} style={{...bp,flex:1,background:`linear-gradient(135deg,${DNG},#9B0000)`}}>🗑 Delete Permanently</button>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ══ FEATURE 34 — 10s UNDO TOAST (34.16/34.20) ══════════════════════════════ */}
      {undoToast && (
        <div style={{position:'fixed' as any,left:16,bottom:16,zIndex:9260,background:CRD,border:`1px solid ${DNG}44`,borderRadius:14,padding:'14px 16px',minWidth:260,maxWidth:340,boxShadow:'0 8px 28px rgba(0,0,0,0.5)'}}>
          <div style={{fontSize:12,color:TS,marginBottom:8}}>🗑 Deleting "{undoToast.exam.title}"... ({undoToast.secondsLeft}s)</div>
          <div style={{height:4,borderRadius:3,background:'rgba(255,255,255,0.08)',overflow:'hidden',marginBottom:10}}>
            <div style={{height:'100%',width:`${(undoToast.secondsLeft/10)*100}%`,background:`linear-gradient(90deg,${DNG},${WRN})`,transition:'width 1s linear'}}/>
          </div>
          <button onClick={cancelUndo} style={{...bpAcc,width:'100%',padding:'9px',fontSize:12,fontWeight:800}}>↩️ UNDO</button>
        </div>
      )}

      {/* ══ FEATURE 31 — CLONE DIALOG (31.1-31.6/31.8/31.13) ══════════════════════ */}
      {cloneDialogExam && (
        <div style={{position:'fixed' as any,inset:0,background:'rgba(0,4,14,0.7)',backdropFilter:'blur(4px)',zIndex:9210,display:'flex',alignItems:'flex-start',justifyContent:'center',padding:'76px 14px 20px',overflowY:'auto' as any}} onClick={()=>setCloneDialogExam(null)}>
          <div onClick={e=>e.stopPropagation()} style={{...cs,width:'100%',maxWidth:400,marginTop:10}}>
            <div style={{fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:15,color:TS,marginBottom:14}}>📋 Clone Exam</div>
            <div style={{fontSize:11,color:DIM,marginBottom:14}}>The same questions, settings, and marking scheme will be copied. The new exam will be created as a Draft.</div>
            <div style={{display:'flex',flexDirection:'column' as any,gap:12}}>
              <div>
                <label style={lbl}>New Title</label>
                <input value={cloneForm.newTitle} onChange={e=>setCloneForm((f:any)=>({...f,newTitle:e.target.value}))} style={inp}/>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                <div><label style={lbl}>New Start Date/Time</label><input type="datetime-local" value={cloneForm.startTime} onChange={e=>setCloneForm((f:any)=>({...f,startTime:e.target.value}))} style={inp}/></div>
                <div><label style={lbl}>New End Date/Time</label><input type="datetime-local" value={cloneForm.endTime} onChange={e=>setCloneForm((f:any)=>({...f,endTime:e.target.value}))} style={inp}/></div>
              </div>
              <div>
                <label style={lbl}>Batch (change this to clone into a different batch)</label>
                <select value={cloneForm.targetBatch} onChange={e=>setCloneForm((f:any)=>({...f,targetBatch:e.target.value}))} style={inp}>
                  <option value="">— Open / No Batch —</option>
                  {realBatches.map((b:any)=><option key={b._id} value={b.name}>{b.name}{b.status!=='active'?` (${b.status})`:''}</option>)}
                </select>
              </div>
              <div>
                <label style={lbl}>Test Series / Mini Series (optional)</label>
                <input list="series-suggestions" value={cloneForm.seriesName} onChange={e=>setCloneForm((f:any)=>({...f,seriesName:e.target.value}))} style={inp} placeholder="Leave blank, or pick/type a series name"/>
              </div>
            </div>
            <div style={{display:'flex',gap:10,marginTop:18}}>
              <button onClick={()=>setCloneDialogExam(null)} style={{...bg_,flex:1}}>Cancel</button>
              <button onClick={submitClone} disabled={cloning} style={{...bpAcc,flex:1}}>{cloning?'Cloning...':'📋 Clone Now'}</button>
            </div>
          </div>
        </div>
      )}

      {/* ══ FEATURE 31 — PREMIUM CLONE SUCCESS TOAST (31.14) ══════════════════════ */}
      {cloneSuccessToast && (
        <div style={{position:'fixed' as any,inset:0,zIndex:9270,display:'flex',alignItems:'center',justifyContent:'center',pointerEvents:'none' as any}}>
          <div onClick={()=>{ openEdit(cloneSuccessToast); setCloneSuccessToast(null) }} style={{pointerEvents:'auto' as any,cursor:'pointer',background:`linear-gradient(135deg,rgba(0,196,140,0.18),${CRD})`,border:`1.5px solid ${SUC}55`,borderRadius:18,padding:'22px 28px',textAlign:'center' as any,boxShadow:`0 12px 40px rgba(0,0,0,0.5),0 0 30px ${SUC}33`,animation:'aeFadeIn 0.35s ease',maxWidth:300}}>
            <div style={{fontSize:34,marginBottom:8}}>✅</div>
            <div style={{fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:15,color:TS,marginBottom:4}}>Exam cloned successfully!</div>
            <div style={{fontSize:11,color:SUC,fontWeight:600}}>Click to edit "{cloneSuccessToast.title}" →</div>
            <button onClick={(e:any)=>{e.stopPropagation();setCloneSuccessToast(null)}} style={{marginTop:12,background:'transparent',border:'none',color:DIM,fontSize:11,cursor:'pointer'}}>Dismiss</button>
          </div>
        </div>
      )}

      {/* ══ FEATURE 31 — CLONE HISTORY + COMPARE (31.9/31.10/31.11/31.15) ════════ */}
      {cloneInfoExam && (
        <div style={{position:'fixed' as any,inset:0,background:'rgba(0,4,14,0.7)',backdropFilter:'blur(4px)',zIndex:9210,display:'flex',alignItems:'flex-start',justifyContent:'center',padding:'76px 14px 20px',overflowY:'auto' as any}} onClick={()=>{setCloneInfoExam(null);setCompareData(null)}}>
          <div onClick={e=>e.stopPropagation()} style={{...cs,width:'100%',maxWidth:480,marginTop:10}}>
            <div style={{fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:15,color:TS,marginBottom:4}}>🔗 Clone History</div>
            <div style={{fontSize:11,color:DIM,marginBottom:14}}>{cloneInfoExam.title}</div>

            {cloneInfoLoading ? (
              <div style={{textAlign:'center' as any,padding:24,color:DIM}}><span className="ae-spin">⟳</span></div>
            ) : !cloneInfoData ? null : (
              <div style={{display:'flex',flexDirection:'column' as any,gap:12}}>
                {cloneInfoData.parent && (
                  <div>
                    <label style={lbl}>Source (parent)</label>
                    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'9px 12px',background:'rgba(255,255,255,0.03)',borderRadius:8,fontSize:12}}>
                      <span style={{color:TS}}>{cloneInfoData.parent.title}</span>
                      <button onClick={()=>openCompare(cloneInfoExam._id,cloneInfoData.parent._id)} style={{...bg_,fontSize:10,padding:'4px 10px'}}>⇄ Compare</button>
                    </div>
                  </div>
                )}
                <div>
                  <label style={lbl}>Cloned {cloneInfoData.children?.length||0} time(s)</label>
                  {(!cloneInfoData.children || cloneInfoData.children.length===0) ? (
                    <div style={{fontSize:11,color:DIM}}>No clones have been made from this exam yet.</div>
                  ) : (
                    <div style={{display:'flex',flexDirection:'column' as any,gap:6}}>
                      {cloneInfoData.children.map((c:any)=>(
                        <div key={c._id} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'9px 12px',background:'rgba(255,255,255,0.03)',borderRadius:8,fontSize:12}}>
                          <span style={{color:TS}}>{c.title} <span style={{color:DIM,fontSize:10}}>({STATUS_META[c.status]?.label||c.status})</span></span>
                          <button onClick={()=>openCompare(cloneInfoExam._id,c._id)} style={{...bg_,fontSize:10,padding:'4px 10px'}}>⇄ Compare</button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {compareLoading && <div style={{textAlign:'center' as any,padding:14,color:DIM}}><span className="ae-spin">⟳</span></div>}
                {compareData && (
                  <div>
                    <label style={lbl}>Settings Diff</label>
                    <div style={{border:`1px solid ${BOR}`,borderRadius:8,overflow:'hidden'}}>
                      {[
                        {key:'category',label:'Category'},{key:'subject',label:'Subject'},{key:'type',label:'Exam Type'},
                        {key:'duration',label:'Duration'},{key:'totalMarks',label:'Total Marks'},{key:'batch',label:'Batch'},
                        {key:'seriesName',label:'Series'},{key:'status',label:'Status'}
                      ].map((f,i)=>{
                        const valA = compareData.examA[f.key] ?? '—'
                        const valB = compareData.examB[f.key] ?? '—'
                        const diff = String(valA)!==String(valB)
                        return (
                          <div key={f.key} style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',fontSize:10,padding:'7px 10px',background:diff?`${WRN}0C`:'transparent',borderTop:i>0?`1px solid ${BOR}`:'none'}}>
                            <span style={{color:DIM,fontWeight:700}}>{f.label}</span>
                            <span style={{color:diff?WRN:TS}}>{String(valA)}</span>
                            <span style={{color:diff?WRN:TS}}>{String(valB)}</span>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}
            <button onClick={()=>{setCloneInfoExam(null);setCompareData(null)}} style={{...bg_,width:'100%',marginTop:16}}>Close</button>
          </div>
        </div>
      )}

      {/* ══ QUICK EDIT MODAL — 33.9 ═════════════════════════════════════════════ */}
      {editExam && (
        <div style={{position:'fixed' as any,inset:0,background:'rgba(0,4,14,0.7)',backdropFilter:'blur(4px)',zIndex:9200,display:'flex',alignItems:'flex-start',justifyContent:'center',padding:'76px 14px 20px',overflowY:'auto' as any}} onClick={()=>setEditExam(null)}>
          <div onClick={e=>e.stopPropagation()} style={{...cs,width:'100%',maxWidth:480,marginTop:10}}>
            <div style={{fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:16,color:TS,marginBottom:8}}>✏️ Edit Exam</div>
            {editExam.clonedFrom && (
              <div style={{fontSize:11,color:PRP,background:`${PRP}14`,border:`1px solid ${PRP}33`,borderRadius:8,padding:'8px 10px',marginBottom:14}}>
                🔗 This is a cloned exam (draft) — adjust the settings before publishing. To replace/edit questions, use the "Add Questions" / Question Bank flow (only settings can be edited here).
              </div>
            )}
            <div style={{display:'flex',flexDirection:'column' as any,gap:12}}>
              <div>
                <label style={lbl}>Title</label>
                <input value={editForm.title} onChange={e=>setEditForm((f:any)=>({...f,title:e.target.value}))} style={inp}/>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                <div><label style={lbl}>Duration (min)</label><input type="number" value={editForm.duration} onChange={e=>setEditForm((f:any)=>({...f,duration:parseInt(e.target.value)||0}))} style={inp}/></div>
                <div><label style={lbl}>Total Marks</label><input type="number" value={editForm.totalMarks} onChange={e=>setEditForm((f:any)=>({...f,totalMarks:parseInt(e.target.value)||0}))} style={inp}/></div>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                <div><label style={lbl}>Correct Marks</label><input type="number" value={editForm.correctMarks} onChange={e=>setEditForm((f:any)=>({...f,correctMarks:parseFloat(e.target.value)||0}))} style={inp}/></div>
                <div><label style={lbl}>Incorrect Marks</label><input type="number" value={editForm.incorrectMarks} onChange={e=>setEditForm((f:any)=>({...f,incorrectMarks:parseFloat(e.target.value)||0}))} style={inp}/></div>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                <div><label style={lbl}>Start Time</label><input type="datetime-local" value={editForm.startTime} onChange={e=>setEditForm((f:any)=>({...f,startTime:e.target.value}))} style={inp}/></div>
                <div><label style={lbl}>End Time</label><input type="datetime-local" value={editForm.endTime} onChange={e=>setEditForm((f:any)=>({...f,endTime:e.target.value}))} style={inp}/></div>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                <div>
                  <label style={lbl}>Batch</label>
                  <select value={editForm.batch} onChange={e=>setEditForm((f:any)=>({...f,batch:e.target.value}))} style={inp}>
                    <option value="">— Open / No Batch —</option>
                    {realBatches.map((b:any)=><option key={b._id} value={b.name}>{b.name}{b.status!=='active'?` (${b.status})`:''}</option>)}
                  </select>
                </div>
                <div>
                  <label style={lbl}>Test Series / Mini Series</label>
                  <input list="series-suggestions" value={editForm.seriesName} onChange={e=>setEditForm((f:any)=>({...f,seriesName:e.target.value}))} style={inp} placeholder="Leave blank, or pick/type a series name"/>
                </div>
              </div>
              <div>
                <label style={lbl}>Status</label>
                <select value={editForm.status} onChange={e=>setEditForm((f:any)=>({...f,status:e.target.value}))} style={inp}>
                  {STATUS_ORDER.map(s=><option key={s} value={s}>{STATUS_META[s].label}</option>)}
                </select>
              </div>
              <label style={{display:'flex',alignItems:'center',gap:7,fontSize:12,color:TS,cursor:'pointer'}}>
                <input type="checkbox" checked={editForm.watermark} onChange={e=>setEditForm((f:any)=>({...f,watermark:e.target.checked}))}/>
                Student Watermark
              </label>
              <div>
                <label style={lbl}>Custom Instructions</label>
                <textarea value={editForm.customInstructions} onChange={e=>setEditForm((f:any)=>({...f,customInstructions:e.target.value}))} rows={3} style={{...inp,resize:'vertical' as any}}/>
              </div>
            </div>
            <div style={{display:'flex',gap:10,marginTop:18}}>
              <button onClick={()=>setEditExam(null)} style={{...bg_,flex:1}}>Cancel</button>
              <button onClick={saveEdit} disabled={savingEdit} style={{...bpAcc,flex:1,opacity:savingEdit?0.7:1}}>{savingEdit?'Saving...':'Save Changes'}</button>
            </div>
          </div>
        </div>
      )}

      {/* ══ ANALYTICS SIDE PANEL — 33.14 ════════════════════════════════════════ */}
      {analyticsExam && (
        <div style={{position:'fixed' as any,inset:0,background:'rgba(0,4,14,0.6)',backdropFilter:'blur(3px)',zIndex:9220,display:'flex',justifyContent:'flex-end'}} onClick={()=>setAnalyticsExam(null)}>
          <div onClick={e=>e.stopPropagation()} style={{width:'100%',maxWidth:420,height:'100%',overflowY:'auto' as any,background:CRD,borderLeft:`1px solid ${BOR}`,padding:20,boxSizing:'border-box' as any}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:16}}>
              <div>
                <div style={{fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:16,color:TS}}>{analyticsExam.title}</div>
                <div style={{fontSize:11,color:DIM,marginTop:2}}>📈 Exam Analytics</div>
              </div>
              <button onClick={()=>setAnalyticsExam(null)} style={{background:'transparent',border:'none',color:DIM,fontSize:18,cursor:'pointer'}}>✕</button>
            </div>

            {analyticsLoading ? (
              <div style={{textAlign:'center' as any,padding:'40px 0',color:DIM}}><span className="ae-spin" style={{fontSize:22}}>⟳</span></div>
            ) : !analyticsData ? (
              <div style={{fontSize:12,color:DIM,textAlign:'center' as any,padding:'30px 0'}}>Analytics load nahi ho payi.</div>
            ) : (
              <div style={{display:'flex',flexDirection:'column' as any,gap:14}}>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
                  <div style={{background:'rgba(255,255,255,0.03)',borderRadius:10,padding:'12px',textAlign:'center' as any}}>
                    <div style={{fontSize:20,fontWeight:800,color:ACC}}>{analyticsData.totalAttempts}</div>
                    <div style={{fontSize:9,color:DIM,textTransform:'uppercase' as any,fontWeight:700}}>Attempts</div>
                  </div>
                  <div style={{background:'rgba(255,255,255,0.03)',borderRadius:10,padding:'12px',textAlign:'center' as any}}>
                    <div style={{fontSize:20,fontWeight:800,color:GOLD}}>{analyticsData.avgScore}</div>
                    <div style={{fontSize:9,color:DIM,textTransform:'uppercase' as any,fontWeight:700}}>Avg Score</div>
                  </div>
                  <div style={{background:'rgba(255,255,255,0.03)',borderRadius:10,padding:'12px',textAlign:'center' as any}}>
                    <div style={{fontSize:20,fontWeight:800,color:SUC}}>{analyticsData.passRate}%</div>
                    <div style={{fontSize:9,color:DIM,textTransform:'uppercase' as any,fontWeight:700}}>Pass Rate</div>
                  </div>
                  <div style={{background:'rgba(255,255,255,0.03)',borderRadius:10,padding:'12px',textAlign:'center' as any}}>
                    <div style={{fontSize:20,fontWeight:800,color:PRP}}>{analyticsData.completionRate}%</div>
                    <div style={{fontSize:9,color:DIM,textTransform:'uppercase' as any,fontWeight:700}}>Completion</div>
                  </div>
                </div>

                <div style={{display:'flex',gap:6,flexWrap:'wrap' as any}}>
                  <Chip ico="🔺" label={`Max: ${analyticsData.maxScore}`} col={SUC}/>
                  <Chip ico="🔻" label={`Min: ${analyticsData.minScore}`} col={DNG}/>
                  <Chip ico="✅" label={`Passed: ${analyticsData.passCount}`} col={SUC}/>
                  <Chip ico="❓" label={`${analyticsData.exam?.questionCount||0} Qs`} col={DIM}/>
                </div>

                {analyticsData.scoreDistribution?.length>0 && (
                  <div>
                    <div style={{fontSize:11,fontWeight:700,color:TS,marginBottom:8}}>Score Distribution</div>
                    <div style={{display:'flex',gap:4,alignItems:'flex-end',height:60}}>
                      {analyticsData.scoreDistribution.map((b:any,i:number)=>{
                        const maxC = Math.max(...analyticsData.scoreDistribution.map((x:any)=>x.count),1)
                        return <div key={i} style={{flex:1,background:`linear-gradient(180deg,${ACC},${PRP})`,borderRadius:'4px 4px 0 0',height:`${Math.max((b.count/maxC)*100,4)}%`}} title={`${b.count} students`}/>
                      })}
                    </div>
                  </div>
                )}

                <div>
                  <div style={{fontSize:11,fontWeight:700,color:TS,marginBottom:8}}>🏆 Leaderboard (Top 10)</div>
                  {(!analyticsData.leaderboard || analyticsData.leaderboard.length===0) ? (
                    <div style={{fontSize:11,color:DIM}}>No attempts yet.</div>
                  ) : (
                    <div style={{display:'flex',flexDirection:'column' as any,gap:6}}>
                      {analyticsData.leaderboard.map((l:any,i:number)=>(
                        <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'7px 10px',background:'rgba(255,255,255,0.03)',borderRadius:8,fontSize:11}}>
                          <span style={{color:TS}}>{i===0?'🥇':i===1?'🥈':i===2?'🥉':`#${i+1}`} {l.studentName||l.studentEmail||'Student'}</span>
                          <span style={{color:GOLD,fontWeight:700}}>{l.score}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ══ PREVIEW EXAM — content/option rendering check (no attempt created) ══ */}
      {previewExam && (
        <div style={{position:'fixed' as any,inset:0,background:'rgba(0,4,14,0.85)',backdropFilter:'blur(4px)',zIndex:9230,display:'flex',flexDirection:'column' as any}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'14px 18px',borderBottom:`1px solid ${BOR}`,background:CRD,flexShrink:0,gap:10}}>
            <div style={{minWidth:0}}>
              <div style={{fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:15,color:TS,overflow:'hidden',whiteSpace:'nowrap' as any,textOverflow:'ellipsis'}}>👁 {previewExam.title}</div>
              <div style={{fontSize:10,color:DIM,marginTop:2}}>Same content view as students see — read-only, no attempt record is created</div>
            </div>
            <div style={{display:'flex',alignItems:'center',gap:8,flexShrink:0}}>
              {previewQuestions.some((q:any)=>q.hindiText || (q.hindiOptions&&q.hindiOptions.length>0)) && (
                <div style={{display:'flex',background:'rgba(255,255,255,0.04)',borderRadius:8,border:`1px solid ${BOR}`,padding:2}}>
                  <button onClick={()=>setPreviewLang('en')} style={{background:previewLang==='en'?`${ACC}33`:'transparent',border:'none',color:previewLang==='en'?TS:DIM,borderRadius:6,padding:'5px 10px',cursor:'pointer',fontSize:11,fontWeight:700}}>EN</button>
                  <button onClick={()=>setPreviewLang('hi')} style={{background:previewLang==='hi'?`${ACC}33`:'transparent',border:'none',color:previewLang==='hi'?TS:DIM,borderRadius:6,padding:'5px 10px',cursor:'pointer',fontSize:11,fontWeight:700}}>हिं</button>
                </div>
              )}
              {previewExam.status!=='live' && (
                <button onClick={()=>{const ex=previewExam; setPreviewExam(null); openDeleteModal(ex)}} title="Delete this exam" style={{...bg_,padding:'6px 10px',fontSize:13,color:DNG,borderColor:`${DNG}33`}}>🗑️</button>
              )}
              <button onClick={()=>setPreviewExam(null)} style={{background:'transparent',border:'none',color:DIM,fontSize:20,cursor:'pointer'}}>✕</button>
            </div>
          </div>

          <div style={{flex:1,overflowY:'auto' as any,padding:'16px',boxSizing:'border-box' as any}}>
            {previewLoading ? (
              <div style={{textAlign:'center' as any,padding:'60px 0',color:DIM}}><span className="ae-spin" style={{fontSize:24}}>⟳</span><div style={{marginTop:10,fontSize:12}}>Questions load ho rahe hain...</div></div>
            ) : previewQuestions.length===0 ? (
              <div style={{...cs,textAlign:'center' as any,padding:'40px 20px'}}>
                <div style={{fontSize:40,marginBottom:10}}>❓</div>
                <div style={{fontSize:13,color:TS,fontWeight:700,marginBottom:4}}>This exam has no questions</div>
                <div style={{fontSize:11,color:DIM}}>Step 2 (Add Questions) probably hasn't been completed yet.</div>
              </div>
            ) : (
              <div style={{display:'flex',flexDirection:'column' as any,gap:12,maxWidth:680,margin:'0 auto'}}>
                {previewQuestions.map((q:any,qi:number)=>{
                  const qid = String(q._id||qi)
                  const showHindi = previewLang==='hi'
                  const hasHindiQ = !!q.hindiText
                  const hasHindiOpts = !!(q.hindiOptions && q.hindiOptions.length>0)
                  const qTextEn = q.questionText || q.text || q.question || q.title || '(Question text missing — render issue!)'
                  const qText = (showHindi && hasHindiQ) ? q.hindiText : qTextEn
                  const opts = q.options || q.choices || []
                  const correctRaw = q.correct ?? q.correctAnswer ?? q.correctOption ?? q.answer
                  const isCorrect = (idx:number, letter:string) => {
                    if(Array.isArray(correctRaw)) return correctRaw.includes(idx) || correctRaw.includes(letter)
                    if(typeof correctRaw==='number') return correctRaw===idx
                    if(typeof correctRaw==='string') return correctRaw.toUpperCase()===letter || correctRaw===String(idx)
                    return false
                  }
                  const missingOpts = !opts || opts.length===0
                  const explanation = q.explanation || q.solution || q.explanationText || q.answerExplanation || q.detailedSolution
                  const hindiExplanation = q.hindiExplanation || q.explanationHindi
                  const explainShown = !!expandedExplain[qid]
                  return (
                    <div key={qid} style={{...cs,padding:'14px 16px',borderLeft:`3px solid ${missingOpts?DNG:ACC}`}}>
                      <div style={{display:'flex',gap:6,alignItems:'center',marginBottom:8,flexWrap:'wrap' as any}}>
                        <span style={{fontFamily:'Playfair Display,serif',fontWeight:700,fontSize:13,color:TS}}>Q{qi+1}</span>
                        {q.subject && <Chip ico="📚" label={q.subject} col={PRP}/>}
                        {q.difficulty && <Chip ico="🎯" label={q.difficulty} col={WRN}/>}
                        {q.type && <Chip ico="📝" label={q.type} col={ACC}/>}
                        {missingOpts && <Chip ico="⚠️" label="No options found!" col={DNG}/>}
                      </div>
                      <div style={{fontSize:13,color:TS,lineHeight:1.6,marginBottom:6}}>{qText}</div>
                      {showHindi && !hasHindiQ && <div style={{fontSize:9,color:'#818CF8',marginBottom:8}}>हिंदी अनुवाद उपलब्ध नहीं — अंग्रेज़ी दिखाया जा रहा है</div>}
                      {!missingOpts && (
                        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6,marginBottom:explanation?10:0}}>
                          {opts.map((opt:any,oi:number)=>{
                            const letter = String.fromCharCode(65+oi)
                            const correct = isCorrect(oi,letter)
                            const optTextEn = typeof opt==='string' ? opt : (opt?.text||opt?.label||JSON.stringify(opt))
                            const optText = (showHindi && hasHindiOpts && q.hindiOptions[oi]) ? q.hindiOptions[oi] : optTextEn
                            return (
                              <div key={oi} style={{padding:'7px 10px',borderRadius:8,fontSize:11,border:`1px solid ${correct?`${SUC}55`:BOR}`,background:correct?`${SUC}10`:'rgba(255,255,255,0.02)',color:correct?SUC:'#CBD5E1'}}>
                                <b style={{marginRight:4}}>{letter}.</b>{optText} {correct?'✓':''}
                              </div>
                            )
                          })}
                        </div>
                      )}
                      {explanation && (
                        <div>
                          <button onClick={()=>toggleExplain(qid)} style={{...bg_,fontSize:10,padding:'5px 11px',color:GOLD,borderColor:`${GOLD}33`}}>
                            {explainShown?'🔼 Hide Explanation':'💡 Show Explanation'}
                          </button>
                          {explainShown && (
                            <div style={{marginTop:8,padding:'10px 12px',background:`${GOLD}0C`,border:`1px solid ${GOLD}33`,borderRadius:8,fontSize:11,color:'#FDE68A',lineHeight:1.6}}>
                              {(showHindi && hindiExplanation) ? hindiExplanation : explanation}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

// ── 33.15 — Calendar month grid ────────────────────────────────────────────────
function CalendarGrid({month,exams,onDayClick,onExamClick}:{month:Date;exams:any[];onDayClick:(d:Date)=>void;onExamClick:(e:any)=>void}){
  const year = month.getFullYear(), mon = month.getMonth()
  const firstDay = new Date(year,mon,1).getDay()
  const daysInMonth = new Date(year,mon+1,0).getDate()
  const cells: (number|null)[] = []
  for(let i=0;i<firstDay;i++) cells.push(null)
  for(let d=1;d<=daysInMonth;d++) cells.push(d)
  while(cells.length%7!==0) cells.push(null)

  const examsByDay: Record<number,any[]> = {}
  exams.forEach(e=>{
    const dt = e.schedule?.startTime ? new Date(e.schedule.startTime) : null
    if(dt && dt.getFullYear()===year && dt.getMonth()===mon){
      const day = dt.getDate()
      if(!examsByDay[day]) examsByDay[day]=[]
      examsByDay[day].push(e)
    }
  })

  const todayStr = new Date().toDateString()

  return (
    <div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:4,marginBottom:6}}>
        {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d=>(
          <div key={d} style={{textAlign:'center' as any,fontSize:10,fontWeight:700,color:DIM,padding:'4px 0'}}>{d}</div>
        ))}
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:4}}>
        {cells.map((d,i)=>{
          if(d===null) return <div key={i}/>
          const dayExams = examsByDay[d]||[]
          const dateObj = new Date(year,mon,d)
          const isToday = dateObj.toDateString()===todayStr
          return (
            <div key={i} onClick={()=>onDayClick(dateObj)} style={{minHeight:64,borderRadius:8,padding:'5px 4px',background:isToday?`${ACC}14`:'rgba(255,255,255,0.02)',border:`1px solid ${isToday?ACC:BOR}`,cursor:'pointer',overflow:'hidden'}}>
              <div style={{fontSize:10,fontWeight:isToday?800:600,color:isToday?ACC:DIM,marginBottom:3}}>{d}</div>
              {dayExams.slice(0,2).map((e:any,idx:number)=>{
                const meta = STATUS_META[e.status]||STATUS_META.draft
                return (
                  <div key={idx} onClick={(ev:any)=>{ev.stopPropagation();onExamClick(e)}} title={e.title} style={{fontSize:8,color:meta.color,background:`${meta.color}1A`,borderRadius:4,padding:'1px 4px',marginBottom:2,overflow:'hidden',whiteSpace:'nowrap' as any,textOverflow:'ellipsis'}}>
                    {e.title}
                  </div>
                )
              })}
              {dayExams.length>2 && <div style={{fontSize:8,color:DIM}}>+{dayExams.length-2} more</div>}
            </div>
          )
        })}
      </div>
    </div>
  )
}
