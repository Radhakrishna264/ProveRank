'use client';
import * as React from 'react';
import { useState, useEffect, useRef, useCallback } from 'react';

// ═══ Types ═══
interface ParsedQ {
  id: string;
  num: number;
  text: string;
  hindiText: string;
  options: string[];
  hindiOptions: string[];
  correct: number[];
  correctLetter: string;
  explanation: string;
  hasError: boolean;
  error: string;
  subject?: string;
  chapter?: string;
  difficulty?: string;
  type?: string;
  imageUrl?: string;
  optionImages?: string[];
  isDuplicateInDB?: boolean;
  isDuplicateInFile?: boolean;
  isDuplicate?: boolean;
  needsReview?: boolean;
  confidencePct?: number;
  page?: number | null;
}

type View =
  | 'home'
  | 'cp_home' | 'cp_qs' | 'cp_exam'
  | 'ex_home' | 'ex_qs' | 'ex_exam'
  | 'pdf_home' | 'pdf_qs' | 'pdf_exam';

// Shared state shapes used across all 3 "Create Exam" wizards (19B / 20B / 21B)
interface SubjectCount { subject: string; count: number; }

interface ExamDetailsState {
  title: string;
  subjects: string[];     // multi-select (was single string) — admin can run multi-subject tests
  category: string;       // Full Mock / Chapter Test / Part Test / Grand Test / Mini Test
  examType: string;       // NEET / JEE / Custom
  duration: number;       // minutes — field name MUST be "duration"
  totalMarks: number;
  correctMarks: number;
  negativeMarks: number;
  startTime: string;
  endTime: string;
  resultDateTime: string; // when result/scorecard becomes visible to students
  customInstructions: string;
  passwordEnabled: boolean;
  password: string;
  waitingRoomEnabled: boolean;
  waitingRoomMinutes: number;
  reattemptCount: 'best' | 'last';
  unlimitedAttempts: boolean;
  maxAttempts: number;
  sectionWiseEnabled: boolean;
  watermark: boolean;
  totalQuestionsRequested: number;
  subjectWiseCount: SubjectCount[];
}

interface AssignmentState {
  assignmentType: 'batch' | 'series' | 'individual';
  batch: string;
  multiBatchEnabled: boolean;
  multiBatch: string[];
  testSeriesId: string;
  notifyStudents: boolean;
}

interface PostCreateState {
  scheduledPublishEnabled: boolean;
  publishAt: string;
  isTemplate: boolean;
  publishNow: boolean; // if true -> status sent as live/scheduled via /publish after create
}

function defaultExamDetails(): ExamDetailsState {
  return {
    title: '', subjects: [], category: 'Full Mock', examType: 'NEET',
    duration: 180, totalMarks: 720, correctMarks: 4, negativeMarks: -1,
    startTime: '', endTime: '', resultDateTime: '', customInstructions: '',
    passwordEnabled: false, password: '',
    waitingRoomEnabled: false, waitingRoomMinutes: 10,
    reattemptCount: 'last', unlimitedAttempts: true, maxAttempts: 1, // unlimited attempts ON by default
    sectionWiseEnabled: true, watermark: true,
    totalQuestionsRequested: 0, subjectWiseCount: [],
  };
}
function defaultAssignment(): AssignmentState {
  return { assignmentType: 'individual', batch: '', multiBatchEnabled: false, multiBatch: [], testSeriesId: '', notifyStudents: false };
}
function defaultPostCreate(): PostCreateState {
  return { scheduledPublishEnabled: false, publishAt: '', isTemplate: false, publishNow: false };
}

// ═══ Design Constants ═══
const C = {
  acc:   '#4D9FFF',
  gold:  '#F59E0B',
  suc:   '#00C48C',
  err:   '#FF4D4D',
  wrn:   '#FFB84D',
  ts:    '#E8F4FF',
  dim:   '#6B8FAF',
  card:  'rgba(0,22,40,0.8)',
  bor:   'rgba(77,159,255,0.15)',
  purple:'#A78BFA',
  green: '#00C48C',
  pink:  '#F472B6',
};
const S = {
  card: { background:C.card, border:`1px solid ${C.bor}`, borderRadius:16, padding:20, backdropFilter:'blur(12px)', marginBottom:14 } as React.CSSProperties,
  bp:   { background:`linear-gradient(135deg,${C.acc},#0055CC)`, color:'#fff', border:'none', borderRadius:10, padding:'10px 20px', fontWeight:700, fontSize:13, cursor:'pointer', boxShadow:'0 4px 16px rgba(77,159,255,0.3)' } as React.CSSProperties,
  bg:   { background:'rgba(77,159,255,0.1)', color:C.acc, border:`1px solid ${C.bor}`, borderRadius:10, padding:'8px 16px', fontSize:12, cursor:'pointer', fontWeight:600 } as React.CSSProperties,
  bs:   { background:'linear-gradient(135deg,#00C48C,#00955E)', color:'#fff', border:'none', borderRadius:10, padding:'10px 20px', fontWeight:700, fontSize:13, cursor:'pointer' } as React.CSSProperties,
  inp:  { width:'100%', padding:'10px 12px', background:'rgba(0,22,40,0.85)', border:`1.5px solid ${C.bor}`, borderRadius:10, color:C.ts, fontSize:12, outline:'none', boxSizing:'border-box' as const, fontFamily:'Inter,monospace', resize:'vertical' as const },
  lbl:  { fontSize:10, color:C.dim, fontWeight:700, letterSpacing:'0.5px', textTransform:'uppercase' as const, display:'block', marginBottom:5 },
  toggle:(on:boolean)=>({ width:38, height:21, borderRadius:11, background:on?C.acc:'rgba(107,143,175,0.25)', position:'relative' as const, cursor:'pointer', transition:'all 0.2s', flexShrink:0 }),
  toggleDot:(on:boolean)=>({ width:16, height:16, borderRadius:'50%', background:'#fff', position:'absolute' as const, top:2.5, left:on?19:3, transition:'all 0.2s', boxShadow:'0 1px 3px rgba(0,0,0,0.4)' }),
};

function Toggle({ on, onClick, label }: { on:boolean; onClick:()=>void; label?:string }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer' }} onClick={onClick}>
      <div style={S.toggle(on)}><div style={S.toggleDot(on)} /></div>
      {label && <span style={{ fontSize:11, color:C.dim }}>{label}</span>}
    </div>
  );
}

// Mobile/desktop responsive layout switch (inline-style based, no CSS media queries available)
function useIsMobile(): boolean {
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 860);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);
  return isMobile;
}

function PageHero({ icon, title, subtitle, badge }: { icon:string; title:string; subtitle:string; badge?:string }) {
  return (
    <div style={{ marginBottom:20 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
        <span style={{ fontSize:22 }}>{icon}</span>
        <span style={{ fontSize:19, fontWeight:800, background:`linear-gradient(135deg,${C.acc},${C.purple})`, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>{title}</span>
        {badge && <span style={{ fontSize:10, padding:'3px 10px', borderRadius:20, background:'rgba(167,139,250,0.15)', border:'1px solid rgba(167,139,250,0.35)', color:C.purple, fontWeight:700 }}>{badge}</span>}
      </div>
      <div style={{ fontSize:12, color:C.dim, marginTop:4 }}>{subtitle}</div>
    </div>
  );
}

// F19B.36 / F20B.44 / F21B.31 — LaTeX/KaTeX rendering for question text & options.
// Self-contained (doesn't depend on an external renderLatex.ts import path) so it
// can never break the build even if that sibling file moves/renames.
function renderMath(text: string): string {
  if (!text) return '';
  let html = text.replace(/\$\$([^$]+)\$\$/g, (_, m) => {
    try { return (window as any).katex ? (window as any).katex.renderToString(m, { displayMode:true, throwOnError:false }) : m; }
    catch { return m; }
  });
  html = html.replace(/\$([^\n$]+)\$/g, (_, m) => {
    try { return (window as any).katex ? (window as any).katex.renderToString(m, { displayMode:false, throwOnError:false }) : m; }
    catch { return m; }
  });
  return html;
}
function MathText({ text, style }: { text:string; style?:React.CSSProperties }) {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    if ((window as any).katex) { setReady(true); return; }
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.js';
    script.onload = () => setReady(true);
    document.head.appendChild(script);
    if (!document.getElementById('katex-css')) {
      const link = document.createElement('link');
      link.id = 'katex-css'; link.rel = 'stylesheet';
      link.href = 'https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.css';
      document.head.appendChild(link);
    }
  }, []);
  const hasMath = /\$[^$]+\$/.test(text);
  if (!hasMath) return <span style={style}>{text}</span>;
  return <span style={style} dangerouslySetInnerHTML={{ __html: ready ? renderMath(text) : text }} />;
}

// ═══════════════════════════════════════════════════════
// COPY-PASTE PARSING ENGINE (Feature 19 — reused as-is for 19B)
// ═══════════════════════════════════════════════════════
function smartClean(text: string): string {
  return text
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/\*(.+?)\*/g, '$1')
    .replace(/_{2}(.+?)_{2}/g, '$1')
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function parseAnswerKey(text: string): Record<number, string> {
  const map: Record<number, string> = {};
  if (!text.trim()) return map;
  const lines = text.trim().split('\n').map(l => l.trim()).filter(Boolean);

  // Try the flexible "Q1-A, Q2-(A,B,D), Q3-96" global format FIRST (handles both
  // single-line combined AND multi-line "1. A" style, since it scans the whole text).
  const combined = lines.join(' ');
  const matches = combined.matchAll(/Q?\s*(\d+)\s*[\-\:\.\)]\s*\(?([A-Da-d,\s]+|\-?\d+\.?\d*)\)?/gi);
  for (const m of matches) map[parseInt(m[1])] = m[2].trim().toUpperCase();
  if (Object.keys(map).length > 0) return map;

  // Fallback formats (only reached if the flexible format found nothing):
  if (lines.every(l => l.match(/^[A-Da-d]$/))) {
    lines.forEach((l, i) => { map[i + 1] = l.toUpperCase(); });
    return map;
  }
  if (lines.length === 1 && lines[0].match(/^[A-Da-d]+$/)) {
    lines[0].split('').forEach((ch, i) => { map[i + 1] = ch.toUpperCase(); });
    return map;
  }
  lines.forEach((l, i) => {
    const m = l.match(/([A-Da-d])/);
    if (m) map[i + 1] = m[1].toUpperCase();
  });
  return map;
}

// F19B.2.4 / F19B.2.5 — parse SCQ letter(s) / MSQ combo / Integer numeric from the raw answer-key token
function parseAnswerToken(raw: string): { type:'SCQ'|'MSQ'|'Integer'; letters:string[]; numeric?:number } {
  const val = (raw || '').trim();
  const letters = [...new Set((val.toUpperCase().match(/[A-D]/g) || []))];
  if (letters.length >= 2) return { type:'MSQ', letters };
  if (letters.length === 1 && !/^\-?\d+\.?\d*$/.test(val)) return { type:'SCQ', letters };
  const num = parseFloat(val);
  if (!isNaN(num)) return { type:'Integer', letters:[], numeric:num };
  return { type:'SCQ', letters };
}

function parseExplanations(text: string): { map: Record<number, string>; arr: string[] } {
  const map: Record<number, string> = {};
  var arr: string[] = [];
  if (!text.trim()) return { map, arr };
  const blocks = text.split(/(?=(?:^|\n)\s*Q?\d+[\.\)\:\-\s])/im);
  var foundAny = false;
  blocks.forEach(block => {
    const m = block.trim().match(/^Q?\s*(\d+)[\.\)\:\-\s]+(.+)/is);
    if (m) { map[parseInt(m[1])] = m[2].trim(); foundAny = true; }
  });
  if (!foundAny) {
    arr = text.split(/\n{2,}/).map(s => s.trim()).filter(Boolean);
  }
  return { map, arr };
}

// F19B.4.5 / F20B.4.5 / F21B.7.5 — reorder helper (up/down arrows), shared by all 3 preview lists
function moveQuestion<T>(arr: T[], idx: number, dir: 'up'|'down'): T[] {
  const newIdx = dir==='up' ? idx-1 : idx+1;
  if (newIdx < 0 || newIdx >= arr.length) return arr;
  const copy = [...arr];
  [copy[idx], copy[newIdx]] = [copy[newIdx], copy[idx]];
  return copy;
}

// F19B.9B — lightweight difficulty auto-tag heuristic (mirrors backend excelParser.guessDifficulty)
function guessDifficultyClient(text: string): string {
  const t = (text || '').toLowerCase();
  if (t.match(/calculate|derive|prove|evaluate|analyse|mechanism|complex/)) return 'Hard';
  if (t.match(/define|what is|name|which|identify|state/)) return 'Easy';
  return 'Medium';
}

function detectDelimiter(text: string): string | null {
  const delimiters = ['---', '***', '===', '###', '///'];
  for (const d of delimiters) {
    if (text.includes(d)) return d;
  }
  return null;
}

function splitIntoBlocks(text: string, customDelim?: string): string[] {
  if (customDelim && text.includes(customDelim)) {
    return text.split(customDelim).map(s => s.trim()).filter(Boolean);
  }
  const patterns = [
    { re: /(?=(?:^|\n)\s*Q\s*\.?\s*\d+[\s\.\)\:\-])/im, name: 'Q-number' },
    { re: /(?=(?:^|\n)\s*\*\*\s*Q?\d+[\s\.\)\:\-])/m,   name: 'WhatsApp-bold' },
    { re: /(?=(?:^|\n)\s*\d+[\.\)\:\-\s])/m,             name: 'numbered' },
    { re: /(?=(?:^|\n)\s*[ivxlc]+[\.\)\:\-\s])/im,       name: 'roman' },
  ];
  for (const p of patterns) {
    if (p.re.test(text)) {
      const blocks = text.split(p.re).map(s => s.trim()).filter(Boolean);
      if (blocks.length > 1) return blocks;
    }
  }
  return text.split(/\n{2,}/).map(s => s.trim()).filter(Boolean);
}

function parseOneBlock(block: string, idx: number): Omit<ParsedQ, 'id'|'hindiText'|'hindiOptions'|'explanation'|'correctLetter'|'correct'|'hasError'|'error'> {
  const lines = block.split('\n').map(l => l.trim()).filter(Boolean);
  const numMatch = lines[0]?.match(/^(?:\*{1,2})?\s*Q?\s*(\d+)[\s\.\)\:\-](?:\*{1,2})?/i);
  const qNum = numMatch ? parseInt(numMatch[1]) : idx + 1;
  let qText = lines[0]?.replace(/^(?:\*{1,2})?\s*Q?\s*\d+[\s\.\)\:\-](?:\*{1,2})?\s*/i, '').replace(/\*\*/g,'').trim() || '';
  let i = 1;
  while (i < lines.length) {
    const l = lines[i];
    if (l.match(/^(?:\*{1,2})?\s*[\(\[]?[A-Da-d][\)\]\.\:\-\s]/)) break;
    qText += ' ' + l.replace(/\*\*/g,'');
    i++;
  }
  const options: string[] = [];
  while (i < lines.length) {
    const l = lines[i];
    const m = l.match(/^(?:\*{1,2})?\s*[\(\[]?\s*([A-Da-d])\s*[\)\]\.\:\-\s]+(?:\*{1,2})?\s*(.+)/i);
    if (m) { options.push(m[2].replace(/\*\*/g,'').trim()); }
    i++;
  }
  return { num: qNum, text: qText.trim(), options, subject:undefined, chapter:undefined, difficulty:undefined, type:undefined };
}

function parseHindiBlocks(hindiText: string, customDelim?: string): { map: Record<number, { text:string; options:string[] }>; arr: { text:string; options:string[] }[] } {
  const map: Record<number, { text:string; options:string[] }> = {};
  const arr: { text:string; options:string[] }[] = [];
  if (!hindiText.trim()) return { map, arr };
  const blocks = splitIntoBlocks(hindiText, customDelim);
  blocks.forEach((block, idx) => {
    const parsed = parseOneBlock(block, idx);
    const entry = { text: parsed.text, options: parsed.options };
    map[parsed.num] = entry;
    arr.push(entry);
  });
  return { map, arr };
}

function parseAll(engText: string, hindiText: string, ansKeyText: string, explText: string, customDelim: string): ParsedQ[] {
  if (!engText.trim()) return [];
  const delim = customDelim || detectDelimiter(engText) || undefined;
  const blocks = splitIntoBlocks(engText, delim);
  const ansMap  = parseAnswerKey(ansKeyText);
  const explResult = parseExplanations(explText);
  const explMap = explResult.map;
  const explArr = explResult.arr;
  const hindiResult = parseHindiBlocks(hindiText, delim);
  const hindiMap = hindiResult.map;
  const hindiArr = hindiResult.arr;

  return blocks.map((block, idx) => {
    const base = parseOneBlock(block, idx);
    const hindi = hindiMap[base.num] || hindiArr[idx] || { text:'', options:[] };
    const ansRaw = ansMap[base.num] || '';
    const parsedAns = parseAnswerToken(ansRaw);
    let correct: number[] = [];
    let correctLetter = '';
    if (parsedAns.type === 'Integer' && parsedAns.numeric !== undefined) {
      correct = [parsedAns.numeric];
    } else {
      correct = parsedAns.letters.map(l => ['A','B','C','D'].indexOf(l)).filter(i => i >= 0);
      correctLetter = parsedAns.letters.join(',');
    }
    const hasEngOpts = base.options.length >= 2 || parsedAns.type === 'Integer';
    const hasAns = correct.length > 0;
    const errors: string[] = [];
    if (!base.text) errors.push('English text missing');
    if (!hasEngOpts) errors.push('Options not detected (<2)');
    if (!hasAns) errors.push(`Answer missing for Q${base.num}`);
    return {
      id:           'q_'+base.num+'_'+idx,
      num:          base.num,
      text:         base.text,
      hindiText:    hindi.text,
      options:      base.options,
      hindiOptions: hindi.options,
      correct,
      correctLetter,
      explanation:  explMap[base.num] || explArr[idx] || '',
      hasError:     errors.length > 0,
      error:        errors.join('; '),
      type:         parsedAns.type,
      difficulty:   guessDifficultyClient(base.text), // F19B.9B auto-tag (admin can still override in edit modal)
    };
  }).sort((a,b) => a.num - b.num);
}
// ═══════════════════════════════════════════════════════
// SHARED — Exam Details Form (Step used by 19B.5 / 20B.5 / 21B.8)
// ═══════════════════════════════════════════════════════
function ExamDetailsForm({ d, setD, totalParsed, detectedSubjects }: { d:ExamDetailsState; setD:React.Dispatch<React.SetStateAction<ExamDetailsState>>; totalParsed:number; detectedSubjects:string[] }) {
  const upd = (patch: Partial<ExamDetailsState>) => setD(prev => ({ ...prev, ...patch }));

  // F19B.5.29 / F20B.5.37 — subject color bars
  const subjectColor = (s:string) => ({ Physics:'#4D9FFF', Chemistry:'#F472B6', Biology:'#00C48C', Math:'#A78BFA', Zoology:'#22D3EE', Botany:'#84CC16' } as Record<string,string>)[s] || '#94A3B8';

  // Multi-select subject: list = whatever was actually detected/allotted in the parsed content
  // (paste subject-allotment text / Excel Subject column / PDF subject-range map) — NOT a static list.
  const availableSubjects = detectedSubjects.length > 0 ? detectedSubjects : ['Physics','Chemistry','Biology','Math'];
  const toggleSubject = (s:string) => {
    const next = d.subjects.includes(s) ? d.subjects.filter(x=>x!==s) : [...d.subjects, s];
    syncDistribution(next);
  };

  // Subject-wise distribution is COMPULSORY once subjects are chosen — rows are
  // auto-synced to exactly match the selected subjects (admin only edits counts).
  const syncDistribution = (subjList: string[]) => {
    const existing: Record<string,number> = {};
    d.subjectWiseCount.forEach(r => { existing[r.subject] = r.count; });
    const newRows = subjList.map(s => ({ subject: s, count: existing[s] ?? 0 }));
    upd({ subjects: subjList, subjectWiseCount: newRows });
  };
  const updSubjectRowCount = (i:number, count:number) => {
    const arr = [...d.subjectWiseCount]; arr[i] = { ...arr[i], count }; upd({ subjectWiseCount: arr });
  };
  const distributedTotal = d.subjectWiseCount.reduce((s,r)=>s+(r.count||0),0);

  return (
    <div style={{ ...S.card }}>
      <div style={{ fontSize:13, fontWeight:800, color:C.ts, marginBottom:14 }}>📝 Step — Exam Details</div>

      <div style={{ marginBottom:10 }}>
        <label style={S.lbl}>Exam Title *</label>
        <input value={d.title} onChange={e=>upd({title:e.target.value})} placeholder="e.g. NEET Weekly Grand Test #12" style={S.inp} />
      </div>

      {/* Multi-select subject chips — populated from detected/allotted subjects only */}
      <div style={{ marginBottom:10 }}>
        <label style={S.lbl}>Subject(s) * — tap to select one or more</label>
        <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
          {availableSubjects.map(s=>(
            <span key={s} onClick={()=>toggleSubject(s)} style={{
              padding:'6px 12px', borderRadius:20, cursor:'pointer', fontSize:11, fontWeight:700,
              border:`1.5px solid ${d.subjects.includes(s)?subjectColor(s):C.bor}`,
              background:d.subjects.includes(s)?`${subjectColor(s)}22`:'rgba(0,22,40,0.5)',
              color:d.subjects.includes(s)?subjectColor(s):C.dim,
            }}>{d.subjects.includes(s)?'✓ ':''}{s}</span>
          ))}
        </div>
        {detectedSubjects.length === 0 && <div style={{ fontSize:10, color:C.dim, marginTop:4 }}>Paste/upload questions first — subjects will appear here automatically.</div>}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:10 }}>
        <div>
          <label style={S.lbl}>Category</label>
          <select value={d.category} onChange={e=>upd({category:e.target.value})} style={S.inp}>
            {['Full Mock','Chapter Test','Part Test','Grand Test','Mini Test'].map(s=><option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div>
          <label style={S.lbl}>Exam Format</label>
          <select value={d.examType} onChange={e=>upd({examType:e.target.value})} style={S.inp}>
            {['NEET','JEE','Custom'].map(s=><option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:10 }}>
        <div>
          <label style={S.lbl}>Total Questions for this Exam (of {totalParsed} parsed)</label>
          <input type="number" value={d.totalQuestionsRequested||''} onChange={e=>upd({totalQuestionsRequested:parseInt(e.target.value)||0})} placeholder={`Leave blank to use all ${totalParsed}`} style={S.inp} />
        </div>
        <div>
          <label style={S.lbl}>Duration (minutes)</label>
          <div style={{ display:'flex', gap:8, alignItems:'center' }}>
            <input type="range" min={10} max={360} step={5} value={d.duration} onChange={e=>upd({duration:parseInt(e.target.value)})} style={{ flex:1 }} />
            <input type="number" value={d.duration} onChange={e=>upd({duration:parseInt(e.target.value)||0})} style={{ ...S.inp, width:70 }} />
          </div>
        </div>
      </div>

      {/* Subject-wise Qs count — COMPULSORY, auto-synced from selected subjects above */}
      <div style={{ marginBottom:10, padding:'10px 12px', background:'rgba(0,22,40,0.5)', borderRadius:10, border:`1px solid ${d.subjects.length===0?'rgba(255,77,77,0.4)':C.bor}` }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
          <label style={{ ...S.lbl, marginBottom:0 }}>Subject-wise Question Distribution * (required)</label>
          <span style={{ fontSize:10, color:distributedTotal===(d.totalQuestionsRequested||totalParsed)?C.suc:C.gold }}>{distributedTotal} / {d.totalQuestionsRequested||totalParsed} allocated</span>
        </div>
        {d.subjects.length === 0 && <div style={{ fontSize:11, color:C.err }}>⚠️ Select at least one subject above first</div>}
        {d.subjectWiseCount.map((row,i)=>(
          <div key={row.subject} style={{ display:'flex', gap:6, marginBottom:6, alignItems:'center' }}>
            <span style={{ width:6, height:18, borderRadius:3, background:subjectColor(row.subject), flexShrink:0 }} />
            <span style={{ fontSize:11, color:C.ts, flex:2 }}>{row.subject}</span>
            <input type="number" value={row.count} onChange={e=>updSubjectRowCount(i,parseInt(e.target.value)||0)} placeholder="Qs count" style={{ ...S.inp, flex:1 }} />
          </div>
        ))}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:10 }}>
        <div>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <label style={{ ...S.lbl, marginBottom:0 }}>Total Marks</label>
            <button onClick={()=>upd({totalMarks:(d.totalQuestionsRequested||totalParsed)*d.correctMarks})} style={{ fontSize:9, color:C.acc, background:'transparent', border:'none', cursor:'pointer' }}>⚡ Auto-calc</button>
          </div>
          <input type="number" value={d.totalMarks} onChange={e=>upd({totalMarks:parseInt(e.target.value)||0})} style={S.inp} />
        </div>
        <div />
        <div>
          <label style={S.lbl}>Correct Marks</label>
          <input type="number" value={d.correctMarks} onChange={e=>upd({correctMarks:parseFloat(e.target.value)||0})} style={S.inp} />
        </div>
        <div>
          <label style={S.lbl}>Negative Marks</label>
          <input type="number" value={d.negativeMarks} onChange={e=>upd({negativeMarks:parseFloat(e.target.value)||0})} style={S.inp} />
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:10 }}>
        <div>
          <label style={S.lbl}>Start Date & Time</label>
          <input type="datetime-local" value={d.startTime} onChange={e=>upd({startTime:e.target.value})} style={S.inp} />
        </div>
        <div>
          <label style={S.lbl}>End Date & Time</label>
          <input type="datetime-local" value={d.endTime} onChange={e=>upd({endTime:e.target.value})} style={S.inp} />
        </div>
        <div>
          <label style={S.lbl}>Result Date & Time</label>
          <input type="datetime-local" value={d.resultDateTime} onChange={e=>upd({resultDateTime:e.target.value})} style={S.inp} />
        </div>
      </div>

      <div style={{ marginBottom:10 }}>
        <label style={S.lbl}>Custom Instructions</label>
        <textarea value={d.customInstructions} onChange={e=>upd({customInstructions:e.target.value})} rows={2} style={S.inp} />
      </div>

      {/* Toggles grid (Whitelist & Review Window removed — handled by a separate dedicated feature later) */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:10 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <span style={{ fontSize:11, color:C.dim }}>🔒 Password Protect</span>
          <Toggle on={d.passwordEnabled} onClick={()=>upd({passwordEnabled:!d.passwordEnabled})} />
        </div>
        {d.passwordEnabled && <input value={d.password} onChange={e=>upd({password:e.target.value})} placeholder="Exam password" style={S.inp} />}

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <span style={{ fontSize:11, color:C.dim }}>⏳ Waiting Room</span>
          <Toggle on={d.waitingRoomEnabled} onClick={()=>upd({waitingRoomEnabled:!d.waitingRoomEnabled})} />
        </div>
        {d.waitingRoomEnabled && <input type="number" value={d.waitingRoomMinutes} onChange={e=>upd({waitingRoomMinutes:parseInt(e.target.value)||0})} placeholder="Minutes before start" style={S.inp} />}

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <span style={{ fontSize:11, color:C.dim }}>♾️ Unlimited Attempts</span>
          <Toggle on={d.unlimitedAttempts} onClick={()=>upd({unlimitedAttempts:!d.unlimitedAttempts})} />
        </div>
        {!d.unlimitedAttempts && <input type="number" value={d.maxAttempts} onChange={e=>upd({maxAttempts:parseInt(e.target.value)||1})} placeholder="Max attempts" style={S.inp} />}

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <span style={{ fontSize:11, color:C.dim }}>📑 Section-wise Display</span>
          <Toggle on={d.sectionWiseEnabled} onClick={()=>upd({sectionWiseEnabled:!d.sectionWiseEnabled})} />
        </div>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <span style={{ fontSize:11, color:C.dim }}>💧 Watermark</span>
          <Toggle on={d.watermark} onClick={()=>upd({watermark:!d.watermark})} />
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// SHARED — Assignment Selector (19B.6 / 20B.6 / 21B.9)
// ═══════════════════════════════════════════════════════
function AssignmentSelector({ a, setA, API, token }: { a:AssignmentState; setA:React.Dispatch<React.SetStateAction<AssignmentState>>; API:string; token:string }) {
  const upd = (patch: Partial<AssignmentState>) => setA(prev => ({ ...prev, ...patch }));
  const [batches, setBatches] = useState<{_id:string; name:string; studentCount?:number}[]>([]);
  const [seriesList, setSeriesList] = useState<{_id:string; name:string; title?:string; lifecycleStatus?:string}[]>([]);

  useEffect(() => {
    fetch(`${API}/api/admin/batches`, { headers:{ Authorization:`Bearer ${token}` } })
      .then(r=>r.json()).then(d=>setBatches(d.batches||d||[])).catch(()=>{});
    fetch(`${API}/api/content-forge/series`, { headers:{ Authorization:`Bearer ${token}` } })
      .then(r=>r.json()).then(d=>setSeriesList(d.series||[])).catch(()=>{});
  }, [API, token]);

  const cards: { key:AssignmentState['assignmentType']; icon:string; label:string }[] = [
    { key:'batch', icon:'🏫', label:'Assign to Batch' },
    { key:'series', icon:'📚', label:'Test Series' },
    { key:'individual', icon:'👤', label:'Individual / Open' },
  ];

  return (
    <div style={{ ...S.card }}>
      <div style={{ fontSize:13, fontWeight:800, color:C.ts, marginBottom:14 }}>🎯 Step — Assignment</div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:8, marginBottom:14 }}>
        {cards.map(c=>(
          <div key={c.key} onClick={()=>upd({assignmentType:c.key})}
            style={{ textAlign:'center', padding:'14px 8px', borderRadius:12, cursor:'pointer',
              border:`1.5px solid ${a.assignmentType===c.key?C.acc:C.bor}`,
              background:a.assignmentType===c.key?'rgba(77,159,255,0.12)':'rgba(0,22,40,0.5)',
              boxShadow:a.assignmentType===c.key?`0 0 0 2px ${C.acc}33`:'none', transition:'all 0.2s' }}>
            <div style={{ fontSize:22, marginBottom:4 }}>{c.icon}</div>
            <div style={{ fontSize:10, fontWeight:700, color:a.assignmentType===c.key?C.acc:C.dim }}>{c.label}</div>
            {a.assignmentType===c.key && <div style={{ fontSize:10, color:C.acc, marginTop:2 }}>✓</div>}
          </div>
        ))}
      </div>

      {a.assignmentType==='batch' && (
        <div style={{ marginBottom:10 }}>
          <label style={S.lbl}>Batch</label>
          <select value={a.batch} onChange={e=>upd({batch:e.target.value})} style={S.inp}>
            <option value="">— Select Batch —</option>
            {batches.map(b=><option key={b._id} value={b._id}>{b.name} {b.studentCount?`(${b.studentCount} students)`:''}</option>)}
          </select>
          {a.assignmentType==='batch' && (
            <div style={{ marginTop:8, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <span style={{ fontSize:11, color:C.dim }}>Multi-batch assign</span>
              <Toggle on={a.multiBatchEnabled} onClick={()=>upd({multiBatchEnabled:!a.multiBatchEnabled})} />
            </div>
          )}
          {a.multiBatchEnabled && a.assignmentType==='batch' && (
            <select multiple value={a.multiBatch} onChange={e=>upd({multiBatch:Array.from(e.target.selectedOptions).map(o=>o.value)})} style={{ ...S.inp, height:90, marginTop:6 }}>
              {batches.map(b=><option key={b._id} value={b._id}>{b.name}</option>)}
            </select>
          )}
        </div>
      )}

      {a.assignmentType==='series' && (
        <div style={{ marginBottom:10 }}>
          <label style={S.lbl}>Test Series</label>
          <select value={a.testSeriesId} onChange={e=>upd({testSeriesId:e.target.value})} style={S.inp}>
            <option value="">— Select Test Series —</option>
            {seriesList.map(s=><option key={s._id} value={s._id}>{s.name||s.title}{s.lifecycleStatus?` · ${s.lifecycleStatus}`:''}</option>)}
          </select>
          <label style={{ ...S.lbl, marginTop:8 }}>Batch (optional)</label>
          <select value={a.batch} onChange={e=>upd({batch:e.target.value})} style={S.inp}>
            <option value="">— Select Batch —</option>
            {batches.map(b=><option key={b._id} value={b._id}>{b.name}</option>)}
          </select>
        </div>
      )}

      {a.assignmentType==='individual' && (
        <div style={{ fontSize:11, color:C.dim }}>No batch restriction — exam will be open to all students.</div>
      )}

      <div style={{ marginTop:10, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <span style={{ fontSize:11, color:C.dim }}>🔔 Notify students in batch</span>
        <Toggle on={a.notifyStudents} onClick={()=>upd({notifyStudents:!a.notifyStudents})} />
      </div>
      {a.notifyStudents && a.batch && (
        <div style={{ marginTop:6, fontSize:10, color:C.gold }}>
          🔔 {batches.find(b=>b._id===a.batch)?.studentCount ?? '?'} students in selected batch will be notified
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// SHARED — Post-Create Actions (19B.8 / 20B.8 / 21B.11)
// ═══════════════════════════════════════════════════════
function PostCreateActions({ p, setP }: { p:PostCreateState; setP:React.Dispatch<React.SetStateAction<PostCreateState>> }) {
  const upd = (patch: Partial<PostCreateState>) => setP(prev => ({ ...prev, ...patch }));
  return (
    <div style={{ ...S.card }}>
      <div style={{ fontSize:13, fontWeight:800, color:C.ts, marginBottom:14 }}>🚀 Step — Post-Create Actions</div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
        <span style={{ fontSize:11, color:C.dim }}>⏰ Scheduled auto-publish</span>
        <Toggle on={p.scheduledPublishEnabled} onClick={()=>upd({scheduledPublishEnabled:!p.scheduledPublishEnabled})} />
      </div>
      {p.scheduledPublishEnabled && (
        <input type="datetime-local" value={p.publishAt} onChange={e=>upd({publishAt:e.target.value})} style={{ ...S.inp, marginBottom:10 }} />
      )}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
        <span style={{ fontSize:11, color:C.dim }}>📑 Save as Template (reuse settings next time)</span>
        <Toggle on={p.isTemplate} onClick={()=>upd({isTemplate:!p.isTemplate})} />
      </div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <span style={{ fontSize:11, color:C.dim }}>📤 Publish Now (instead of saving as Draft)</span>
        <Toggle on={p.publishNow} onClick={()=>upd({publishNow:!p.publishNow})} />
      </div>
    </div>
  );
}

// BUGFIX: shared rich preview card — full text (no .slice truncation), Hindi
// text/options shown when present, explanation shown when present, image
// shown when present. Used by ALL preview lists (19B/20B/21B parsed+exam
// modes, and Feature 20/21 QB-upload previews) so this fixes the
// "Qs/options/Hindi/explanation not showing properly" bug everywhere at once.
function QuestionPreviewCard({ q, index, accent, onEdit, onDelete, onMoveUp, onMoveDown }: {
  q: ParsedQ; index?: number; accent?: string;
  onEdit?: () => void; onDelete?: () => void; onMoveUp?: () => void; onMoveDown?: () => void;
}) {
  const acc = accent || C.acc;
  const status = q.hasError ? 'error' : (q.isDuplicateInDB || q.isDuplicateInFile || q.isDuplicate) ? 'duplicate' : (q.needsReview ? 'review' : 'valid');
  const borderColor = status==='error' ? 'rgba(255,77,77,0.4)' : status==='duplicate' ? 'rgba(255,184,77,0.4)' : status==='review' ? 'rgba(245,158,11,0.4)' : C.bor;
  const bgColor = status==='error' ? 'rgba(255,77,77,0.05)' : 'rgba(0,22,40,0.7)';

  return (
    <div style={{ border:`1px solid ${borderColor}`, borderLeft:`3px solid ${borderColor}`, borderRadius:10, padding:12, marginBottom:8, background:bgColor }}>
      <div style={{ display:'flex', gap:6, marginBottom:8, flexWrap:'wrap', alignItems:'center' }}>
        <span style={{ fontSize:10, color:acc, fontWeight:800 }}>{index!==undefined ? `${index+1}.` : `Q${q.num}`}</span>
        {q.subject && <span style={{ fontSize:9, padding:'2px 6px', borderRadius:6, background:`${acc}1A`, color:acc }}>{q.subject}</span>}
        {q.type && <span style={{ fontSize:9, padding:'2px 6px', borderRadius:6, background:'rgba(0,22,40,0.5)', color:C.dim }}>{q.type}</span>}
        {q.page && <span style={{ fontSize:9, color:C.dim }}>· Page {q.page}</span>}
        {q.confidencePct !== undefined && <span style={{ fontSize:9, color:C.dim }}>· {q.confidencePct}% confident</span>}
        {q.hasError && <span style={{ fontSize:9, color:C.err }}>⚠️ {q.error}</span>}
        {status==='duplicate' && <span style={{ fontSize:9, color:C.wrn }}>⚠️ Duplicate</span>}
        {status==='review' && <span style={{ fontSize:9, color:C.gold }}>🔶 Needs Review</span>}
        {(onMoveUp || onMoveDown || onEdit || onDelete) && (
          <div style={{ display:'flex', gap:4, marginLeft:'auto' }}>
            {onMoveUp && <button onClick={onMoveUp} style={{ fontSize:9, padding:'2px 6px', borderRadius:6, border:`1px solid ${C.bor}`, background:'transparent', color:C.dim, cursor:'pointer' }}>↑</button>}
            {onMoveDown && <button onClick={onMoveDown} style={{ fontSize:9, padding:'2px 6px', borderRadius:6, border:`1px solid ${C.bor}`, background:'transparent', color:C.dim, cursor:'pointer' }}>↓</button>}
            {onEdit && <button onClick={onEdit} style={{ fontSize:9, padding:'2px 8px', borderRadius:6, border:`1px solid ${C.bor}`, background:'transparent', color:acc, cursor:'pointer' }}>✏️</button>}
            {onDelete && <button onClick={onDelete} style={{ fontSize:9, padding:'2px 8px', borderRadius:6, border:'1px solid rgba(255,77,77,0.3)', background:'transparent', color:C.err, cursor:'pointer' }}>✕</button>}
          </div>
        )}
      </div>

      <div style={{ fontSize:12, color:C.ts, marginBottom:4, lineHeight:1.5 }}><MathText text={q.text} /></div>
      {q.hindiText && <div style={{ fontSize:11, color:'#B8C7D9', marginBottom:6, lineHeight:1.5, fontStyle:'italic' }}><MathText text={q.hindiText} /></div>}
      {q.imageUrl && <img src={q.imageUrl} alt="question" style={{ maxWidth:'100%', borderRadius:8, marginBottom:6 }} />}

      {q.options.length > 0 && (
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:4, marginBottom:6 }}>
          {q.options.map((opt,j)=>(
            <div key={j} style={{ fontSize:10, padding:'4px 7px', borderRadius:6, background:q.correct.includes(j)?'rgba(0,196,140,0.12)':'rgba(77,159,255,0.06)', color:q.correct.includes(j)?C.suc:'#93C5FD' }}>
              {String.fromCharCode(65+j)}) <MathText text={opt} /> {q.correct.includes(j)&&'✅'}
              {q.hindiOptions?.[j] && <div style={{ fontSize:9, color:'#7C93AD', fontStyle:'italic' }}>{q.hindiOptions[j]}</div>}
            </div>
          ))}
        </div>
      )}
      {q.type==='Integer' && <div style={{ fontSize:11, color:C.suc, marginBottom:6, fontWeight:700 }}>✅ Answer: {q.correct[0]}</div>}

      {q.explanation && (
        <div style={{ marginTop:6, padding:'6px 10px', borderRadius:8, background:'rgba(167,139,250,0.08)', border:'1px solid rgba(167,139,250,0.2)' }}>
          <div style={{ fontSize:9, color:C.purple, fontWeight:700, marginBottom:2 }}>💡 EXPLANATION</div>
          <div style={{ fontSize:10, color:'#D8D2F5' }}><MathText text={q.explanation} /></div>
        </div>
      )}
    </div>
  );
}

// ═══ Pre-submit checklist (19B.35 / 20B.43) ═══
function PreSubmitChecklist({ questionsOk, titleOk, dateOk, batchOk }: { questionsOk:boolean; titleOk:boolean; dateOk:boolean; batchOk:boolean }) {
  const items = [
    { ok:questionsOk, label:'Questions' },
    { ok:titleOk, label:'Title' },
    { ok:dateOk, label:'Schedule' },
    { ok:batchOk, label:'Assignment' },
  ];
  return (
    <div style={{ display:'flex', gap:10, flexWrap:'wrap', marginBottom:10 }}>
      {items.map(it=>(
        <span key={it.label} style={{ fontSize:11, color:it.ok?C.suc:C.dim }}>{it.label} {it.ok?'✅':'○'}</span>
      ))}
    </div>
  );
}

// F19B.4.7 / F20B.3.7 / F21B.7.6 — Duplicate-in-exam/batch check (wires the backend
// /check-duplicates endpoint into the UI, shared across all 3 Create-Exam wizards)
function DuplicateCheckPanel({ texts, batch, API, token }: { texts:string[]; batch:string; API:string; token:string }) {
  const [checking, setChecking] = useState(false);
  const [result, setResult] = useState<{text:string; inSameBatch:boolean}[]|null>(null);

  const runCheck = async () => {
    if (texts.length === 0) return;
    setChecking(true); setResult(null);
    try {
      const res = await fetch(`${API}/api/content-forge/check-duplicates`, {
        method:'POST', headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${token}` },
        body: JSON.stringify({ texts, batch }),
      });
      const d = await res.json();
      setResult(d.duplicates || []);
    } catch (e) { setResult([]); }
    setChecking(false);
  };

  return (
    <div style={{ marginBottom:10 }}>
      <button onClick={runCheck} disabled={checking||texts.length===0} style={{ ...S.bg, fontSize:11, opacity:checking?0.6:1 }}>
        {checking ? '⟳ Checking...' : '🔍 Check Duplicates (vs Question Bank & this batch)'}
      </button>
      {result && (
        result.length === 0
          ? <div style={{ marginTop:6, fontSize:11, color:C.suc }}>✅ No duplicates found</div>
          : <div style={{ marginTop:6, fontSize:11, color:C.wrn }}>⚠️ {result.length} question(s) already exist {result.some(r=>r.inSameBatch)?'(some in this batch!)':'elsewhere in Question Bank'}</div>
      )}
    </div>
  );
}
// ═══════════════════════════════════════════════════════
// VIEWS — Home pages
// ═══════════════════════════════════════════════════════

// ── Premium 3-Card Home (Feature 19.22 / 19B.37 / 20B.45 / 21B.32 — all 3 now active)
function HomeView({ onNav }: { onNav:(v:View)=>void }) {
  const cards = [
    { icon:'📋', title:'Copy-Paste Method', sub:'Paste raw question text — auto-parses, syncs answers & explanations', grad:'linear-gradient(135deg,#4D9FFF22,#0055CC11)', bor:'rgba(77,159,255,0.3)', accent:'#4D9FFF', view:'cp_home' as View, badge:'Feature 19' },
    { icon:'📊', title:'Excel / CSV Upload', sub:'Upload structured .xlsx or .csv file with questions in columns', grad:'linear-gradient(135deg,#00C48C22,#00955E11)', bor:'rgba(0,196,140,0.3)', accent:'#00C48C', view:'ex_home' as View, badge:'Feature 20' },
    { icon:'📄', title:'PDF Parsing', sub:'Upload PDF — engine extracts questions, options and answers automatically', grad:'linear-gradient(135deg,#F59E0B22,#D9770011)', bor:'rgba(245,158,11,0.3)', accent:'#F59E0B', view:'pdf_home' as View, badge:'Feature 21' },
  ];
  return (
    <div style={{ maxWidth:900, margin:'0 auto' }}>
      <div style={{ textAlign:'center', marginBottom:36 }}>
        <div style={{ fontSize:28, fontWeight:800, background:'linear-gradient(135deg,#4D9FFF,#A78BFA)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', marginBottom:8 }}>
          ⚡ Content Forge
        </div>
        <div style={{ fontSize:14, color:C.dim }}>Choose your preferred method to create questions at scale</div>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))', gap:20 }}>
        {cards.map(card => (
          <div key={card.title}
            onClick={() => onNav(card.view)}
            style={{ background:card.grad, border:`1px solid ${card.bor}`, borderRadius:20, padding:'32px 24px', cursor:'pointer', transition:'all 0.25s', backdropFilter:'blur(16px)', position:'relative', overflow:'hidden' }}
            onMouseEnter={e => ((e.currentTarget as HTMLDivElement).style.transform='translateY(-4px)', (e.currentTarget as HTMLDivElement).style.boxShadow=`0 16px 40px ${card.bor}`)}
            onMouseLeave={e => ((e.currentTarget as HTMLDivElement).style.transform='translateY(0)', (e.currentTarget as HTMLDivElement).style.boxShadow='none')}
          >
            <div style={{ position:'absolute', top:14, right:14, fontSize:10, padding:'3px 10px', borderRadius:20, background:`${card.accent}22`, border:`1px solid ${card.accent}44`, color:card.accent, fontWeight:700 }}>{card.badge}</div>
            <div style={{ fontSize:40, marginBottom:16 }}>{card.icon}</div>
            <div style={{ fontSize:17, fontWeight:800, color:C.ts, marginBottom:8 }}>{card.title}</div>
            <div style={{ fontSize:12, color:C.dim, lineHeight:1.7 }}>{card.sub}</div>
            <div style={{ marginTop:20, fontSize:12, color:card.accent, fontWeight:700 }}>Get Started →</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Generic 2-card sub-home (QB Upload / Create Exam) — reused for all 3 methods (19B.37/20B.45/20.21/21B.32/21.23)
function MethodSubHome({ onNav, title, subtitle, qbView, examView, accent }: {
  onNav:(v:View)=>void; title:string; subtitle:string; qbView:View; examView:View; accent:string;
}) {
  const isMobile = useIsMobile();
  const cards = [
    { icon:'📚', title:'Upload to QB / PYQ Bank', sub:'Parse → auto-sync answers & explanations → bulk save to Question Bank or PYQ Bank', grad:`linear-gradient(135deg,${accent}22,${accent}11)`, bor:`${accent}55`, view:qbView },
    { icon:'🎯', title:'Create Exam', sub:'Parse → build full exam with sections, marking scheme, schedule & batch assignment', grad:'linear-gradient(135deg,#A78BFA22,#7C3AED11)', bor:'rgba(167,139,250,0.3)', view:examView },
  ];
  return (
    <div style={{ maxWidth:760, margin:'0 auto' }}>
      <button onClick={() => onNav('home')} style={{ ...S.bg, marginBottom:24, fontSize:11 }}>← Back to Creation Studio</button>
      <div style={{ textAlign:'center', marginBottom:32 }}>
        <div style={{ fontSize:24, fontWeight:800, color:C.ts, marginBottom:6 }}>{title}</div>
        <div style={{ fontSize:13, color:C.dim }}>{subtitle}</div>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:isMobile?'1fr':'1fr 1fr', gap:20 }}>
        {cards.map(card => (
          <div key={card.title}
            onClick={() => onNav(card.view)}
            style={{ background:card.grad, border:`1px solid ${card.bor}`, borderRadius:20, padding:'36px 24px', cursor:'pointer', transition:'all 0.25s', backdropFilter:'blur(16px)', textAlign:'center' }}
            onMouseEnter={e => ((e.currentTarget as HTMLDivElement).style.transform='translateY(-4px)', (e.currentTarget as HTMLDivElement).style.boxShadow=`0 16px 40px ${card.bor}`)}
            onMouseLeave={e => ((e.currentTarget as HTMLDivElement).style.transform='translateY(0)', (e.currentTarget as HTMLDivElement).style.boxShadow='none')}
          >
            <div style={{ fontSize:48, marginBottom:16 }}>{card.icon}</div>
            <div style={{ fontSize:16, fontWeight:800, color:C.ts, marginBottom:10 }}>{card.title}</div>
            <div style={{ fontSize:12, color:C.dim, lineHeight:1.7 }}>{card.sub}</div>
            <div style={{ marginTop:20, fontSize:12, color:accent, fontWeight:700 }}>Open →</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CopyPasteHome({ onNav }: { onNav:(v:View)=>void }) {
  return <MethodSubHome onNav={onNav} title="📋 Copy-Paste Method" subtitle="What would you like to create from pasted content?" qbView="cp_qs" examView="cp_exam" accent="#4D9FFF" />;
}
function ExcelHome({ onNav }: { onNav:(v:View)=>void }) {
  return <MethodSubHome onNav={onNav} title="📊 Excel / CSV Method" subtitle="What would you like to create from your spreadsheet?" qbView="ex_qs" examView="ex_exam" accent="#00C48C" />;
}
function PDFHome({ onNav }: { onNav:(v:View)=>void }) {
  return <MethodSubHome onNav={onNav} title="📄 PDF Parsing Method" subtitle="What would you like to create from your PDF paper?" qbView="pdf_qs" examView="pdf_exam" accent="#F59E0B" />;
}
// ═══════════════════════════════════════════════════════
// MAIN QB UPLOAD VIEW — Full Feature 19
// ═══════════════════════════════════════════════════════
function CopyPasteQBView({ API, token, onNav }: { API:string; token:string; onNav:(v:View)=>void }) {
  const getToken = () => typeof window !== 'undefined' ? localStorage.getItem('pr_token')||'' : token;

  // Inputs
  const [engText,    setEngText]    = useState('');
  const [hindiText,  setHindiText]  = useState('');
  const [ansKey,     setAnsKey]     = useState('');
  const [explText,   setExplText]   = useState('');
  const [customDelim,setCustomDelim]= useState('');

  // Parse state
  const [parsedQs,   setParsedQs]   = useState<ParsedQ[]>([]);
  const [isParsing,  setIsParsing]  = useState(false);
  const [parseAnim,  setParseAnim]  = useState(false);

  // Bulk assign (19.10)
  const [subject,    setSubject]    = useState('Physics');
  const [chapter,    setChapter]    = useState('');
  const [difficulty, setDifficulty] = useState('Medium');
  const [qtype,      setQtype]      = useState('SCQ');

  // Upload target (19.23)
  const [target,     setTarget]     = useState<'qs_bank'|'pyq_bank'>('qs_bank');

  // Edit (19.9)
  const [editingQ,   setEditingQ]   = useState<ParsedQ|null>(null);
  const [editDraft,  setEditDraft]  = useState<ParsedQ|null>(null);

  // Drag (19.15)
  const [dragIdx,    setDragIdx]    = useState<number|null>(null);
  const [dragOverIdx,setDragOverIdx]= useState<number|null>(null);

  // Save
  const [saving,     setSaving]     = useState(false);
  const [saveMsg,    setSaveMsg]    = useState('');
  const [tooltip,    setTooltip]    = useState<{idx:number;msg:string}|null>(null);

  // Auto-parse on text change (19.4 / 19.5 / 19.19)
  useEffect(() => {
    if (!engText.trim()) { setParsedQs([]); return; }
    setIsParsing(true);
    setParseAnim(true);
    const t = setTimeout(() => {
      const result = parseAll(engText, hindiText, ansKey, explText, customDelim);
      // Apply bulk subject/difficulty
      const withMeta = result.map(q => ({ ...q, subject: q.subject||subject, chapter: q.chapter||chapter, difficulty: q.difficulty||difficulty, type: q.type||qtype }));
      setParsedQs(withMeta);
      setIsParsing(false);
      setTimeout(() => setParseAnim(false), 500);
    }, 400);
    return () => clearTimeout(t);
  }, [engText, hindiText, ansKey, explText, customDelim]);

  // Re-apply bulk meta when changed (19.10)
  const applyBulkMeta = () => {
    setParsedQs(prev => prev.map(q => ({ ...q, subject, chapter, difficulty, type:qtype })));
  };

  // Smart Clean (19.13)
  const handleSmartClean = () => {
    setEngText(smartClean(engText));
    setHindiText(smartClean(hindiText));
    setAnsKey(ansKey.trim());
    setExplText(explText.trim());
  };

  // Drag-drop (19.15)
  const handleDragStart = (idx:number) => setDragIdx(idx);
  const handleDragOver  = (e:React.DragEvent, idx:number) => { e.preventDefault(); setDragOverIdx(idx); };
  const handleDrop      = (idx:number) => {
    if (dragIdx === null || dragIdx === idx) { setDragIdx(null); setDragOverIdx(null); return; }
    const arr = [...parsedQs];
    const [moved] = arr.splice(dragIdx, 1);
    arr.splice(idx, 0, moved);
    setParsedQs(arr.map((q,i) => ({...q, num:i+1})));
    setDragIdx(null); setDragOverIdx(null);
  };

  // Edit save (19.9)
  const saveEdit = () => {
    if (!editDraft) return;
    setParsedQs(prev => prev.map(q => q.id === editDraft.id ? editDraft : q));
    setEditingQ(null); setEditDraft(null);
  };

  // Final save (19.11)
  const handleSave = async () => {
    const toSave = parsedQs.filter(q => !q.hasError || q.text);
    if (!toSave.length) return;
    setSaving(true); setSaveMsg('');
    try {
      const res = await fetch(`${API}/api/questions/bulk-paste-save`, {
        method:'POST',
        headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${getToken()}` },
        body: JSON.stringify({ questions:toSave, target, subject, chapter, difficulty, type:qtype })
      });
      const d = await res.json();
      setSaveMsg(d.success ? `✅ ${d.saved} questions saved to ${target==='pyq_bank'?'PYQ Bank':'Question Bank'}!` : `❌ ${d.message}`);
    } catch(e:any) { setSaveMsg('❌ '+e.message); }
    setSaving(false);
  };

  const errQs   = parsedQs.filter(q => q.hasError).length;
  const goodQs  = parsedQs.length - errQs;

  return (
    <div style={{ color:C.ts, fontFamily:'Inter,sans-serif' }}>
      {/* Header */}
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:20 }}>
        <button onClick={()=>onNav('cp_home')} style={{ ...S.bg, fontSize:11 }}>← Back</button>
        <div>
          <div style={{ fontSize:20, fontWeight:800, background:`linear-gradient(135deg,${C.acc},#A78BFA)`, WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
            📋 Upload via Copy-Paste
          </div>
          <div style={{ fontSize:11, color:C.dim }}>Paste questions → auto-parse → save to QB / PYQ Bank · Feature 19</div>
        </div>
        {/* 19.20 Counter badge */}
        {parsedQs.length > 0 && (
          <div style={{ marginLeft:'auto', display:'flex', gap:8 }}>
            <span style={{ padding:'4px 12px', borderRadius:20, background:'rgba(77,159,255,0.15)', border:`1px solid ${C.bor}`, fontSize:12, fontWeight:700, color:C.acc }}>
              📊 {parsedQs.length} detected
            </span>
            {goodQs > 0 && <span style={{ padding:'4px 12px', borderRadius:20, background:'rgba(0,196,140,0.12)', border:'1px solid rgba(0,196,140,0.3)', fontSize:12, fontWeight:700, color:C.suc }}>{goodQs} ✅</span>}
            {errQs > 0  && <span style={{ padding:'4px 12px', borderRadius:20, background:'rgba(255,77,77,0.1)', border:'1px solid rgba(255,77,77,0.3)', fontSize:12, fontWeight:700, color:C.err }}>{errQs} ❌</span>}
          </div>
        )}
      </div>

      {/* 19.17 Split Screen */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:16 }}>

        {/* ── LEFT: Input Textareas ── */}
        <div>
          {/* Tools row */}
          <div style={{ display:'flex', gap:8, marginBottom:10, flexWrap:'wrap' }}>
            {/* 19.13 Smart Clean */}
            <button onClick={handleSmartClean} style={{ ...S.bg, fontSize:11, padding:'6px 12px' }}>🧹 Smart Clean (19.13)</button>
            {/* 19.16 Custom delimiter */}
            <input value={customDelim} onChange={e=>setCustomDelim(e.target.value)} placeholder="Custom delimiter e.g. ---" style={{ ...S.inp, width:170, padding:'5px 10px', fontSize:11 }} />
          </div>

          {/* 19.1 English Questions textarea */}
          <div style={{ marginBottom:10 }}>
            <label style={S.lbl}>📝 English Questions Text (19.1) — Paste Q1. Q2. format</label>
            <textarea value={engText} onChange={e=>setEngText(e.target.value)} rows={10} placeholder={`Paste questions here...\n\nQ1. What is osmosis?\nA) Water moves high to low\nB) Water moves low to high\nC) Both A and B\nD) None\n\nQ2. Newton's first law states...`}
              style={{ ...S.inp, height:200, lineHeight:1.6 }} />
          </div>

          {/* 19.1 Hindi Questions textarea */}
          <div style={{ marginBottom:10 }}>
            <label style={S.lbl}>🇮🇳 Hindi Questions Text (19.1) — Optional, same Q numbering</label>
            <textarea value={hindiText} onChange={e=>setHindiText(e.target.value)} rows={6} placeholder="Q1. ऑस्मोसिस क्या है?\nA) पानी उच्च से निम्न की ओर जाता है\n..."
              style={{ ...S.inp, height:130, lineHeight:1.6 }} />
          </div>

          {/* 19.2 Answer Key */}
          <div style={{ marginBottom:10 }}>
            <label style={S.lbl}>🔑 Answer Key (19.2) — A/B/C/D per line OR "1. A" OR "ABCD..."</label>
            <textarea value={ansKey} onChange={e=>setAnsKey(e.target.value)} rows={5} placeholder={"A\nB\nA\nC\nD\n\nOR:\n1. A\n2. B\n3. A\n\nOR: ABACD"}
              style={{ ...S.inp, height:110, fontFamily:'monospace', color:'#6EE7B7' }} />
          </div>

          {/* 19.3 Explanation (Optional) */}
          <div style={{ marginBottom:10 }}>
            <label style={S.lbl}>💡 Explanations (19.3) — Optional · Format: "1. explanation text"</label>
            <textarea value={explText} onChange={e=>setExplText(e.target.value)} rows={5} placeholder={"1. Osmosis is the movement of water...\n2. Newton's first law also called law of inertia...\n(Leave blank if not available)"}
              style={{ ...S.inp, height:110, color:'#FCA5A5' }} />
          </div>

          {/* 19.10 Bulk Assign */}
          <div style={{ ...S.card, padding:'14px 16px' }}>
            <label style={{ ...S.lbl, marginBottom:10 }}>⚙️ Bulk Assign to All Questions (19.10)</label>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:8 }}>
              <div>
                <label style={S.lbl}>Subject</label>
                <select value={subject} onChange={e=>setSubject(e.target.value)} style={{ ...S.inp }}>
                  {['Physics','Chemistry','Biology','Mathematics','Zoology','Botany','General'].map(s=><option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label style={S.lbl}>Difficulty</label>
                <select value={difficulty} onChange={e=>setDifficulty(e.target.value)} style={{ ...S.inp }}>
                  {['Easy','Medium','Hard'].map(d=><option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label style={S.lbl}>Chapter</label>
                <input value={chapter} onChange={e=>setChapter(e.target.value)} placeholder="e.g. Thermodynamics" style={{ ...S.inp }} />
              </div>
              <div>
                <label style={S.lbl}>Type</label>
                <select value={qtype} onChange={e=>setQtype(e.target.value)} style={{ ...S.inp }}>
                  {['SCQ','MSQ','Integer'].map(t=><option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
            <button onClick={applyBulkMeta} style={{ ...S.bg, fontSize:11, width:'100%' }}>↻ Apply to All Parsed Questions</button>
          </div>

          {/* 19.23 Upload Target */}
          <div style={{ ...S.card, padding:'14px 16px' }}>
            <label style={S.lbl}>📤 Upload Target (19.23)</label>
            <div style={{ display:'flex', gap:8 }}>
              {[{v:'qs_bank',l:'📚 Question Bank'},{v:'pyq_bank',l:'📜 PYQ Bank (base ready)'}].map(t=>(
                <button key={t.v} onClick={()=>setTarget(t.v as any)} style={{ flex:1, padding:'9px', borderRadius:9, border:`1px solid ${target===t.v?C.acc:C.bor}`, background:target===t.v?'rgba(77,159,255,0.15)':'transparent', color:target===t.v?C.acc:C.dim, cursor:'pointer', fontSize:12, fontWeight:700, transition:'all 0.2s' }}>
                  {t.l}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* ── RIGHT: Live Preview ── */}
        <div>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
            <span style={{ fontSize:12, fontWeight:700, color:C.ts }}>
              {/* 19.19 parsing animation */}
              {isParsing ? '⟳ Parsing...' : `👁️ Live Preview (${parsedQs.length} questions)`}
            </span>
            {/* 19.18 color legend */}
            <div style={{ display:'flex', gap:8, fontSize:10 }}>
              {[['#E8F4FF','Q Text'],['#93C5FD','Options'],['#6EE7B7','Answer'],['#FCA5A5','Expl'],['#F87171','Error']].map(([col,lbl])=>(
                <span key={lbl} style={{ display:'flex', alignItems:'center', gap:3 }}>
                  <span style={{ width:8, height:8, borderRadius:2, background:col, display:'inline-block' }}/>
                  <span style={{ color:C.dim }}>{lbl}</span>
                </span>
              ))}
            </div>
          </div>

          {/* 19.19 Line parsing animation */}
          {parseAnim && (
            <div style={{ height:3, borderRadius:2, background:`linear-gradient(90deg,${C.acc},#A78BFA,${C.acc})`, backgroundSize:'200%', animation:'shimmer 1s linear infinite', marginBottom:8 }} />
          )}

          <div style={{ height:'calc(100vh - 280px)', overflowY:'auto', paddingRight:4 }}>
            {parsedQs.length === 0 && !isParsing && (
              <div style={{ textAlign:'center', padding:'60px 20px', color:C.dim }}>
                <div style={{ fontSize:32, marginBottom:8 }}>📋</div>
                <div>Paste questions on the left — live preview appears here</div>
                <div style={{ fontSize:11, marginTop:8, color:'rgba(107,143,175,0.6)' }}>Supports Q1./1./WhatsApp bold format</div>
              </div>
            )}

            {/* 19.15 Drag-drop reorder */}
            {parsedQs.map((q, idx) => (
              <div key={q.id}
                draggable
                onDragStart={()=>handleDragStart(idx)}
                onDragOver={e=>handleDragOver(e,idx)}
                onDrop={()=>handleDrop(idx)}
                onDragEnd={()=>{setDragIdx(null);setDragOverIdx(null);}}
                style={{
                  border:`1px solid ${q.hasError?'rgba(255,77,77,0.45)':dragOverIdx===idx?C.acc:C.bor}`,
                  borderRadius:10, padding:'10px 12px', marginBottom:8,
                  background: q.hasError?'rgba(255,77,77,0.05)':'rgba(0,22,40,0.7)',
                  cursor:'grab', transition:'all 0.15s',
                  opacity: dragIdx===idx ? 0.5 : 1,
                  boxShadow: dragOverIdx===idx ? `0 0 0 2px ${C.acc}` : 'none'
                }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:6 }}>
                  <div style={{ display:'flex', gap:6, alignItems:'center', flexWrap:'wrap' }}>
                    <span style={{ fontSize:10, color:C.acc, fontWeight:800 }}>Q{q.num}</span>
                    <span style={{ fontSize:9, padding:'2px 7px', borderRadius:8, background:'rgba(77,159,255,0.1)', color:C.acc }}>{q.subject||subject}</span>
                    <span style={{ fontSize:9, padding:'2px 7px', borderRadius:8, background:'rgba(0,22,40,0.5)', color:C.dim }}>{q.difficulty||difficulty}</span>
                    <span style={{ fontSize:9, padding:'2px 7px', borderRadius:8, background:'rgba(0,22,40,0.5)', color:C.dim }}>{q.type||qtype}</span>
                    {/* 19.7 Error badge */}
                    {q.hasError && (
                      <span
                        style={{ fontSize:9, padding:'2px 7px', borderRadius:8, background:'rgba(255,77,77,0.15)', color:'#FF4D4D', cursor:'help', fontWeight:700 }}
                        onMouseEnter={()=>setTooltip({idx,msg:q.error})}
                        onMouseLeave={()=>setTooltip(null)}
                        title={q.error}
                      >
                        {/* 19.21 Error tooltip */}
                        ⚠️ {q.error.length>30?q.error.slice(0,30)+'...':q.error}
                      </span>
                    )}
                  </div>
                  <div style={{ display:'flex', gap:4 }}>
                    {/* 19.9 Edit individual */}
                    <button onClick={()=>{setEditingQ(q);setEditDraft({...q});}} style={{ fontSize:10, padding:'3px 8px', borderRadius:6, border:`1px solid ${C.bor}`, background:'transparent', color:C.acc, cursor:'pointer' }}>✏️ Edit</button>
                    <button onClick={()=>setParsedQs(prev=>prev.filter(x=>x.id!==q.id))} style={{ fontSize:10, padding:'3px 8px', borderRadius:6, border:'1px solid rgba(255,77,77,0.3)', background:'transparent', color:'#FF4D4D', cursor:'pointer' }}>✕</button>
                    <span style={{ fontSize:12, cursor:'grab', color:C.dim, paddingLeft:4 }}>⠿</span>
                  </div>
                </div>

                {/* 19.18 Color-coded: Q text white */}
                <div style={{ fontSize:11, color:'#E8F4FF', lineHeight:1.6, marginBottom:q.options.length?6:0 }}>{q.text?.slice(0,150)}{q.text?.length>150?'...':''}</div>
                {q.hindiText && <div style={{ fontSize:10, color:'#C4B5FD', lineHeight:1.6, marginBottom:6, fontFamily:'serif', wordBreak:'break-word' as const, whiteSpace:'pre-wrap' as const }}>{q.hindiText}</div>}
                {q.explanation && (
                  <div style={{ fontSize:10, color:'#F9A8D4', lineHeight:1.6, marginTop:2, marginBottom:6, padding:'6px 9px', background:'rgba(249,168,212,0.06)', border:'1px solid rgba(249,168,212,0.18)', borderRadius:7, wordBreak:'break-word' as const, whiteSpace:'pre-wrap' as const }}>
                    💡 {q.explanation}
                  </div>
                )}

                {/* 19.18 Options: blue */}
                {q.options.length > 0 && (
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:3, marginBottom:4 }}>
                    {q.options.slice(0,4).map((opt,j) => {
                      const isCor = q.correct.includes(j);
                      return (
                        <div key={j} style={{ fontSize:10, padding:'3px 7px', borderRadius:5, background:isCor?'rgba(0,196,140,0.12)':'rgba(77,159,255,0.08)', border:`1px solid ${isCor?'rgba(0,196,140,0.4)':'rgba(77,159,255,0.15)'}`, color:isCor?C.suc:'#93C5FD' }}>
                          {/* 19.18 Answer: green, Options: blue */}
                          <b>{String.fromCharCode(65+j)})</b> {opt.slice(0,45)} {isCor&&'✅'}
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* 19.6 Validation indicators */}
                <div style={{ display:'flex', gap:6, fontSize:9, flexWrap:'wrap' }}>
                  <span style={{ color: q.text?C.suc:C.err }}>Eng{q.text?'✓':'✗'}</span>
                  <span style={{ color: q.hindiText?C.suc:C.dim }}>Hindi{q.hindiText?'✓':'⚠'}</span>
                  <span style={{ color: q.options.length>=2?C.suc:C.err }}>Opts{q.options.length>=2?'✓':'✗'}</span>
                  <span style={{ color: q.correct.length?C.suc:C.err }}>Ans{q.correct.length?`(${q.correctLetter})✓`:'✗'}</span>
                  {/* 19.18 Explanation: light pink */}
                  <span style={{ color: q.explanation?'#FCA5A5':C.dim }}>Expl{q.explanation?'✓':'—'}</span>
                </div>
              </div>
            ))}
          </div>

          {/* 19.8 Preview save bar */}
          {parsedQs.length > 0 && (
            <div style={{ marginTop:12, padding:'12px 14px', background:'rgba(0,22,40,0.9)', border:`1px solid ${C.bor}`, borderRadius:12, display:'flex', justifyContent:'space-between', alignItems:'center', gap:10, flexWrap:'wrap' }}>
              <div style={{ fontSize:11, color:C.dim }}>
                {/* 19.11 Final bulk save */}
                {goodQs} ready · {errQs} errors · Target: <span style={{ color:C.acc, fontWeight:700 }}>{target==='pyq_bank'?'PYQ Bank':'QB'}</span>
              </div>
              <div style={{ display:'flex', gap:8 }}>
                <button onClick={()=>setParsedQs(parseAll(engText,hindiText,ansKey,explText,customDelim))} style={{ ...S.bg, fontSize:11, padding:'7px 14px' }}>🔄 Re-parse</button>
                <button onClick={handleSave} disabled={saving||goodQs===0} style={{ ...S.bs, opacity:saving||goodQs===0?0.6:1, fontSize:12 }}>
                  {saving?'⟳ Saving...':'💾 Save '+goodQs+' Questions'}
                </button>
              </div>
            </div>
          )}
          {saveMsg && <div style={{ marginTop:8, padding:'8px 12px', borderRadius:9, fontSize:12, background:saveMsg.startsWith('✅')?'rgba(0,196,140,0.1)':'rgba(255,77,77,0.1)', color:saveMsg.startsWith('✅')?C.suc:C.err }}>{saveMsg}</div>}
        </div>
      </div>

      {/* 19.9 Edit Modal */}
      {editingQ && editDraft && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.85)', backdropFilter:'blur(8px)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:16 }}
          onClick={e=>e.target===e.currentTarget&&setEditingQ(null)}>
          <div style={{ width:'100%', maxWidth:580, maxHeight:'90vh', overflowY:'auto', background:'#020D18', border:`1px solid ${C.bor}`, borderRadius:18, padding:24 }}>
            <div style={{ fontSize:15, fontWeight:700, color:C.ts, marginBottom:16 }}>✏️ Edit Q{editDraft.num}</div>
            <label style={S.lbl}>English Text</label>
            <textarea value={editDraft.text} onChange={e=>setEditDraft(p=>p?{...p,text:e.target.value}:null)} rows={3} style={{ ...S.inp, marginBottom:10 }}/>
            <label style={S.lbl}>Hindi Text</label>
            <textarea value={editDraft.hindiText} onChange={e=>setEditDraft(p=>p?{...p,hindiText:e.target.value}:null)} rows={2} style={{ ...S.inp, marginBottom:10 }}/>
            {editDraft.options.map((opt,j)=>(
              <div key={j} style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6 }}>
                <span style={{ color:C.acc, fontWeight:700, width:20 }}>{String.fromCharCode(65+j)})</span>
                <input value={opt} onChange={e=>{const o=[...editDraft.options];o[j]=e.target.value;setEditDraft(p=>p?{...p,options:o}:null);}} style={{ ...S.inp }}/>
                <button onClick={()=>{const correct=editDraft.correct.includes(j)?editDraft.correct.filter(x=>x!==j):[...editDraft.correct,j];const cl=['A','B','C','D'][correct[0]]||'';setEditDraft(p=>p?{...p,correct,correctLetter:cl}:null);}} style={{ fontSize:11, padding:'4px 8px', borderRadius:6, border:`1px solid ${editDraft.correct.includes(j)?'rgba(0,196,140,0.5)':C.bor}`, background:editDraft.correct.includes(j)?'rgba(0,196,140,0.1)':'transparent', color:editDraft.correct.includes(j)?C.suc:C.dim, cursor:'pointer' }}>
                  {editDraft.correct.includes(j)?'✅ Correct':'Set Correct'}
                </button>
              </div>
            ))}
            <label style={{ ...S.lbl, marginTop:8 }}>Explanation</label>
            <textarea value={editDraft.explanation} onChange={e=>setEditDraft(p=>p?{...p,explanation:e.target.value}:null)} rows={2} style={{ ...S.inp, marginBottom:12 }}/>
            <div style={{ display:'flex', gap:8 }}>
              <button onClick={saveEdit} style={{ ...S.bs, flex:1 }}>💾 Save Changes</button>
              <button onClick={()=>{setEditingQ(null);setEditDraft(null);}} style={{ ...S.bg, flex:1 }}>Cancel</button>
            </div>
          </div>
        </div>
      )}
      <style>{`@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}`}</style>
    </div>
  );
}
// ═══════════════════════════════════════════════════════
// FEATURE 19B — Create Exam via Copy-Paste
// ═══════════════════════════════════════════════════════
function CopyPasteCreateExamView({ API, token, onNav }: { API:string; token:string; onNav:(v:View)=>void }) {
  const isMobile = useIsMobile();
  const getToken = () => typeof window !== 'undefined' ? localStorage.getItem('pr_token')||'' : token;

  // STEP 1/2 — Questions + Answer Key + Explanation input (F19B.1/19B.2)
  const [engText, setEngText] = useState('');
  const [hindiText, setHindiText] = useState('');
  const [ansKey, setAnsKey] = useState('');
  const [explText, setExplText] = useState('');
  const [customDelim, setCustomDelim] = useState('');
  // F19B.1B — subject-per-question allotment textarea
  const [subjectMapText, setSubjectMapText] = useState('');

  const [parsedQs, setParsedQs] = useState<ParsedQ[]>([]);
  const [isParsing, setIsParsing] = useState(false);

  // STEP 5 — Exam Details / STEP 6 — Assignment / STEP 8 — Post-Create
  const [examD, setExamD] = useState<ExamDetailsState>(defaultExamDetails());
  const [assign, setAssign] = useState<AssignmentState>(defaultAssignment());
  const [postC, setPostC] = useState<PostCreateState>(defaultPostCreate());

  const [previewMode, setPreviewMode] = useState<'parsed'|'exam'>('parsed'); // F19B.4.1 toggle
  const [editingQ, setEditingQ] = useState<ParsedQ|null>(null);
  const [editDraft, setEditDraft] = useState<ParsedQ|null>(null);

  const [creating, setCreating] = useState(false);
  const [createMsg, setCreateMsg] = useState('');
  const [createdExam, setCreatedExam] = useState<any>(null);

  // F19B.1B — parse "Q1-Q45 Physics; Q46-Q90 Chemistry" or "Q1. Physics" into a num->subject map
  const parseSubjectMap = (text:string): Record<number,string> => {
    const map: Record<number,string> = {};
    if (!text.trim()) return map;
    text.split(/[;\n]+/).map(s=>s.trim()).filter(Boolean).forEach(chunk => {
      const range = chunk.match(/Q?\s*(\d+)\s*-\s*Q?\s*(\d+)\s+([A-Za-z\s]+)/i);
      if (range) { const f=parseInt(range[1]), t=parseInt(range[2]), s=range[3].trim(); for(let i=f;i<=t;i++) map[i]=s; return; }
      const single = chunk.match(/Q?\s*(\d+)[\.\)\:\-\s]+([A-Za-z\s]+)/i);
      if (single) map[parseInt(single[1])] = single[2].trim();
    });
    return map;
  };

  useEffect(() => {
    if (!engText.trim()) { setParsedQs([]); return; }
    setIsParsing(true);
    const t = setTimeout(() => {
      const result = parseAll(engText, hindiText, ansKey, explText, customDelim);
      const sMap = parseSubjectMap(subjectMapText);
      const withSubj = result.map(q => ({ ...q, subject: sMap[q.num] || q.subject || 'General' }));
      setParsedQs(withSubj);
      setIsParsing(false);
    }, 400);
    return () => clearTimeout(t);
  }, [engText, hindiText, ansKey, explText, customDelim, subjectMapText]);

  // BUGFIX: subject dropdown must be populated from what was actually detected/allotted
  // in the pasted content — not a hardcoded static list.
  const detectedSubjects = [...new Set(parsedQs.map(q => q.subject).filter(Boolean))] as string[];

  const goodQs = parsedQs.filter(q => !q.hasError);
  const errQs = parsedQs.filter(q => q.hasError);

  const saveEdit = () => {
    if (!editDraft) return;
    setParsedQs(prev => prev.map(q => q.id === editDraft.id ? editDraft : q));
    setEditingQ(null); setEditDraft(null);
  };

  const handleCreate = async () => {
    if (!examD.title.trim()) { setCreateMsg('❌ Exam title required'); return; }
    if (goodQs.length === 0) { setCreateMsg('❌ No valid questions to create exam'); return; }
    setCreating(true); setCreateMsg('');
    try {
      const payload = {
        questions: goodQs,
        examDetails: {
          title: examD.title, subject: examD.subjects.join(', '), category: examD.category, type: examD.examType,
          duration: examD.duration, totalMarks: examD.totalMarks,
          markingScheme: { correct: examD.correctMarks, incorrect: examD.negativeMarks, unattempted: 0 },
          schedule: { startTime: examD.startTime||undefined, endTime: examD.endTime||undefined, resultTime: examD.resultDateTime||undefined },
          customInstructions: examD.customInstructions,
          password: examD.passwordEnabled ? examD.password : '',
          waitingRoomEnabled: examD.waitingRoomEnabled, waitingRoomMinutes: examD.waitingRoomMinutes,
          reattemptCount: examD.reattemptCount, unlimitedAttempts: examD.unlimitedAttempts, maxAttempts: examD.maxAttempts,
          watermark: examD.watermark,
          totalQuestionsRequested: examD.totalQuestionsRequested, subjectWiseCount: examD.subjectWiseCount,
        },
        assignment: {
          assignmentType: assign.assignmentType, batch: assign.batch,
          multiBatch: assign.multiBatchEnabled ? assign.multiBatch : [],
          testSeriesId: assign.testSeriesId, notifyStudents: assign.notifyStudents,
        },
        postCreate: {
          scheduledPublish: { enabled: postC.scheduledPublishEnabled, publishAt: postC.publishAt||null },
          isTemplate: postC.isTemplate,
        },
      };
      const res = await fetch(`${API}/api/content-forge/paste/create-exam`, {
        method:'POST', headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${getToken()}` },
        body: JSON.stringify(payload),
      });
      const d = await res.json();
      if (!d.success) { setCreateMsg('❌ '+d.message); setCreating(false); return; }
      setCreatedExam(d.exam); // F19B.7.2 — d?.exam?._id
      if (postC.publishNow && d.examId) {
        await fetch(`${API}/api/content-forge/exam/${d.examId}/publish`, { method:'POST', headers:{ Authorization:`Bearer ${getToken()}` } }).catch(()=>{});
      }
      setCreateMsg(`✅ Exam created with ${d.questionsCreated} questions!`); // F19B.7.5 success toast
    } catch (e:any) { setCreateMsg('❌ '+e.message); }
    setCreating(false);
  };

  if (createdExam) {
    const examLink = `${typeof window!=='undefined'?window.location.origin:''}/exam/${createdExam._id}`;
    return (
      <div style={{ textAlign:'center', padding:'60px 20px' }}>
        <div style={{ fontSize:48, marginBottom:16 }}>🎉</div>
        <div style={{ fontSize:20, fontWeight:800, color:C.suc, marginBottom:10 }}>Exam Created Successfully!</div>
        <div style={{ fontSize:13, color:C.dim, marginBottom:20 }}>{createdExam.title}</div>
        <div style={{ display:'flex', gap:10, justifyContent:'center', flexWrap:'wrap' }}>
          <button onClick={()=>{navigator.clipboard?.writeText(examLink);}} style={S.bg}>🔗 Copy Exam Link</button>
          <button onClick={()=>onNav('home')} style={S.bp}>← Back to All Exams</button>
          <button onClick={()=>{setCreatedExam(null);setParsedQs([]);setEngText('');setHindiText('');setAnsKey('');setExplText('');setExamD(defaultExamDetails());}} style={S.bs}>+ Create Another</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ color:C.ts }}>
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:16 }}>
        <button onClick={()=>onNav('cp_home')} style={{ ...S.bg, fontSize:11 }}>← Back</button>
        <PageHero icon="🎯" title="Create Exam via Copy-Paste" subtitle="Paste questions + answer key → build a full exam" badge="Feature 19B" />
      </div>

      <div style={{ display:'grid', gridTemplateColumns:isMobile?'1fr':'65% 35%', gap:16 }}>
        {/* LEFT — Step-by-step form (19B.19.1) */}
        <div>
          <div style={{ ...S.card }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
              <div style={{ fontSize:13, fontWeight:800 }}>📝 Step 1-2 — Questions & Answer Key</div>
              <div style={{ display:'flex', gap:6 }}>
                <button onClick={()=>{setEngText(smartClean(engText));setHindiText(smartClean(hindiText));}} style={{ ...S.bg, fontSize:10, padding:'5px 10px' }}>🧹 Smart Clean</button>
                <button onClick={()=>{setEngText('');setHindiText('');setAnsKey('');setExplText('');setSubjectMapText('');}} style={{ ...S.bg, fontSize:10, padding:'5px 10px', color:C.err, borderColor:'rgba(255,77,77,0.3)' }}>🗑️ Clear</button>
              </div>
            </div>
            <div style={{ display:'flex', gap:8, marginBottom:10 }}>
              <input value={customDelim} onChange={e=>setCustomDelim(e.target.value)} placeholder="Custom delimiter e.g. ---" style={{ ...S.inp, flex:1 }} />
            </div>
            <div style={{ display:'flex', justifyContent:'space-between' }}><label style={S.lbl}>English Questions Text</label><span style={{ fontSize:9, color:C.dim }}>{engText.length} chars</span></div>
            <textarea value={engText} onChange={e=>setEngText(e.target.value)} rows={8} placeholder="Q1. What is osmosis?\nA) ...\nB) ..." style={{ ...S.inp, marginBottom:10 }} />
            <div style={{ display:'flex', justifyContent:'space-between' }}><label style={S.lbl}>Hindi Questions Text (optional)</label><span style={{ fontSize:9, color:C.dim }}>{hindiText.length} chars</span></div>
            <textarea value={hindiText} onChange={e=>setHindiText(e.target.value)} rows={4} style={{ ...S.inp, marginBottom:10 }} />
            <label style={S.lbl}>Subject Allotment — "Q1-Q45 Physics; Q46-Q90 Chemistry" or "Q1. Physics"</label>
            <textarea value={subjectMapText} onChange={e=>setSubjectMapText(e.target.value)} rows={2} style={{ ...S.inp, marginBottom:10 }} />
            <label style={S.lbl}>Answer Key — "1-A, 2-(A,B,D), 3-96"</label>
            <textarea value={ansKey} onChange={e=>setAnsKey(e.target.value)} rows={4} style={{ ...S.inp, marginBottom:10, fontFamily:'monospace', color:'#6EE7B7' }} />
            <label style={S.lbl}>Explanations (optional) — will show only in post-result solution view</label>
            <textarea value={explText} onChange={e=>setExplText(e.target.value)} rows={4} style={{ ...S.inp, color:'#FCA5A5' }} />
          </div>


          <ExamDetailsForm d={examD} setD={setExamD} totalParsed={parsedQs.length} detectedSubjects={detectedSubjects} />
          <AssignmentSelector a={assign} setA={setAssign} API={API} token={getToken()} />
          <PostCreateActions p={postC} setP={setPostC} />

          <DuplicateCheckPanel texts={goodQs.map(q=>q.text)} batch={assign.batch} API={API} token={getToken()} />
          <PreSubmitChecklist questionsOk={goodQs.length>0} titleOk={!!examD.title.trim()} dateOk={!!examD.startTime} batchOk={assign.assignmentType==='individual'||!!assign.batch||!!assign.seriesName} />
          <button onClick={handleCreate} disabled={creating} style={{ ...S.bp, width:'100%', padding:14, fontSize:14, opacity:creating?0.6:1 }}>
            {creating ? '⟳ Creating Exam...' : `Create Exam (${goodQs.length} Qs) →`}
          </button>
          {createMsg && <div style={{ marginTop:10, padding:10, borderRadius:8, fontSize:12, background:createMsg.startsWith('✅')?'rgba(0,196,140,0.1)':'rgba(255,77,77,0.1)', color:createMsg.startsWith('✅')?C.suc:C.err }}>{createMsg}</div>}
        </div>

        {/* RIGHT — Live preview toggle (19B.4.1 / 19B.19.2) */}
        <div>
          <div style={{ display:'flex', gap:6, marginBottom:10 }}>
            <button onClick={()=>setPreviewMode('parsed')} style={{ flex:1, padding:8, borderRadius:8, border:`1px solid ${previewMode==='parsed'?C.acc:C.bor}`, background:previewMode==='parsed'?'rgba(77,159,255,0.15)':'transparent', color:previewMode==='parsed'?C.acc:C.dim, cursor:'pointer', fontSize:11, fontWeight:700 }}>📋 All Parsed Qs</button>
            <button onClick={()=>setPreviewMode('exam')} style={{ flex:1, padding:8, borderRadius:8, border:`1px solid ${previewMode==='exam'?C.acc:C.bor}`, background:previewMode==='exam'?'rgba(77,159,255,0.15)':'transparent', color:previewMode==='exam'?C.acc:C.dim, cursor:'pointer', fontSize:11, fontWeight:700 }}>🎯 Live Exam Preview</button>
          </div>
          <div style={{ display:'flex', gap:8, marginBottom:10, flexWrap:'wrap' }}>
            <span style={{ fontSize:11, padding:'4px 10px', borderRadius:20, background:'rgba(77,159,255,0.12)', color:C.acc, fontWeight:700 }}>📝 {parsedQs.length} Detected</span>
            {goodQs.length>0 && <span style={{ fontSize:11, padding:'4px 10px', borderRadius:20, background:'rgba(0,196,140,0.1)', color:C.suc, fontWeight:700 }}>{goodQs.length} ✅</span>}
            {errQs.length>0 && <span style={{ fontSize:11, padding:'4px 10px', borderRadius:20, background:'rgba(255,77,77,0.1)', color:C.err, fontWeight:700 }}>{errQs.length} ❌</span>}
          </div>

          <div style={{ height:isMobile?420:'calc(100vh - 320px)', overflowY:'auto' }}>
            {parsedQs.length===0 && <div style={{ textAlign:'center', padding:40, color:C.dim }}>Paste questions on the left to see live preview</div>}
            {previewMode==='parsed' && parsedQs.map((q,i)=>(
              <QuestionPreviewCard key={q.id} q={q} accent={C.acc}
                onMoveUp={()=>setParsedQs(prev=>moveQuestion(prev,i,'up'))}
                onMoveDown={()=>setParsedQs(prev=>moveQuestion(prev,i,'down'))}
                onEdit={()=>{setEditingQ(q);setEditDraft({...q});}}
                onDelete={()=>setParsedQs(prev=>prev.filter(x=>x.id!==q.id))}
              />
            ))}
            {previewMode==='exam' && (
              <div>
                <div style={{ ...S.card, padding:14, marginBottom:10 }}>
                  <div style={{ fontSize:13, fontWeight:800, color:C.ts }}>{examD.title || 'Untitled Exam'}</div>
                  <div style={{ fontSize:10, color:C.dim, marginTop:4 }}>{examD.examType} · {examD.duration} mins · {examD.totalMarks} marks · {goodQs.length} Qs</div>
                </div>
                {goodQs.map((q,i)=> <QuestionPreviewCard key={q.id} q={q} index={i} accent={C.acc} />)}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Edit Modal — reused pattern */}
      {editingQ && editDraft && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.85)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:16 }} onClick={e=>e.target===e.currentTarget&&setEditingQ(null)}>
          <div style={{ width:'100%', maxWidth:580, maxHeight:'90vh', overflowY:'auto', background:'#020D18', border:`1px solid ${C.bor}`, borderRadius:18, padding:24 }}>
            <div style={{ fontSize:15, fontWeight:700, marginBottom:16 }}>✏️ Edit Q{editDraft.num}</div>
            <label style={S.lbl}>Text</label>
            <textarea value={editDraft.text} onChange={e=>setEditDraft(p=>p?{...p,text:e.target.value}:null)} rows={3} style={{ ...S.inp, marginBottom:10 }} />
            <label style={S.lbl}>Image URL (optional)</label>
            <input value={editDraft.imageUrl||''} onChange={e=>setEditDraft(p=>p?{...p,imageUrl:e.target.value}:null)} style={{ ...S.inp, marginBottom:10 }} />
            {editDraft.options.map((opt,j)=>(
              <div key={j} style={{ display:'flex', gap:8, marginBottom:6, alignItems:'center' }}>
                <span style={{ color:C.acc, width:20 }}>{String.fromCharCode(65+j)})</span>
                <input value={opt} onChange={e=>{const o=[...editDraft.options];o[j]=e.target.value;setEditDraft(p=>p?{...p,options:o}:null);}} style={S.inp} />
                <button onClick={()=>{const correct=editDraft.correct.includes(j)?editDraft.correct.filter(x=>x!==j):[...editDraft.correct,j];setEditDraft(p=>p?{...p,correct}:null);}} style={{ fontSize:10, padding:'4px 8px', borderRadius:6, border:`1px solid ${editDraft.correct.includes(j)?'rgba(0,196,140,0.5)':C.bor}`, background:'transparent', color:editDraft.correct.includes(j)?C.suc:C.dim, cursor:'pointer' }}>{editDraft.correct.includes(j)?'✅':'Set'}</button>
              </div>
            ))}
            <label style={{ ...S.lbl, marginTop:8 }}>Subject</label>
            <input value={editDraft.subject||''} onChange={e=>setEditDraft(p=>p?{...p,subject:e.target.value}:null)} style={{ ...S.inp, marginBottom:10 }} />
            <label style={S.lbl}>Explanation (shown in post-result solution only)</label>
            <textarea value={editDraft.explanation||''} onChange={e=>setEditDraft(p=>p?{...p,explanation:e.target.value}:null)} rows={2} style={{ ...S.inp, marginBottom:10 }} />
            <div style={{ display:'flex', gap:8 }}>
              <button onClick={saveEdit} style={{ ...S.bs, flex:1 }}>💾 Save</button>
              <button onClick={()=>{setEditingQ(null);setEditDraft(null);}} style={{ ...S.bg, flex:1 }}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
// ═══════════════════════════════════════════════════════
// SHARED — Excel/CSV Upload + Parse widget (F20.1-20.13 / F20B.1-20B.9)
// ═══════════════════════════════════════════════════════
const CANONICAL_FIELDS = ['Q_No','Question_Text','Hindi_Text','Option_A','Option_B','Option_C','Option_D','Hindi_A','Hindi_B','Hindi_C','Hindi_D','Correct_Answer','Subject','Chapter','Topic','Difficulty','Type','Explanation','Image_URL','OptionsImage_URL','Tags','Ignore'];

function ExcelUploadZone({ API, token, onParsed }: { API:string; token:string; onParsed:(qs:ParsedQ[], summary:any)=>void }) {
  const [file, setFile] = useState<File|null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [parsing, setParsing] = useState(false);
  const [error, setError] = useState('');
  const [gsheetUrl, setGsheetUrl] = useState(''); // F20.12
  const fileRef = useRef<HTMLInputElement>(null);

  // F20.17 — Column mapping UI state
  const [rawHeaders, setRawHeaders] = useState<string[]>([]);
  const [columnMap, setColumnMap] = useState<Record<string,string>>({});
  const [showMapping, setShowMapping] = useState(false);

  // F20.14 — Re-upload to fix errors, matched by row number
  const [prevErrorRows, setPrevErrorRows] = useState<Set<number>>(new Set());
  const [reuploadDiff, setReuploadDiff] = useState<{fixed:number[]; stillErroring:number[]}|null>(null);

  // F20.15 — Import history panel
  const [historyOpen, setHistoryOpen] = useState(false);
  const [historyLogs, setHistoryLogs] = useState<any[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  const downloadTemplate = () => { // F20.2
    window.open(`${API}/api/content-forge/excel/template`, '_blank');
  };

  const loadHistory = async () => { // F20.15
    setHistoryOpen(true); setHistoryLoading(true);
    try {
      const res = await fetch(`${API}/api/content-forge/import-history`, { headers:{ Authorization:`Bearer ${token}` } });
      const d = await res.json();
      setHistoryLogs(d.logs || []);
    } catch (e) { setHistoryLogs([]); }
    setHistoryLoading(false);
  };

  const toParsedQ = (rows:any[]): ParsedQ[] => rows.map((q,i) => ({
    id: 'ex_'+(q.qNo||i)+'_'+i,
    num: parseInt(q.qNo) || i+1,
    text: q.text||'', hindiText: q.hindiText||'',
    options: q.options||[], hindiOptions: q.hindiOptions||[],
    correct: q.correct||[], correctLetter: (q.correct||[]).map((c:number)=>['A','B','C','D'][c]).join(','),
    explanation: q.explanation||'', hasError:false, error:'',
    subject:q.subject, chapter:q.chapter, difficulty:q.difficulty, type:q.type,
    imageUrl:q.imageUrl, optionImages:q.optionImages,
    isDuplicateInDB:q.isDuplicateInDB, isDuplicateInFile:q.isDuplicateInFile,
  }));

  const parseFile = async (f:File, opts?: { isReupload?: boolean; map?: Record<string,string> }) => { // F20.3 parse & validate
    setParsing(true); setError('');
    try {
      const fd = new FormData();
      fd.append('file', f);
      const mapToUse = opts?.map || columnMap;
      if (Object.keys(mapToUse).length > 0) fd.append('columnMap', JSON.stringify(mapToUse)); // F20.17
      const res = await fetch(`${API}/api/content-forge/excel/parse`, { method:'POST', headers:{ Authorization:`Bearer ${token}` }, body:fd });
      const d = await res.json();
      if (!d.success) { setError(d.message); setParsing(false); return; }

      if (d.rawHeaders) setRawHeaders(d.rawHeaders); // F20.17 — store for mapping UI

      const newErrorRows: number[] = (d.errors||[]).map((er:any)=>er.row).filter((r:any)=>typeof r === 'number');
      if (opts?.isReupload) { // F20.14 — compare against previous error rows
        const fixed = [...prevErrorRows].filter(r => !newErrorRows.includes(r));
        const stillErroring = [...prevErrorRows].filter(r => newErrorRows.includes(r));
        setReuploadDiff({ fixed, stillErroring });
      } else {
        setReuploadDiff(null);
      }
      setPrevErrorRows(new Set(newErrorRows));

      const parsedRows = toParsedQ(d.questions);
      const errorRows: ParsedQ[] = (d.errors||[]).map((er:any,i:number)=>({
        id:'err_'+i, num: er.row||0, text:`[Row ${er.row}] ${er.message}`, hindiText:'', options:[], hindiOptions:[],
        correct:[], correctLetter:'', explanation:'', hasError:true, error:er.message,
      }));
      onParsed([...parsedRows, ...errorRows], d.summary);
    } catch(e:any) { setError(e.message); }
    setParsing(false);
  };

  const importGoogleSheet = async () => { // F20.12 / F20B.11
    if (!gsheetUrl.trim()) return;
    setParsing(true); setError('');
    try {
      const res = await fetch(`${API}/api/content-forge/excel/google-sheet`, {
        method:'POST', headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${token}` },
        body: JSON.stringify({ url: gsheetUrl }),
      });
      const d = await res.json();
      if (!d.success) { setError(d.message); setParsing(false); return; }
      onParsed(toParsedQ(d.questions), { valid: d.questions.length, errors: (d.errors||[]).length });
    } catch(e:any) { setError(e.message); }
    setParsing(false);
  };

  // F20.17 — detect headers that didn't auto-map to a canonical name (best-effort: just list raw headers for manual override)
  const applyMapping = () => {
    if (file) parseFile(file, { map: columnMap });
    setShowMapping(false);
  };

  return (
    <div style={{ ...S.card }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
        <div style={{ fontSize:13, fontWeight:800 }}>📊 Step 1-2 — Upload Excel / CSV</div>
        <div style={{ display:'flex', gap:8 }}>
          <button onClick={loadHistory} style={{ ...S.bg, fontSize:11 }}>🕘 Import History</button>
          <button onClick={downloadTemplate} style={{ ...S.bg, fontSize:11 }}>📥 Download Template</button>
        </div>
      </div>

      {/* F20.15 — Import History panel */}
      {historyOpen && (
        <div style={{ marginBottom:10, padding:10, background:'rgba(0,22,40,0.5)', borderRadius:10, border:`1px solid ${C.bor}` }}>
          <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
            <span style={{ fontSize:11, fontWeight:700, color:C.ts }}>Recent Imports</span>
            <button onClick={()=>setHistoryOpen(false)} style={{ fontSize:10, color:C.dim, background:'transparent', border:'none', cursor:'pointer' }}>✕</button>
          </div>
          {historyLoading && <div style={{ fontSize:10, color:C.dim }}>Loading...</div>}
          {!historyLoading && historyLogs.length===0 && <div style={{ fontSize:10, color:C.dim }}>No imports yet.</div>}
          {historyLogs.map((log,i)=>(
            <div key={i} style={{ fontSize:10, color:C.dim, padding:'4px 0', borderBottom:`1px solid ${C.bor}` }}>
              {log.sourceType==='excel'?'📊':'📄'} {log.target} — ✅{log.imported} imported, ⚠️{log.skipped} skipped, ❌{log.errorCount} errors — {new Date(log.createdAt).toLocaleString()}
            </div>
          ))}
        </div>
      )}

      <div
        onDragOver={e=>{e.preventDefault();setDragOver(true);}}
        onDragLeave={()=>setDragOver(false)}
        onDrop={e=>{e.preventDefault();setDragOver(false);const f=e.dataTransfer.files[0];if(f){const isReupload=!!file;setFile(f);parseFile(f,{isReupload});}}}
        onClick={()=>fileRef.current?.click()}
        style={{ border:`2px dashed ${dragOver?C.suc:C.bor}`, borderRadius:14, padding:'30px 16px', textAlign:'center', cursor:'pointer', background:dragOver?'rgba(0,196,140,0.06)':'rgba(0,22,40,0.4)', transition:'all 0.2s', marginBottom:10 }}>
        <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" style={{ display:'none' }} onChange={e=>{const f=e.target.files?.[0];if(f){const isReupload=!!file;setFile(f);parseFile(f,{isReupload});}}} />
        <div style={{ fontSize:32, marginBottom:8 }}>📊</div>
        {!file && <div style={{ fontSize:12, color:C.dim }}>Drag & drop .xlsx / .xls / .csv here, or click to browse (max 10MB)</div>}
        {file && (
          <div style={{ fontSize:12, color:C.ts }}>
            📄 {file.name} <span style={{ color:C.dim }}>({(file.size/1024).toFixed(1)} KB)</span>
            <button onClick={(e)=>{e.stopPropagation();setFile(null);setPrevErrorRows(new Set());setReuploadDiff(null);}} style={{ marginLeft:8, color:C.err, background:'transparent', border:'none', cursor:'pointer' }}>✕ Remove</button>
            {prevErrorRows.size > 0 && <div style={{ fontSize:10, color:C.gold, marginTop:4 }}>💡 Fixed the file? Click/drop again above to re-upload — we'll tell you which error rows got fixed.</div>}
          </div>
        )}
        {parsing && <div style={{ fontSize:11, color:C.acc, marginTop:8 }}>⟳ Parsing rows...</div>}
      </div>

      {/* F20.14 — Re-upload comparison result */}
      {reuploadDiff && (
        <div style={{ marginBottom:10, padding:10, borderRadius:8, background:'rgba(0,196,140,0.06)', border:'1px solid rgba(0,196,140,0.25)' }}>
          {reuploadDiff.fixed.length > 0 && <div style={{ fontSize:11, color:C.suc }}>✅ Fixed rows: {reuploadDiff.fixed.join(', ')}</div>}
          {reuploadDiff.stillErroring.length > 0 && <div style={{ fontSize:11, color:C.err, marginTop:4 }}>❌ Still erroring rows: {reuploadDiff.stillErroring.join(', ')}</div>}
          {reuploadDiff.fixed.length===0 && reuploadDiff.stillErroring.length===0 && <div style={{ fontSize:11, color:C.suc }}>✅ No errors remaining</div>}
        </div>
      )}

      {/* F20.17 — Column mapping UI */}
      {rawHeaders.length > 0 && (
        <div style={{ marginBottom:10 }}>
          <button onClick={()=>setShowMapping(!showMapping)} style={{ ...S.bg, fontSize:11 }}>🔧 {showMapping?'Hide':'Adjust'} Column Mapping ({rawHeaders.length} columns detected)</button>
          {showMapping && (
            <div style={{ marginTop:8, padding:10, background:'rgba(0,22,40,0.5)', borderRadius:10, border:`1px solid ${C.bor}` }}>
              {rawHeaders.map(h=>(
                <div key={h} style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6 }}>
                  <span style={{ fontSize:11, color:C.ts, flex:1 }}>{h}</span>
                  <span style={{ color:C.dim }}>→</span>
                  <select value={columnMap[h]||''} onChange={e=>setColumnMap(prev=>({...prev,[h]:e.target.value}))} style={{ ...S.inp, flex:1 }}>
                    <option value="">(auto-detect)</option>
                    {CANONICAL_FIELDS.map(f=><option key={f} value={f}>{f}</option>)}
                  </select>
                </div>
              ))}
              <button onClick={applyMapping} style={{ ...S.bs, marginTop:6, fontSize:11 }}>Apply Mapping & Re-parse</button>
            </div>
          )}
        </div>
      )}

      <div style={{ display:'flex', gap:8, alignItems:'center' }}>
        <input value={gsheetUrl} onChange={e=>setGsheetUrl(e.target.value)} placeholder="Or paste Google Sheets public link..." style={{ ...S.inp, flex:1 }} />
        <button onClick={importGoogleSheet} style={{ ...S.bg, fontSize:11, whiteSpace:'nowrap' }}>Import Sheet</button>
      </div>
      {error && <div style={{ marginTop:8, fontSize:11, color:C.err }}>❌ {error}</div>}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// FEATURE 20 (upgraded) — Bulk Upload via Excel/CSV → QB/PYQ Bank
// ═══════════════════════════════════════════════════════
function ExcelQBUploadView({ API, token, onNav }: { API:string; token:string; onNav:(v:View)=>void }) {
  const getToken = () => typeof window !== 'undefined' ? localStorage.getItem('pr_token')||'' : token;
  const [parsedQs, setParsedQs] = useState<ParsedQ[]>([]);
  const [summary, setSummary] = useState<any>(null);
  const [target, setTarget] = useState<'qs_bank'|'pyq_bank'>('qs_bank');
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState('');
  const [editingQ, setEditingQ] = useState<ParsedQ|null>(null);
  const [editDraft, setEditDraft] = useState<ParsedQ|null>(null);

  const rowStatus = (q:ParsedQ) => q.hasError ? 'error' : (q.isDuplicateInDB||q.isDuplicateInFile) ? 'duplicate' : 'valid'; // F20.4.2 color coding

  const validCount = parsedQs.filter(q=>rowStatus(q)==='valid').length;
  const dupCount = parsedQs.filter(q=>rowStatus(q)==='duplicate').length;
  const errCount = parsedQs.filter(q=>rowStatus(q)==='error').length;

  const handleImport = async () => { // F20.7/20.8/20.9
    setSaving(true); setSaveMsg('');
    try {
      const res = await fetch(`${API}/api/content-forge/excel/save-to-bank`, {
        method:'POST', headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${getToken()}` },
        body: JSON.stringify({ questions: parsedQs.filter(q=>rowStatus(q)!=='error'), target }),
      });
      const d = await res.json();
      setSaveMsg(d.success ? `✅ ${d.imported} Imported / ${d.skipped} Skipped` : `❌ ${d.message}`); // F20.7.4 import summary
    } catch(e:any) { setSaveMsg('❌ '+e.message); }
    setSaving(false);
  };

  const saveEdit = () => { if(!editDraft) return; setParsedQs(prev=>prev.map(q=>q.id===editDraft.id?editDraft:q)); setEditingQ(null); setEditDraft(null); };

  return (
    <div style={{ color:C.ts }}>
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:16 }}>
        <button onClick={()=>onNav('ex_home')} style={{ ...S.bg, fontSize:11 }}>← Back</button>
        <PageHero icon="📚" title="Upload to QB / PYQ via Excel" subtitle="Upload structured spreadsheet → validate → bulk save" badge="Feature 20" />
      </div>

      <ExcelUploadZone API={API} token={getToken()} onParsed={(qs,sum)=>{setParsedQs(qs);setSummary(sum);}} />

      {parsedQs.length > 0 && (
        <>
          <div style={{ display:'flex', gap:10, margin:'14px 0', flexWrap:'wrap' }}>
            <span style={{ ...S.bg, color:C.suc, borderColor:'rgba(0,196,140,0.3)' }}>✅ {validCount} Valid</span>
            <span style={{ ...S.bg, color:C.wrn, borderColor:'rgba(255,184,77,0.3)' }}>⚠️ {dupCount} Duplicate</span>
            <span style={{ ...S.bg, color:C.err, borderColor:'rgba(255,77,77,0.3)' }}>❌ {errCount} Error</span>
            <select value={target} onChange={e=>setTarget(e.target.value as any)} style={{ ...S.inp, width:200, marginLeft:'auto' }}>
              <option value="qs_bank">📚 Question Bank</option>
              <option value="pyq_bank">📜 PYQ Bank</option>
            </select>
          </div>

          <div style={{ maxHeight:500, overflowY:'auto', marginBottom:14 }}>
            {parsedQs.map(q=>(
              <QuestionPreviewCard key={q.id} q={q} accent={C.green}
                onEdit={()=>{setEditingQ(q);setEditDraft({...q});}}
                onDelete={()=>setParsedQs(prev=>prev.filter(x=>x.id!==q.id))}
              />
            ))}
          </div>

          <button onClick={handleImport} disabled={saving||validCount===0} style={{ ...S.bp, width:'100%', padding:14, opacity:saving||validCount===0?0.6:1 }}>
            {saving?'⟳ Importing...':`Import ${validCount} Valid Questions →`}
          </button>
          {saveMsg && <div style={{ marginTop:10, padding:10, borderRadius:8, fontSize:12, background:saveMsg.startsWith('✅')?'rgba(0,196,140,0.1)':'rgba(255,77,77,0.1)', color:saveMsg.startsWith('✅')?C.suc:C.err }}>{saveMsg}</div>}
        </>
      )}

      {editingQ && editDraft && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.85)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:16 }} onClick={e=>e.target===e.currentTarget&&setEditingQ(null)}>
          <div style={{ width:'100%', maxWidth:520, background:'#020D18', border:`1px solid ${C.bor}`, borderRadius:18, padding:24, maxHeight:'85vh', overflowY:'auto' }}>
            <div style={{ fontSize:15, fontWeight:700, marginBottom:14 }}>✏️ Edit Q{editDraft.num}</div>
            <textarea value={editDraft.text} onChange={e=>setEditDraft(p=>p?{...p,text:e.target.value}:null)} rows={3} style={{ ...S.inp, marginBottom:10 }} />
            <input value={editDraft.subject||''} onChange={e=>setEditDraft(p=>p?{...p,subject:e.target.value}:null)} placeholder="Subject" style={{ ...S.inp, marginBottom:10 }} />
            <div style={{ display:'flex', gap:8 }}>
              <button onClick={saveEdit} style={{ ...S.bs, flex:1 }}>💾 Save</button>
              <button onClick={()=>{setEditingQ(null);setEditDraft(null);}} style={{ ...S.bg, flex:1 }}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
// ═══════════════════════════════════════════════════════
// FEATURE 20B — Create Exam via Excel/CSV
// ═══════════════════════════════════════════════════════
function ExcelCreateExamView({ API, token, onNav }: { API:string; token:string; onNav:(v:View)=>void }) {
  const isMobile = useIsMobile();
  const getToken = () => typeof window !== 'undefined' ? localStorage.getItem('pr_token')||'' : token;
  const [parsedQs, setParsedQs] = useState<ParsedQ[]>([]);
  const [examD, setExamD] = useState<ExamDetailsState>(defaultExamDetails());
  const [assign, setAssign] = useState<AssignmentState>(defaultAssignment());
  const [postC, setPostC] = useState<PostCreateState>(defaultPostCreate());
  const [previewMode, setPreviewMode] = useState<'parsed'|'exam'>('parsed');
  const [creating, setCreating] = useState(false);
  const [createMsg, setCreateMsg] = useState('');
  const [createdExam, setCreatedExam] = useState<any>(null);
  const [editingQ, setEditingQ] = useState<ParsedQ|null>(null);
  const [editDraft, setEditDraft] = useState<ParsedQ|null>(null);

  const goodQs = parsedQs.filter(q => !q.hasError && !q.isDuplicateInDB && !q.isDuplicateInFile);
  const errQs = parsedQs.filter(q => q.hasError);
  // BUGFIX: subject dropdown populated from subjects actually present in the uploaded sheet
  const detectedSubjects = [...new Set(parsedQs.map(q => q.subject).filter(Boolean))] as string[];

  const saveEdit = () => { if(!editDraft) return; setParsedQs(prev=>prev.map(q=>q.id===editDraft.id?editDraft:q)); setEditingQ(null); setEditDraft(null); };

  const handleCreate = async () => {
    if (!examD.title.trim()) { setCreateMsg('❌ Exam title required'); return; }
    if (goodQs.length === 0) { setCreateMsg('❌ No valid questions to create exam'); return; }
    setCreating(true); setCreateMsg('');
    try {
      const payload = {
        questions: goodQs,
        examDetails: {
          title: examD.title, subject: examD.subjects.join(', '), category: examD.category, type: examD.examType,
          duration: examD.duration, totalMarks: examD.totalMarks,
          markingScheme: { correct: examD.correctMarks, incorrect: examD.negativeMarks, unattempted: 0 },
          schedule: { startTime: examD.startTime||undefined, endTime: examD.endTime||undefined, resultTime: examD.resultDateTime||undefined },
          customInstructions: examD.customInstructions,
          password: examD.passwordEnabled ? examD.password : '',
          waitingRoomEnabled: examD.waitingRoomEnabled, waitingRoomMinutes: examD.waitingRoomMinutes,
          reattemptCount: examD.reattemptCount, unlimitedAttempts: examD.unlimitedAttempts, maxAttempts: examD.maxAttempts,
          watermark: examD.watermark,
          totalQuestionsRequested: examD.totalQuestionsRequested, subjectWiseCount: examD.subjectWiseCount,
        },
        assignment: {
          assignmentType: assign.assignmentType, batch: assign.batch,
          multiBatch: assign.multiBatchEnabled ? assign.multiBatch : [],
          testSeriesId: assign.testSeriesId, notifyStudents: assign.notifyStudents,
        },
        postCreate: {
          scheduledPublish: { enabled: postC.scheduledPublishEnabled, publishAt: postC.publishAt||null },
          isTemplate: postC.isTemplate,
        },
        sourceMeta: { fileName: 'excel-upload', uploadedAt: new Date().toISOString(), totalParsed: parsedQs.length, totalErrors: errQs.length },
      };
      const res = await fetch(`${API}/api/content-forge/excel/create-exam`, {
        method:'POST', headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${getToken()}` },
        body: JSON.stringify(payload),
      });
      const d = await res.json();
      if (!d.success) { setCreateMsg('❌ '+d.message); setCreating(false); return; }
      setCreatedExam(d.exam); // F20B.7.2 — exam._id
      if (postC.publishNow && d.examId) {
        await fetch(`${API}/api/content-forge/exam/${d.examId}/publish`, { method:'POST', headers:{ Authorization:`Bearer ${getToken()}` } }).catch(()=>{});
      }
      setCreateMsg(`✅ Exam created with ${d.questionsCreated} questions!`);
    } catch (e:any) { setCreateMsg('❌ '+e.message); }
    setCreating(false);
  };

  if (createdExam) {
    const examLink = `${typeof window!=='undefined'?window.location.origin:''}/exam/${createdExam._id}`;
    return (
      <div style={{ textAlign:'center', padding:'60px 20px' }}>
        <div style={{ fontSize:48, marginBottom:16 }}>🎉</div>
        <div style={{ fontSize:20, fontWeight:800, color:C.suc, marginBottom:10 }}>Exam Created Successfully!</div>
        <div style={{ fontSize:13, color:C.dim, marginBottom:20 }}>{createdExam.title}</div>
        <div style={{ display:'flex', gap:10, justifyContent:'center', flexWrap:'wrap' }}>
          <button onClick={()=>{navigator.clipboard?.writeText(examLink);}} style={S.bg}>🔗 Copy Exam Link</button>
          <button onClick={()=>onNav('home')} style={S.bp}>← Back to All Exams</button>
          <button onClick={()=>{setCreatedExam(null);setParsedQs([]);setExamD(defaultExamDetails());}} style={S.bs}>+ Create Another</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ color:C.ts }}>
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:16 }}>
        <button onClick={()=>onNav('ex_home')} style={{ ...S.bg, fontSize:11 }}>← Back</button>
        <PageHero icon="🎯" title="Create Exam via Excel/CSV" subtitle="Upload spreadsheet → validate → build full exam" badge="Feature 20B" />
      </div>

      <div style={{ display:'grid', gridTemplateColumns:isMobile?'1fr':'65% 35%', gap:16 }}>
        <div>
          <ExcelUploadZone API={API} token={getToken()} onParsed={(qs)=>setParsedQs(qs)} />
          <ExamDetailsForm d={examD} setD={setExamD} totalParsed={goodQs.length} detectedSubjects={detectedSubjects} />
          <AssignmentSelector a={assign} setA={setAssign} API={API} token={getToken()} />
          <PostCreateActions p={postC} setP={setPostC} />
          <DuplicateCheckPanel texts={goodQs.map(q=>q.text)} batch={assign.batch} API={API} token={getToken()} />
          <PreSubmitChecklist questionsOk={goodQs.length>0} titleOk={!!examD.title.trim()} dateOk={!!examD.startTime} batchOk={assign.assignmentType==='individual'||!!assign.batch||!!assign.seriesName} />
          <button onClick={handleCreate} disabled={creating} style={{ ...S.bp, width:'100%', padding:14, fontSize:14, opacity:creating?0.6:1 }}>
            {creating ? '⟳ Creating Exam...' : `Create Exam (${goodQs.length} Qs) →`}
          </button>
          {createMsg && <div style={{ marginTop:10, padding:10, borderRadius:8, fontSize:12, background:createMsg.startsWith('✅')?'rgba(0,196,140,0.1)':'rgba(255,77,77,0.1)', color:createMsg.startsWith('✅')?C.suc:C.err }}>{createMsg}</div>}
        </div>

        <div>
          <div style={{ display:'flex', gap:6, marginBottom:10 }}>
            <button onClick={()=>setPreviewMode('parsed')} style={{ flex:1, padding:8, borderRadius:8, border:`1px solid ${previewMode==='parsed'?C.green:C.bor}`, background:previewMode==='parsed'?'rgba(0,196,140,0.15)':'transparent', color:previewMode==='parsed'?C.green:C.dim, cursor:'pointer', fontSize:11, fontWeight:700 }}>📋 Parsed Rows</button>
            <button onClick={()=>setPreviewMode('exam')} style={{ flex:1, padding:8, borderRadius:8, border:`1px solid ${previewMode==='exam'?C.green:C.bor}`, background:previewMode==='exam'?'rgba(0,196,140,0.15)':'transparent', color:previewMode==='exam'?C.green:C.dim, cursor:'pointer', fontSize:11, fontWeight:700 }}>🎯 Exam Preview</button>
          </div>
          <div style={{ display:'flex', gap:8, marginBottom:10, flexWrap:'wrap' }}>
            <span style={{ fontSize:11, padding:'4px 10px', borderRadius:20, background:'rgba(0,196,140,0.12)', color:C.green, fontWeight:700 }}>{goodQs.length} Valid</span>
            {errQs.length>0 && <span style={{ fontSize:11, padding:'4px 10px', borderRadius:20, background:'rgba(255,77,77,0.1)', color:C.err, fontWeight:700 }}>{errQs.length} ❌</span>}
          </div>
          <div style={{ height:isMobile?420:'calc(100vh - 320px)', overflowY:'auto' }}>
            {parsedQs.length===0 && <div style={{ textAlign:'center', padding:40, color:C.dim }}>Upload a file on the left to preview</div>}
            {previewMode==='parsed' && parsedQs.map((q,i)=>(
              <QuestionPreviewCard key={q.id} q={q} accent={C.green}
                onMoveUp={()=>setParsedQs(prev=>moveQuestion(prev,i,'up'))}
                onMoveDown={()=>setParsedQs(prev=>moveQuestion(prev,i,'down'))}
                onEdit={()=>{setEditingQ(q);setEditDraft({...q});}}
                onDelete={()=>setParsedQs(prev=>prev.filter(x=>x.id!==q.id))}
              />
            ))}
            {previewMode==='exam' && goodQs.map((q,i)=> <QuestionPreviewCard key={q.id} q={q} index={i} accent={C.green} />)}
          </div>
        </div>
      </div>

      {editingQ && editDraft && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.85)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:16 }} onClick={e=>e.target===e.currentTarget&&setEditingQ(null)}>
          <div style={{ width:'100%', maxWidth:520, background:'#020D18', border:`1px solid ${C.bor}`, borderRadius:18, padding:24, maxHeight:'85vh', overflowY:'auto' }}>
            <div style={{ fontSize:15, fontWeight:700, marginBottom:14 }}>✏️ Edit Q{editDraft.num}</div>
            <textarea value={editDraft.text} onChange={e=>setEditDraft(p=>p?{...p,text:e.target.value}:null)} rows={3} style={{ ...S.inp, marginBottom:10 }} />
            <input value={editDraft.imageUrl||''} onChange={e=>setEditDraft(p=>p?{...p,imageUrl:e.target.value}:null)} placeholder="Image URL (optional)" style={{ ...S.inp, marginBottom:10 }} />
            {editDraft.options.map((opt,j)=>(
              <div key={j} style={{ display:'flex', gap:8, marginBottom:6, alignItems:'center' }}>
                <span style={{ color:C.green, width:20 }}>{String.fromCharCode(65+j)})</span>
                <input value={opt} onChange={e=>{const o=[...editDraft.options];o[j]=e.target.value;setEditDraft(p=>p?{...p,options:o}:null);}} style={S.inp} />
                <button onClick={()=>{const correct=editDraft.correct.includes(j)?editDraft.correct.filter(x=>x!==j):[...editDraft.correct,j];setEditDraft(p=>p?{...p,correct}:null);}} style={{ fontSize:10, padding:'4px 8px', borderRadius:6, border:`1px solid ${editDraft.correct.includes(j)?'rgba(0,196,140,0.5)':C.bor}`, background:'transparent', color:editDraft.correct.includes(j)?C.suc:C.dim, cursor:'pointer' }}>{editDraft.correct.includes(j)?'✅':'Set'}</button>
              </div>
            ))}
            <input value={editDraft.subject||''} onChange={e=>setEditDraft(p=>p?{...p,subject:e.target.value}:null)} placeholder="Subject" style={{ ...S.inp, marginTop:10, marginBottom:10 }} />
            <textarea value={editDraft.explanation||''} onChange={e=>setEditDraft(p=>p?{...p,explanation:e.target.value}:null)} placeholder="Explanation" rows={2} style={{ ...S.inp, marginBottom:10 }} />
            <div style={{ display:'flex', gap:8, marginTop:10 }}>
              <button onClick={saveEdit} style={{ ...S.bs, flex:1 }}>💾 Save</button>
              <button onClick={()=>{setEditingQ(null);setEditDraft(null);}} style={{ ...S.bg, flex:1 }}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
// ═══════════════════════════════════════════════════════
// SHARED — PDF Upload + Parse widget (F21.1-21.20 / F21B.1-21B.7)
// ═══════════════════════════════════════════════════════

// BUGFIX: FileSlot must be defined at module scope, NOT inside PDFUploadZone's
// render body. Redefining a component function on every render makes React
// treat it as a different component type each time, forcing it to unmount &
// remount the underlying <input type=file> on every keystroke/state-change —
// this was the root cause of "choose file → nothing happens". Also broadened
// `accept` to include the MIME type (some Android file pickers hide files
// that aren't extension-AND-mimetype tagged when only ".pdf" is given).
function FileSlot({ label, file, setFile, inputRef, required }: { label:string; file:File|null; setFile:(f:File|null)=>void; inputRef:React.RefObject<HTMLInputElement>; required?:boolean }) {
  return (
    <div onClick={()=>inputRef.current?.click()} style={{ border:`2px dashed ${file?C.gold:C.bor}`, borderRadius:12, padding:'16px 10px', textAlign:'center', cursor:'pointer', background:file?'rgba(245,158,11,0.06)':'rgba(0,22,40,0.4)' }}>
      <input ref={inputRef} type="file" accept=".pdf,application/pdf" style={{ display:'none' }} onChange={e=>{ const f=e.target.files?.[0]; setFile(f||null); e.target.value=''; }} />
      <div style={{ fontSize:22, marginBottom:4 }}>📄</div>
      <div style={{ fontSize:10, color:C.dim, marginBottom:2 }}>{label} {required && <span style={{color:C.err}}>*</span>}</div>
      {file ? <div style={{ fontSize:10, color:C.gold }}>{file.name} <span onClick={(e)=>{e.stopPropagation();setFile(null);}} style={{color:C.err,cursor:'pointer'}}>✕</span></div> : <div style={{ fontSize:9, color:C.dim }}>Drop / click (max 10MB)</div>}
    </div>
  );
}

function PDFUploadZone({ API, token, onParsed }: { API:string; token:string; onParsed:(qs:ParsedQ[], meta:any)=>void }) {
  const [qFile, setQFile] = useState<File|null>(null);     // F21.1.6
  const [aFile, setAFile] = useState<File|null>(null);
  const [eFile, setEFile] = useState<File|null>(null);
  const [subjectMapText, setSubjectMapText] = useState(''); // F21.1.7
  const [pageFrom, setPageFrom] = useState('');             // F21.16
  const [pageTo, setPageTo] = useState('');
  const [customDelim, setCustomDelim] = useState('');       // F21.13
  const [parsing, setParsing] = useState(false);
  const [error, setError] = useState('');
  const [rawPreviewOpen, setRawPreviewOpen] = useState(false);
  const [meta, setMeta] = useState<any>(null);

  const qRef = useRef<HTMLInputElement>(null);
  const aRef = useRef<HTMLInputElement>(null);
  const eRef = useRef<HTMLInputElement>(null);

  const toParsedQ = (rows:any[]): ParsedQ[] => rows.map((q,i) => ({
    id: 'pdf_'+(q.num||i)+'_'+i,
    num: q.num||i+1, text: q.text||'', hindiText:'', options: q.options||[], hindiOptions:[],
    correct: q.correct||[], correctLetter:(q.correct||[]).map((c:number)=>['A','B','C','D'][c]).join(','),
    explanation: q.explanation||'', hasError: !!q.hasError, error: q.error||'',
    subject: q.subject, type: q.type, isDuplicateInDB: q.isDuplicateInDB, isDuplicate: q.isDuplicate,
    needsReview: q.needsReview, confidencePct: q.confidencePct, page: q.page,
  }));

  const runParse = async () => { // F21.2-21.7 / F21B.2-21B.7
    if (!qFile) { setError('Question paper PDF required'); return; }
    if (!aFile) { setError('Answer key PDF required'); return; }
    setParsing(true); setError('');
    try {
      const fd = new FormData();
      fd.append('questionsPdf', qFile);
      fd.append('answerKeyPdf', aFile);
      if (eFile) fd.append('explanationPdf', eFile);
      if (subjectMapText) fd.append('subjectMapText', subjectMapText);
      if (pageFrom) fd.append('pageFrom', pageFrom);
      if (pageTo) fd.append('pageTo', pageTo);
      if (customDelim) fd.append('customDelimiter', customDelim);
      const res = await fetch(`${API}/api/content-forge/pdf/parse`, { method:'POST', headers:{ Authorization:`Bearer ${token}` }, body:fd });
      const d = await res.json();
      if (!d.success) { setError(d.message); setParsing(false); return; }
      setMeta(d);
      onParsed(toParsedQ(d.questions), d);
    } catch(e:any) { setError(e.message); }
    setParsing(false);
  };

  return (
    <div style={{ ...S.card }}>
      <div style={{ fontSize:13, fontWeight:800, marginBottom:12 }}>📄 Step 1 — Upload PDFs</div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8, marginBottom:12 }}>
        <FileSlot label="Question Paper" file={qFile} setFile={setQFile} inputRef={qRef} required />
        <FileSlot label="Answer Key" file={aFile} setFile={setAFile} inputRef={aRef} required />
        <FileSlot label="Explanations (optional)" file={eFile} setFile={setEFile} inputRef={eRef} />
      </div>

      <label style={S.lbl}>Subject Allotment — "Q1-Q45 Physics; Q46-Q90 Chemistry" or "Q1. Physics"</label>
      <textarea value={subjectMapText} onChange={e=>setSubjectMapText(e.target.value)} rows={2} style={{ ...S.inp, marginBottom:10 }} />

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8, marginBottom:10 }}>
        <div>
          <label style={S.lbl}>Page From</label>
          <input type="number" value={pageFrom} onChange={e=>setPageFrom(e.target.value)} placeholder="e.g. 5" style={S.inp} />
        </div>
        <div>
          <label style={S.lbl}>Page To</label>
          <input type="number" value={pageTo} onChange={e=>setPageTo(e.target.value)} placeholder="e.g. 40" style={S.inp} />
        </div>
        <div>
          <label style={S.lbl}>Custom Delimiter</label>
          <input value={customDelim} onChange={e=>setCustomDelim(e.target.value)} placeholder="e.g. ---" style={S.inp} />
        </div>
      </div>

      <button onClick={runParse} disabled={parsing} style={{ ...S.bp, width:'100%', opacity:parsing?0.6:1 }}>
        {parsing ? '⟳ Extracting text → Detecting patterns → Syncing answers...' : '🔍 Parse PDFs'}
      </button>
      {error && <div style={{ marginTop:8, fontSize:11, color:C.err }}>❌ {error}</div>}

      {meta && (
        <div style={{ marginTop:10, fontSize:11, color:C.dim }}>
          📃 {meta.pageCount} pages · 🌐 {meta.language} · {meta.summary?.parsed} parsed / {meta.summary?.errors} errors / {meta.summary?.duplicates} duplicates
          <button onClick={()=>setRawPreviewOpen(!rawPreviewOpen)} style={{ marginLeft:10, color:C.acc, background:'transparent', border:'none', cursor:'pointer', fontSize:11 }}>{rawPreviewOpen?'Hide':'View'} Extracted Text</button>
          {rawPreviewOpen && <div style={{ marginTop:6, padding:10, background:'rgba(0,0,0,0.4)', borderRadius:8, fontSize:10, maxHeight:150, overflowY:'auto', whiteSpace:'pre-wrap' }}>{meta.rawTextPreview}</div>}
        </div>
      )}
    </div>
  );
}
// ═══════════════════════════════════════════════════════
// FEATURE 21 (upgraded) — Bulk Upload via PDF Parse → QB/PYQ Bank
// ═══════════════════════════════════════════════════════
function PDFQBUploadView({ API, token, onNav }: { API:string; token:string; onNav:(v:View)=>void }) {
  const getToken = () => typeof window !== 'undefined' ? localStorage.getItem('pr_token')||'' : token;
  const [parsedQs, setParsedQs] = useState<ParsedQ[]>([]);
  const [target, setTarget] = useState<'qs_bank'|'pyq_bank'>('qs_bank');
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState('');
  const [editingQ, setEditingQ] = useState<ParsedQ|null>(null);
  const [editDraft, setEditDraft] = useState<ParsedQ|null>(null);

  const rowStatus = (q:ParsedQ) => q.hasError ? 'error' : (q.isDuplicateInDB||q.isDuplicate) ? 'duplicate' : (q.needsReview ? 'review' : 'valid');
  const validCount = parsedQs.filter(q=>rowStatus(q)==='valid').length;
  const reviewCount = parsedQs.filter(q=>rowStatus(q)==='review').length;
  const dupCount = parsedQs.filter(q=>rowStatus(q)==='duplicate').length;
  const errCount = parsedQs.filter(q=>rowStatus(q)==='error').length;

  const handleImport = async () => {
    setSaving(true); setSaveMsg('');
    try {
      const res = await fetch(`${API}/api/content-forge/pdf/save-to-bank`, {
        method:'POST', headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${getToken()}` },
        body: JSON.stringify({ questions: parsedQs.filter(q=>rowStatus(q)!=='error'), target }),
      });
      const d = await res.json();
      setSaveMsg(d.success ? `✅ ${d.imported} Imported / ${d.skipped} Skipped` : `❌ ${d.message}`);
    } catch(e:any) { setSaveMsg('❌ '+e.message); }
    setSaving(false);
  };

  const saveEdit = () => { if(!editDraft) return; setParsedQs(prev=>prev.map(q=>q.id===editDraft.id?editDraft:q)); setEditingQ(null); setEditDraft(null); };

  return (
    <div style={{ color:C.ts }}>
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:16 }}>
        <button onClick={()=>onNav('pdf_home')} style={{ ...S.bg, fontSize:11 }}>← Back</button>
        <PageHero icon="📚" title="Upload to QB / PYQ via PDF" subtitle="Upload question paper + answer key PDF → extract → bulk save" badge="Feature 21" />
      </div>

      <PDFUploadZone API={API} token={getToken()} onParsed={(qs)=>setParsedQs(qs)} />

      {parsedQs.length > 0 && (
        <>
          <div style={{ display:'flex', gap:10, margin:'14px 0', flexWrap:'wrap' }}>
            <span style={{ ...S.bg, color:C.suc, borderColor:'rgba(0,196,140,0.3)' }}>✅ {validCount} Valid</span>
            <span style={{ ...S.bg, color:C.gold, borderColor:'rgba(245,158,11,0.3)' }}>🔶 {reviewCount} Needs Review</span>
            <span style={{ ...S.bg, color:C.wrn, borderColor:'rgba(255,184,77,0.3)' }}>⚠️ {dupCount} Duplicate</span>
            <span style={{ ...S.bg, color:C.err, borderColor:'rgba(255,77,77,0.3)' }}>❌ {errCount} Error</span>
            <select value={target} onChange={e=>setTarget(e.target.value as any)} style={{ ...S.inp, width:200, marginLeft:'auto' }}>
              <option value="qs_bank">📚 Question Bank</option>
              <option value="pyq_bank">📜 PYQ Bank</option>
            </select>
          </div>

          <div style={{ maxHeight:500, overflowY:'auto', marginBottom:14 }}>
            {parsedQs.map(q=>(
              <QuestionPreviewCard key={q.id} q={q} accent={C.gold}
                onEdit={()=>{setEditingQ(q);setEditDraft({...q});}}
                onDelete={()=>setParsedQs(prev=>prev.filter(x=>x.id!==q.id))}
              />
            ))}
          </div>

          <button onClick={handleImport} disabled={saving||validCount===0} style={{ ...S.bp, width:'100%', padding:14, opacity:saving||validCount===0?0.6:1 }}>
            {saving?'⟳ Importing...':`Import ${validCount} Valid Questions →`}
          </button>
          {saveMsg && <div style={{ marginTop:10, padding:10, borderRadius:8, fontSize:12, background:saveMsg.startsWith('✅')?'rgba(0,196,140,0.1)':'rgba(255,77,77,0.1)', color:saveMsg.startsWith('✅')?C.suc:C.err }}>{saveMsg}</div>}
        </>
      )}

      {editingQ && editDraft && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.85)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:16 }} onClick={e=>e.target===e.currentTarget&&setEditingQ(null)}>
          <div style={{ width:'100%', maxWidth:520, background:'#020D18', border:`1px solid ${C.bor}`, borderRadius:18, padding:24, maxHeight:'85vh', overflowY:'auto' }}>
            <div style={{ fontSize:15, fontWeight:700, marginBottom:14 }}>✏️ Edit Q{editDraft.num}</div>
            <textarea value={editDraft.text} onChange={e=>setEditDraft(p=>p?{...p,text:e.target.value}:null)} rows={3} style={{ ...S.inp, marginBottom:10 }} />
            <input value={editDraft.imageUrl||''} onChange={e=>setEditDraft(p=>p?{...p,imageUrl:e.target.value}:null)} placeholder="Image URL (for diagram questions)" style={{ ...S.inp, marginBottom:10 }} />
            {editDraft.options.map((opt,j)=>(
              <div key={j} style={{ display:'flex', gap:8, marginBottom:6, alignItems:'center' }}>
                <span style={{ color:C.gold, width:20 }}>{String.fromCharCode(65+j)})</span>
                <input value={opt} onChange={e=>{const o=[...editDraft.options];o[j]=e.target.value;setEditDraft(p=>p?{...p,options:o}:null);}} style={S.inp} />
                <button onClick={()=>{const correct=editDraft.correct.includes(j)?editDraft.correct.filter(x=>x!==j):[...editDraft.correct,j];setEditDraft(p=>p?{...p,correct}:null);}} style={{ fontSize:10, padding:'4px 8px', borderRadius:6, border:`1px solid ${editDraft.correct.includes(j)?'rgba(0,196,140,0.5)':C.bor}`, background:'transparent', color:editDraft.correct.includes(j)?C.suc:C.dim, cursor:'pointer' }}>{editDraft.correct.includes(j)?'✅':'Set'}</button>
              </div>
            ))}
            <input value={editDraft.subject||''} onChange={e=>setEditDraft(p=>p?{...p,subject:e.target.value}:null)} placeholder="Subject" style={{ ...S.inp, marginTop:10, marginBottom:10 }} />
            <textarea value={editDraft.explanation||''} onChange={e=>setEditDraft(p=>p?{...p,explanation:e.target.value}:null)} placeholder="Explanation" rows={2} style={{ ...S.inp, marginBottom:10 }} />
            <div style={{ display:'flex', gap:8, marginTop:10 }}>
              <button onClick={saveEdit} style={{ ...S.bs, flex:1 }}>💾 Save</button>
              <button onClick={()=>{setEditingQ(null);setEditDraft(null);}} style={{ ...S.bg, flex:1 }}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// FEATURE 21B — Create Exam via PDF Parsing
// ═══════════════════════════════════════════════════════
function PDFCreateExamView({ API, token, onNav }: { API:string; token:string; onNav:(v:View)=>void }) {
  const isMobile = useIsMobile();
  const getToken = () => typeof window !== 'undefined' ? localStorage.getItem('pr_token')||'' : token;
  const [parsedQs, setParsedQs] = useState<ParsedQ[]>([]);
  const [pdfMeta, setPdfMeta] = useState<any>(null);
  const [examD, setExamD] = useState<ExamDetailsState>(defaultExamDetails());
  const [assign, setAssign] = useState<AssignmentState>(defaultAssignment());
  const [postC, setPostC] = useState<PostCreateState>(defaultPostCreate());
  const [previewMode, setPreviewMode] = useState<'parsed'|'exam'>('parsed');
  const [creating, setCreating] = useState(false);
  const [createMsg, setCreateMsg] = useState('');
  const [createdExam, setCreatedExam] = useState<any>(null);
  const [editingQ, setEditingQ] = useState<ParsedQ|null>(null);
  const [editDraft, setEditDraft] = useState<ParsedQ|null>(null);

  const goodQs = parsedQs.filter(q => !q.hasError);
  // BUGFIX: subject dropdown populated from subjects actually detected in the PDF (subjectMapText / per-Q)
  const detectedSubjects = [...new Set(parsedQs.map(q => q.subject).filter(Boolean))] as string[];
  const errQs = parsedQs.filter(q => q.hasError);

  const saveEdit = () => { if(!editDraft) return; setParsedQs(prev=>prev.map(q=>q.id===editDraft.id?editDraft:q)); setEditingQ(null); setEditDraft(null); };

  const handleCreate = async () => {
    if (!examD.title.trim()) { setCreateMsg('❌ Exam title required'); return; }
    if (goodQs.length === 0) { setCreateMsg('❌ No valid questions to create exam'); return; }
    setCreating(true); setCreateMsg('');
    try {
      const payload = {
        questions: goodQs,
        examDetails: {
          title: examD.title, subject: examD.subjects.join(', '), category: examD.category, type: examD.examType,
          duration: examD.duration, totalMarks: examD.totalMarks,
          markingScheme: { correct: examD.correctMarks, incorrect: examD.negativeMarks, unattempted: 0 },
          schedule: { startTime: examD.startTime||undefined, endTime: examD.endTime||undefined, resultTime: examD.resultDateTime||undefined },
          customInstructions: examD.customInstructions,
          password: examD.passwordEnabled ? examD.password : '',
          waitingRoomEnabled: examD.waitingRoomEnabled, waitingRoomMinutes: examD.waitingRoomMinutes,
          reattemptCount: examD.reattemptCount, unlimitedAttempts: examD.unlimitedAttempts, maxAttempts: examD.maxAttempts,
          watermark: examD.watermark,
          totalQuestionsRequested: examD.totalQuestionsRequested, subjectWiseCount: examD.subjectWiseCount,
        },
        assignment: {
          assignmentType: assign.assignmentType, batch: assign.batch,
          multiBatch: assign.multiBatchEnabled ? assign.multiBatch : [],
          testSeriesId: assign.testSeriesId, notifyStudents: assign.notifyStudents,
        },
        postCreate: {
          scheduledPublish: { enabled: postC.scheduledPublishEnabled, publishAt: postC.publishAt||null },
          isTemplate: postC.isTemplate,
        },
        sourceMeta: { pageCount: pdfMeta?.pageCount||0, totalParsed: parsedQs.length, totalErrors: errQs.length, uploadedAt: new Date().toISOString() }, // F21B.10.3
      };
      const res = await fetch(`${API}/api/content-forge/pdf/create-exam`, {
        method:'POST', headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${getToken()}` },
        body: JSON.stringify(payload),
      });
      const d = await res.json();
      if (!d.success) { setCreateMsg('❌ '+d.message); setCreating(false); return; }
      setCreatedExam(d.exam);
      if (postC.publishNow && d.examId) {
        await fetch(`${API}/api/content-forge/exam/${d.examId}/publish`, { method:'POST', headers:{ Authorization:`Bearer ${getToken()}` } }).catch(()=>{});
      }
      setCreateMsg(`✅ Exam created with ${d.questionsCreated} questions!`);
    } catch (e:any) { setCreateMsg('❌ '+e.message); }
    setCreating(false);
  };

  if (createdExam) {
    const examLink = `${typeof window!=='undefined'?window.location.origin:''}/exam/${createdExam._id}`;
    return (
      <div style={{ textAlign:'center', padding:'60px 20px' }}>
        <div style={{ fontSize:48, marginBottom:16 }}>🎉</div>
        <div style={{ fontSize:20, fontWeight:800, color:C.suc, marginBottom:10 }}>Exam Created Successfully!</div>
        <div style={{ fontSize:13, color:C.dim, marginBottom:20 }}>{createdExam.title}</div>
        <div style={{ display:'flex', gap:10, justifyContent:'center', flexWrap:'wrap' }}>
          <button onClick={()=>{navigator.clipboard?.writeText(examLink);}} style={S.bg}>🔗 Copy Exam Link</button>
          <button onClick={()=>onNav('home')} style={S.bp}>← Back to All Exams</button>
          <button onClick={()=>{setCreatedExam(null);setParsedQs([]);setExamD(defaultExamDetails());}} style={S.bs}>+ Create Another</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ color:C.ts }}>
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:16 }}>
        <button onClick={()=>onNav('pdf_home')} style={{ ...S.bg, fontSize:11 }}>← Back</button>
        <PageHero icon="🎯" title="Create Exam via PDF Parsing" subtitle="Upload question paper + answer key PDF → build full exam" badge="Feature 21B" />
      </div>

      <div style={{ display:'grid', gridTemplateColumns:isMobile?'1fr':'65% 35%', gap:16 }}>
        <div>
          <PDFUploadZone API={API} token={getToken()} onParsed={(qs,meta)=>{setParsedQs(qs);setPdfMeta(meta);}} />
          <ExamDetailsForm d={examD} setD={setExamD} totalParsed={goodQs.length} detectedSubjects={detectedSubjects} />
          <AssignmentSelector a={assign} setA={setAssign} API={API} token={getToken()} />
          <PostCreateActions p={postC} setP={setPostC} />
          <DuplicateCheckPanel texts={goodQs.map(q=>q.text)} batch={assign.batch} API={API} token={getToken()} />
          <PreSubmitChecklist questionsOk={goodQs.length>0} titleOk={!!examD.title.trim()} dateOk={!!examD.startTime} batchOk={assign.assignmentType==='individual'||!!assign.batch||!!assign.seriesName} />
          <button onClick={handleCreate} disabled={creating} style={{ ...S.bp, width:'100%', padding:14, fontSize:14, opacity:creating?0.6:1 }}>
            {creating ? '⟳ Creating Exam...' : `Create Exam (${goodQs.length} Qs) →`}
          </button>
          {createMsg && <div style={{ marginTop:10, padding:10, borderRadius:8, fontSize:12, background:createMsg.startsWith('✅')?'rgba(0,196,140,0.1)':'rgba(255,77,77,0.1)', color:createMsg.startsWith('✅')?C.suc:C.err }}>{createMsg}</div>}
        </div>

        <div>
          <div style={{ display:'flex', gap:6, marginBottom:10 }}>
            <button onClick={()=>setPreviewMode('parsed')} style={{ flex:1, padding:8, borderRadius:8, border:`1px solid ${previewMode==='parsed'?C.gold:C.bor}`, background:previewMode==='parsed'?'rgba(245,158,11,0.15)':'transparent', color:previewMode==='parsed'?C.gold:C.dim, cursor:'pointer', fontSize:11, fontWeight:700 }}>📋 Parsed Qs</button>
            <button onClick={()=>setPreviewMode('exam')} style={{ flex:1, padding:8, borderRadius:8, border:`1px solid ${previewMode==='exam'?C.gold:C.bor}`, background:previewMode==='exam'?'rgba(245,158,11,0.15)':'transparent', color:previewMode==='exam'?C.gold:C.dim, cursor:'pointer', fontSize:11, fontWeight:700 }}>🎯 Exam Preview</button>
          </div>
          <div style={{ display:'flex', gap:8, marginBottom:10, flexWrap:'wrap' }}>
            <span style={{ fontSize:11, padding:'4px 10px', borderRadius:20, background:'rgba(245,158,11,0.12)', color:C.gold, fontWeight:700 }}>{goodQs.length} Valid</span>
            {errQs.length>0 && <span style={{ fontSize:11, padding:'4px 10px', borderRadius:20, background:'rgba(255,77,77,0.1)', color:C.err, fontWeight:700 }}>{errQs.length} ❌</span>}
          </div>
          <div style={{ height:isMobile?420:'calc(100vh - 320px)', overflowY:'auto' }}>
            {parsedQs.length===0 && <div style={{ textAlign:'center', padding:40, color:C.dim }}>Upload PDFs on the left to preview</div>}
            {previewMode==='parsed' && parsedQs.map((q,i)=>(
              <QuestionPreviewCard key={q.id} q={q} accent={C.gold}
                onMoveUp={()=>setParsedQs(prev=>moveQuestion(prev,i,'up'))}
                onMoveDown={()=>setParsedQs(prev=>moveQuestion(prev,i,'down'))}
                onEdit={()=>{setEditingQ(q);setEditDraft({...q});}}
                onDelete={()=>setParsedQs(prev=>prev.filter(x=>x.id!==q.id))}
              />
            ))}
            {previewMode==='exam' && goodQs.map((q,i)=> <QuestionPreviewCard key={q.id} q={q} index={i} accent={C.gold} />)}
          </div>
        </div>
      </div>

      {editingQ && editDraft && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.85)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center', padding:16 }} onClick={e=>e.target===e.currentTarget&&setEditingQ(null)}>
          <div style={{ width:'100%', maxWidth:520, background:'#020D18', border:`1px solid ${C.bor}`, borderRadius:18, padding:24, maxHeight:'85vh', overflowY:'auto' }}>
            <div style={{ fontSize:15, fontWeight:700, marginBottom:14 }}>✏️ Edit Q{editDraft.num}</div>
            <textarea value={editDraft.text} onChange={e=>setEditDraft(p=>p?{...p,text:e.target.value}:null)} rows={3} style={{ ...S.inp, marginBottom:10 }} />
            <input value={editDraft.imageUrl||''} onChange={e=>setEditDraft(p=>p?{...p,imageUrl:e.target.value}:null)} placeholder="Image URL (optional)" style={{ ...S.inp, marginBottom:10 }} />
            {editDraft.options.map((opt,j)=>(
              <div key={j} style={{ display:'flex', gap:8, marginBottom:6, alignItems:'center' }}>
                <span style={{ color:C.gold, width:20 }}>{String.fromCharCode(65+j)})</span>
                <input value={opt} onChange={e=>{const o=[...editDraft.options];o[j]=e.target.value;setEditDraft(p=>p?{...p,options:o}:null);}} style={S.inp} />
                <button onClick={()=>{const correct=editDraft.correct.includes(j)?editDraft.correct.filter(x=>x!==j):[...editDraft.correct,j];setEditDraft(p=>p?{...p,correct}:null);}} style={{ fontSize:10, padding:'4px 8px', borderRadius:6, border:`1px solid ${editDraft.correct.includes(j)?'rgba(0,196,140,0.5)':C.bor}`, background:'transparent', color:editDraft.correct.includes(j)?C.suc:C.dim, cursor:'pointer' }}>{editDraft.correct.includes(j)?'✅':'Set'}</button>
              </div>
            ))}
            <input value={editDraft.subject||''} onChange={e=>setEditDraft(p=>p?{...p,subject:e.target.value}:null)} placeholder="Subject" style={{ ...S.inp, marginTop:10, marginBottom:10 }} />
            <textarea value={editDraft.explanation||''} onChange={e=>setEditDraft(p=>p?{...p,explanation:e.target.value}:null)} placeholder="Explanation" rows={2} style={{ ...S.inp, marginBottom:10 }} />
            <div style={{ display:'flex', gap:8, marginTop:10 }}>
              <button onClick={saveEdit} style={{ ...S.bs, flex:1 }}>💾 Save</button>
              <button onClick={()=>{setEditingQ(null);setEditDraft(null);}} style={{ ...S.bg, flex:1 }}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
// ═══════════════════════════════════════════════════════
// MAIN EXPORT — view router
// ═══════════════════════════════════════════════════════

// BUGFIX: refreshing the page was always resetting back to Home because
// React state doesn't survive a full page reload. We now persist the
// current view in sessionStorage so a refresh keeps the admin on the
// exact page they were on (clears automatically when the tab is closed).
function getInitialView(): View {
  if (typeof window === 'undefined') return 'home';
  const saved = window.sessionStorage.getItem('cf_view');
  const validViews: View[] = ['home','cp_home','cp_qs','cp_exam','ex_home','ex_qs','ex_exam','pdf_home','pdf_qs','pdf_exam'];
  return (saved && validViews.includes(saved as View)) ? (saved as View) : 'home';
}

export default function ContentForge({ API, token }: { API:string; token:string }) {
  const [view, setViewRaw] = useState<View>(getInitialView);
  const setView = (v: View) => {
    setViewRaw(v);
    if (typeof window !== 'undefined') window.sessionStorage.setItem('cf_view', v);
  };

  return (
    <div style={{ minHeight:'100vh', padding:'20px 16px', background:'radial-gradient(ellipse at top,#041427,#000814)' }}>
      {view === 'home'    && <HomeView onNav={setView} />}
      {view === 'cp_home' && <CopyPasteHome onNav={setView} />}
      {view === 'cp_qs'   && <CopyPasteQBView API={API} token={token} onNav={setView} />}
      {view === 'cp_exam' && <CopyPasteCreateExamView API={API} token={token} onNav={setView} />}
      {view === 'ex_home' && <ExcelHome onNav={setView} />}
      {view === 'ex_qs'   && <ExcelQBUploadView API={API} token={token} onNav={setView} />}
      {view === 'ex_exam' && <ExcelCreateExamView API={API} token={token} onNav={setView} />}
      {view === 'pdf_home'&& <PDFHome onNav={setView} />}
      {view === 'pdf_qs'  && <PDFQBUploadView API={API} token={token} onNav={setView} />}
      {view === 'pdf_exam'&& <PDFCreateExamView API={API} token={token} onNav={setView} />}
      <style>{`@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}`}</style>
    </div>
  );
}

