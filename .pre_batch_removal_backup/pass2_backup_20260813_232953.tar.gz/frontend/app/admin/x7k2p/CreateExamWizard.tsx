'use client'
import { useState, useEffect, useCallback, useRef } from 'react'

// ── Design tokens ─────────────────────────────────────────────────────────────
const ACC='#4D9FFF', TS='#E8F4FF', DIM='#6B8FAF', GOLD='#FFD700'
const SUC='#00C48C', DNG='#FF4D4D', WRN='#FFB84D', PRP='#A78BFA'
const PHY='#60A5FA', CHM='#F472B6', BIO='#34D399', MTH='#FBBF24'
const BOR='rgba(77,159,255,0.16)', CRD='rgba(0,15,35,0.88)'
const bp:any={background:`linear-gradient(135deg,${PRP},#6D28D9)`,color:'#fff',border:'none',borderRadius:10,padding:'11px 22px',cursor:'pointer',fontWeight:700,fontSize:13,transition:'all 0.2s'}
const bpAcc:any={...bp,background:`linear-gradient(135deg,${ACC},#0055CC)`}
const bpSuc:any={...bp,background:`linear-gradient(135deg,${SUC},#007a40)`}
const bg_:any={background:'rgba(0,25,55,0.7)',color:TS,border:`1px solid ${BOR}`,borderRadius:10,padding:'10px 18px',cursor:'pointer',fontSize:12,transition:'all 0.2s'}
const inp:any={width:'100%',padding:'11px 14px',background:'rgba(0,12,30,0.9)',border:`1.5px solid ${BOR}`,borderRadius:10,color:TS,fontSize:13,outline:'none',boxSizing:'border-box' as any,fontFamily:'Inter,sans-serif'}
const lbl:any={display:'block',fontSize:10,color:DIM,marginBottom:5,fontWeight:700,letterSpacing:0.6,textTransform:'uppercase' as any}
const cs:any={background:CRD,border:`1px solid ${BOR}`,borderRadius:16,padding:'20px',backdropFilter:'blur(14px)'}
const tog:any={width:42,height:22,borderRadius:11,border:'none',cursor:'pointer',transition:'all 0.25s',position:'relative' as any,flexShrink:0}

const sColor=(s:string)=>s==='Physics'?PHY:s==='Chemistry'?CHM:s==='Biology'?BIO:s==='Math'?MTH:'#94A3B8'

function Toggle({on,onChange,col=SUC}:{on:boolean;onChange:(v:boolean)=>void;col?:string}){
  return(
    <div onClick={()=>onChange(!on)} style={{...tog,background:on?col:'rgba(255,255,255,0.1)'}}>
      <div style={{position:'absolute',top:2,left:on?22:2,width:18,height:18,borderRadius:'50%',background:'#fff',transition:'all 0.25s',boxShadow:'0 1px 4px rgba(0,0,0,0.4)'}}/>
    </div>
  )
}

function Field({label,req,children,col}:{label:string;req?:boolean;children:React.ReactNode;col?:string}){
  return(
    <div>
      <label style={{...lbl,color:col||DIM}}>{label}{req&&<span style={{color:DNG,marginLeft:3}}>*</span>}</label>
      {children}
    </div>
  )
}

function Badge({l,col}:{l:string;col:string}){
  return <span style={{background:`${col}18`,border:`1px solid ${col}30`,color:col,borderRadius:8,padding:'2px 8px',fontSize:10,fontWeight:600}}>{l}</span>
}

interface Props { token:string; API:string; T:(m:string,t?:'s'|'e'|'w')=>void; fetchAll:()=>void; batches:any[]; testSeries:any[]; exams:any[]; questions:any[]; pendingTemplate?:any; onTemplateConsumed?:()=>void }

const SUBJECTS = ['Physics','Chemistry','Biology','Math','GK','English','Other']
const CATEGORIES = ['Full Mock','Chapter Test','Part Test','Grand Test','Mini Test','PYQ','Custom']
const EXAM_TYPES = ['NEET','JEE','CUET','RBSE','CBSE','Custom']

export default function CreateExamWizard({ token, API, T, fetchAll, batches, testSeries, exams, questions, pendingTemplate, onTemplateConsumed }:Props) {
  const hdrs = { 'Content-Type':'application/json', Authorization:`Bearer ${token}` }

  // ── Wizard step ──────────────────────────────────────────────────────────────
  const [step, setStep] = useState<1|2|3>(1)
  const [createdExamId, setCreatedExamId] = useState('')
  const [animDir, setAnimDir] = useState<'left'|'right'>('right')
  const [shakeNext, setShakeNext] = useState(false)

  // ── Step 1: Exam Settings ────────────────────────────────────────────────────
  const [title, setTitle]             = useState('')
  const [subject, setSubject]         = useState('Full Mock')
  const [category, setCategory]       = useState('Full Mock')
  const [totalQs, setTotalQs]         = useState(180)
  const [subjectQs, setSubjectQs]     = useState<Record<string,number>>({ Physics:45, Chemistry:45, Biology:90 })
  const [examType, setExamType]       = useState('NEET')
  const [duration, setDuration]       = useState(200)
  const [correctMarks, setCorrectMarks] = useState(4)
  const [negativeMarks, setNegativeMarks] = useState(1)
  const [startDate, setStartDate]     = useState('')
  const [endDate, setEndDate]         = useState('')
  const [instructions, setInstructions] = useState('')
  const [passwordEnabled, setPasswordEnabled] = useState(false)
  const [password, setPassword]       = useState('')
  const [whitelist, setWhitelist]     = useState(false)
  const [waitingRoom, setWaitingRoom] = useState(false)
  const [waitingMins, setWaitingMins] = useState(10)
  const [reattempt, setReattempt]     = useState(1)
  const [reattemptUnlimited, setReattemptUnlimited] = useState(false)
  const [reviewWindow, setReviewWindow] = useState(true)
  const [sectionWise, setSectionWise] = useState(true)
  const [watermark, setWatermark]     = useState(false)
  const [liveQsRange, setLiveQsRange] = useState<{from:number;to:number;subject:string}[]>([{from:1,to:45,subject:'Physics'},{from:46,to:90,subject:'Chemistry'},{from:91,to:180,subject:'Biology'}])
  const [assignType, setAssignType]   = useState<'batch'|'series'|'open'>('open')
  const [batchId, setBatchId]         = useState('')
  const [testSeriesId, setTestSeriesId] = useState('')
  const [multiBatches, setMultiBatches] = useState<string[]>([])
  const [formErrors, setFormErrors]   = useState<Record<string,string>>({})
  const [creating, setCreating]       = useState(false)
  const [templates, setTemplates]     = useState<any[]>([])
  const [showTemplates, setShowTemplates] = useState(false)
  const [justApplied, setJustApplied] = useState(false)

  // ── Step 2: Questions ────────────────────────────────────────────────────────
  const [qMethod, setQMethod]         = useState<'bank'|'pyq'|'smart'|'copypaste'|'excel'|'pdf'>('bank')
  const [selectedQs, setSelectedQs]   = useState<any[]>([])
  const [bankQs, setBankQs]           = useState<any[]>([])
  const [bankFilter, setBankFilter]   = useState({ subject:'all', chapter:'all', difficulty:'all', type:'all', search:'' })
  const [bankLoading, setBankLoading] = useState(false)
  const [cpText, setCpText]           = useState('')
  const [cpKey, setCpKey]             = useState('')
  const [excelFile, setExcelFile]     = useState<File|null>(null)
  const [pdfFile, setPdfFile]         = useState<File|null>(null)
  const [uploading, setUploading]     = useState(false)
  const [uploadRes, setUploadRes]     = useState<any>(null)
  const [duplicates, setDuplicates]   = useState<Record<string,any[]>>({})
  const [setCount, setSetCount]       = useState(2)
  const [generatingSets, setGeneratingSets] = useState(false)
  const [generatedSets, setGeneratedSets]   = useState<any[]>([])
  const dragIdx = useRef<number|null>(null)

  // ── Step 3: Review & Publish ─────────────────────────────────────────────────
  const [reviewData, setReviewData]   = useState<any>(null)
  const [reviewLoading, setReviewLoading] = useState(false)
  const [publishing, setPublishing]   = useState(false)
  const [scheduling, setScheduling]   = useState(false)
  const [publishAt, setPublishAt]     = useState('')
  const [notifyStudents, setNotifyStudents] = useState(true)
  const [questionsExpanded, setQuestionsExpanded] = useState(false)
  const [publishSuccess, setPublishSuccess] = useState(false)
  const [publishedExamId, setPublishedExamId] = useState('')
  const [cloning, setCloning]         = useState(false)

  // ── Auto-calculate total marks ────────────────────────────────────────────────
  const totalMarks = Math.round(totalQs * correctMarks)

  // ── Load templates ────────────────────────────────────────────────────────────
  useEffect(() => {
    fetch(`${API}/api/exam-wizard/templates`, { headers: { Authorization:`Bearer ${token}` } })
      .then(r => r.json()).then(d => { if (d.success) setTemplates(d.templates || []) }).catch(() => {})
  }, [token, API])

  // ── Navigate steps with animation ────────────────────────────────────────────
  const goStep = (n: 1|2|3, dir: 'left'|'right' = 'right') => {
    setAnimDir(dir); setTimeout(() => setStep(n), 50)
  }

  // ── Apply template ────────────────────────────────────────────────────────────
  const applyTemplate = (t: any) => {
    setTitle(t.examTitle || t.name || '')
    setSubject(t.subject || 'Full Mock')
    setCategory(t.category || 'Full Mock')
    setTotalQs(t.totalQs || 180)
    setSubjectQs(t.subjectQs || {})
    setExamType(t.examType || 'NEET')
    setDuration(t.duration || 200)
    setCorrectMarks(t.correctMarks || 4)
    setNegativeMarks(t.negativeMarks || 1)
    setShowTemplates(false)
    T(`Template "${t.name}" applied ✅`)
  }

  // ── 29.13: template applied from the dedicated Templates Manager page ──────
  useEffect(() => {
    if (pendingTemplate) {
      applyTemplate(pendingTemplate)
      setJustApplied(true)
      setTimeout(() => setJustApplied(false), 1300)
      if (onTemplateConsumed) onTemplateConsumed()
    }
  }, [pendingTemplate])

  // ── Step 1: Create Exam ───────────────────────────────────────────────────────
  const submitStep1 = async () => {
    const errs: Record<string,string> = {}
    if (!title.trim())  errs.title = 'Exam title is required'
    if (!startDate)     errs.startDate = 'Start date is required'
    if (duration < 1)   errs.duration = 'Duration must be > 0'
    if (Object.keys(errs).length) {
      setFormErrors(errs); setShakeNext(true); setTimeout(() => setShakeNext(false), 600)
      T('Please fill required fields', 'e'); return
    }
    setCreating(true)
    try {
      const body = {
        title: title.trim(), subject, category, totalQs, subjectQs, examType,
        duration, totalMarks, correctMarks, negativeMarks, startDate, endDate,
        instructions, passwordEnabled, password, whitelist: [], waitingRoom,
        waitingMinutes: waitingMins, reattempt, reattemptUnlimited, reviewWindow,
        sectionWise, watermark, liveQsRange, assignType, batchId, testSeriesId, multiBatches, status: 'draft'
      }
      const r = await fetch(`${API}/api/exam-wizard/create`, { method:'POST', headers: hdrs, body: JSON.stringify(body) })
      const d = await r.json()
      if (d.success) {
        setCreatedExamId(d.examId || d.exam?._id || '')
        T('Exam created! Now add questions. ✅')
        goStep(2)
        fetchAll()
      } else T(d.message || 'Failed to create exam', 'e')
    } catch { T('Network error', 'e') }
    setCreating(false)
  }

  // ── Step 2: Load bank questions ───────────────────────────────────────────────
  const loadBankQs = useCallback(async () => {
    setBankLoading(true)
    try {
      const p = new URLSearchParams()
      if (bankFilter.subject !== 'all')    p.set('subject', bankFilter.subject)
      if (bankFilter.difficulty !== 'all') p.set('difficulty', bankFilter.difficulty)
      if (bankFilter.type !== 'all')       p.set('type', bankFilter.type)
      if (bankFilter.search)               p.set('search', bankFilter.search)
      p.set('limit', '50')
      const r = await fetch(`${API}/api/questions-active?${p}`, { headers: { Authorization:`Bearer ${token}` } })
      const d = await r.json()
      if (d.success) setBankQs(d.questions || [])
    } catch {}
    setBankLoading(false)
  }, [token, API, bankFilter])

  useEffect(() => { if (qMethod === 'bank' || qMethod === 'pyq') loadBankQs() }, [qMethod, bankFilter, loadBankQs])

  // ── Step 2: Import from bank ──────────────────────────────────────────────────
  const importFromBank = async () => {
    if (!selectedQs.length) { T('Select questions first', 'e'); return }
    setUploading(true)
    try {
      const ids = selectedQs.map(q => q._id)
      const r = await fetch(`${API}/api/exam-wizard/${createdExamId}/questions/bank`, { method:'POST', headers: hdrs, body: JSON.stringify({ questionIds: ids }) })
      const d = await r.json()
      setUploadRes(d)
      if (d.success) {
        T(`${d.added} questions imported ✅`)
        // Duplicate check
        checkDuplicates(ids)
      } else T(d.message || 'Import failed', 'e')
    } catch { T('Error', 'e') }
    setUploading(false)
  }

  // ── Duplicate check ───────────────────────────────────────────────────────────
  const checkDuplicates = async (ids: string[]) => {
    try {
      const r = await fetch(`${API}/api/exam-wizard/duplicate-check`, { method:'POST', headers: hdrs, body: JSON.stringify({ questionIds: ids }) })
      const d = await r.json()
      if (d.success) setDuplicates(d.duplicates || {})
    } catch {}
  }

  // ── Upload (copy-paste/excel/pdf) ─────────────────────────────────────────────
  const uploadQuestions = async () => {
    if (!createdExamId) { T('Create exam first', 'e'); return }
    setUploading(true); setUploadRes(null)
    try {
      if (qMethod === 'copypaste') {
        const r = await fetch(`${API}/api/exam-wizard/${createdExamId}/questions/copypaste`, { method:'POST', headers: hdrs, body: JSON.stringify({ questionsText: cpText, answerKeyText: cpKey }) })
        const d = await r.json(); setUploadRes(d)
        if (d.success) { T(`${d.saved} questions added ✅`); fetchAll() }
        else T(d.message || 'Failed', 'e')
      } else if (qMethod === 'excel') {
        if (!excelFile) { T('Select Excel file', 'e'); return }
        const fd = new FormData(); fd.append('file', excelFile)
        const r = await fetch(`${API}/api/exam-wizard/${createdExamId}/questions/excel`, { method:'POST', headers: { Authorization:`Bearer ${token}` }, body: fd })
        const d = await r.json(); setUploadRes(d)
        if (d.success) { T(`${d.saved} questions added ✅`); fetchAll() }
        else T(d.message || 'Failed', 'e')
      } else if (qMethod === 'pdf') {
        if (!pdfFile) { T('Select PDF file', 'e'); return }
        const fd = new FormData(); fd.append('file', pdfFile)
        const r = await fetch(`${API}/api/exam-wizard/${createdExamId}/questions/pdf`, { method:'POST', headers: { Authorization:`Bearer ${token}` }, body: fd })
        const d = await r.json(); setUploadRes(d)
        if (d.success) { T(`${d.saved} questions from PDF ✅`); fetchAll() }
        else T(d.message || 'Failed', 'e')
      } else if (qMethod === 'smart') {
        const r = await fetch(`${API}/api/exam-wizard/${createdExamId}/questions/smart-suggest`, { method:'POST', headers: hdrs, body: JSON.stringify({ subjectQs, examLevel: examType, existingIds: selectedQs.map(q=>q._id) }) })
        const d = await r.json()
        if (d.success) {
          const toImport = d.questions || []
          await fetch(`${API}/api/exam-wizard/${createdExamId}/questions/bank`, { method:'POST', headers: hdrs, body: JSON.stringify({ questionIds: toImport.map((q:any) => q._id) }) })
          setSelectedQs(prev => [...prev, ...toImport.filter((q:any) => !prev.find(p => p._id === q._id))])
          T(`${toImport.length} questions auto-selected ✅`)
          fetchAll()
        } else T(d.message || 'Smart suggest failed', 'e')
      }
    } catch { T('Upload error', 'e') }
    setUploading(false)
  }

  // ── Generate multi-sets ───────────────────────────────────────────────────────
  const generateSets = async () => {
    if (!createdExamId) return
    setGeneratingSets(true)
    try {
      const r = await fetch(`${API}/api/exam-wizard/${createdExamId}/generate-sets`, { method:'POST', headers: hdrs, body: JSON.stringify({ setCount }) })
      const d = await r.json()
      if (d.success) { setGeneratedSets(d.sets); T(`${d.setCount} sets generated ✅`) }
      else T(d.message || 'Failed', 'e')
    } catch { T('Error', 'e') }
    setGeneratingSets(false)
  }

  // ── Drag-drop reorder ─────────────────────────────────────────────────────────
  const onDragStart = (i: number) => { dragIdx.current = i }
  const onDrop = (i: number) => {
    if (dragIdx.current === null || dragIdx.current === i) return
    const arr = [...selectedQs]; const [moved] = arr.splice(dragIdx.current, 1); arr.splice(i, 0, moved)
    setSelectedQs(arr); dragIdx.current = null
  }

  // ── Derived stats for Step 2 ──────────────────────────────────────────────────
  const selectedBySubj: Record<string,number> = {}
  selectedQs.forEach(q => { selectedBySubj[q.subject||'Other'] = (selectedBySubj[q.subject||'Other']||0) + 1 })
  const totalSelected = selectedQs.length
  const subjectTarget = Object.entries(subjectQs)
  const balanceOk = subjectTarget.every(([s,n]) => selectedBySubj[s] === n)
  const totalTarget = Object.values(subjectQs).reduce((a,b) => a+b, 0) || totalQs
  const easyPct  = totalSelected ? Math.round(selectedQs.filter(q=>q.difficulty==='Easy'||q.difficulty==='easy').length/totalSelected*100) : 0
  const medPct   = totalSelected ? Math.round(selectedQs.filter(q=>q.difficulty==='Medium'||q.difficulty==='medium').length/totalSelected*100) : 0
  const hardPct  = 100 - easyPct - medPct
  const imgCount = selectedQs.filter(q => q.image || q.imageUrl).length
  const chapSet  = new Set(selectedQs.map(q => q.chapter).filter(Boolean))

  // ── Load review data ──────────────────────────────────────────────────────────
  const loadReview = async () => {
    if (!createdExamId) return
    setReviewLoading(true)
    try {
      const r = await fetch(`${API}/api/exam-wizard/${createdExamId}/review`, { headers: { Authorization:`Bearer ${token}` } })
      const d = await r.json()
      if (d.success) setReviewData(d)
    } catch {}
    setReviewLoading(false)
  }

  useEffect(() => { if (step === 3 && createdExamId) loadReview() }, [step, createdExamId])

  // F55 FIX — auto-carry Step 1's Start Date into Step 3's Schedule field
  // instead of leaving publishAt empty and forcing admin to re-type the same date.
  useEffect(() => { if (step === 3 && startDate && !publishAt) setPublishAt(startDate) }, [step, startDate])

  // ── Step 3: Publish ───────────────────────────────────────────────────────────
  const doPublish = async (asDraft = false) => {
    setPublishing(true)
    try {
      const ep  = asDraft ? 'draft' : 'publish'
      const r   = await fetch(`${API}/api/exam-wizard/${createdExamId}/${ep}`, { method:'PATCH', headers: hdrs })
      const d   = await r.json()
      if (d.success) {
        if (!asDraft) {
          if (notifyStudents) {
            await fetch(`${API}/api/exam-wizard/${createdExamId}/notify-students`, { method:'POST', headers: hdrs }).catch(() => {})
          }
          setPublishSuccess(true); setPublishedExamId(createdExamId)
        } else {
          T('Saved as draft ✅'); fetchAll()
        }
        fetchAll()
      } else T(d.message || 'Failed', 'e')
    } catch { T('Error', 'e') }
    setPublishing(false)
  }

  const doSchedule = async () => {
    if (!publishAt) { T('Select publish date/time', 'e'); return }
    setScheduling(true)
    try {
      const r = await fetch(`${API}/api/exam-wizard/${createdExamId}/schedule-publish`, { method:'PATCH', headers: hdrs, body: JSON.stringify({ publishAt }) })
      const d = await r.json()
      if (d.success) { T('Exam scheduled ✅'); setPublishSuccess(true); setPublishedExamId(createdExamId); fetchAll() }
      else T(d.message || 'Failed', 'e')
    } catch { T('Error', 'e') }
    setScheduling(false)
  }

  const doClone = async () => {
    setCloning(true)
    try {
      const r = await fetch(`${API}/api/exam-wizard/${createdExamId}/clone`, { method:'POST', headers: hdrs })
      const d = await r.json()
      if (d.success) { T('Exam cloned ✅'); fetchAll() }
      else T(d.message || 'Failed', 'e')
    } catch { T('Error', 'e') }
    setCloning(false)
  }

  const copyLink = () => {
    const url = `${window.location.origin}/exam/${createdExamId}`
    navigator.clipboard?.writeText(url).then(() => T('Link copied! 📋')).catch(() => T('Copy failed', 'e'))
  }

  // ── Pre-publish checklist ─────────────────────────────────────────────────────
  const checklist = [
    { label: 'Exam title set',         ok: !!title.trim() },
    { label: 'Start date configured',  ok: !!startDate },
    { label: 'Duration configured',    ok: duration > 0 },
    { label: 'Marking scheme set',     ok: correctMarks > 0 },
    { label: `Questions added (${(reviewData?.exam?.questions||[]).length}/${totalTarget})`, ok: (reviewData?.exam?.questions||[]).length >= totalTarget },
    { label: 'Assignment configured',  ok: assignType === 'open' || !!batchId || !!testSeriesId },
  ]
  const checklistOk = checklist.every(c => c.ok)

  // ── Success Screen ────────────────────────────────────────────────────────────
  if (publishSuccess) {
    return (
      <div style={{textAlign:'center' as any, padding:'50px 20px', position:'relative' as any, overflow:'hidden'}}>
        <style dangerouslySetInnerHTML={{__html:`
          @keyframes confetti{0%{transform:translateY(-10px) rotate(0deg);opacity:1}100%{transform:translateY(100vh) rotate(720deg);opacity:0}}
          @keyframes scaleIn{0%{transform:scale(0.5);opacity:0}70%{transform:scale(1.1)}100%{transform:scale(1);opacity:1}}
          @keyframes glow{0%,100%{box-shadow:0 0 20px ${PRP}55}50%{box-shadow:0 0 40px ${PRP}88,0 0 60px ${PRP}44}}
          .confetti-piece{position:absolute;width:8px;height:8px;animation:confetti 3s ease-in infinite;}
        `}}/>
        {Array.from({length:20}).map((_,i)=>(
          <div key={i} className="confetti-piece" style={{left:`${Math.random()*100}%`,top:'-10px',background:[PRP,ACC,GOLD,SUC,WRN][i%5],borderRadius:i%2===0?'50%':'2px',animationDelay:`${Math.random()*2}s`,animationDuration:`${2+Math.random()*2}s`}}/>
        ))}
        <div style={{animation:'scaleIn 0.6s ease',position:'relative' as any,zIndex:2}}>
          <div style={{fontSize:80,marginBottom:16}}>🎉</div>
          <div style={{fontFamily:'Playfair Display,serif',fontSize:28,fontWeight:800,background:`linear-gradient(90deg,${PRP},${ACC})`,WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent',marginBottom:8}}>
            Exam Published!
          </div>
          <div style={{fontSize:14,color:DIM,marginBottom:28}}>{title} is now live for students</div>
          <div style={{display:'flex',gap:10,justifyContent:'center' as any,flexWrap:'wrap' as any,marginBottom:20}}>
            <button onClick={copyLink} style={{...bpAcc,fontSize:12}}>📋 Copy Exam Link</button>
            <button onClick={doClone} disabled={cloning} style={{...bg_,fontSize:12}}>{cloning?'⟳':'📑'} Clone Exam</button>
            <button onClick={()=>{setStep(1);setCreatedExamId('');setTitle('');setSelectedQs([]);setPublishSuccess(false)}} style={{...bpSuc,fontSize:12}}>➕ Create Another</button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={{fontFamily:'Inter,sans-serif',position:'relative' as any,overflow:'hidden'}}>
      <style dangerouslySetInnerHTML={{__html:`
        @keyframes slideInRight{from{transform:translateX(60px);opacity:0}to{transform:translateX(0);opacity:1}}
        @keyframes slideInLeft{from{transform:translateX(-60px);opacity:0}to{transform:translateX(0);opacity:1}}
        @keyframes shake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-6px)}40%,80%{transform:translateX(6px)}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.5}}
        .step-enter{animation:slideInRight 0.35s cubic-bezier(0.4,0,0.2,1)}
        .step-enter-left{animation:slideInLeft 0.35s cubic-bezier(0.4,0,0.2,1)}
        .shake-anim{animation:shake 0.5s ease}
        .inp-error{border-color:#FF4D4D !important;box-shadow:0 0 0 3px rgba(255,77,77,0.15) !important}
        @keyframes templateFlash{0%{box-shadow:0 0 0 3px ${GOLD}77,0 0 24px ${GOLD}33}100%{box-shadow:0 0 0 0px ${GOLD}00}}
        .tpl-flash{animation:templateFlash 1.3s ease}
      `}}/>

      {/* ══ STEP INDICATOR ══════════════════════════════════════════════════════ */}
      <div style={{...cs,marginBottom:20,padding:'16px 20px',background:'rgba(0,8,24,0.95)'}}>
        <div style={{display:'flex',alignItems:'center',gap:0,position:'relative' as any}}>
          {[{n:1,l:'Exam Details',ico:'📋'},{n:2,l:'Add Questions',ico:'❓'},{n:3,l:'Review & Publish',ico:'✅'}].map((s,i)=>{
            const isDone = step > s.n, isActive = step === s.n
            const col = isActive ? PRP : isDone ? SUC : DIM
            return (
              <div key={s.n} style={{flex:1,display:'flex',flexDirection:'column' as any,alignItems:'center',position:'relative' as any}}>
                {i > 0 && <div style={{position:'absolute',left:'-50%',right:'50%',top:22,height:2,background:isDone?`linear-gradient(90deg,${SUC},${SUC})`:`rgba(255,255,255,0.06)`,transition:'all 0.4s',zIndex:0}}/>}
                <div onClick={()=>{if(isDone||(s.n===1))goStep(s.n as 1|2|3,'left')}} style={{
                  width:44,height:44,borderRadius:'50%',
                  background:isActive?`linear-gradient(135deg,${PRP},#6D28D9)`:isDone?`linear-gradient(135deg,${SUC},#007a40)`:'rgba(255,255,255,0.05)',
                  border:`2px solid ${col}`,
                  display:'flex',alignItems:'center',justifyContent:'center',
                  fontSize:isActive?18:14,fontWeight:800,color:'#fff',
                  cursor:(isDone||s.n===1)?'pointer':'default',
                  transition:'all 0.3s',
                  boxShadow:isActive?`0 0 20px ${PRP}55, 0 0 40px ${PRP}22`:'none',
                  animation:isActive?'pulse 2s ease infinite':'none',
                  position:'relative' as any,zIndex:1
                }}>
                  {isDone ? '✓' : s.ico}
                </div>
                <div style={{marginTop:6,fontSize:10,fontWeight:isActive?700:400,color:col,textAlign:'center' as any,letterSpacing:0.2}}>{s.l}</div>
                {isActive && <div style={{width:6,height:6,borderRadius:'50%',background:PRP,marginTop:3,boxShadow:`0 0 8px ${PRP}`,animation:'pulse 1.5s ease infinite'}}/>}
              </div>
            )
          })}
        </div>
      </div>

      {/* ════════════════ STEP 1 ════════════════════════════════════════════════ */}
      {step === 1 && (
        <div className="step-enter">
          <div style={{display:'flex',gap:14,flexWrap:'wrap' as any}}>

            {/* Left: Main form */}
            <div style={{flex:'1 1 300px',display:'flex',flexDirection:'column' as any,gap:12}}>

              {/* Templates */}
              <div style={{...cs,padding:'14px'}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:showTemplates?12:0}}>
                  <div style={{fontWeight:700,fontSize:13,color:TS}}>⚡ Quick Templates</div>
                  <button onClick={()=>setShowTemplates(p=>!p)} style={{...bg_,fontSize:11,padding:'4px 10px'}}>{showTemplates?'▲ Hide':'▼ Show'}</button>
                </div>
                {showTemplates && (
                  <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(140px,1fr))',gap:8}}>
                    {templates.map((t,i)=>(
                      <div key={i} onClick={()=>applyTemplate(t)} style={{background:'rgba(167,139,250,0.06)',border:`1px solid ${PRP}22`,borderRadius:10,padding:'10px',cursor:'pointer',transition:'all 0.15s'}}
                        onMouseEnter={e=>(e.currentTarget as HTMLElement).style.borderColor=`${PRP}55`}
                        onMouseLeave={e=>(e.currentTarget as HTMLElement).style.borderColor=`${PRP}22`}>
                        <div style={{fontSize:20,marginBottom:4}}>{t.icon||'📋'}</div>
                        <div style={{fontSize:11,fontWeight:700,color:TS,marginBottom:2}}>{t.name}</div>
                        <div style={{fontSize:9,color:DIM}}>{t.totalQs||'-'} Qs · {t.duration||'-'} min</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Section 1: Exam Identity */}
              <div style={cs} className={justApplied?'tpl-flash':''}>
                <div style={{fontWeight:700,fontSize:13,color:PRP,marginBottom:14,display:'flex',alignItems:'center',gap:6}}>📋 Exam Identity</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr',gap:12}}>
                  <Field label="Exam Title" req>
                    <input value={title} onChange={e=>{setTitle(e.target.value);setFormErrors(p=>({...p,title:''}))}}
                      placeholder="e.g. NEET Full Mock Test — March 2026"
                      style={{...inp,...(formErrors.title?{border:`1.5px solid ${DNG}`,boxShadow:`0 0 0 3px rgba(255,77,77,0.15)`}:{})}}/>
                    {formErrors.title && <div style={{fontSize:10,color:DNG,marginTop:4}}>⚠️ {formErrors.title}</div>}
                  </Field>
                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                    <Field label="Subject">
                      <select value={subject} onChange={e=>setSubject(e.target.value)} style={inp}>
                        <option value="Full Mock">Full Mock</option>
                        {SUBJECTS.map(s=><option key={s} value={s}>{s}</option>)}
                      </select>
                    </Field>
                    <Field label="Category">
                      <select value={category} onChange={e=>setCategory(e.target.value)} style={inp}>
                        {CATEGORIES.map(c=><option key={c} value={c}>{c}</option>)}
                      </select>
                    </Field>
                    <Field label="Exam Type / Format">
                      <select value={examType} onChange={e=>setExamType(e.target.value)} style={inp}>
                        {EXAM_TYPES.map(t=><option key={t} value={t}>{t}</option>)}
                      </select>
                    </Field>
                    <Field label="Total Question Count" req>
                      <input type="number" value={totalQs} onChange={e=>setTotalQs(parseInt(e.target.value)||0)} style={inp} min={1}/>
                    </Field>
                  </div>
                </div>
              </div>

              {/* Subject-wise Qs */}
              <div style={cs}>
                <div style={{fontWeight:700,fontSize:13,color:PRP,marginBottom:12}}>🔬 Subject-wise Question Split</div>
                {SUBJECTS.slice(0,5).map(s=>(
                  <div key={s} style={{display:'flex',alignItems:'center',gap:10,marginBottom:8}}>
                    <div style={{width:80,fontSize:11,color:sColor(s),fontWeight:600}}>{s}</div>
                    <input type="number" value={subjectQs[s]||0} min={0}
                      onChange={e=>setSubjectQs(p=>({...p,[s]:parseInt(e.target.value)||0}))}
                      style={{...inp,width:'100%',padding:'7px 10px'}}/>
                    <div style={{width:30,height:30,borderRadius:'50%',background:`${sColor(s)}18`,border:`1px solid ${sColor(s)}44`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,fontWeight:700,color:sColor(s),flexShrink:0}}>
                      {Math.round((subjectQs[s]||0)/totalQs*100)||0}%
                    </div>
                  </div>
                ))}
                <div style={{fontSize:10,color:Object.values(subjectQs).reduce((a,b)=>a+b,0)===totalQs?SUC:WRN,marginTop:6,fontWeight:600}}>
                  Total split: {Object.values(subjectQs).reduce((a,b)=>a+b,0)} / {totalQs}
                  {Object.values(subjectQs).reduce((a,b)=>a+b,0)===totalQs?' ✅':' ⚠️ Must match total'}
                </div>
              </div>

              {/* Duration + Marks */}
              <div style={cs}>
                <div style={{fontWeight:700,fontSize:13,color:PRP,marginBottom:14}}>⏱️ Duration & Marks</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                  <Field label="Duration (minutes)" req>
                    <div style={{display:'flex',flexDirection:'column' as any,gap:6}}>
                      <input type="range" min={10} max={360} value={duration} onChange={e=>setDuration(parseInt(e.target.value))}
                        style={{width:'100%',accentColor:PRP}}/>
                      <input type="number" value={duration} onChange={e=>setDuration(parseInt(e.target.value)||1)}
                        style={{...inp,...(formErrors.duration?{border:`1.5px solid ${DNG}`}:{})}} min={1}/>
                    </div>
                    {formErrors.duration && <div style={{fontSize:10,color:DNG}}>{formErrors.duration}</div>}
                  </Field>
                  <div>
                    <label style={lbl}>Total Marks (auto)</label>
                    <div style={{padding:'20px 14px',background:`${GOLD}08`,border:`1px solid ${GOLD}22`,borderRadius:10,textAlign:'center' as any}}>
                      <div style={{fontSize:24,fontWeight:900,color:GOLD}}>{totalMarks}</div>
                      <div style={{fontSize:10,color:DIM,marginTop:2}}>{totalQs} × {correctMarks} = {totalMarks}</div>
                    </div>
                  </div>
                </div>
                {/* Marking scheme */}
                <div style={{marginTop:12}}>
                  <label style={lbl}>Marking Scheme</label>
                  <div style={{display:'flex',gap:10,alignItems:'center'}}>
                    <div style={{display:'flex',alignItems:'center',gap:6,flex:1}}>
                      <span style={{background:`${SUC}18`,border:`1px solid ${SUC}33`,color:SUC,borderRadius:8,padding:'5px 10px',fontSize:13,fontWeight:700,minWidth:30,textAlign:'center' as any}}>+{correctMarks}</span>
                      <input type="number" value={correctMarks} onChange={e=>setCorrectMarks(parseFloat(e.target.value)||0)} style={{...inp,width:80,padding:'7px 10px'}} min={0} step={0.5}/>
                      <span style={{fontSize:11,color:DIM}}>correct</span>
                    </div>
                    <div style={{color:DIM,fontSize:14}}>|</div>
                    <div style={{display:'flex',alignItems:'center',gap:6,flex:1}}>
                      <span style={{background:`${DNG}18`,border:`1px solid ${DNG}33`,color:DNG,borderRadius:8,padding:'5px 10px',fontSize:13,fontWeight:700,minWidth:36,textAlign:'center' as any}}>−{negativeMarks}</span>
                      <input type="number" value={negativeMarks} onChange={e=>setNegativeMarks(parseFloat(e.target.value)||0)} style={{...inp,width:80,padding:'7px 10px'}} min={0} step={0.25}/>
                      <span style={{fontSize:11,color:DIM}}>wrong</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Schedule */}
              <div style={cs}>
                <div style={{fontWeight:700,fontSize:13,color:PRP,marginBottom:14}}>📅 Schedule</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                  <Field label="Start Date & Time" req>
                    <input type="datetime-local" value={startDate} onChange={e=>{setStartDate(e.target.value);setFormErrors(p=>({...p,startDate:''}))}}
                      style={{...inp,...(formErrors.startDate?{border:`1.5px solid ${DNG}`}:{})}}/>
                    {formErrors.startDate && <div style={{fontSize:10,color:DNG}}>{formErrors.startDate}</div>}
                  </Field>
                  <Field label="End Date & Time">
                    <input type="datetime-local" value={endDate} onChange={e=>setEndDate(e.target.value)} style={inp}/>
                  </Field>
                </div>
              </div>

              {/* Live Qs Range */}
              <div style={cs}>
                <div style={{fontWeight:700,fontSize:13,color:PRP,marginBottom:12}}>📍 Live Exam — Question Range per Subject</div>
                <div style={{fontSize:11,color:DIM,marginBottom:10}}>Specify which Q numbers correspond to which subject during live exam</div>
                {liveQsRange.map((r,i)=>(
                  <div key={i} style={{display:'grid',gridTemplateColumns:'auto 1fr 1fr auto',gap:8,marginBottom:8,alignItems:'center'}}>
                    <select value={r.subject} onChange={e=>{const a=[...liveQsRange];a[i]={...a[i],subject:e.target.value};setLiveQsRange(a)}} style={{...inp,width:120,padding:'7px 8px'}}>
                      {SUBJECTS.map(s=><option key={s} value={s}>{s}</option>)}
                    </select>
                    <div style={{display:'flex',gap:4,alignItems:'center'}}>
                      <span style={{fontSize:10,color:DIM,flexShrink:0}}>Q#</span>
                      <input type="number" value={r.from} onChange={e=>{const a=[...liveQsRange];a[i]={...a[i],from:parseInt(e.target.value)||1};setLiveQsRange(a)}} style={{...inp,padding:'7px 8px'}} min={1}/>
                    </div>
                    <div style={{display:'flex',gap:4,alignItems:'center'}}>
                      <span style={{fontSize:10,color:DIM,flexShrink:0}}>to</span>
                      <input type="number" value={r.to} onChange={e=>{const a=[...liveQsRange];a[i]={...a[i],to:parseInt(e.target.value)||1};setLiveQsRange(a)}} style={{...inp,padding:'7px 8px'}} min={1}/>
                    </div>
                    <button onClick={()=>setLiveQsRange(p=>p.filter((_,j)=>j!==i))} style={{background:`${DNG}12`,border:`1px solid ${DNG}33`,color:DNG,borderRadius:7,width:28,height:28,cursor:'pointer',fontSize:13}}>✕</button>
                  </div>
                ))}
                <button onClick={()=>setLiveQsRange(p=>[...p,{from:1,to:45,subject:'Physics'}])} style={{...bg_,fontSize:11,padding:'6px 12px',marginTop:4}}>+ Add Range</button>
              </div>

              {/* Settings toggles */}
              <div style={cs}>
                <div style={{fontWeight:700,fontSize:13,color:PRP,marginBottom:14}}>⚙️ Settings</div>
                {[
                  {l:'🔐 Password Protection', v:passwordEnabled, fn:setPasswordEnabled},
                  {l:'📋 Whitelist Mode', v:whitelist, fn:setWhitelist},
                  {l:'⏳ Waiting Room', v:waitingRoom, fn:setWaitingRoom},
                  {l:'🔄 Review Window', v:reviewWindow, fn:setReviewWindow, desc:'Students can review answers after exam'},
                  {l:'📑 Section-wise Navigation', v:sectionWise, fn:setSectionWise},
                  {l:'💧 Student Watermark', v:watermark, fn:setWatermark},
                ].map(item=>(
                  <div key={item.l} style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12,padding:'8px 0',borderBottom:`1px solid ${BOR}`}}>
                    <div>
                      <div style={{fontSize:12,color:TS,fontWeight:500}}>{item.l}</div>
                      {item.desc && <div style={{fontSize:10,color:DIM,marginTop:1}}>{item.desc}</div>}
                    </div>
                    <Toggle on={item.v} onChange={item.fn}/>
                  </div>
                ))}
                {passwordEnabled && (
                  <div style={{marginTop:8}}>
                    <Field label="Exam Password">
                      <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter exam password" style={inp}/>
                    </Field>
                  </div>
                )}
                {waitingRoom && (
                  <div style={{marginTop:8,display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                    <Field label="Waiting Room (minutes)">
                      <input type="number" value={waitingMins} onChange={e=>setWaitingMins(parseInt(e.target.value)||0)} style={inp} min={0}/>
                    </Field>
                  </div>
                )}
                <div style={{marginTop:8}}>
                  <Field label="Re-attempt">
                    <div style={{display:'flex',gap:8,alignItems:'center'}}>
                      <input type="number" value={reattempt} onChange={e=>setReattempt(parseInt(e.target.value)||1)} style={{...inp,flex:1}} min={1} disabled={reattemptUnlimited}/>
                      <div style={{display:'flex',alignItems:'center',gap:6}}>
                        <span style={{fontSize:11,color:DIM}}>Unlimited</span>
                        <Toggle on={reattemptUnlimited} onChange={setReattemptUnlimited} col={ACC}/>
                      </div>
                    </div>
                  </Field>
                </div>
              </div>

              {/* Batch / Test Series assignment */}
              <div style={cs}>
                <div style={{fontWeight:700,fontSize:13,color:PRP,marginBottom:14}}>🏫 Assign To</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:12}}>
                  {([['open','🌐 Open','All students'],['batch','🏫 Batch','Specific batch'],['series','📚 Test Series','Series group']] as const).map(([v,l,d])=>(
                    <div key={v} onClick={()=>{setAssignType(v);if(v!=='batch')setBatchId('');if(v!=='series')setTestSeriesId('')}} style={{padding:'10px',borderRadius:10,border:`1.5px solid ${assignType===v?PRP:BOR}`,background:assignType===v?`${PRP}12`:'transparent',cursor:'pointer',transition:'all 0.15s'}}>
                      <div style={{fontSize:13,fontWeight:700,color:assignType===v?PRP:TS,marginBottom:2}}>{l}</div>
                      <div style={{fontSize:10,color:DIM}}>{d}</div>
                    </div>
                  ))}
                </div>
                {assignType === 'batch' && (
                  <Field label="Select Batch">
                    <select value={batchId} onChange={e=>setBatchId(e.target.value)} style={inp}>
                      <option value="">— Select Batch —</option>
                      {batches.map((b:any)=><option key={b._id} value={b._id}>{b.name}{b.lifecycleStatus?` · ${b.lifecycleStatus}`:''}</option>)}
                    </select>
                  </Field>
                )}
                {assignType === 'series' && (
                  <Field label="Select Test Series">
                    <select value={testSeriesId} onChange={e=>setTestSeriesId(e.target.value)} style={inp}>
                      <option value="">— Select Test Series —</option>
                      {testSeries.map((s:any)=><option key={s._id} value={s._id}>{s.name||s.title}{s.lifecycleStatus?` · ${s.lifecycleStatus}`:''}</option>)}
                    </select>
                  </Field>
                )}
              </div>

              {/* Instructions */}
              <div style={cs}>
                <Field label="Custom Instructions">
                  <textarea value={instructions} onChange={e=>setInstructions(e.target.value)} rows={3} placeholder="Special instructions shown to students before starting..." style={{...inp,resize:'vertical' as any}}/>
                </Field>
              </div>
            </div>

            {/* Right: Live Preview Card */}
            <div style={{width:240,flexShrink:0}}>
              <div style={{position:'sticky' as any,top:80}}>
                <div style={{fontWeight:700,fontSize:12,color:DIM,marginBottom:8,textTransform:'uppercase' as any,letterSpacing:1}}>Live Preview</div>
                <div style={{...cs,borderColor:`${PRP}33`,background:'rgba(109,40,217,0.06)'}}>
                  <div style={{fontWeight:800,fontSize:15,color:TS,marginBottom:4,lineHeight:1.3}}>{title||'Exam Title'}</div>
                  <div style={{display:'flex',gap:5,flexWrap:'wrap' as any,marginBottom:10}}>
                    <Badge l={category} col={PRP}/>
                    <Badge l={examType} col={ACC}/>
                  </div>
                  {[
                    ['📅',startDate?new Date(startDate).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}):'Not set'],
                    ['⏱️',`${duration} min`],
                    ['❓',`${totalQs} questions`],
                    ['🏆',`${totalMarks} marks`],
                    ['+',`+${correctMarks} / −${negativeMarks}`],
                    ['🏫',assignType==='batch'?(batches.find((b:any)=>b._id===batchId)?.name||'Batch not chosen'):assignType==='series'?(testSeries.find((s:any)=>s._id===testSeriesId)?.name||'Series not chosen'):'Open Access'],
                  ].map(([ico,val],i)=>(
                    <div key={i} style={{display:'flex',gap:8,alignItems:'flex-start',padding:'5px 0',borderBottom:`1px solid ${BOR}`}}>
                      <span style={{fontSize:12,flexShrink:0,color:DIM}}>{ico}</span>
                      <span style={{fontSize:11,color:TS}}>{val}</span>
                    </div>
                  ))}
                  {Object.entries(subjectQs).filter(([,v])=>v>0).map(([s,v])=>(
                    <div key={s} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'4px 0'}}>
                      <span style={{fontSize:10,color:sColor(s)}}>{s}</span>
                      <span style={{fontSize:10,fontWeight:700,color:sColor(s)}}>{v} Qs</span>
                    </div>
                  ))}
                  {passwordEnabled && <div style={{marginTop:8,fontSize:10,color:WRN}}>🔐 Password Protected</div>}
                </div>
              </div>
            </div>
          </div>

          {/* Step 1 Next button */}
          <div style={{marginTop:20}}>
            <button onClick={submitStep1} disabled={creating} className={shakeNext?'shake-anim':''}
              style={{...bp,width:'100%',fontSize:14,padding:'14px',letterSpacing:0.5,opacity:creating?0.7:1,boxShadow:`0 4px 20px ${PRP}44`}}>
              {creating ? '⟳ Creating Exam…' : 'Next: Add Questions →'}
            </button>
          </div>
        </div>
      )}

      {/* ════════════════ STEP 2 ════════════════════════════════════════════════ */}
      {step === 2 && (
        <div className={animDir==='right'?'step-enter':'step-enter-left'}>
          {/* Sticky top bar */}
          <div style={{position:'sticky' as any,top:0,zIndex:50,background:'rgba(0,8,24,0.97)',backdropFilter:'blur(16px)',borderBottom:`1px solid ${BOR}`,padding:'10px 14px',marginBottom:14,borderRadius:12,boxShadow:'0 4px 20px rgba(0,0,0,0.4)'}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',flexWrap:'wrap' as any,gap:8}}>
              <div style={{fontWeight:800,fontSize:13,color:balanceOk?SUC:WRN}}>
                {Object.entries(subjectQs).filter(([,v])=>v>0).map(([s,v])=>(
                  <span key={s} style={{marginRight:8,color:sColor(s)}}>
                    {selectedBySubj[s]||0}<span style={{color:DIM}}>/{v}</span> {s.slice(0,4)}
                  </span>
                ))}
                <span style={{color:DIM}}>= </span>
                <span style={{color:totalSelected>=totalTarget?SUC:WRN,fontWeight:900}}>{totalSelected}/{totalTarget}</span>
                {' '}{balanceOk?'✅':'⚠️'}
              </div>
              <div style={{display:'flex',gap:8,alignItems:'center'}}>
                {imgCount>0 && <span style={{fontSize:11,color:PHY}}>🖼️ {imgCount} image Qs</span>}
                {chapSet.size>0 && <span style={{fontSize:11,color:PRP}}>{chapSet.size} chapters</span>}
              </div>
            </div>
            {/* Difficulty mini bar */}
            <div style={{display:'flex',gap:3,marginTop:8,height:4,borderRadius:2,overflow:'hidden'}}>
              <div style={{width:`${easyPct}%`,background:SUC,transition:'all 0.3s'}}/>
              <div style={{width:`${medPct}%`,background:WRN,transition:'all 0.3s'}}/>
              <div style={{width:`${hardPct}%`,background:DNG,transition:'all 0.3s'}}/>
            </div>
            <div style={{display:'flex',gap:12,marginTop:4,fontSize:9,color:DIM}}>
              <span style={{color:SUC}}>Easy {easyPct}%</span>
              <span style={{color:WRN}}>Med {medPct}%</span>
              <span style={{color:DNG}}>Hard {hardPct}%</span>
            </div>
          </div>

          <div style={{display:'flex',gap:12}}>
            {/* Left: Source selector + filter + bank */}
            <div style={{flex:'1 1 260px',minWidth:0}}>
              {/* Method tabs */}
              <div style={{...cs,padding:'14px',marginBottom:12}}>
                <div style={{fontWeight:700,fontSize:13,color:TS,marginBottom:10}}>📦 Add Questions Via</div>
                <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:6}}>
                  {([['bank','🏦','QB Bank'],['pyq','📜','PYQ Bank'],['smart','✨','Smart AI'],['copypaste','📋','Paste'],['excel','📊','Excel'],['pdf','📄','PDF']] as const).map(([v,ico,l])=>(
                    <button key={v} onClick={()=>setQMethod(v)} style={{
                      padding:'9px 4px',background:qMethod===v?`linear-gradient(135deg,${PRP},#6D28D9)`:'rgba(0,22,40,0.6)',
                      border:`1px solid ${qMethod===v?PRP:BOR}`,borderRadius:9,
                      color:qMethod===v?'#fff':DIM,cursor:'pointer',fontSize:10,fontWeight:qMethod===v?700:400,transition:'all 0.2s',textAlign:'center' as any
                    }}>
                      <div style={{fontSize:16,marginBottom:2}}>{ico}</div>{l}
                    </button>
                  ))}
                </div>
              </div>

              {/* QB / PYQ Bank */}
              {(qMethod==='bank'||qMethod==='pyq')&&(
                <div style={cs}>
                  <div style={{fontWeight:700,fontSize:12,color:TS,marginBottom:10}}>🔍 Filter & Browse</div>
                  <div style={{display:'grid',gap:7,marginBottom:10}}>
                    <input value={bankFilter.search} onChange={e=>setBankFilter(p=>({...p,search:e.target.value}))} placeholder="Search questions..." style={{...inp,fontSize:11,padding:'8px 12px'}}/>
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6}}>
                      {[
                        {l:'Subject',k:'subject' as const,opts:['all',...SUBJECTS]},
                        {l:'Difficulty',k:'difficulty' as const,opts:['all','Easy','Medium','Hard']},
                        {l:'Type',k:'type' as const,opts:['all','SCQ','MSQ','Integer']},
                      ].map(f=>(
                        <div key={f.l}>
                          <label style={{...lbl,fontSize:9}}>{f.l}</label>
                          <select value={(bankFilter as any)[f.k]} onChange={e=>setBankFilter(p=>({...p,[f.k]:e.target.value}))} style={{...inp,fontSize:11,padding:'6px 8px',color:(bankFilter as any)[f.k]!=='all'?ACC:DIM}}>
                            {f.opts.map(o=><option key={o} value={o}>{o==='all'?`All ${f.l}`:o}</option>)}
                          </select>
                        </div>
                      ))}
                    </div>
                  </div>
                  {bankLoading ? (
                    <div style={{textAlign:'center' as any,padding:'30px',color:DIM}}>⟳ Loading...</div>
                  ) : (
                    <div style={{maxHeight:400,overflowY:'auto' as any,display:'flex',flexDirection:'column' as any,gap:5}}>
                      {bankQs.filter(q=>qMethod==='pyq'?q.isPYQ:!q.isPYQ).map(q=>{
                        const isSel = selectedQs.some(s=>s._id===q._id)
                        const isDup = !!duplicates[q._id]
                        return(
                          <div key={q._id} onClick={()=>{if(isSel)setSelectedQs(p=>p.filter(s=>s._id!==q._id));else setSelectedQs(p=>[...p,q])}}
                            style={{padding:'8px 10px',borderRadius:9,border:`1px solid ${isSel?sColor(q.subject):BOR}`,background:isSel?`${sColor(q.subject)}08`:'rgba(0,10,25,0.5)',cursor:'pointer',transition:'all 0.15s'}}>
                            <div style={{display:'flex',gap:6,marginBottom:4,alignItems:'center'}}>
                              <input type="checkbox" checked={isSel} onChange={()=>{}} style={{cursor:'pointer',accentColor:sColor(q.subject),flexShrink:0}}/>
                              <Badge l={q.subject||'Gen'} col={sColor(q.subject||'')}/>
                              <Badge l={q.difficulty||'?'} col={q.difficulty==='Hard'?DNG:q.difficulty==='Easy'?SUC:WRN}/>
                              {isDup && <Badge l={`Used ${duplicates[q._id]?.length}x`} col={WRN}/>}
                              {q.usageCount>0 && <span style={{fontSize:9,color:PHY,marginLeft:'auto'}}>📊 {q.usageCount}</span>}
                            </div>
                            <div style={{fontSize:11,color:'#CBD5E1',overflow:'hidden',display:'-webkit-box' as any,WebkitLineClamp:2,WebkitBoxOrient:'vertical' as any}}>{q.text}</div>
                            {q.chapter && <div style={{fontSize:9,color:DIM,marginTop:3}}>📖 {q.chapter}</div>}
                          </div>
                        )
                      })}
                      {bankQs.length === 0 && <div style={{textAlign:'center' as any,padding:'30px',color:DIM}}>No questions match filter</div>}
                    </div>
                  )}
                  <button onClick={importFromBank} disabled={uploading||!selectedQs.length} style={{...bp,width:'100%',marginTop:12,opacity:(uploading||!selectedQs.length)?0.5:1,fontSize:12}}>
                    {uploading?'⟳ Importing…':`Import ${selectedQs.length} Selected →`}
                  </button>
                </div>
              )}

              {/* Smart AI */}
              {qMethod==='smart'&&(
                <div style={{...cs,textAlign:'center' as any}}>
                  <div style={{fontSize:40,marginBottom:12}}>✨</div>
                  <div style={{fontWeight:700,fontSize:15,color:PRP,marginBottom:6}}>Smart Auto-Select</div>
                  <div style={{fontSize:12,color:DIM,marginBottom:16}}>AI will auto-select questions based on your subject splits, difficulty, and exam type</div>
                  <div style={{background:`${PRP}08`,border:`1px solid ${PRP}22`,borderRadius:10,padding:'12px',marginBottom:16,textAlign:'left' as any}}>
                    {Object.entries(subjectQs).filter(([,v])=>v>0).map(([s,v])=>(
                      <div key={s} style={{display:'flex',justifyContent:'space-between',fontSize:11,color:sColor(s),marginBottom:4}}>
                        <span>{s}</span><span style={{fontWeight:700}}>{v} Qs needed</span>
                      </div>
                    ))}
                  </div>
                  <button onClick={uploadQuestions} disabled={uploading} style={{...bp,width:'100%',fontSize:13,boxShadow:`0 4px 20px ${PRP}55`,opacity:uploading?0.7:1}}>
                    {uploading?'⟳ Auto-selecting…':'✨ Smart Select'}
                  </button>
                </div>
              )}

              {/* Copy-Paste */}
              {qMethod==='copypaste'&&(
                <div style={cs}>
                  <div style={{fontWeight:700,fontSize:13,color:TS,marginBottom:10}}>📋 Copy-Paste Questions</div>
                  <div style={{background:`${ACC}08`,border:`1px solid ${ACC}22`,borderRadius:8,padding:'10px',marginBottom:12,fontSize:11,color:DIM}}>
                    Format: <code style={{color:WRN}}>1. Question text\nA. Opt1\nB. Opt2\nC. Opt3\nD. Opt4</code>
                  </div>
                  <Field label="Questions Text">
                    <textarea rows={8} value={cpText} onChange={e=>setCpText(e.target.value)} placeholder={'1. Which element...\nA. Hydrogen\nB. Carbon\nC. Nitrogen\nD. Oxygen\n\n2. Next question...'} style={{...inp,resize:'vertical' as any}}/>
                  </Field>
                  <div style={{marginTop:8}}>
                    <Field label="Answer Key (optional)">
                      <textarea rows={3} value={cpKey} onChange={e=>setCpKey(e.target.value)} placeholder={'1-B\n2-A\n3-D'} style={{...inp,resize:'vertical' as any}}/>
                    </Field>
                  </div>
                  <button onClick={uploadQuestions} disabled={uploading||!cpText} style={{...bp,width:'100%',marginTop:12,opacity:(uploading||!cpText)?0.7:1}}>
                    {uploading?'⟳ Uploading…':'⬆️ Upload Questions'}
                  </button>
                </div>
              )}

              {/* Excel */}
              {qMethod==='excel'&&(
                <div style={{...cs,textAlign:'center' as any,padding:'30px'}}>
                  <div style={{fontSize:48,marginBottom:10}}>📊</div>
                  <div style={{fontWeight:700,fontSize:14,color:TS,marginBottom:6}}>Upload Excel / CSV</div>
                  <div style={{fontSize:11,color:DIM,marginBottom:16}}>Columns: <span style={{color:ACC}}>Question, Option A-D, Correct Answer, Subject, Difficulty, Explanation</span></div>
                  <div style={{border:`2px dashed ${BOR}`,borderRadius:12,padding:'20px',marginBottom:16,cursor:'pointer'}}>
                    <input type="file" accept=".xlsx,.xls,.csv" onChange={e=>setExcelFile(e.target.files?.[0]||null)} style={{color:TS,fontSize:12}}/>
                    {excelFile && <div style={{fontSize:11,color:SUC,marginTop:6}}>✅ {excelFile.name}</div>}
                  </div>
                  <button onClick={uploadQuestions} disabled={uploading||!excelFile} style={{...bp,width:'100%',opacity:(uploading||!excelFile)?0.7:1}}>
                    {uploading?'⟳ Processing…':'⬆️ Upload'}
                  </button>
                </div>
              )}

              {/* PDF */}
              {qMethod==='pdf'&&(
                <div style={{...cs,textAlign:'center' as any,padding:'30px'}}>
                  <div style={{fontSize:48,marginBottom:10}}>📄</div>
                  <div style={{fontWeight:700,fontSize:14,color:TS,marginBottom:6}}>Upload PDF</div>
                  <div style={{fontSize:11,color:WRN,marginBottom:16}}>⚠️ Works with selectable text PDFs only</div>
                  <div style={{border:`2px dashed ${BOR}`,borderRadius:12,padding:'20px',marginBottom:16}}>
                    <input type="file" accept=".pdf" onChange={e=>setPdfFile(e.target.files?.[0]||null)} style={{color:TS,fontSize:12}}/>
                    {pdfFile && <div style={{fontSize:11,color:SUC,marginTop:6}}>✅ {pdfFile.name}</div>}
                  </div>
                  <button onClick={uploadQuestions} disabled={uploading||!pdfFile} style={{...bp,width:'100%',opacity:(uploading||!pdfFile)?0.7:1}}>
                    {uploading?'⟳ Parsing…':'⬆️ Parse & Upload'}
                  </button>
                </div>
              )}

              {uploadRes && (
                <div style={{background:uploadRes.success?`${SUC}10`:`${DNG}10`,border:`1px solid ${uploadRes.success?SUC:DNG}44`,borderRadius:10,padding:'10px 14px',marginTop:10,fontSize:12,color:uploadRes.success?SUC:DNG}}>
                  {uploadRes.success?'✅':'❌'} {uploadRes.message}
                  {uploadRes.saved !== undefined && <div style={{fontSize:10,color:DIM,marginTop:3}}>Saved: {uploadRes.saved} | Failed: {uploadRes.failed||0}</div>}
                </div>
              )}

              {/* Multi-sets */}
              <div style={{...cs,marginTop:12}}>
                <div style={{fontWeight:700,fontSize:13,color:TS,marginBottom:10}}>🎲 Generate Multiple Sets</div>
                <div style={{fontSize:11,color:DIM,marginBottom:10}}>Auto-shuffle question order to create Set A, B, C...</div>
                <div style={{display:'flex',gap:10,alignItems:'center',marginBottom:10}}>
                  <Field label="Number of Sets">
                    <input type="number" value={setCount} onChange={e=>setSetCount(Math.min(6,Math.max(2,parseInt(e.target.value)||2)))} style={{...inp,padding:'7px 10px'}} min={2} max={6}/>
                  </Field>
                  <button onClick={generateSets} disabled={generatingSets||!selectedQs.length} style={{...bp,fontSize:11,padding:'10px 14px',marginTop:18,opacity:(generatingSets||!selectedQs.length)?0.7:1}}>
                    {generatingSets?'⟳':'🎲'} Generate
                  </button>
                </div>
                {generatedSets.length > 0 && (
                  <div style={{display:'flex',gap:6,flexWrap:'wrap' as any}}>
                    {generatedSets.map((s:any,i:number)=>(
                      <div key={i} style={{background:`${PRP}12`,border:`1px solid ${PRP}22`,borderRadius:8,padding:'6px 12px',fontSize:11,color:PRP,fontWeight:700}}>
                        Set {s.setLabel} — {s.questions.length} Qs
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Right: Selected questions tray */}
            <div style={{width:260,flexShrink:0}}>
              <div style={{position:'sticky' as any,top:130}}>
                <div style={{fontWeight:700,fontSize:12,color:DIM,marginBottom:8,textTransform:'uppercase' as any,letterSpacing:1}}>Selected ({selectedQs.length})</div>
                {selectedQs.length === 0 ? (
                  <div style={{...cs,textAlign:'center' as any,padding:'30px'}}>
                    <div style={{fontSize:36,marginBottom:8}}>📝</div>
                    <div style={{fontSize:11,color:DIM}}>Select questions from the bank or upload them</div>
                  </div>
                ) : (
                  <div style={{...cs,padding:'10px',maxHeight:500,overflowY:'auto' as any}}>
                    {selectedQs.map((q,i)=>(
                      <div key={q._id||i} draggable onDragStart={()=>onDragStart(i)} onDragOver={e=>e.preventDefault()} onDrop={()=>onDrop(i)}
                        style={{display:'flex',gap:7,alignItems:'flex-start',padding:'7px 8px',borderRadius:8,background:'rgba(255,255,255,0.02)',border:`1px solid ${BOR}`,marginBottom:5,cursor:'grab'}}>
                        <div style={{color:DIM,fontSize:12,flexShrink:0,cursor:'grab',marginTop:2}}>⠿</div>
                        <div style={{flex:1,minWidth:0}}>
                          <div style={{fontSize:9,display:'flex',gap:4,marginBottom:3,flexWrap:'wrap' as any}}>
                            <Badge l={`Q${i+1}`} col={ACC}/>
                            <Badge l={q.subject?.slice(0,4)||'Gen'} col={sColor(q.subject||'')}/>
                          </div>
                          <div style={{fontSize:10,color:'#CBD5E1',overflow:'hidden',display:'-webkit-box' as any,WebkitLineClamp:2,WebkitBoxOrient:'vertical' as any}}>{q.text}</div>
                        </div>
                        <button onClick={()=>setSelectedQs(p=>p.filter(s=>s._id!==q._id))} style={{background:'none',border:'none',color:DNG,cursor:'pointer',fontSize:14,flexShrink:0,lineHeight:1}}>✕</button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div style={{display:'flex',gap:10,marginTop:20}}>
            <button onClick={()=>goStep(1,'left')} style={{...bg_,fontSize:13}}>← Back</button>
            <button onClick={()=>{
              if (!balanceOk && totalSelected < totalTarget) { setShakeNext(true); setTimeout(()=>setShakeNext(false),600); T(`Questions incomplete: ${totalSelected}/${totalTarget}`,'w') }
              goStep(3)
            }} className={shakeNext?'shake-anim':''} style={{...bp,flex:1,fontSize:14,padding:'13px',boxShadow:`0 4px 20px ${PRP}44`}}>
              Next: Review & Publish →
            </button>
          </div>
        </div>
      )}

      {/* ════════════════ STEP 3 ════════════════════════════════════════════════ */}
      {step === 3 && (
        <div className={animDir==='right'?'step-enter':'step-enter-left'}>

          {/* Pre-publish checklist */}
          <div style={{...cs,marginBottom:14,borderColor:`${checklistOk?SUC:WRN}33`}}>
            <div style={{fontWeight:700,fontSize:13,color:TS,marginBottom:12}}>✅ Pre-publish Checklist</div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
              {checklist.map((c,i)=>(
                <div key={i} style={{display:'flex',gap:8,alignItems:'center',padding:'7px 10px',background:c.ok?`${SUC}08`:`${DNG}08`,borderRadius:9,border:`1px solid ${c.ok?SUC:DNG}22`}}>
                  <div style={{width:18,height:18,borderRadius:'50%',background:c.ok?SUC:DNG,display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,color:'#fff',flexShrink:0,transition:'all 0.3s'}}>
                    {c.ok?'✓':'!'}
                  </div>
                  <span style={{fontSize:11,color:c.ok?SUC:WRN,fontWeight:c.ok?600:400}}>{c.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Summary card */}
          <div style={{...cs,marginBottom:14,borderColor:`${PRP}22`}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
              <div style={{fontWeight:700,fontSize:14,color:TS}}>📋 Exam Summary</div>
              <button onClick={()=>goStep(1,'left')} style={{...bg_,fontSize:11,padding:'5px 12px'}}>✏️ Edit Details</button>
            </div>
            {reviewLoading ? (
              <div style={{textAlign:'center' as any,padding:'20px',color:DIM}}>⟳ Loading review...</div>
            ) : (
              <div>
                <div style={{fontFamily:'Playfair Display,serif',fontSize:20,fontWeight:800,color:TS,marginBottom:10}}>{reviewData?.exam?.title||title}</div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:12}}>
                  {[
                    ['📅 Start',startDate?new Date(startDate).toLocaleString('en-IN',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}):'Not set'],
                    ['⏱️ Duration',`${duration} min`],
                    ['❓ Questions',`${(reviewData?.exam?.questions||[]).length} / ${totalTarget}`],
                    ['🏆 Total Marks',`${totalMarks}`],
                    ['✅/❌ Marking',`+${correctMarks} / −${negativeMarks}`],
                    ['🏫 Assignment',assignType==='open'?'Open Access':assignType==='batch'?(batches.find((b:any)=>b._id===batchId)?.name||'Batch'):(testSeries.find((s:any)=>s._id===testSeriesId)?.name||'Series')],
                    ['🔐 Password',passwordEnabled?'Set':'None'],
                    ['📊 Category',category],
                  ].map(([l,v])=>(
                    <div key={String(l)} style={{padding:'8px 10px',background:'rgba(255,255,255,0.02)',borderRadius:8,border:`1px solid ${BOR}`}}>
                      <div style={{fontSize:10,color:DIM,marginBottom:2}}>{l}</div>
                      <div style={{fontSize:12,color:TS,fontWeight:600}}>{v}</div>
                    </div>
                  ))}
                </div>
                {/* Difficulty estimate */}
                {(reviewData?.exam?.questions||[]).length > 0 && (() => {
                  const qs = reviewData.exam.questions
                  const hard = qs.filter((q:any) => q.difficulty==='Hard'||q.difficulty==='hard').length
                  const easy = qs.filter((q:any) => q.difficulty==='Easy'||q.difficulty==='easy').length
                  const pct  = Math.round(hard/qs.length*100)
                  const rating = pct >= 50 ? 'Hard' : pct >= 30 ? 'Medium-Hard' : easy/qs.length > 0.5 ? 'Easy' : 'Medium'
                  const col   = rating.includes('Hard') ? DNG : rating==='Medium' ? WRN : SUC
                  return (
                    <div style={{display:'flex',alignItems:'center',gap:8,padding:'8px 12px',background:`${col}08`,border:`1px solid ${col}22`,borderRadius:9}}>
                      <span style={{fontSize:14}}>📊</span>
                      <span style={{fontSize:12,color:col,fontWeight:700}}>Estimated Difficulty: {rating}</span>
                      <span style={{fontSize:10,color:DIM,marginLeft:'auto'}}>Based on question mix</span>
                    </div>
                  )
                })()}
              </div>
            )}
          </div>

          {/* Questions accordion */}
          <div style={{...cs,marginBottom:14}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <div style={{fontWeight:700,fontSize:13,color:TS}}>❓ Questions ({(reviewData?.exam?.questions||[]).length})</div>
              <div style={{display:'flex',gap:8}}>
                <button onClick={()=>goStep(2,'left')} style={{...bg_,fontSize:11,padding:'5px 12px'}}>✏️ Edit</button>
                <button onClick={()=>setQuestionsExpanded(p=>!p)} style={{...bg_,fontSize:11,padding:'5px 10px'}}>{questionsExpanded?'▲':'▼'}</button>
              </div>
            </div>
            {questionsExpanded && (
              <div style={{marginTop:12,maxHeight:400,overflowY:'auto' as any}}>
                {(reviewData?.exam?.questions||[]).map((q:any,i:number)=>(
                  <div key={q._id||i} style={{padding:'8px 10px',borderRadius:8,background:'rgba(255,255,255,0.02)',border:`1px solid ${BOR}`,marginBottom:5}}>
                    <div style={{display:'flex',gap:6,marginBottom:4,alignItems:'center'}}>
                      <Badge l={`Q${i+1}`} col={ACC}/>
                      <Badge l={q.subject||'Gen'} col={sColor(q.subject||'')}/>
                      <Badge l={q.difficulty||'?'} col={q.difficulty==='Hard'?DNG:q.difficulty==='Easy'?SUC:WRN}/>
                    </div>
                    <div style={{fontSize:11,color:'#CBD5E1',overflow:'hidden',display:'-webkit-box' as any,WebkitLineClamp:2,WebkitBoxOrient:'vertical' as any}}>{q.text}</div>
                    {q.explanation && <div style={{fontSize:10,color:SUC,marginTop:3}}>💡 Has explanation</div>}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Student count */}
          {reviewData?.studentCount !== undefined && (
            <div style={{...cs,marginBottom:14,borderColor:`${PHY}22`}}>
              <div style={{display:'flex',gap:10,alignItems:'center'}}>
                <div style={{fontSize:32,fontWeight:900,color:PHY}}>{reviewData.studentCount}</div>
                <div>
                  <div style={{fontWeight:700,fontSize:13,color:TS}}>Students will see this exam</div>
                  <div style={{fontSize:10,color:DIM}}>Based on {assignType==='batch'?'selected batch':'all students'}</div>
                </div>
              </div>
            </div>
          )}

          {/* Exam link */}
          <div style={{...cs,marginBottom:14,borderColor:`${GOLD}22`}}>
            <div style={{fontWeight:700,fontSize:12,color:GOLD,marginBottom:8}}>🔗 Exam Link</div>
            <div style={{display:'flex',gap:8}}>
              <input readOnly value={`${typeof window!=='undefined'?window.location.origin:''}/exam/${createdExamId}`} style={{...inp,color:DIM,fontSize:11}}/>
              <button onClick={copyLink} style={{...bg_,flexShrink:0,color:GOLD,borderColor:`${GOLD}33`,padding:'10px 14px'}}>📋</button>
            </div>
          </div>

          {/* Notify students toggle */}
          <div style={{...cs,marginBottom:14}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <div>
                <div style={{fontSize:13,color:TS,fontWeight:600}}>🔔 Notify Students on Publish</div>
                <div style={{fontSize:10,color:DIM,marginTop:2}}>Send notification to all students in assigned batch</div>
              </div>
              <Toggle on={notifyStudents} onChange={setNotifyStudents}/>
            </div>
          </div>

          {/* Password reminder */}
          {passwordEnabled && password && (
            <div style={{...cs,marginBottom:14,borderColor:`${WRN}33`,background:`${WRN}05`}}>
              <div style={{fontWeight:700,fontSize:12,color:WRN,marginBottom:4}}>🔐 Password Reminder</div>
              <div style={{fontSize:13,color:TS,fontFamily:'monospace',background:'rgba(0,0,0,0.3)',padding:'8px 12px',borderRadius:8,letterSpacing:1}}>{password}</div>
              <div style={{fontSize:10,color:DIM,marginTop:4}}>Save this — students will need it to access the exam</div>
            </div>
          )}

          {/* Publish actions */}
          <div style={{...cs,borderColor:`${PRP}33`,background:`${PRP}05`}}>
            <div style={{fontWeight:700,fontSize:13,color:TS,marginBottom:14}}>🚀 Publish Options</div>

            {/* Schedule */}
            <div style={{marginBottom:14,padding:'12px',background:'rgba(0,0,0,0.2)',borderRadius:10,border:`1px solid ${ACC}22`}}>
              <div style={{fontSize:12,color:ACC,fontWeight:700,marginBottom:8}}>⏰ Schedule Auto-Publish</div>
              <div style={{display:'flex',gap:8}}>
                <input type="datetime-local" value={publishAt} onChange={e=>setPublishAt(e.target.value)} style={{...inp,flex:1,fontSize:11}}/>
                <button onClick={doSchedule} disabled={scheduling||!publishAt} style={{flexShrink:0,background:`linear-gradient(135deg,${ACC},#0044AA)`,color:'#fff',border:'none',borderRadius:9,padding:'10px 14px',cursor:'pointer',fontWeight:700,fontSize:12,boxShadow:`0 4px 16px ${ACC}44`,opacity:(scheduling||!publishAt)?0.6:1}}>
                  {scheduling?'⟳':'⏰'} Schedule
                </button>
              </div>
            </div>

            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:8}}>
              {/* Save Draft */}
              <button onClick={()=>doPublish(true)} disabled={publishing} style={{...bg_,padding:'12px 8px',fontSize:12,textAlign:'center' as any,opacity:publishing?0.7:1}}>
                💾 Save Draft
              </button>
              {/* Save Template */}
              <button onClick={async()=>{
                try{const r=await fetch(`${API}/api/exam-wizard/templates`,{method:'POST',headers:hdrs,body:JSON.stringify({name:title,subject,category,totalQs,subjectQs,examType,duration,totalMarks,correctMarks,negativeMarks,icon:'📋'})});const d=await r.json();if(d.success)T('Saved as template ✅');else T('Failed','e')}catch{T('Error','e')}
              }} style={{...bg_,padding:'12px 8px',fontSize:12,textAlign:'center' as any,color:GOLD,borderColor:`${GOLD}22`}}>
                📁 Save Template
              </button>
              {/* Clone */}
              <button onClick={doClone} disabled={cloning} style={{...bg_,padding:'12px 8px',fontSize:12,textAlign:'center' as any,opacity:cloning?0.7:1}}>
                📑 Clone Exam
              </button>
            </div>

            {/* Publish Now */}
            <button onClick={()=>doPublish(false)} disabled={publishing} style={{...bp,width:'100%',marginTop:12,fontSize:16,padding:'16px',boxShadow:`0 6px 30px ${PRP}66`,opacity:publishing?0.7:1,letterSpacing:0.5}}>
              {publishing ? '⟳ Publishing…' : '🚀 Publish Now'}
            </button>
          </div>

          {/* Back button */}
          <div style={{marginTop:12}}>
            <button onClick={()=>goStep(2,'left')} style={{...bg_,width:'100%'}}>← Back to Questions</button>
          </div>
        </div>
      )}
    </div>
  )
}
