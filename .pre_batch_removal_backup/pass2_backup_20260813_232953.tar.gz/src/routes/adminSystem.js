const express = require('express');
const router = express.Router();
const { verifyToken, isSuperAdmin } = require('../middleware/auth');

// In-memory store (MongoDB mein save karna ho toh model banao)
// Maintenance state ab MongoDB mein save hoga
let featureFlags = {
  darkMode: true, liveRank: true, webcam: true,
  twoFactor: true, aiFeatures: true, pyqBank: true,
  bulkImport: true, pdfExport: true, emailNotifications: false
};

// ── S66: MAINTENANCE MODE ────────────────────────────────────
router.post('/maintenance', verifyToken, isSuperAdmin, async (req, res) => {
  const { enabled, message, allowedEmails } = req.body;
  const mongoose = require('mongoose')
  await mongoose.connection.db.collection('settings').updateOne(
    { key: 'maintenance' },
    { $set: { enabled: enabled === true, message: message || 'Site under maintenance. We will be back shortly.', allowedEmails: Array.isArray(allowedEmails) ? allowedEmails : [], updatedAt: new Date() } },
    { upsert: true }
  )
  const saved = await mongoose.connection.db.collection('settings').findOne({ key: 'maintenance' })
  // F42A §2.4.2 — auto-announcement trigger on maintenance mode toggle
  try {
    const Announcement = require('../models/Announcement')
    const User = require('../models/User')
    const targetCount = await User.countDocuments({ role: 'student', banned: { $ne: true } })
    await Announcement.create({
      title: enabled ? 'Scheduled Maintenance' : 'Maintenance Complete',
      message: enabled
        ? (message || 'The platform will undergo scheduled maintenance shortly. Some features may be temporarily unavailable.')
        : 'Maintenance is complete — the platform is back to normal. Thank you for your patience!',
      type: 'maintenance', audience: { mode: 'all' }, sendVia: 'in-app',
      pinned: enabled, status: 'sent', createdBy: req.user.id,
      templateName: 'Maintenance Notice (auto)', targetCount,
    })
  } catch (e) { console.error('[F42A auto-announcement] maintenance trigger failed:', e.message) }
  res.json({ success: true, message: `Maintenance mode ${enabled ? 'ON' : 'OFF'} ho gaya`, state: saved });
});

router.get('/maintenance', async (req, res) => {
  const mongoose = require('mongoose')
  const state = await mongoose.connection.db.collection('settings').findOne({ key: 'maintenance' })
  res.json({ success: true, maintenance: state || { enabled: false, message: '' } });
});

// ── N21: FEATURE FLAG SYSTEM ─────────────────────────────────
router.get('/feature-flags', verifyToken, isSuperAdmin, (req, res) => {
  res.json({ success: true, flags: featureFlags });
});

router.put('/feature-flags', verifyToken, isSuperAdmin, (req, res) => {
  const { feature, enabled } = req.body;
  if (!feature) return res.status(400).json({ message: 'feature name required' });
  featureFlags[feature] = enabled === true;
  res.json({ success: true, message: `Feature '${feature}' ${enabled ? 'ON' : 'OFF'} ho gaya`, flags: featureFlags });
});

router.put('/feature-flags/bulk', verifyToken, isSuperAdmin, (req, res) => {
  const { flags } = req.body;
  if (!flags || typeof flags !== 'object')
    return res.status(400).json({ message: 'flags object required' });
  Object.assign(featureFlags, flags);
  res.json({ success: true, message: 'Bulk flags update ho gaye', flags: featureFlags });
});


// ── N21: FEATURE FLAGS - MongoDB Persistent (/features) ──────
const FeatureFlag = require('../models/FeatureFlag');
const DEFAULT_FLAGS = [
  {key:'open_registration',label:'Student Registration',description:'Allow new student registrations. Toggle OFF to close (Superadmin only)',enabled:true},
  {key:'webcam',label:'Webcam Proctoring',description:'Camera compulsory during exams (Phase 5.2)',enabled:true},
  {key:'audio',label:'Audio Monitoring',description:'Microphone noise detection (S57)',enabled:false},
  {key:'eyeTracking',label:'Eye Tracking AI',description:'Detect looking away from screen (S-ET)',enabled:false},
  {key:'faceDetection',label:'Face Detection TF.js',description:'Multi/no-face detection (Phase 5.4)',enabled:false},
  {key:'headPose',label:'Head Pose Detection',description:'Head angle tracking (S73)',enabled:false},
  {key:'virtualBg',label:'Virtual Background Block',description:'Detect and block fake backgrounds (S74)',enabled:false},
  {key:'vpnBlock',label:'VPN/Proxy Block',description:'Block VPN users from attempting (S20)',enabled:false},
  {key:'liveRank',label:'Live Rank Updates',description:'Socket.io real-time ranking (S107)',enabled:true},
  {key:'socialShare',label:'Social Share Results',description:'WhatsApp/Instagram result card (S99)',enabled:true},
  {key:'parentPortal',label:'Parent Portal',description:'Read-only child progress access (N17)',enabled:false},
  {key:'pyqBank',label:'PYQ Bank Access',description:'NEET 2015-2024 questions (S104)',enabled:true},
  {key:'maintenance',label:'Maintenance Mode',description:'Block students, keep admin accessible (S66)',enabled:false},
  {key:'sms',label:'SMS Notifications',description:'Result SMS via Textlocal/2SMS (M19)',enabled:false},
  {key:'whatsapp',label:'WhatsApp Alerts',description:'Exam reminders via WhatsApp (S65)',enabled:false},
  {key:'twoFactor',label:'Two Factor Auth',description:'Admin mandatory 2FA (Phase 1.1)',enabled:true},
  {key:'aiFeatures',label:'AI Features',description:'AI tagging, difficulty, classifier',enabled:true},
  {key:'bulkImport',label:'Bulk Import',description:'Excel/PDF/Copy-paste upload',enabled:true},
  {key:'pdfExport',label:'PDF Export',description:'Result/report PDF download',enabled:true},
  {key:'emailNotifications',label:'Email Notifications',description:'Email templates active (S109)',enabled:false},
  {key:'antiCheat',label:'Anti-Cheat System',description:'Full proctoring system active',enabled:true},
  {key:'reAttempt',label:'Re-Attempt System',description:'Admin can allow re-attempts (S31)',enabled:true},
  {key:'leaderboard',label:'Leaderboard',description:'Public rank leaderboard visible',enabled:true},
  {key:'questionAI',label:'Question AI Generator',description:'AI question generation (S101)',enabled:true},
  {key:'admitCard',label:'Admit Card',description:'Digital admit card system (S106)',enabled:true},
  {key:'grievance',label:'Grievance System',description:'Student grievance submission (S92)',enabled:true},
  {key:'darkMode',label:'Dark Mode',description:'Platform dark theme default',enabled:true}
];
async function seedDefaultFlags(){
  try{
    for(const f of DEFAULT_FLAGS){
      await FeatureFlag.findOneAndUpdate({key:f.key},{$setOnInsert:{key:f.key,label:f.label,description:f.description,enabled:f.enabled}},{upsert:true,new:false});
    }
  }catch(e){console.log('Flag seed error:',e.message);}
}
setTimeout(()=>seedDefaultFlags(),3000);

router.get('/features', verifyToken, isSuperAdmin, async (req, res) => {
  try {
    let flags = await FeatureFlag.find({}).lean();
    if(!flags||flags.length===0){ await seedDefaultFlags(); flags=await FeatureFlag.find({}).lean(); }
    const flagsObj={};
    flags.forEach(f=>{flagsObj[f.key]=f.enabled;});
    global.featureFlags=flagsObj;
    res.json(flags);
  } catch(e){ res.status(500).json({success:false,message:e.message}); }
});

router.post('/features', verifyToken, isSuperAdmin, async (req, res) => {
  try {
    const {key,enabled}=req.body;
    if(!key) return res.status(400).json({message:'key required'});
    const flag=await FeatureFlag.findOneAndUpdate(
      {key},
      {enabled:enabled===true,updatedAt:new Date()},
      {upsert:true,new:true}
    );
    if(!global.featureFlags) global.featureFlags={};
    global.featureFlags[key]=enabled===true;
    res.json({success:true,message:key+' '+(enabled?'enabled':'disabled'),flag});
  } catch(e){ res.status(500).json({success:false,message:e.message}); }
});


// ── S109: Admin Email Send (POST /api/admin/email/send) ──────────
router.post('/email/send', verifyToken, async (req, res) => {
  try {
    const { type, subject, body } = req.body
    if (!subject || !body) return res.status(400).json({success:false,message:'Subject aur body required hai'})
    const { sendCustomEmail } = require('../utils/emailService')
    const User = require('../models/User')
    let recipients = []
        let recipientObjs = []
    if (type==='broadcast'||type==='reminder'||type==='result'||type==='announcement'||type==='welcome'||type==='custom'||true) {
      const students = await User.collection.find(
        {role:'student',banned:{$ne:true}},{projection:{email:1}}
      ).toArray()
          recipientObjs = students.filter(s=>s.email&&!s.email.includes('@proverank.com')).map(s=>({email:s.email,name:s.name||'Student'}))
          recipients = recipientObjs.map(r=>r.email)
    }
          // admin email removed
          // admin fallback removed
    // Send individually with name personalization
        let sentCount = 0
        for(const r of recipientObjs){
          try{
            const personalBody = body.replace(/{student_name}/g, r.name).replace(/{date}/g, new Date().toLocaleDateString('en-IN'))
            await sendCustomEmail([r.email], subject, personalBody)
            sentCount++
          }catch(e){console.error('Failed:',r.email,e.message)}
        }
        const result = {success:true, message:'Sent to '+sentCount+' students!'}
    if (!result.success) return res.status(500).json({success:false,message:'Email failed: '+(result.error||'Unknown')})
    res.json({success:true,message:`Email sent to ${recipients.length} recipient(s)`})
  } catch(e){
    console.error('[S109]',e.message)
    res.status(500).json({success:false,message:e.message})
  }
})


// ── S109 Option B: Email Template Routes ─────────────────────────
const EmailTemplate = require('../models/EmailTemplate')

// Save template to MongoDB
router.post('/email/template/save', verifyToken, isSuperAdmin, async (req, res) => {
  try {
    const { type, subject, body } = req.body
    if (!type || !subject || !body)
      return res.status(400).json({ success:false, message:'type, subject, body required' })
    const template = await EmailTemplate.findOneAndUpdate(
      { type },
      { type, subject, htmlBody:body, active:true, updatedBy:req.user.email, updatedAt:new Date() },
      { upsert:true, new:true }
    )
    res.json({ success:true, message:`${type} template saved & activated!`, template })
  } catch(e) { res.status(500).json({ success:false, message:e.message }) }
})

// Get saved template by type
router.get('/email/template/:type', verifyToken, async (req, res) => {
  try {
    const template = await EmailTemplate.findOne({ type: req.params.type })
    if (!template) return res.json({ success:false, message:'Template not saved yet' })
    res.json({ success:true, template })
  } catch(e) { res.status(500).json({ success:false, message:e.message }) }
})

// Get all templates
router.get('/email/templates', verifyToken, async (req, res) => {
  try {
    const templates = await EmailTemplate.find({})
    res.json({ success:true, templates })
  } catch(e) { res.status(500).json({ success:false, message:e.message }) }
})

// Broadcast — Manual send to all students
router.post('/email/send', verifyToken, isSuperAdmin, async (req, res) => {
  try {
    const { type, subject, body } = req.body
    if (!subject || !body)
      return res.status(400).json({ success:false, message:'Subject aur body required' })
    const { sendCustomEmail } = require('../utils/emailService')
    const User = require('../models/User')
    const students = await User.collection.find(
      { role:'student', banned:{ $ne:true } },
      { projection:{ email:1 } }
    ).toArray()
    let recipientObjs = students.map(s=>({email:s.email,name:s.name||'Student'})).filter(r=>r.email)
        let recipients = recipientObjs.map(r=>r.email)
    const adminEmail = req.user?.email || 'admin@proverank.com'
    // adminEmail unshift removed — only student emails
    if (recipients.length===0) recipients = [adminEmail]
    const result = await sendCustomEmail(recipients, subject, body)
    if (!result.success) return res.status(500).json({ success:false, message:result.error })
    res.json({ success:true, message:`Broadcast sent to ${recipients.length} students!` })
  } catch(e) { res.status(500).json({ success:false, message:e.message }) }
})

module.exports = router

// GLOBAL SEARCH API (M12)
router.get('/global-search', verifyToken, isSuperAdmin, async (req, res) => {
  try {
    const { q = '' } = req.query
    if (!q || q.length < 2) return res.json({ success: true, results: { students: [], admins: [], exams: [], questions: [], batches: [] } })
    const rx = new RegExp(q, 'i')
    const db = req.app.locals.db || router.db
    const col = (name) => require('mongoose').connection.db.collection(name)
    const [students, admins, exams, questions, batches] = await Promise.all([
      col('students').find({ role: 'student', $or: [{ name: rx }, { email: rx }, { studentId: rx }] }).limit(8).project({ name: 1, email: 1, studentId: 1 }).toArray(),
      col('students').find({ role: { $in: ['admin', 'superadmin'] }, $or: [{ name: rx }, { email: rx }, { adminId: rx }] }).limit(6).project({ name: 1, email: 1, adminId: 1, role: 1 }).toArray(),
      col('exams').find({ $or: [{ title: rx }, { status: rx }] }).limit(8).project({ title: 1, status: 1, createdAt: 1 }).toArray(),
      col('questions').find({ $or: [{ text: rx }, { subject: rx }, { chapter: rx }] }).limit(8).project({ text: 1, subject: 1, chapter: 1, difficulty: 1 }).toArray(),
      col('batches').find({ name: rx }).limit(6).project({ name: 1, description: 1 }).toArray()
    ])
    res.json({ success: true, results: { students, admins, exams, questions, batches } })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// Global search for admin role too
router.get('/global-search-admin', verifyToken, isSuperAdmin, async (req, res) => {
  try {
    const { q = '' } = req.query
    if (!q || q.length < 2) return res.json({ success: true, results: { students: [], admins: [], exams: [], questions: [], batches: [] } })
    const rx = new RegExp(q, 'i')
    const col = (name) => require('mongoose').connection.db.collection(name)
    const [students, exams, questions, batches] = await Promise.all([
      col('students').find({ role: 'student', $or: [{ name: rx }, { email: rx }, { studentId: rx }] }).limit(8).project({ name: 1, email: 1, studentId: 1 }).toArray(),
      col('exams').find({ $or: [{ title: rx }, { status: rx }] }).limit(8).project({ title: 1, status: 1 }).toArray(),
      col('questions').find({ $or: [{ text: rx }, { subject: rx }, { chapter: rx }] }).limit(8).project({ text: 1, subject: 1, chapter: 1, difficulty: 1 }).toArray(),
      col('batches').find({ name: rx }).limit(6).project({ name: 1, description: 1 }).toArray()
    ])
    res.json({ success: true, results: { students, admins: [], exams, questions, batches } })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})
