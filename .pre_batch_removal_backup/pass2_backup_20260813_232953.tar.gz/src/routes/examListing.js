/**
 * ProveRank — Feature 33: All Exams — List, Filter, Search
 * Mounted at /api/exams-manage (deliberately a DIFFERENT prefix from /api/exams,
 * which is already shared by 6 other routers — exam.js, examFeatures.js,
 * examPatchRoutes, examPaperRoutes, examExtraRoutes, examSubmissionRoutes —
 * to avoid any risk of an existing GET /:id style route silently shadowing
 * these new endpoints depending on mount order).
 *
 * Delete (33.9) and Clone (33.9) reuse the EXISTING, already-working
 * DELETE /api/exams/:id and POST /api/exams/:examId/clone — not duplicated here.
 *
 * Status mapping note: the real Exam schema enum is
 *   draft / scheduled / live / ended
 * which the UI shows as: Draft / Upcoming / Active / Completed.
 *
 *  33.1  GET  /list             paginated/filtered/sorted exam list + stats bar counts
 *  33.2  search query param     SMART search by title
 *  33.3  status query param     filter by draft/scheduled/live/ended
 *  33.4  category/subject       filter by category + subject
 *  33.5  batch/series           filter by batch + seriesName
 *  33.6  startDate/endDate      filter by schedule.startTime range
 *  33.7  studentCount           computed per exam via Attempt aggregation
 *  33.8  sort query param       newest/oldest/dateAsc/dateDesc
 *  33.9  (reuses existing)      Edit→quick-edit below, Clone/Delete reuse routes/exam.js
 *  33.10 page/limit             pagination
 *  33.11 PATCH /:id/publish     quick status toggle (Draft → Scheduled/Live)
 *  33.12 mine/createdBy         "My Created Exams" + superadmin admin-picker
 *  33.14 GET /:id/analytics     attempts, avg score, pass%, leaderboard, distribution
 *  33.17 GET /export            CSV/XLSX export of the filtered list
 *  33.18 needsAttention         filter — no batch assigned OR 0 questions
 *  33.20 PATCH /:id/pin         pin toggle
 *  33.27 POST /bulk-delete,
 *        POST /bulk-publish     bulk actions
 */
const express = require('express')
const router  = express.Router()
const { verifyToken, isAdmin } = require('../middleware/auth')
const Exam = require('../models/Exam')

// ── 29-style helper: who can see what (33.12) ─────────────────────────────────
function visibilityFilter(req) {
  const f = {}
  if (req.user.role !== 'superadmin') {
    f.createdBy = req.user.id // admins always see only their own
  } else {
    if (req.query.mine === 'true') f.createdBy = req.user.id
    else if (req.query.createdBy) f.createdBy = req.query.createdBy
    // else: superadmin sees everyone's exams
  }
  return f
}

function buildFilter(req) {
  const { search, status, category, subject, batch, series, startDate, endDate, needsAttention } = req.query
  const filter = visibilityFilter(req)
  filter.isArchived = { $ne: true } // Feature 34 — archived exams only show in the Recycle Bin (/trash)
  if (search && String(search).trim()) filter.title = new RegExp(String(search).trim(), 'i')
  if (status) {
    const statuses = String(status).split(',').map(s => s.trim()).filter(Boolean)
    if (statuses.length) filter.status = { $in: statuses }
  }
  if (category) filter.category = category
  if (subject) filter.subject = subject
  if (batch) filter.batch = batch
  if (series) filter.seriesName = series
  if (startDate || endDate) {
    filter['schedule.startTime'] = {}
    if (startDate) filter['schedule.startTime'].$gte = new Date(startDate)
    if (endDate) filter['schedule.startTime'].$lte = new Date(endDate)
  }
  if (needsAttention === 'true') {
    filter.$or = [{ batch: '' }, { batch: null }, { questions: { $size: 0 } }]
  }
  return filter
}

// ════════════════════════════════════════════════════════════════
// 33.4 / 33.5 — FILTER OPTIONS (dynamic distinct values — always matches real data)
// ════════════════════════════════════════════════════════════════
router.get('/filter-options', verifyToken, isAdmin, async (req, res) => {
  try {
    const filter = req.user.role === 'superadmin' ? {} : { createdBy: req.user.id }
    const [categories, subjects, batches, series] = await Promise.all([
      Exam.distinct('category', filter),
      Exam.distinct('subject', filter),
      Exam.distinct('batch', filter),
      Exam.distinct('seriesName', filter)
    ])
    res.json({
      success: true,
      categories: categories.filter(Boolean),
      subjects: subjects.filter(Boolean),
      batches: batches.filter(Boolean),
      series: series.filter(Boolean)
    })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ════════════════════════════════════════════════════════════════
// 33.12 — ADMINS LIST (superadmin "view by admin" picker)
// ════════════════════════════════════════════════════════════════
router.get('/admins', verifyToken, isAdmin, async (req, res) => {
  try {
    if (req.user.role !== 'superadmin') return res.status(403).json({ success: false, message: 'Superadmin access required' })
    const User = require('../models/User')
    const creatorIds = await Exam.distinct('createdBy')
    const admins = await User.find({ _id: { $in: creatorIds } }).select('name email role')
    const counts = await Exam.aggregate([{ $group: { _id: '$createdBy', count: { $sum: 1 } } }])
    const countMap = {}
    counts.forEach(c => { countMap[String(c._id)] = c.count })
    const result = admins.map(a => ({ _id: a._id, name: a.name, email: a.email, role: a.role, examCount: countMap[String(a._id)] || 0 }))
    res.json({ success: true, admins: result })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ════════════════════════════════════════════════════════════════
// 33.1 — MAIN LIST (filters + sort + pagination + stats bar)
// ════════════════════════════════════════════════════════════════
router.get('/list', verifyToken, isAdmin, async (req, res) => {
  try {
    const filter = buildFilter(req)

    let sortSpec = { createdAt: -1 } // newest (default)
    if (req.query.sort === 'oldest') sortSpec = { createdAt: 1 }
    else if (req.query.sort === 'dateAsc') sortSpec = { 'schedule.startTime': 1 }
    else if (req.query.sort === 'dateDesc') sortSpec = { 'schedule.startTime': -1 }
    const finalSort = { isPinned: -1, ...sortSpec } // pinned always first — 33.20

    const page = Math.max(1, parseInt(req.query.page) || 1)
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 20))
    const skip = (page - 1) * limit

    const total = await Exam.countDocuments(filter)
    const exams = await Exam.find(filter)
      .select('title category subject type duration totalMarks status batch seriesName schedule createdAt isPinned questions createdBy markingScheme assignmentType clonedFrom')
      .sort(finalSort).skip(skip).limit(limit)
      .populate('createdBy', 'name email')
      .populate('clonedFrom', 'title')
      .lean()

    // 33.7 — student count per exam (distinct attempters), single batched aggregation
    const Attempt = require('../models/Attempt')
    const examIds = exams.map(e => e._id)
    const counts = examIds.length ? await Attempt.aggregate([
      { $match: { examId: { $in: examIds } } },
      { $group: { _id: '$examId', students: { $addToSet: '$studentId' } } }
    ]) : []
    const countMap = {}
    counts.forEach(c => { countMap[String(c._id)] = (c.students || []).length })

    // 31.9 / 31.10 — clone count: how many other exams were cloned FROM each of these
    const cloneCounts = examIds.length ? await Exam.aggregate([
      { $match: { clonedFrom: { $in: examIds } } },
      { $group: { _id: '$clonedFrom', n: { $sum: 1 } } }
    ]) : []
    const cloneCountMap = {}
    cloneCounts.forEach(c => { cloneCountMap[String(c._id)] = c.n })

    exams.forEach(e => {
      e.studentCount = countMap[String(e._id)] || 0
      e.questionCount = (e.questions || []).length
      e.cloneCount = cloneCountMap[String(e._id)] || 0
      delete e.questions // not needed on the list view, keeps payload light
    })

    // 33.21 — stats bar counts, scoped to the same visibility (not the other filters)
    const statsBase = visibilityFilter(req)
    const [totalAll, draftC, scheduledC, liveC, endedC] = await Promise.all([
      Exam.countDocuments(statsBase),
      Exam.countDocuments({ ...statsBase, status: 'draft' }),
      Exam.countDocuments({ ...statsBase, status: 'scheduled' }),
      Exam.countDocuments({ ...statsBase, status: 'live' }),
      Exam.countDocuments({ ...statsBase, status: 'ended' })
    ])

    res.json({
      success: true,
      exams,
      total, page, totalPages: Math.max(1, Math.ceil(total / limit)),
      stats: { total: totalAll, draft: draftC, scheduled: scheduledC, live: liveC, ended: endedC }
    })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ════════════════════════════════════════════════════════════════
// 33.14 — ANALYTICS QUICK VIEW (side panel)
// ════════════════════════════════════════════════════════════════
// ════════════════════════════════════════════════════════════════
// NEW — PREVIEW EXAM CONTENT (admin checks questions/options render
// correctly before students attempt it). Read-only, no attempt created.
// ════════════════════════════════════════════════════════════════
router.get('/:id/preview', verifyToken, isAdmin, async (req, res) => {
  try {
    const exam = await Exam.findById(req.params.id).populate('questions').lean()
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' })
    res.json({ success: true, examTitle: exam.title, questions: exam.questions || [] })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

router.get('/:id/analytics', verifyToken, isAdmin, async (req, res) => {
  try {
    const exam = await Exam.findById(req.params.id).select('title totalMarks duration category subject type status schedule questions')
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' })
    const Attempt = require('../models/Attempt')
    const tm = exam.totalMarks || 720
    const passMark = tm * 0.5

    const summaryAgg = await Attempt.aggregate([
      { $match: { examId: exam._id, status: { $in: ['submitted', 'timeout'] } } },
      { $group: {
          _id: null,
          totalAttempts: { $sum: 1 },
          avgScore: { $avg: '$score' },
          maxScore: { $max: '$score' },
          minScore: { $min: '$score' },
          passed: { $sum: { $cond: [{ $gte: ['$score', passMark] }, 1, 0] } }
      } }
    ])
    const s = summaryAgg[0] || { totalAttempts: 0, avgScore: 0, maxScore: 0, minScore: 0, passed: 0 }
    const passRate = s.totalAttempts ? (s.passed / s.totalAttempts) * 100 : 0
    const startedCount = await Attempt.countDocuments({ examId: exam._id })
    const completionRate = startedCount ? (s.totalAttempts / startedCount) * 100 : 0

    const leaderboard = await Attempt.aggregate([
      { $match: { examId: exam._id, status: { $in: ['submitted', 'timeout'] } } },
      { $sort: { score: -1 } },
      { $limit: 10 },
      { $lookup: { from: 'users', localField: 'studentId', foreignField: '_id', as: 'student' } },
      { $unwind: { path: '$student', preserveNullAndEmptyArrays: true } },
      { $project: { score: 1, studentName: '$student.name', studentEmail: '$student.email', createdAt: 1 } }
    ])

    const bucketSize = tm > 0 ? tm / 5 : 1
    const scoreDistribution = await Attempt.aggregate([
      { $match: { examId: exam._id, status: { $in: ['submitted', 'timeout'] } } },
      { $bucket: {
          groupBy: '$score',
          boundaries: [0, bucketSize, bucketSize * 2, bucketSize * 3, bucketSize * 4, tm + 1],
          default: 'other',
          output: { count: { $sum: 1 } }
      } }
    ])

    res.json({
      success: true,
      exam: {
        title: exam.title, totalMarks: exam.totalMarks, duration: exam.duration,
        category: exam.category, subject: exam.subject, type: exam.type, status: exam.status,
        schedule: exam.schedule, questionCount: (exam.questions || []).length
      },
      totalAttempts: s.totalAttempts,
      startedCount,
      completionRate: Math.round(completionRate * 10) / 10,
      avgScore: s.avgScore ? Math.round(s.avgScore * 10) / 10 : 0,
      maxScore: s.maxScore || 0,
      minScore: s.minScore || 0,
      passCount: s.passed,
      passRate: Math.round(passRate * 10) / 10,
      leaderboard,
      scoreDistribution
    })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ════════════════════════════════════════════════════════════════
// 33.11 — QUICK STATUS TOGGLE (Draft ↔ Scheduled/Live)
// ════════════════════════════════════════════════════════════════
router.patch('/:id/publish', verifyToken, isAdmin, async (req, res) => {
  try {
    const exam = await Exam.findById(req.params.id)
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' })
    if (exam.status === 'draft') {
      const now = new Date()
      exam.status = (exam.schedule && exam.schedule.startTime && new Date(exam.schedule.startTime) > now) ? 'scheduled' : 'live'
    } else {
      exam.status = 'draft'
    }
    await exam.save()
    res.json({ success: true, status: exam.status, message: `Exam status: ${exam.status}` })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ════════════════════════════════════════════════════════════════
// 33.20 — PIN TOGGLE
// ════════════════════════════════════════════════════════════════
router.patch('/:id/pin', verifyToken, isAdmin, async (req, res) => {
  try {
    const exam = await Exam.findById(req.params.id)
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' })
    exam.isPinned = !exam.isPinned
    await exam.save()
    res.json({ success: true, isPinned: exam.isPinned })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ════════════════════════════════════════════════════════════════
// 33.9 — QUICK EDIT (core fields, without re-running the whole wizard)
// ════════════════════════════════════════════════════════════════
router.put('/:id/quick-edit', verifyToken, isAdmin, async (req, res) => {
  try {
    const b = req.body
    const exam = await Exam.findById(req.params.id)
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' })

    if (b.title !== undefined) exam.title = b.title
    if (b.category !== undefined) exam.category = b.category
    if (b.subject !== undefined) exam.subject = b.subject
    if (b.type !== undefined) exam.type = b.type
    if (b.totalMarks !== undefined) exam.totalMarks = parseInt(b.totalMarks) || exam.totalMarks
    if (b.batch !== undefined) exam.batch = b.batch
    if (b.seriesName !== undefined) exam.seriesName = b.seriesName
    if (b.watermark !== undefined) exam.watermark = !!b.watermark
    if (b.customInstructions !== undefined) exam.customInstructions = b.customInstructions
    if (b.status !== undefined) exam.status = b.status
    // F60 FIX — Attempt Limit editable from Batch/Series Manager's Exams tab Edit modal. -1 = unlimited.
    if (b.maxAttempts !== undefined) exam.maxAttempts = parseInt(b.maxAttempts) || 1
    // F63 FIX — 'unlimited' is a separate boolean field (exam.unlimitedAttempts),
    // NOT a -1 sentinel in maxAttempts. examFlow.js's attempt-start check reads
    // exam.unlimitedAttempts directly; writing -1 into maxAttempts made attemptsLeft
    // compute as 0 (Math.max(0, -1 - 0)) and blocked the very first attempt.
    if (b.unlimitedAttempts !== undefined) exam.unlimitedAttempts = !!b.unlimitedAttempts

    if (b.correctMarks !== undefined || b.incorrectMarks !== undefined) {
      exam.markingScheme = exam.markingScheme || {}
      if (b.correctMarks !== undefined) exam.markingScheme.correct = parseFloat(b.correctMarks)
      if (b.incorrectMarks !== undefined) exam.markingScheme.incorrect = parseFloat(b.incorrectMarks)
      exam.markModified('markingScheme')
    }
    // F62 FIX — Duration replaces manual End Date/Time entry; end time is now
    // always auto-derived from startTime + duration instead of being editable
    // separately (previously admins had to enter a matching end time by hand).
    if (b.duration !== undefined) exam.duration = parseInt(b.duration) || exam.duration
    if (b.startTime !== undefined || b.duration !== undefined || b.endTime !== undefined) {
      exam.schedule = exam.schedule || {}
      if (b.startTime !== undefined) exam.schedule.startTime = b.startTime ? new Date(b.startTime) : null
      if (b.duration !== undefined) {
        const st = exam.schedule.startTime
        const durMin = parseInt(b.duration) || exam.duration || 0
        exam.schedule.endTime = st ? new Date(st.getTime() + durMin * 60000) : null
      } else if (b.endTime !== undefined) {
        // legacy path — still supported for any other caller that sends endTime directly
        exam.schedule.endTime = b.endTime ? new Date(b.endTime) : null
      }
      exam.markModified('schedule')
    }

    await exam.save()
    res.json({ success: true, message: 'Exam updated ✅', exam })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ════════════════════════════════════════════════════════════════
// 33.27 — BULK ACTIONS
// ════════════════════════════════════════════════════════════════
router.post('/bulk-delete', verifyToken, isAdmin, async (req, res) => {
  try {
    const { ids } = req.body
    if (!Array.isArray(ids) || !ids.length) return res.status(400).json({ success: false, message: 'ids array is required' })
    const filter = { _id: { $in: ids } }
    if (req.user.role !== 'superadmin') filter.createdBy = req.user.id
    const candidates = await Exam.find(filter).select('title status')

    const Attempt = require('../models/Attempt')
    const Result = require('../models/Result')
    const eligible = [] // 34.6 / 34.12 — bulk permanent delete only ever touches draft exams with zero attempts
    const skipped = []
    for (const c of candidates) {
      if (c.status !== 'draft') { skipped.push(c.title); continue }
      const n = await Attempt.countDocuments({ examId: c._id })
      if (n > 0) { skipped.push(c.title) } else { eligible.push(c._id) }
    }

    if (eligible.length) {
      await Promise.all([ // 34.13 — cascade (defensive; should already be 0 for these)
        Attempt.deleteMany({ examId: { $in: eligible } }),
        Result.deleteMany({ examId: { $in: eligible } })
      ])
      await Exam.deleteMany({ _id: { $in: eligible } })
      try {
        const AuditLog = require('../models/AuditLog')
        await AuditLog.create({ action: 'EXAM_DELETE', performedBy: req.user.id, details: `Bulk permanent-deleted ${eligible.length} draft exam(s)` })
      } catch {}
    }

    res.json({
      success: true,
      message: skipped.length
        ? `${eligible.length} draft exam(s) deleted. ${skipped.length} skipped (not draft, or have attempts) — archive those instead.`
        : `${eligible.length} exam(s) deleted`,
      deletedCount: eligible.length,
      skipped
    })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

router.post('/bulk-publish', verifyToken, isAdmin, async (req, res) => {
  try {
    const { ids } = req.body
    if (!Array.isArray(ids) || !ids.length) return res.status(400).json({ success: false, message: 'ids array is required' })
    const filter = { _id: { $in: ids }, status: 'draft' }
    if (req.user.role !== 'superadmin') filter.createdBy = req.user.id
    const list = await Exam.find(filter)
    const now = new Date()
    let updated = 0
    for (const exam of list) {
      exam.status = (exam.schedule && exam.schedule.startTime && new Date(exam.schedule.startTime) > now) ? 'scheduled' : 'live'
      await exam.save()
      updated++
    }
    res.json({ success: true, message: `${updated} exam(s) published`, updated })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ════════════════════════════════════════════════════════════════
// 33.17 — EXPORT (CSV / XLSX) — same filters as /list
// ════════════════════════════════════════════════════════════════
router.get('/export', verifyToken, isAdmin, async (req, res) => {
  try {
    const filter = buildFilter(req)
    const exams = await Exam.find(filter)
      .select('title category subject type duration totalMarks status batch seriesName schedule createdAt isPinned questions')
      .lean()

    const rows = exams.map(e => ({
      Title: e.title,
      Category: e.category,
      Subject: e.subject,
      Type: e.type,
      'Duration (min)': e.duration,
      'Total Marks': e.totalMarks,
      Status: e.status,
      Batch: e.batch,
      Series: e.seriesName,
      'Start Time': e.schedule && e.schedule.startTime ? new Date(e.schedule.startTime).toLocaleString() : '',
      'End Time': e.schedule && e.schedule.endTime ? new Date(e.schedule.endTime).toLocaleString() : '',
      Questions: (e.questions || []).length,
      'Created At': e.createdAt ? new Date(e.createdAt).toLocaleString() : '',
      Pinned: e.isPinned ? 'Yes' : 'No'
    }))

    const format = (req.query.format || 'xlsx').toLowerCase()

    if (format === 'csv') {
      const headers = Object.keys(rows[0] || { Title: '' })
      const esc = v => `"${String(v == null ? '' : v).replace(/"/g, '""')}"`
      const csv = [headers.join(','), ...rows.map(r => headers.map(h => esc(r[h])).join(','))].join('\n')
      res.setHeader('Content-Type', 'text/csv')
      res.setHeader('Content-Disposition', 'attachment; filename="ProveRank_Exams.csv"')
      return res.send(csv)
    }

    const XLSX = require('xlsx')
    const ws = XLSX.utils.json_to_sheet(rows)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, 'Exams')
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' })
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    res.setHeader('Content-Disposition', 'attachment; filename="ProveRank_Exams.xlsx"')
    res.send(buf)
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ════════════════════════════════════════════════════════════════════════
// FEATURE 31 — EXAM CLONE / DUPLICATE
// ════════════════════════════════════════════════════════════════════════

// ── 31.1-31.6 / 31.8 — rich clone with dialog inputs (new title/date/batch) ──
router.post('/:id/clone-advanced', verifyToken, isAdmin, async (req, res) => {
  try {
    const original = await Exam.findById(req.params.id)
    if (!original) return res.status(404).json({ success: false, message: 'Exam not found' })

    const obj = original.toObject() // 31.3/31.4 — copies every setting + the same questions array
    delete obj._id; delete obj.createdAt; delete obj.updatedAt; delete obj.__v

    const b = req.body || {}
    obj.title = (b.newTitle && b.newTitle.trim()) ? b.newTitle.trim() : `Copy of ${original.title}` // 31.2
    obj.status = 'draft' // 31.6
    obj.isPinned = false
    obj.isArchived = false
    obj.archivedAt = null
    obj.archivedBy = null
    obj.clonedFrom = original._id // 31.9

    // F62 FIX — Duration replaces manual End Date/Time entry; end time is now
    // always auto-derived from startTime + duration instead of a separately
    // entered end date/time.
    const cloneStart = b.startTime ? new Date(b.startTime) : null
    if (b.duration !== undefined) obj.duration = parseInt(b.duration) || obj.duration
    obj.schedule = {
      startTime: cloneStart,
      endTime: cloneStart ? new Date(cloneStart.getTime() + (parseInt(b.duration) || obj.duration || 0) * 60000) : (b.endTime ? new Date(b.endTime) : null)
    }
    // F60/F61 FIX — Attempt Limit copyable from the Batch/Series Manager Copy modal. -1 = unlimited.
    if (b.maxAttempts !== undefined) obj.maxAttempts = parseInt(b.maxAttempts) || 1
    // F63 FIX — 'unlimited' is a separate boolean field, not a -1 sentinel (see quick-edit route)
    if (b.unlimitedAttempts !== undefined) obj.unlimitedAttempts = !!b.unlimitedAttempts

    // 31.8 — clone to a different batch if provided, else keep original's batch
    if (b.targetBatch !== undefined) {
      obj.batch = b.targetBatch
      obj.multiBatch = []
      if (b.targetBatch) obj.assignmentType = 'batch'
    }
    // F61 FIX — clone to a different test series (previously only wrote a stray
    // 'seriesName' string, not the real testSeriesId, so the copy never actually
    // linked to the series the same way normal assign does).
    if (b.targetSeries !== undefined) {
      obj.testSeriesId = b.targetSeries || null
      if (b.targetSeries) obj.assignmentType = 'series'
    }
    if (b.seriesName !== undefined) obj.seriesName = b.seriesName

    obj.createdBy = req.user.id
    obj.updatedBy = req.user.id

    const cloned = await Exam.create(obj)

    // F61 FIX — reverse-link the clone into Batch.exams / TestSeries.tests so it
    // immediately shows up in the Assigned list, mirroring the normal assign flow.
    try {
      if (b.targetBatch) {
        const Batch = require('../models/Batch')
        await Batch.updateOne({ _id: b.targetBatch }, { $addToSet: { exams: cloned._id } })
      }
      if (b.targetSeries) {
        const TestSeries = require('../models/TestSeries')
        await TestSeries.updateOne({ _id: b.targetSeries }, { $addToSet: { tests: cloned._id } })
      }
    } catch (linkErr) { console.error('clone-advanced reverse-link warning:', linkErr.message) }

    try {
      const AuditLog = require('../models/AuditLog')
      await AuditLog.create({ action: 'EXAM_CLONE', performedBy: req.user.id, details: `Cloned exam "${original.title}" → "${cloned.title}" (${cloned._id})` })
    } catch {}

    res.status(201).json({ success: true, message: 'Exam cloned ✅', exam: cloned })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})


// ── 31.9 / 31.10 / 31.15 — clone history: this exam's parent + its children ──
router.get('/:id/clone-info', verifyToken, isAdmin, async (req, res) => {
  try {
    const exam = await Exam.findById(req.params.id).select('title clonedFrom').populate('clonedFrom', 'title status createdAt')
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' })
    const children = await Exam.find({ clonedFrom: exam._id }).select('title status createdAt schedule').sort({ createdAt: -1 }).lean()
    res.json({ success: true, parent: exam.clonedFrom || null, children })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ── 31.11 — compare original vs clone (frontend renders the side-by-side diff) ─
router.get('/compare', verifyToken, isAdmin, async (req, res) => {
  try {
    const { a, b } = req.query
    if (!a || !b) return res.status(400).json({ success: false, message: 'Both exam id a and id b are required' })
    const [examA, examB] = await Promise.all([
      Exam.findById(a).select('-questions').lean(),
      Exam.findById(b).select('-questions').lean()
    ])
    if (!examA || !examB) return res.status(404).json({ success: false, message: 'One or both exams were not found' })
    res.json({ success: true, examA, examB })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ════════════════════════════════════════════════════════════════════════
// FEATURE 34 — EXAM DELETE (with safety checks, archive, recycle bin)
// ════════════════════════════════════════════════════════════════════════

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000

// ── 34.3 / 34.11 / 34.13 — stats + cascade impact preview before delete ──────
router.get('/:id/delete-impact', verifyToken, isAdmin, async (req, res) => {
  try {
    const exam = await Exam.findById(req.params.id).select('title status createdBy questions')
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' })
    const Attempt = require('../models/Attempt')
    const Result = require('../models/Result')
    const [attemptCount, resultCount, distinctStudents] = await Promise.all([
      Attempt.countDocuments({ examId: exam._id }),
      Result.countDocuments({ examId: exam._id }),
      Attempt.distinct('studentId', { examId: exam._id })
    ])
    const isDraft = exam.status === 'draft'
    res.json({
      success: true,
      exam: { title: exam.title, status: exam.status, questionCount: (exam.questions || []).length },
      attemptCount, resultCount,
      studentsAttempted: distinctStudents.length,
      isLive: exam.status === 'live',
      canPermanentDeleteFreely: isDraft && attemptCount === 0, // 34.6
      requiresTypeToConfirm: !isDraft || attemptCount > 0,      // 34.17
      requiresReason: exam.status === 'ended'                   // 34.14
    })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ── 34.5 / 34.9 / 34.21 — ARCHIVE (soft delete → Recycle Bin) ────────────────
router.patch('/:id/archive', verifyToken, isAdmin, async (req, res) => {
  try {
    const exam = await Exam.findById(req.params.id)
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' })
    if (exam.status === 'live') return res.status(403).json({ success: false, message: '⚠️ Cannot archive a live exam — end/unpublish it first.' }) // 34.4
    if (req.user.role !== 'superadmin' && exam.status !== 'draft') return res.status(403).json({ success: false, message: 'Only a Superadmin can archive a non-draft exam.' }) // 34.15

    exam.isArchived = true
    exam.archivedAt = new Date()
    exam.archivedBy = req.user.id
    await exam.save()

    try {
      const AuditLog = require('../models/AuditLog')
      await AuditLog.create({ action: 'EXAM_ARCHIVE', performedBy: req.user.id, details: `Archived exam "${exam.title}" (${exam._id})` })
    } catch {}

    res.json({ success: true, message: 'Exam archived — it will stay in the Recycle Bin for 30 days' })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ── restore from Recycle Bin ──────────────────────────────────────────────────
router.patch('/:id/restore', verifyToken, isAdmin, async (req, res) => {
  try {
    const exam = await Exam.findById(req.params.id)
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' })
    exam.isArchived = false
    exam.archivedAt = null
    exam.archivedBy = null
    await exam.save()

    try {
      const AuditLog = require('../models/AuditLog')
      await AuditLog.create({ action: 'EXAM_RESTORE', performedBy: req.user.id, details: `Restored exam "${exam.title}" (${exam._id}) from Recycle Bin` })
    } catch {}

    res.json({ success: true, message: 'Exam restored ✅' })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ── 34.10 / 34.24 — Recycle Bin list (lazy 30-day auto-purge on each visit) ──
router.get('/trash', verifyToken, isAdmin, async (req, res) => {
  try {
    const cutoff = new Date(Date.now() - THIRTY_DAYS_MS)
    const expired = await Exam.find({ isArchived: true, archivedAt: { $lte: cutoff } }).select('_id title')
    if (expired.length) {
      const expiredIds = expired.map(e => e._id)
      const Attempt = require('../models/Attempt')
      const Result = require('../models/Result')
      await Promise.all([
        Attempt.deleteMany({ examId: { $in: expiredIds } }),
        Result.deleteMany({ examId: { $in: expiredIds } }),
        Exam.deleteMany({ _id: { $in: expiredIds } })
      ])
      try {
        const AuditLog = require('../models/AuditLog')
        await AuditLog.create({ action: 'EXAM_DELETE', performedBy: req.user.id, details: `Auto-purged ${expired.length} exam(s) from Recycle Bin after 30 days: ${expired.map(e => e.title).join(', ')}` })
      } catch {}
    }

    const filter = { isArchived: true }
    if (req.user.role !== 'superadmin') filter.createdBy = req.user.id
    const trash = await Exam.find(filter).select('title category status duration totalMarks archivedAt createdAt').sort({ archivedAt: -1 }).lean()
    res.json({ success: true, exams: trash })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ── 34.6 / 34.7 / 34.13 / 34.14 / 34.15 / 34.17 — PERMANENT DELETE ───────────
router.delete('/:id/permanent', verifyToken, isAdmin, async (req, res) => {
  try {
    const exam = await Exam.findById(req.params.id)
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found' })

    if (exam.status === 'live') return res.status(403).json({ success: false, message: '⚠️ Cannot delete a live exam — end/unpublish it first.' }) // 34.4

    if (req.user.role !== 'superadmin' && exam.status !== 'draft') {
      return res.status(403).json({ success: false, message: 'Only a Superadmin can permanently delete a non-draft exam.' }) // 34.15
    }

    const Attempt = require('../models/Attempt')
    const Result = require('../models/Result')
    const attemptCount = await Attempt.countDocuments({ examId: exam._id })
    const notDraft = exam.status !== 'draft'

    if ((notDraft || attemptCount > 0) && req.body.confirmTitle !== exam.title) { // 34.17
      return res.status(400).json({ success: false, message: 'Type the exact exam title to confirm.', requiresTypeToConfirm: true })
    }
    if (exam.status === 'ended' && !(req.body.reason && req.body.reason.trim())) { // 34.14
      return res.status(400).json({ success: false, message: 'A reason is required to delete a completed exam.', requiresReason: true })
    }

    const resultCount = await Result.countDocuments({ examId: exam._id })
    await Promise.all([ // 34.13 — cascade delete
      Attempt.deleteMany({ examId: exam._id }),
      Result.deleteMany({ examId: exam._id })
    ])
    await Exam.findByIdAndDelete(exam._id)

    try {
      const AuditLog = require('../models/AuditLog')
      await AuditLog.create({
        action: 'EXAM_DELETE', performedBy: req.user.id,
        details: `Permanently deleted exam "${exam.title}" (${exam._id}). Cascade-removed ${attemptCount} attempt(s), ${resultCount} result(s).${req.body.reason ? ' Reason: ' + req.body.reason : ''}`
      })
    } catch {}

    res.json({ success: true, message: 'Exam permanently deleted', deletedAttempts: attemptCount, deletedResults: resultCount })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

// ── 34.12 — BULK ARCHIVE (safe alternative to bulk permanent delete) ────────
router.post('/bulk-archive', verifyToken, isAdmin, async (req, res) => {
  try {
    const { ids } = req.body
    if (!Array.isArray(ids) || !ids.length) return res.status(400).json({ success: false, message: 'ids array is required' })
    const filter = { _id: { $in: ids }, status: { $ne: 'live' } }
    if (req.user.role !== 'superadmin') filter.createdBy = req.user.id
    const result = await Exam.updateMany(filter, { isArchived: true, archivedAt: new Date(), archivedBy: req.user.id })

    try {
      const AuditLog = require('../models/AuditLog')
      await AuditLog.create({ action: 'EXAM_ARCHIVE', performedBy: req.user.id, details: `Bulk-archived ${result.modifiedCount} exam(s)` })
    } catch {}

    res.json({ success: true, message: `${result.modifiedCount} exam(s) archived`, archived: result.modifiedCount })
  } catch (err) { res.status(500).json({ success: false, message: err.message }) }
})

module.exports = router
