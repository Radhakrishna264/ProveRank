const mongoose = require('mongoose');

const BannerSchema = new mongoose.Schema({
  // ── Legacy fields (preserved for backward compatibility) ──
  batchId: { type: String, default: '' },
  batchName: { type: String, default: '' },
  title: { type: String, required: true },
  tagline: { type: String, default: '' },
  examType: { type: String, default: 'NEET' },
  price: { type: String, default: '' },
  totalTests: { type: String, default: '' },
  duration: { type: String, default: '' },
  validity: { type: String, default: '' },
  highlights: [{ type: String }],
  ctaText: { type: String, default: 'Enroll Now' },
  ctaShape: { type: String, enum: ['pill', 'rounded', 'square', 'outline'], default: 'pill' },
  textAlign: { type: String, enum: ['left', 'center', 'right'], default: 'left' },
  sectionVisibility: { type: mongoose.Schema.Types.Mixed, default: () => ({ icon: true, badge: true, title: true, tagline: true, highlights: true, price: true, cta: true }) },
  sectionLock: { type: mongoose.Schema.Types.Mixed, default: () => ({}) },
  badgeStyle: { type: String, enum: ['pill', 'ribbon', 'corner'], default: 'pill' },
  cardStyle: { type: String, enum: ['sharp', 'rounded', 'soft', 'elevated'], default: 'rounded' },
  gradientAngle: { type: Number, default: 135 },
  spacing: { type: String, enum: ['compact', 'normal', 'spacious'], default: 'normal' },
  badge: { type: String, default: 'none' },
  template: { type: String, default: 'classic' },
  primaryColor: { type: String, default: '#4D9FFF' },
  secondaryColor: { type: String, default: '#00D4FF' },
  textColor: { type: String, default: '#FFFFFF' },
  accentColor: { type: String, default: '#FFD700' },
  fontStyle: { type: String, default: 'modern' },
  bgImage: { type: String, default: '' },
  published: { type: Boolean, default: false },
  scheduledAt: { type: Date },
  versions: [{
    data: { type: mongoose.Schema.Types.Mixed },
    savedAt: { type: Date, default: Date.now },
    label: { type: String, default: '' }
  }],
  analytics: {
    views: { type: Number, default: 0 },
    clicks: { type: Number, default: 0 },
    enrolls: { type: Number, default: 0 }
  },
  createdBy: { type: String, default: '' },

  // ── FPR3 Ultra SaaS Publish-Gate fields ──
  linkedBatchId: { type: mongoose.Schema.Types.ObjectId, default: null },
  linkedType: { type: String, default: 'none', enum: ['batch', 'series', 'none'] },
  status: { type: String, default: 'draft', enum: ['draft', 'ready', 'scheduled', 'published', 'archived', 'removed', 'replaced'] },
  syncState: { type: String, default: 'synced', enum: ['synced', 'pending_sync', 'conflict', 'manual_override', 'ready_to_publish'] },
  qualityScore: { type: Number, default: 0 },
  tags: [{ type: String }],
  autoPublish: { type: Boolean, default: false },
  timezone: { type: String, default: 'Asia/Kolkata' },
  replacedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Banner', default: null },
  replacedFrom: { type: mongoose.Schema.Types.ObjectId, ref: 'Banner', default: null },
  removedAt: { type: Date, default: null },
  approvedAt: { type: Date, default: null },
  approvedBy: { type: String, default: '' },
  fieldLocks: [{ type: String }],

  // ── FPR4: layered assets (stickers/decorative/subject graphics/
  // icons/illustrations placed on the banner) — plain data, edited
  // client-side, persisted via the normal banner save. ──
  layers: [{
    id: { type: String, required: true },
    type: { type: String, enum: ['sticker', 'decorative', 'subject_graphic', 'icon', 'illustration', 'logo', 'watermark'], required: true },
    content: { type: String, default: '' },
    assetId: { type: mongoose.Schema.Types.ObjectId, ref: 'SavedAsset', default: null },
    x: { type: Number, default: 50 },
    y: { type: Number, default: 50 },
    scale: { type: Number, default: 1 },
    rotation: { type: Number, default: 0 },
    opacity: { type: Number, default: 1 },
    zIndex: { type: Number, default: 1 },
    locked: { type: Boolean, default: false },
    flipH: { type: Boolean, default: false },
    flipV: { type: Boolean, default: false },
    shadow: { type: Boolean, default: false },
    shadowColor: { type: String, default: '#000000' },
    border: { type: Boolean, default: false },
    borderColor: { type: String, default: '#FFFFFF' },
    borderWidth: { type: Number, default: 2 },
    blendMode: { type: String, default: 'normal' },
    cropTop: { type: Number, default: 0 },
    cropRight: { type: Number, default: 0 },
    cropBottom: { type: Number, default: 0 },
    cropLeft: { type: Number, default: 0 }
  }],
  textStyleOverride: { type: mongoose.Schema.Types.Mixed, default: null },
}, { timestamps: true });

module.exports = mongoose.models.Banner || mongoose.model('Banner', BannerSchema);
