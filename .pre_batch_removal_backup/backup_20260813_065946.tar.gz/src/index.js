require('dotenv').config();
const express    = require('express');

// ===== STAGE 8: Security Middleware =====
const applySecurityMiddleware = require('./middleware/security').applySecurityMiddleware;
const { apiLimiter, uploadLimiter } = require('./middleware/rateLimiter');
const { checkJWTExpiry } = require('./middleware/loginProtection');
// ========================================
const http       = require('http');
const cors       = require('cors');
const helmet     = require('helmet');
const mongoose   = require('mongoose');
const { initSocket } = require('./config/socket');

// ── Route Imports ─────────────────────────────────────────────
const authRoutes             = require('./routes/auth');
const adminRoutes            = require('./routes/admin');
const examPatchRoutes = require('./routes/exam_patch');
const examRoutes             = require('./routes/exam');
const examExtraRoutes        = require('./routes/examExtra');
const questionRoutes         = require('./routes/question');
const uploadRoutes           = require('./routes/upload');
const excelUploadRoutes      = require('./routes/excelUpload');
const paperGeneratorRoutes   = require('./routes/paperGenerator');
const pdfRoutes              = require('./routes/pdfRoutes');

// ── New Feature Routes (load BEFORE conflicting base routes) ──
const examFeaturesRoutes     = require('./routes/examFeatures');
const examPaperRoutes = require('./routes/examPaper');
const pyqBankAdminRoutes = require('./routes/pyqBankAdmin');
const adminSystemRoutes      = require('./routes/adminSystem');
const adminMonitoringRoutes = require('./routes/adminMonitoringRoutes');
require('./models/AdminNotification');
require('./models/Challenge');
require('./models/ReEvaluation');
require('./models/Grievance');
require('./models/QuestionVersion');
require('./models/QuestionError');
require('./models/ExamTemplate');      // Feature 29 — Exam Templates
require('./models/TemplateCategory');  // Feature 29.10 — custom categories
require('./models/Doubt');
const questionStatsRoutes = require('./routes/questionStatsRoutes');
const examWizardRoutes = require('./routes/examWizardRoutes');
const questionDeleteRoutes = require('./routes/questionDeleteRoutes');
const adminQuestionMgmtRoutes = require('./routes/adminQuestionMgmtRoutes');
const adminResultRoutes = require('./routes/adminResultRoutes');
const adminManagementRoutes  = require('./routes/adminManagement');
const studentProfilePreviewRoutes = require('./routes/studentProfilePreview'); // F38B
const questionFeaturesRoutes = require('./routes/questionFeatures');
const materialRoutes = require('./routes/materialRoutes');
const twoFactorRoutes        = require('./routes/twoFactor');

// ── Optional Routes (load if file exists) ────────────────────
let questionAIRoutes, questionAdvancedRoutes, questionExtraRoutes;
let examSubmissionRoutes, permissionTestRoutes;
try { questionAIRoutes       = require('./routes/questionAI'); } catch(e) {}
try { questionAdvancedRoutes = require('./routes/questionAdvanced'); } catch(e) {}
try { questionExtraRoutes    = require('./routes/questionExtra'); } catch(e) {}
try { examSubmissionRoutes   = require('./routes/examSubmission'); } catch(e) {}
try { permissionTestRoutes   = require('./routes/permissionTest'); } catch(e) {}

// ── App Setup ─────────────────────────────────────────────────
const app    = express();
const server = http.createServer(app);
initSocket(server);

app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({
  origin: [
    'https://prove-rank.vercel.app',
    'http://localhost:3000',
    'http://localhost:3001'
  ],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// ===== STAGE 8: Apply Security =====
applySecurityMiddleware(app);
app.use('/api', apiLimiter);
app.use('/api/excel', uploadLimiter);
app.use('/api/upload', uploadLimiter);
app.use('/api', checkJWTExpiry);
// ====================================
app.use(express.json({limit:'1mb'}));

// ── MongoDB ───────────────────────────────────────────────────
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB Connected:', mongoose.connection.host))
  .catch(err => console.log('MongoDB Error:', err));

// ── Health Check ──────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date() });
});

// ── Auth Routes ───────────────────────────────────────────────
app.use('/api/auth', authRoutes);
app.use('/api/auth', twoFactorRoutes);

// ── Admin Routes ──────────────────────────────────────────────
app.use('/api', questionDeleteRoutes)
app.use('/api', examWizardRoutes);
app.use('/api/exam-templates', require('./routes/examTemplates')); // Feature 29 — Exam Templates

app.use('/api', questionStatsRoutes);
;
app.use('/api/admin/manage', adminManagementRoutes);  // S37/S72/S38/S93/M4
app.use('/api/admin/student-preview', studentProfilePreviewRoutes); // F38B — Superadmin-only 360° preview
app.use('/api/admin', adminSystemRoutes);
app.use('/api/admin', adminMonitoringRoutes);  // Phase 6.2
app.use('/api/admin', adminResultRoutes);       // Phase 6.3
app.use('/api/admin', adminQuestionMgmtRoutes); // Phase 6.4              // S66/N21
app.use('/api/admin', adminRoutes);

// ── Question Routes ───────────────────────────────────────────
app.use('/api/materials', materialRoutes);
app.use('/api/questions', questionFeaturesRoutes);     // AI-1/AI-2/S33/S35/MCQ/MSQ
app.use('/api/questions', questionRoutes);
if (questionAIRoutes)       app.use('/api/questions-advanced', questionAIRoutes);
if (questionAdvancedRoutes) app.use('/api/questions-advanced', questionAdvancedRoutes);
if (questionExtraRoutes)    app.use('/api/questions', questionExtraRoutes);

// ── Exam Routes ───────────────────────────────────────────────
app.use('/api/exams', examFeaturesRoutes);
const examFlowRoutes = require('./routes/examFlow');
app.use('/api/exams', examFlowRoutes);
app.use('/api/exams', examRoutes);
app.use('/api/exams-manage', require('./routes/examListing')); // Feature 33 — All Exams List/Filter/Search
app.use('/api/exams', examPatchRoutes);
             // S5/S75/S85/S26/S62/S31/S96
app.use('/api/exam-paper', examPaperRoutes);
app.use('/api/exams', examExtraRoutes);
if (examSubmissionRoutes) app.use('/api/exams', examSubmissionRoutes);

// ── Other Routes ─────────────────────────────────────────────
app.use('/api/upload', uploadRoutes);
app.use('/api/excel', excelUploadRoutes);
app.use('/api/paper', paperGeneratorRoutes);
app.use('/api/pdf', pdfRoutes);
app.use('/api/exam-instances', require('./routes/examInstance'));
const attemptRoutes = require('./routes/attemptRoutes');
app.use('/api/attempts', attemptRoutes);
if (permissionTestRoutes) app.use('/api/permission', permissionTestRoutes);

// ── Start Server ──────────────────────────────────────────────
const PORT = process.env.PORT || 3000;

const adminBatchControlRoutes  = require('./routes/adminBatchControls');
const studentBatchExtrasRoutes = require('./routes/studentBatchExtras');
const { studentAnnouncementRoutes, adminAnnouncementRoutes } = require('./routes/announcements'); // F42A/F42B
app.use('/api/admin/batch-controls',  adminBatchControlRoutes);
const batchManagerUltraRoutes = require('./routes/batchManagerUltra');
app.use('/api/admin/batch-manager', batchManagerUltraRoutes);
app.use('/api/student/batch-extras',  studentBatchExtrasRoutes);
app.use('/api/announcements', studentAnnouncementRoutes);          // F42B — student-facing
app.use('/api/admin/announcements', adminAnnouncementRoutes);      // F42A — admin-facing

const studentNotificationRoutes = require('./routes/studentNotificationRoutes');
const adminNotificationRoutes = require('./routes/adminNotificationRoutes');
app.use('/api/student/notifications', studentNotificationRoutes);
app.use('/api/admin/notifications', adminNotificationRoutes);

const batchActivityRoutes = require('./routes/batchActivityRoutes');
app.use('/api/batch-activity', batchActivityRoutes);
server.listen(PORT, '0.0.0.0', () => {
  console.log(`ProveRank server running at http://0.0.0.0:${PORT}`);
});

// -- Result Routes (Phase 4.3)
const sessionRoutes = require('./routes/sessionRoutes');
const faceRoutes = require('./routes/faceRoutes');
const audioRoutes = require('./routes/audioRoutes');
const webcamRoutes = require('./routes/webcamRoutes');
const antiCheatRoutes = require('./routes/antiCheatRoutes');
const resultRoutes = require('./routes/resultRoutes');
app.use('/api/session', sessionRoutes);
app.use('/api/face', faceRoutes);
app.use('/api/audio', audioRoutes);
app.use('/api/webcam', webcamRoutes);
app.use('/api/anticheat', antiCheatRoutes);
app.use('/api/results', resultRoutes);
app.use('/api/admin', require('./routes/adminDashboardRoutes'));
const studentBatchRoutes=require('./routes/studentBatches');
const studentBatchWorkspaceRoutes = require('./routes/studentBatchWorkspace');
const { adminEntryProctoringRoutes, studentEntryProctoringRoutes } = require('./routes/entryProctoringControl');
const myBatchesRoutes=require('./routes/myBatches');
const adminStoreRoutes   = require('./routes/adminStore');
const studentStoreRoutes = require('./routes/studentStore');
const paymentRoutes = require('./routes/payment');
const brandingRoutes = require('./routes/brandingRoutes')
app.use('/api/admin', brandingRoutes)
app.use('/api/my-batches',myBatchesRoutes);
app.use('/api/student/batches',studentBatchRoutes);
app.use('/api/student/batch-workspace', studentBatchWorkspaceRoutes);
app.use('/api/admin/entry-proctoring', adminEntryProctoringRoutes);
app.use('/api/entry-proctoring', studentEntryProctoringRoutes);
app.use('/api/admin/email', require('./routes/emailSend'))
app.use('/api/admin/store',  adminStoreRoutes);
const testSeriesManagerUltraRoutes = require('./routes/testSeriesManagerUltra');
app.use('/api/admin/test-series-manager', testSeriesManagerUltraRoutes);
const bannerAssetsRoutes = require('./routes/bannerAssets');
app.use('/api/admin/banner-assets', bannerAssetsRoutes);
app.use('/api/store/payment', paymentRoutes);
app.use('/api/store',        studentStoreRoutes);

// -- Content Forge Routes (Features 19B / 20 / 20B / 21 / 21B)
const contentForgeRoutes = require('./routes/contentForge');
app.use('/api/content-forge', contentForgeRoutes)
app.use('/api/pyq-bank', pyqBankAdminRoutes);
;

const studentBatchUltraRoutes = require('./routes/studentBatchUltra');
app.use('/api/student/batch-ultra', studentBatchUltraRoutes);
